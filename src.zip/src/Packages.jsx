import React, { useState } from "react";
import { Shield, FileText, Award, TrendingUp, Phone } from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";

export default function PricingPage() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    mobile: "",
    city: "",
    query: "",
  });

  const handleSubmit = () => {
    console.log("Form submitted:", formData);
    alert("Callback request submitted!");
  };

  const handleChange = (field, value) => {
    setFormData({
      ...formData,
      [field]: value,
    });
  };

  return (
    <>
      <Header />
      <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white py-12 px-4">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-8">
            <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
              Choose the plan that's just right for you and your business
            </h1>

            {/* Benefits */}
            <div className="flex flex-wrap justify-center gap-6 mb-8">
              <div className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                <span className="text-sm md:text-base text-gray-700">
                  Get instant Visibility
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                <span className="text-sm md:text-base text-gray-700">
                  Close more Deals
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                <span className="text-sm md:text-base text-gray-700">
                  Maximize your Leads
                </span>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-green-600">✓</span>
                <span className="text-sm md:text-base text-gray-700">
                  Grow your Business
                </span>
              </div>
            </div>
          </div>

          {/* Disclaimer */}
          <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-8">
            <p className="text-sm text-gray-700">
              <strong>Disclaimer:</strong> These packs are designed for Real
              Estate Agents, please choose the pack and city carefully as the
              transaction is{" "}
              <span className="text-red-600 font-semibold">non refundable</span>
            </p>
          </div>

          {/* Features Grid */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm">
              <FileText className="w-8 h-8 text-blue-600 mb-2" />
              <p className="text-sm text-center text-gray-700">
                GSTIN: 03AACM9228S1WR
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm">
              <Shield className="w-8 h-8 text-green-600 mb-2" />
              <p className="text-sm text-center text-gray-700">
                100% Secure Payment Gateway
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm">
              <Award className="w-8 h-8 text-purple-600 mb-2" />
              <p className="text-sm text-center text-gray-700">
                100% Service Guarantee
              </p>
            </div>
            <div className="flex flex-col items-center p-4 bg-white rounded-lg shadow-sm">
              <TrendingUp className="w-8 h-8 text-orange-600 mb-2" />
              <p className="text-sm text-center text-gray-700">
                50+ Orders Booked Daily
              </p>
            </div>
          </div>

          {/* Callback Section */}
          <div className="grid md:grid-cols-5 gap-6">
            {/* Talk to Experts Card */}
            <div className="md:col-span-1">
              <div className="bg-green-50 border-2 border-green-500 rounded-lg p-4 flex flex-col items-center justify-center">
                <div className="bg-white rounded-full p-2 mb-3">
                  <Phone className="w-5 h-5 text-green-600" />
                </div>
                <h3 className="font-semibold text-base mb-1">
                  Talk to Experts
                </h3>
                <p className="text-gray-700 text-sm">0120-3435525</p>
              </div>
            </div>

            {/* Request Callback Form */}
            <div className="md:col-span-4">
              <div className="bg-white rounded-lg shadow-md p-5">
                <h3 className="text-lg font-semibold mb-4">
                  Request a Callback
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-[1fr_1fr_1.5fr] gap-3">
                  {/* First Row */}
                  <input
                    type="text"
                    placeholder="Name"
                    value={formData.name}
                    onChange={(e) => handleChange("name", e.target.value)}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                  <input
                    type="email"
                    placeholder="Email"
                    value={formData.email}
                    onChange={(e) => handleChange("email", e.target.value)}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                  <textarea
                    placeholder="Please specify the convenient time to get a callback."
                    value={formData.query}
                    onChange={(e) => handleChange("query", e.target.value)}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none outline-none row-span-2"
                    rows={3}
                  />

                  {/* Second Row */}
                  <PhoneInput
                    international
                    defaultCountry="IN"
                    value={formData.mobile}
                    onChange={(value) => handleChange("mobile", value)}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                  <input
                    type="text"
                    placeholder="City"
                    value={formData.city}
                    onChange={(e) => handleChange("city", e.target.value)}
                    className="px-3 py-2 text-sm border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent outline-none"
                  />
                </div>

                {/* Submit Button */}
                <div className="mt-3 flex justify-end">
                  <button
                    onClick={handleSubmit}
                    className="bg-[#0b154f] text-white font-semibold py-2 px-6 rounded-md transition duration-200 cursor-pointer text-sm"
                  >
                    Get a Callback
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
