// import React from "react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import { Link } from "react-router-dom";
// import { Calendar, User, ArrowLeft } from "lucide-react";
// import { useState, useRef, useEffect } from "react";
// import img1 from "./assets/latestnews/img1.png";
// import img2 from "./assets/latestnews/img2.png";
// import img3 from "./assets/latestnews/img3.png";

// const BlogDetails = () => {
//   const blogData = {
//     id: 1,
//     image:
//       "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&h=600&fit=crop",
//     headline: "Real Estate Market Shows Strong Growth in Downtown Area",
//     description:
//       "Latest market analysis reveals significant uptick in property values and investment opportunities in the central business district.",
//     category: "Headlines",
//     postedBy: "Sarah Mitchell",
//     date: "October 5, 2025",
//     fullContent: `
//       The downtown real estate market is experiencing unprecedented growth, with property values
//       surging by an impressive 18% over the past year. This remarkable trend is driven by a
//       combination of factors including enhanced infrastructure development, an influx of major
//       corporate headquarters, and a renewed interest in urban living.

//       Recent data from the Metropolitan Real Estate Association shows that commercial properties
//       in the central business district have become particularly attractive to investors. Office
//       spaces are commanding premium rates, with occupancy levels reaching a five-year high of 94%.
//       The demand is being fueled by tech companies and financial institutions seeking prime
//       locations to establish their presence.

//       Residential properties are not far behind in this growth trajectory. Luxury condominiums
//       and upscale apartments in the downtown core are selling at record prices, often receiving
//       multiple offers within days of listing. The average price per square foot has climbed to
//       $850, marking a significant milestone for the market.

//       Infrastructure improvements have played a crucial role in this transformation. The completion
//       of the new metro extension, renovation of public spaces, and the development of mixed-use
//       complexes have made downtown living more accessible and appealing than ever before. These
//       enhancements have created a vibrant ecosystem where residents can live, work, and enjoy
//       leisure activities within walking distance.

//       Looking ahead, industry experts predict that this growth trend will continue for the
//       foreseeable future. Several major development projects are in the pipeline, including a
//       state-of-the-art convention center and a waterfront revitalization initiative. These
//       projects are expected to further boost property values and attract even more investment
//       to the area.

//       For potential investors and homebuyers, the current market presents both opportunities
//       and challenges. While property values are high, the strong fundamentals suggest long-term
//       appreciation potential. Financial advisors recommend conducting thorough due diligence and
//       considering factors such as location, amenities, and future development plans before making
//       investment decisions.

//       The downtown real estate boom is also creating positive ripple effects throughout the
//       broader metropolitan area. Neighboring districts are experiencing increased interest, and
//       property values in these areas are beginning to rise as well. This expansion of the growth
//       zone suggests a healthy and sustainable market rather than an isolated bubble.
//     `,
//   };

//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [showScrolling, setShowScrolling] = useState(false);
//   const [containerWidth, setContainerWidth] = useState(0);
//   const scrollContainerRef = useRef(null);

//   const newsData = [
//     {
//       id: 1,
//       image: img1,
//       headline: "Real Estate Market Shows Strong Growth in Downtown Area",
//       description:
//         "Latest market analysis reveals significant uptick in property values and investment opportunities in the central business district.",
//       category: "Headlines",
//     },
//     {
//       id: 2,
//       image: img2,
//       headline: "New Luxury Development Project Announced",
//       description:
//         "Premium residential complex featuring state-of-the-art amenities and sustainable design principles breaks ground this month.",
//       category: "Headlines",
//     },
//     {
//       id: 3,
//       image: img3,
//       headline: "Commercial Property Investment Trends 2024",
//       description:
//         "Industry experts discuss emerging opportunities and market predictions for commercial real estate investments.",
//       category: "Headlines",
//     },
//   ];

//   // Check if scrolling is needed based on screen size
//   useEffect(() => {
//     const checkScrollNeed = () => {
//       const isDesktop = window.innerWidth >= 1024;
//       const needsScrolling = !isDesktop;
//       setShowScrolling(needsScrolling);
//       setContainerWidth(window.innerWidth);
//     };

//     checkScrollNeed();
//     window.addEventListener("resize", checkScrollNeed);

//     return () => {
//       window.removeEventListener("resize", checkScrollNeed);
//     };
//   }, []);

//   const handleCardClick = (clickedIndex) => {
//     if (!showScrolling) return;

//     const nextIndex = (clickedIndex + 1) % newsData.length;
//     setCurrentIndex(nextIndex);
//     scrollToIndex(nextIndex);
//   };

//   const scrollToIndex = (index) => {
//     if (scrollContainerRef.current) {
//       const container = scrollContainerRef.current;
//       const containerWidth = container.offsetWidth;
//       const scrollPosition = index * containerWidth;

//       container.scrollTo({
//         left: scrollPosition,
//         behavior: "smooth",
//       });
//     }
//   };

//   const handlePrevious = () => {
//     const prevIndex =
//       currentIndex === 0 ? newsData.length - 1 : currentIndex - 1;
//     setCurrentIndex(prevIndex);
//     scrollToIndex(prevIndex);
//   };

//   const handleNext = () => {
//     const nextIndex = (currentIndex + 1) % newsData.length;
//     setCurrentIndex(nextIndex);
//     scrollToIndex(nextIndex);
//   };

//   return (
//     <div className="">
//       <Header />
//       {/* Header Section */}
//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
//         <Link
//           to="/blog"
//           className="inline-flex text-lg items-center text-[#0b154f] transition-colors duration-200 mb-4"
//         >
//           <ArrowLeft className="w-5 h-5 mr-2" />
//           Back
//         </Link>
//       </div>

//       {/* Main Content */}
//       <article className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
//         {/* Title */}
//         <h1 className="text-xl md:text-4xl font-bold text-[#0b154f] mb-6 leading-tight">
//           {blogData.headline}
//         </h1>

//         {/* Meta Information */}
//         <div className="flex flex-wrap items-center gap-6 mb-8 text-gray-600">
//           <div className="flex items-center gap-2">
//             <User className="w-5 h-5" />
//             <span className="font-medium">{blogData.postedBy}</span>
//           </div>
//           <div className="flex items-center gap-2">
//             <Calendar className="w-5 h-5" />
//             <span>{blogData.date}</span>
//           </div>
//         </div>

//         {/* Featured Image */}
//         <div className="mb-10 rounded-2xl overflow-hidden shadow-lg">
//           <img
//             src={blogData.image}
//             alt={blogData.headline}
//             className="w-full h-100 object-cover"
//           />
//         </div>

//         {/* Summary */}
//         <div className="mb-8">
//           <p className="text-xl text-gray-700 leading-relaxed font-medium">
//             {blogData.description}
//           </p>
//         </div>

//         {/* Full Content */}
//         <div className="prose prose-lg max-w-none">
//           {blogData.fullContent.split("\n\n").map((paragraph, index) => (
//             <p key={index} className="text-gray-700 leading-relaxed mb-6">
//               {paragraph.trim()}
//             </p>
//           ))}
//         </div>
//       </article>

//       <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-16 my-10">
//         {/* Section Header */}
//         <div className="text-center mb-12">
//           <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-4">
//             Other Blogs
//           </h2>
//         </div>

//         {/* News Container */}
//         <div className="relative">
//           <div
//             ref={scrollContainerRef}
//             className={`flex pb-4 ${
//               showScrolling
//                 ? "overflow-x-auto scrollbar-hide snap-x snap-mandatory"
//                 : "lg:justify-center lg:items-center lg:gap-6 overflow-hidden"
//             }`}
//             style={{
//               scrollbarWidth: "none",
//               msOverflowStyle: "none",
//             }}
//           >
//             {newsData.map((news, index) => (
//               <div
//                 key={news.id}
//                 className={`${
//                   showScrolling
//                     ? "snap-start flex-shrink-0 px-6"
//                     : "lg:flex-1 lg:max-w-sm"
//                 }`}
//                 style={{
//                   width: showScrolling ? "100%" : "auto",
//                 }}
//               >
//                 {/* NewsCard content inlined */}
//                 <Link
//                   to="/blogdetails"
//                   className={`relative group cursor-pointer overflow-hidden transition-all duration-300 transform hover:-translate-y-2 flex-shrink-0 ${
//                     showScrolling && index === currentIndex ? "" : ""
//                   }`}
//                   onClick={() => handleCardClick(index)}
//                   style={{
//                     width:
//                       window.innerWidth >= 1024 ? "auto" : "calc(100vw - 80px)",
//                     minWidth:
//                       window.innerWidth >= 1024
//                         ? "320px"
//                         : "calc(100vw - 80px)",
//                   }}
//                 >
//                   <div className="relative h-64 overflow-hidden rounded-2xl">
//                     <img
//                       src={news.image}
//                       alt={news.headline}
//                       className="w-full h-full object-cover rounded-2xl transition-transform duration-300 group-hover:scale-105"
//                     />
//                   </div>
//                   <div className="p-6">
//                     <h3 className="text-xl font-bold text-[#0b154f] mb-3 line-clamp-2">
//                       {news.headline}
//                     </h3>
//                     <p className="text-gray-600 text-sm line-clamp-3">
//                       {news.description}
//                     </p>
//                   </div>
//                 </Link>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* Hide scrollbar styles */}
//       <style jsx>{`
//         .scrollbar-hide {
//           -webkit-overflow-scrolling: touch;
//         }
//         .scrollbar-hide::-webkit-scrollbar {
//           display: none;
//         }
//         .line-clamp-2 {
//           display: -webkit-box;
//           -webkit-line-clamp: 2;
//           -webkit-box-orient: vertical;
//           overflow: hidden;
//         }
//         .line-clamp-3 {
//           display: -webkit-box;
//           -webkit-line-clamp: 3;
//           -webkit-box-orient: vertical;
//           overflow: hidden;
//         }
//       `}</style>

//       <Footer />
//     </div>
//   );
// };

// export default BlogDetails;
import React from "react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";
import { Calendar, User, ArrowLeft } from "lucide-react";
import img1 from "./assets/latestnews/img1.png";
import img2 from "./assets/latestnews/img2.png";
import img3 from "./assets/latestnews/img3.png";

const BlogDetails = () => {
  const blogData = {
    id: 1,
    image:
      "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200&h=600&fit=crop",
    headline: "Real Estate Market Shows Strong Growth in Downtown Area",
    description:
      "Latest market analysis reveals significant uptick in property values and investment opportunities in the central business district.",
    category: "Headlines",
    postedBy: "Sarah Mitchell",
    date: "October 5, 2025",
    fullContent: `
      The downtown real estate market is experiencing unprecedented growth, with property values 
      surging by an impressive 18% over the past year. This remarkable trend is driven by a 
      combination of factors including enhanced infrastructure development, an influx of major 
      corporate headquarters, and a renewed interest in urban living.

      Recent data from the Metropolitan Real Estate Association shows that commercial properties 
      in the central business district have become particularly attractive to investors. Office 
      spaces are commanding premium rates, with occupancy levels reaching a five-year high of 94%. 
      The demand is being fueled by tech companies and financial institutions seeking prime 
      locations to establish their presence.

      Residential properties are not far behind in this growth trajectory. Luxury condominiums 
      and upscale apartments in the downtown core are selling at record prices, often receiving 
      multiple offers within days of listing. The average price per square foot has climbed to 
      $850, marking a significant milestone for the market.

      Infrastructure improvements have played a crucial role in this transformation. The completion 
      of the new metro extension, renovation of public spaces, and the development of mixed-use 
      complexes have made downtown living more accessible and appealing than ever before. These 
      enhancements have created a vibrant ecosystem where residents can live, work, and enjoy 
      leisure activities within walking distance.

      Looking ahead, industry experts predict that this growth trend will continue for the 
      foreseeable future. Several major development projects are in the pipeline, including a 
      state-of-the-art convention center and a waterfront revitalization initiative. These 
      projects are expected to further boost property values and attract even more investment 
      to the area.

      For potential investors and homebuyers, the current market presents both opportunities 
      and challenges. While property values are high, the strong fundamentals suggest long-term 
      appreciation potential. Financial advisors recommend conducting thorough due diligence and 
      considering factors such as location, amenities, and future development plans before making 
      investment decisions.

      The downtown real estate boom is also creating positive ripple effects throughout the 
      broader metropolitan area. Neighboring districts are experiencing increased interest, and 
      property values in these areas are beginning to rise as well. This expansion of the growth 
      zone suggests a healthy and sustainable market rather than an isolated bubble.
    `,
  };

  const relatedBlogs = [
    {
      id: 1,
      image: img1,
      headline: "Real Estate Market Shows Strong Growth in Downtown Area",
      description:
        "Latest market analysis reveals significant uptick in property values and investment opportunities.",
      category: "Headlines",
    },
    {
      id: 2,
      image: img2,
      headline: "New Luxury Development Project Announced",
      description:
        "Premium residential complex featuring state-of-the-art amenities and sustainable design principles.",
      category: "Headlines",
    },
    {
      id: 3,
      image: img3,
      headline: "Commercial Property Investment Trends 2024",
      description:
        "Industry experts discuss emerging opportunities and market predictions for commercial real estate.",
      category: "Headlines",
    },
  ];

  return (
    <div className="">
      <Header />
      {/* Header Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <Link
          to="/blog"
          className="inline-flex text-lg items-center text-[#0b154f] transition-colors duration-200 mb-4"
        >
          <ArrowLeft className="w-5 h-5 mr-2" />
          Back
        </Link>
      </div>

      {/* Main Content */}
      <article className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        {/* Title */}
        <h1 className="text-xl md:text-4xl font-bold text-[#0b154f] mb-6 leading-tight">
          {blogData.headline}
        </h1>

        {/* Meta Information */}
        <div className="flex flex-wrap items-center gap-6 mb-8 text-gray-600">
          <div className="flex items-center gap-2">
            <User className="w-5 h-5" />
            <span className="font-medium">{blogData.postedBy}</span>
          </div>
          <div className="flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            <span>{blogData.date}</span>
          </div>
        </div>

        {/* Featured Image */}
        <div className="mb-10 rounded-2xl overflow-hidden shadow-lg">
          <img
            src={blogData.image}
            alt={blogData.headline}
            className="w-full h-100 object-cover"
          />
        </div>

        {/* Summary */}
        <div className="mb-8">
          <p className="text-xl text-gray-700 leading-relaxed font-medium">
            {blogData.description}
          </p>
        </div>

        {/* Two Column Layout: Content + Sidebar */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-10">
          {/* Main Content - Left Side (2/3 width) */}
          <div className="lg:col-span-2">
            <div className="prose prose-lg max-w-none">
              {blogData.fullContent.split("\n\n").map((paragraph, index) => (
                <p key={index} className="text-gray-700 leading-relaxed mb-6">
                  {paragraph.trim()}
                </p>
              ))}
            </div>
          </div>

          {/* Related Blogs Sidebar - Right Side (1/3 width) */}
          <div className="lg:col-span-1">
            <div className="lg:sticky lg:top-6">
              <h3 className="text-2xl font-bold text-[#0b154f] mb-6">
                Related Blogs
              </h3>
              <div className="space-y-6">
                {relatedBlogs.map((blog) => (
                  <Link key={blog.id} to="/blogdetails" className="block group">
                    <div className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-xl transition-shadow duration-300 border border-gray-100">
                      <div className="relative h-48 overflow-hidden">
                        <img
                          src={blog.image}
                          alt={blog.headline}
                          className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                        />
                      </div>
                      <div className="p-4">
                        <h4 className="text-base font-bold text-[#0b154f] mb-2 line-clamp-2 group-hover:text-[#0b154f]/80 transition-colors">
                          {blog.headline}
                        </h4>
                        <p className="text-gray-600 text-sm line-clamp-2">
                          {blog.description}
                        </p>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </article>

      {/* Hide scrollbar styles */}
      <style jsx>{`
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>

      <Footer />
    </div>
  );
};

export default BlogDetails;
