import React, { useEffect, useState } from "react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { ArrowLeft, MessageCircle } from "lucide-react";
import { useNavigate, useParams } from "react-router-dom";

const RecentProjects = () => {
  const { id } = useParams();
  console.log(id);
  const navigate = useNavigate();


  const [agentData, setAgentData] = useState(null);

  useEffect(() => {
    fetchAgent();
  }, []);

  const fetchAgent = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:8000/api/agent/${id}/`);
      if (!response.ok) throw new Error("Network error");

      const data = await response.json();
      console.log("Fetched team members:", data);
      setAgentData(data);

    } catch (error) {
      console.error("Error fetching team members:", error);
    }
  };

  if (!agentData)
    return <div className="text-center p-10 text-xl">Loading...</div>;

  return (
    <>
      <Header />

      {/* Header */}
      <div
        onClick={() => navigate(-1)}
        className="flex items-center p-4 px-14 bg-white"
      >
        <ArrowLeft className="w-6 h-6 text-gray-700" />
        <span className="ml-2 text-gray-700 font-medium">Back</span>
      </div>
      <div className="max-w-6xl mx-auto mt-10 mb-6 px-4">
        {/* Main Profile Section */}
        <div className="text-white flex flex-col lg:flex-row gap-1">
          {/* Left Side - Profile Info */}
          <div className="lg:w-2/3 p-4 flex-1 flex flex-col sm:flex-row items-start gap-4 sm:gap-6 rounded-2xl bg-[#3c4372]">
            {/* Profile Image */}
            <div className="w-full sm:w-52 h-64 rounded-xl overflow-hidden border-2 border-slate-600 flex-shrink-0">
              <img
                src={`http://127.0.0.1:8000${agentData.image}`}
                alt={agentData.name}
                className="w-full h-full object-cover"
              />
            </div>

            {/* Team Info and Buttons */}
            <div className="flex-1 flex flex-col justify-between h-full w-full">
              <div>
                <h2 className="text-2xl sm:text-3xl font-bold mb-2">
                  {agentData.name}
                </h2>

                <p className="text-slate-300 text-sm mb-4 sm:mb-6 leading-relaxed">
                  {agentData.country}, {agentData.state}, {agentData.city}
                  <br />
                  +{agentData.experience_years} Years of Experience
                </p>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-col sm:flex-row gap-3">
                <a
                  href={`https://wa.me/${agentData.phone}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center bg-green-500 hover:bg-green-600 transition-colors text-white px-5 py-2.5 rounded-lg text-sm font-medium"
                >
                  <MessageCircle className="w-4 h-4 mr-2" />
                  WhatsApp
                </a>

                {/* <a
                  href={`http://127.0.0.1:8000${agentData.cv}`}
                  download
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-slate-600 hover:bg-slate-500 transition-colors text-white px-5 py-2.5 rounded-lg text-sm font-medium text-center"
                >
                  Download CV
                </a> */}

              </div>
            </div>
          </div>

          {/* Right Side - Brokerage */}
          <div className="lg:w-1/3 py-4 px-0 rounded-2xl bg-[#3c4372] flex flex-col gap-4">
            <div className="w-full px-6">
              <h3 className="text-white text-lg font-semibold mb-4">
                Personal Information
              </h3>

              <div className="space-y-3">
                <div>
                  <div className="text-slate-400 text-sm">Role:</div>
                  <div className="text-white text-base">{agentData.Role}</div>
                </div>

                <div>
                  <div className="text-slate-400 text-sm">Experience:</div>
                  <div className="text-white text-base">
                    {agentData.experience_years} Years
                  </div>
                </div>

                <div>
                  <div className="text-slate-400 text-sm">Phone:</div>
                  <div className="text-white text-base">{agentData.phone}</div>
                </div>

                <div>
                  <div className="text-slate-400 text-sm">Email:</div>
                  <div className="text-white text-base">{agentData.email}</div>
                </div>

                <div>
                  <div className="text-slate-400 text-sm">Address:</div>
                  <div className="text-white text-base">{agentData.address}</div>
                </div>

                {/* <div>
                  <div className="text-slate-400 text-sm">Links:</div>
                  <a
                    href="#"
                    className="text-blue-400 hover:text-blue-300 underline text-base inline-flex items-center gap-1"
                  >
                    LinkedIn
                  </a>
                </div> */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* <div className="max-w-6xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10 my-14">
        <h2 className="text-3xl font-bold text-[#0b154f] mb-6">About Us</h2>
        <p className="text-gray-500 text-lg leading-relaxed text-justify">
          Palm Jebel Ali Front C, a prestigious real estate development by
          Nakheel Properties, is situated on Palm Jebel Ali, one of Dubai's most
          recognizable artificial islands. With a variety of breathtaking
          villas, created for individuals seeking the ultimate in luxurious
          living, this unique project is poised to become a genuine emblem of
          luxury and sophistication. With its vast living areas, modern
          facilities, and peaceful beachfront access, Palm Jebel Ali Front C
          offers an exceptional lifestyle in one of the most sought-after
          locations on earth.
        </p>
      </div> */}

      <Footer />
    </>
  );
};

export default RecentProjects;
