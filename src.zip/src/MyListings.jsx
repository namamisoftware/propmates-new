// import React, { useState } from "react";
// import { Home, User, LogOut, HelpCircle } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import { Link } from "react-router-dom";

// const PropertyCard = ({ property }) => (
//   <div className="bg-blue-50 rounded-lg shadow-sm overflow-hidden mb-3 p-3 sm:p-4">
//     <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
//       <img
//         src={property.image}
//         alt={property.title}
//         className="w-full sm:w-40 md:w-52 lg:w-66 h-40 sm:h-32 md:h-40 lg:h-46 rounded object-cover flex-shrink-0"
//       />
//       <div className="flex-1 flex flex-col justify-between min-w-0">
//         <div>
//           <h3 className="font-semibold text-sm sm:text-base text-gray-900">
//             {property.title}
//           </h3>
//           <p className="text-xs text-gray-600 mt-1 line-clamp-2">
//             {property.description}
//           </p>
//           <p className="text-xs text-gray-600 line-clamp-2">
//             {property.description2}
//           </p>
//         </div>

//         <div className="mt-3 sm:mt-4">
//           <div className="text-lg sm:text-base font-bold text-gray-900">
//             ₹{property.price.toLocaleString()}
//           </div>
//         </div>

//         <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-3">
//           <div>
//             <div className="text-xs font-semibold text-gray-900">
//               {property.area} Sq.Ft.
//             </div>
//             <div className="text-xs text-gray-500">{property.rate}</div>
//           </div>
//           <div>
//             <div className="text-xs font-semibold text-gray-900">
//               {property.furnished}
//             </div>
//             <div className="text-xs text-gray-500">
//               {property.furnishedStatus}
//             </div>
//           </div>
//         </div>

//         <div className="text-xs text-gray-500 mt-3 sm:mt-4">
//           Posted on: {property.postedDate}
//         </div>
//       </div>
//     </div>
//   </div>
// );

// const App = () => {
//   const properties = [
//     {
//       id: 1,
//       title: "MP Trupati M Highshine",
//       description: "Office Space For Rent In Rasoolpura",
//       description2: "Rasoolpura Bhopal",
//       price: 25000,
//       area: 250,
//       rate: "₹100 / Sq.Ft.",
//       furnished: "Furnished",
//       furnishedStatus: "Furnishing Status",
//       postedDate: "21 August 2024",
//       image:
//         "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
//     },
//     {
//       id: 2,
//       title: "MP Trupati M Highshine",
//       description: "Office Space For Rent In Rasoolpura",
//       description2: "Rasoolpura Bhopal",
//       price: 25000,
//       area: 250,
//       rate: "₹100 / Sq.Ft.",
//       furnished: "Furnished",
//       furnishedStatus: "Furnishing Status",
//       postedDate: "21 August 2024",
//       image:
//         "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
//     },
//     {
//       id: 3,
//       title: "MP Trupati M Highshine",
//       description: "Office Space For Rent In Rasoolpura",
//       description2: "Rasoolpura Bhopal",
//       price: 25000,
//       area: 250,
//       rate: "₹100 / Sq.Ft.",
//       furnished: "Furnished",
//       furnishedStatus: "Furnishing Status",
//       postedDate: "21 August 2024",
//       image:
//         "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
//     },
//     {
//       id: 4,
//       title: "MP Trupati M Highshine",
//       description: "Office Space For Rent In Rasoolpura",
//       description2: "Rasoolpura Bhopal",
//       price: 25000,
//       area: 250,
//       rate: "₹100 / Sq.Ft.",
//       furnished: "Furnished",
//       furnishedStatus: "Furnishing Status",
//       postedDate: "21 August 2024",
//       image:
//         "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
//     },
//     {
//       id: 5,
//       title: "MP Trupati M Highshine",
//       description: "Office Space For Rent In Rasoolpura",
//       description2: "Rasoolpura Bhopal",
//       price: 25000,
//       area: 250,
//       rate: "₹100 / Sq.Ft.",
//       furnished: "Furnished",
//       furnishedStatus: "Furnishing Status",
//       postedDate: "21 August 2024",
//       image:
//         "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
//     },
//   ];

//   return (
//     <>
//       <Header />
//       <div className="flex gap-4 max-w-6xl mx-auto my-10">
//         {/* Sidebar */}
//         <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded">
//           <div className="p-4">
//             <nav className="space-y-0.5">
//               <Link
//                 to="/mylistings"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <Home className="w-4 h-4" />
//                 <span>My Listings</span>
//               </Link>
//               <Link
//                 to="/listproperty"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <Home className="w-4 h-4" />
//                 <span>List Property</span>
//               </Link>

//               <Link
//                 to="/profile"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <User className="w-4 h-4" />
//                 <span>Profile</span>
//               </Link>

//               <Link
//                 to="/enquiry"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <HelpCircle className="w-4 h-4" />
//                 <span>Enquiry</span>
//               </Link>
//             </nav>
//           </div>
//         </div>

//         {/* Main Content */}
//         <div className="flex-1 overflow-auto bg-white rounded">
//           <div className="bg-white border-b border-gray-200 px-3 sm:px-5 py-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
//             <h2 className="text-base font-semibold text-gray-800">
//               My Listings
//             </h2>
//             <button className="text-sm text-blue-600 hover:text-blue-700 whitespace-nowrap">
//               Add Property +
//             </button>
//           </div>

//           <div className="p-3 sm:p-5 bg-gray-50">
//             {properties.map((property) => (
//               <PropertyCard key={property.id} property={property} />
//             ))}
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default App;

import React, { useState, useEffect } from "react";
import {
  Home,
  User,
  LogOut,
  HelpCircle,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const PropertyCard = ({ property }) => (
  <div className="bg-blue-50 rounded-lg shadow-sm overflow-hidden mb-3 p-3 sm:p-4">
    <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
      <img
        src={
          property.image ||
          "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop"
        }
        alt={property.title}
        className="w-full sm:w-40 md:w-52 lg:w-66 h-40 sm:h-32 md:h-40 lg:h-46 rounded object-cover flex-shrink-0"
      />
      <div className="flex-1 flex flex-col justify-between min-w-0">
        <div>
          <h3 className="font-semibold text-sm sm:text-base text-gray-900">
            {property.title}
          </h3>
          <p className="text-xs text-gray-600 mt-1 line-clamp-2">
            {property.description}
          </p>
          <p className="text-xs text-gray-600 line-clamp-2">
            {property.description2}
          </p>
        </div>

        <div className="mt-3 sm:mt-4">
          <div className="text-lg sm:text-base font-bold text-gray-900">
            ₹{property.price?.toLocaleString()}
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-3">
          <div>
            <div className="text-xs font-semibold text-gray-900">
              {property.area} Sq.Ft.
            </div>
            <div className="text-xs text-gray-500">{property.rate}</div>
          </div>
          <div>
            <div className="text-xs font-semibold text-gray-900">
              {property.furnished}
            </div>
            <div className="text-xs text-gray-500">
              {property.furnishedStatus}
            </div>
          </div>
        </div>

        <div className="text-xs text-gray-500 mt-3 sm:mt-4">
          Posted on: {property.postedDate}
        </div>
      </div>
    </div>
  </div>
);

const App = () => {
  const [properties, setProperties] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchProperties = async () => {
      try {
        // Get user_id from session storage or local storage
        const storedUser = JSON.parse(sessionStorage.getItem("user") || "{}");
        const userId = storedUser.user_id;
        console.log(userId);

        if (!userId) {
          setError("User ID not found in session. Please log in.");
          setLoading(false);
          return;
        }

        // Fetch properties from API
        const response = await fetch(
          `https://propmatez.shop/api/property-list/${userId}`
        );
        console.log(response);
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`);
        }

        const data = await response.json();
        console.log(data);
        // Map the API response to match the expected property structure
        const mappedProperties = data.map((property) => ({
          id: property.id,
          title: property.name || "No Title",
          description: property.description || "No Description",
          description2:
            property.locality || property.sub_locality || "No Location",
          price: property.price || property.rent_price || 0,
          area: property.carpet_area || property.builtup_area || 0,
          rate:
            property.price && property.carpet_area
              ? `₹${Math.round(property.price / property.carpet_area)} / Sq.Ft.`
              : "N/A",
          furnished: property.furnishing_status || "Not Specified",
          furnishedStatus: "Furnishing Status",
          postedDate:
            property.posted_date ||
            property.created_at ||
            new Date().toLocaleDateString("en-GB", {
              day: "numeric",
              month: "long",
              year: "numeric",
            }),
          image:
            property.image ||
            property.image2 ||
            property.image3 ||
            "https://images.unsplash.com/photo-1524661135-423995f22d0b?w=400&h=300&fit=crop",
        }));

        setProperties(mappedProperties);
        setLoading(false);
      } catch (err) {
        console.error("Error fetching properties:", err);
        setError("Failed to load properties. Please try again later.");
        setLoading(false);
      }
    };

    fetchProperties();
  }, []);

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  return (
    <>
      <Header />
      <div className="flex gap-4 max-w-6xl mx-auto my-10">
        {/* Sidebar */}
        <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded">
          <div className="p-4">
            <nav className="space-y-0.5">
              {/* My Listings */}
              <div>
                <button
                  onClick={() => toggleMenu("mylistings")}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <div className="flex items-center gap-3">
                    <Home className="w-4 h-4" />
                    <span>My Listings</span>
                  </div>
                  {openMenu === "mylistings" ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>

                {/* Submenu for My Listings */}
                {openMenu === "mylistings" && (
                  <div className="ml-8 mt-1 space-y-1">
                    <Link
                      to="/mylistings/commercial"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Commercial
                    </Link>
                    <Link
                      to="/mylistings/residential"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Residential
                    </Link>
                    <Link
                      to="/mylistings/pg"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      PG
                    </Link>
                  </div>
                )}
              </div>

              {/* List Property */}
              <div>
                <button
                  onClick={() => toggleMenu("listproperty")}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm bg-indigo-900 rounded text-left"
                >
                  <div className="flex items-center gap-3">
                    <Home className="w-4 h-4" />
                    <span>List Property</span>
                  </div>
                  {openMenu === "listproperty" ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>

                {/* Submenu for List Property */}
                {openMenu === "listproperty" && (
                  <div className="ml-8 mt-1 space-y-1">
                    <Link
                      to="/listproperty/commercial"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Commercial
                    </Link>
                    <Link
                      to="/listproperty/residential"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Residential
                    </Link>
                    <Link
                      to="/listproperty/pg"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      PG
                    </Link>
                  </div>
                )}
              </div>

              {/* Profile */}
              <Link
                to="/profile"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </Link>

              {/* Enquiry */}
              <Link
                to="/enquiry"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Enquiry</span>
              </Link>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto bg-white rounded">
          <div className="bg-white border-b border-gray-200 px-3 sm:px-5 py-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
            <h2 className="text-base font-semibold text-gray-800">
              My Listings
            </h2>
            <button className="text-sm text-blue-600 hover:text-blue-700 whitespace-nowrap">
              Add Property +
            </button>
          </div>

          <div className="p-3 sm:p-5 bg-gray-50">
            {loading ? (
              <div className="text-center py-10">
                <div className="inline-block animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                <p className="mt-2 text-gray-600">Loading properties...</p>
              </div>
            ) : error ? (
              <div className="text-center py-10">
                <p className="text-red-600">{error}</p>
              </div>
            ) : properties.length === 0 ? (
              <div className="text-center py-10">
                <p className="text-gray-600">No properties found.</p>
              </div>
            ) : (
              properties.map((property) => (
                <PropertyCard key={property.id} property={property} />
              ))
            )}
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default App;
