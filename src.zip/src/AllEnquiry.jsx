import React, { useState } from "react";
import {
  Home,
  User,
  HelpCircle,
  ChevronDown,
  ChevronRight,
  Eye,
  Trash2,
  Search,
  Mail,
  Phone,
  Calendar,
  AlertCircle,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link, useNavigate } from "react-router-dom";

const AllEnquiries = () => {
  const navigate = useNavigate();
  const [openMenu, setOpenMenu] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  // Sample enquiries data
  const [enquiries, setEnquiries] = useState([
    {
      id: 1,
      name: "John Doe",
      email: "john.doe@example.com",
      phone: "+91 9876543210",
      issue: "Problem with My Property Listing",
      status: "Open",
      date: "2025-11-10",
      details: "Unable to upload images to my property listing",
    },
    {
      id: 2,
      name: "Jane Smith",
      email: "jane.smith@example.com",
      phone: "+91 9876543211",
      issue: "Issue with My Enquiries",
      status: "In Progress",
      date: "2025-11-11",
      details: "Not receiving enquiry notifications",
    },
    {
      id: 3,
      name: "Mike Johnson",
      email: "mike.j@example.com",
      phone: "+91 9876543212",
      issue: "Concern with My Property Listing Package",
      status: "Resolved",
      date: "2025-11-09",
      details: "Package upgrade billing issue",
    },
    {
      id: 4,
      name: "Sarah Williams",
      email: "sarah.w@example.com",
      phone: "+91 9876543213",
      issue: "Issue with My Property Search",
      status: "Open",
      date: "2025-11-12",
      details: "Search filters not working properly",
    },
    {
      id: 5,
      name: "Robert Brown",
      email: "robert.b@example.com",
      phone: "+91 9876543214",
      issue: "Assistance Needed with Discount Coupons",
      status: "Closed",
      date: "2025-11-08",
      details: "Discount coupon code not applying",
    },
    {
      id: 6,
      name: "Emily Davis",
      email: "emily.d@example.com",
      phone: "+91 9876543215",
      issue: "Problem with a Requested Service",
      status: "Open",
      date: "2025-11-13",
      details: "Home inspection service not scheduled",
    },
    {
      id: 7,
      name: "Robert Brown",
      email: "robert.b@example.com",
      phone: "+91 9876543214",
      issue: "Assistance Needed with Discount Coupons",
      status: "Closed",
      date: "2025-11-08",
      details: "Discount coupon code not applying",
    },
    {
      id: 8,
      name: "Emily Davis",
      email: "emily.d@example.com",
      phone: "+91 9876543215",
      issue: "Problem with a Requested Service",
      status: "Open",
      date: "2025-11-13",
      details: "Home inspection service not scheduled",
    },
  ]);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this enquiry?")) {
      setEnquiries(enquiries.filter((enq) => enq.id !== id));
    }
  };

  const handleView = (id) => {
    navigate("/enquiry/viewenquiry");
  };

  const getStatusColor = (status) => {
    switch (status) {
      case "Open":
        return "bg-blue-100 text-blue-800 border-blue-200";
      case "In Progress":
        return "bg-yellow-100 text-yellow-800 border-yellow-200";
      case "Resolved":
        return "bg-green-100 text-green-800 border-green-200";
      case "Closed":
        return "bg-gray-100 text-gray-800 border-gray-200";
      default:
        return "bg-gray-100 text-gray-800 border-gray-200";
    }
  };

  const filteredEnquiries = enquiries.filter(
    (enq) =>
      enq.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enq.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enq.issue.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Calculate pagination
  const totalPages = Math.ceil(filteredEnquiries.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentEnquiries = filteredEnquiries.slice(startIndex, endIndex);

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Reset to page 1 when search term changes
  React.useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  return (
    <>
      <Header />
      <div className="max-w-6xl mx-auto my-10 p-4">
        <div className="flex gap-4 items-start">
          {/* Sidebar */}
          <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded shadow-sm sticky top-8 max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-hide">
            <div className="p-4">
              <nav className="space-y-0.5">
                {/* My Listings */}
                <div>
                  <button
                    onClick={() => toggleMenu("mylistings")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>My Listings</span>
                    </div>
                    {openMenu === "mylistings" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "mylistings" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/mylistings/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/mylistings/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/mylistings/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/mylistings/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/mylistings/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/mylistings/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* List Property */}
                <div>
                  <button
                    onClick={() => toggleMenu("listproperty")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>List Property</span>
                    </div>
                    {openMenu === "listproperty" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "listproperty" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/listproperty/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/listproperty/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/listproperty/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/listproperty/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/listproperty/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/listproperty/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* Profile */}
                <Link
                  to="/profile"
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </Link>

                {/* Enquiry */}
                <div>
                  <button
                    onClick={() => toggleMenu("enquiry")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <HelpCircle className="w-4 h-4" />
                      <span>Enquiry/Ticket</span>
                    </div>
                    {openMenu === "enquiry" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "enquiry" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/enquiry/addenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Add Enquiry
                      </Link>
                      <Link
                        to="/enquiry/newenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        New Enquiry
                      </Link>
                      <Link
                        to="/enquiry/allenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        All Enquiry
                      </Link>
                    </div>
                  )}
                </div>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-white rounded shadow-sm">
            <div className="bg-white rounded-lg shadow-sm p-6">
              {/* Header */}
              <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
                <h1 className="text-3xl font-bold text-[#0b154f]">
                  All Enquiries
                </h1>
                <div className="relative w-full md:w-auto">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    placeholder="Search enquiries..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="w-full md:w-64 pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] focus:border-transparent"
                  />
                </div>
              </div>

              {/* Stats Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-6">
                <div className="bg-blue-50 p-3 rounded-lg border border-blue-100">
                  <p className="text-xs text-blue-600 font-semibold">Total</p>
                  <p className="text-xl font-bold text-blue-900">
                    {enquiries.length}
                  </p>
                </div>
                <div className="bg-yellow-50 p-3 rounded-lg border border-yellow-100">
                  <p className="text-xs text-yellow-600 font-semibold">Open</p>
                  <p className="text-xl font-bold text-yellow-900">
                    {enquiries.filter((e) => e.status === "Open").length}
                  </p>
                </div>
                <div className="bg-green-50 p-3 rounded-lg border border-green-100">
                  <p className="text-xs text-green-600 font-semibold">
                    Resolved
                  </p>
                  <p className="text-xl font-bold text-green-900">
                    {enquiries.filter((e) => e.status === "Resolved").length}
                  </p>
                </div>
                <div className="bg-gray-50 p-3 rounded-lg border border-gray-100">
                  <p className="text-xs text-gray-600 font-semibold">Closed</p>
                  <p className="text-xl font-bold text-gray-900">
                    {enquiries.filter((e) => e.status === "Closed").length}
                  </p>
                </div>
              </div>

              {/* Enquiry Cards Grid */}
              {currentEnquiries.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {currentEnquiries.map((enquiry) => (
                    <div
                      key={enquiry.id}
                      className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow"
                    >
                      {/* Card Header */}
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900 text-sm">
                            {enquiry.name}
                          </h3>
                          <p className="text-xs text-gray-500">
                            ID: #{enquiry.id}
                          </p>
                        </div>
                        <span
                          className={`px-2 py-1 rounded-full text-xs font-semibold border ${getStatusColor(
                            enquiry.status
                          )}`}
                        >
                          {enquiry.status}
                        </span>
                      </div>

                      {/* Issue */}
                      <div className="mb-3 flex items-start gap-2">
                        <AlertCircle className="w-4 h-4 text-gray-400 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-gray-700 line-clamp-2">
                          {enquiry.issue}
                        </p>
                      </div>

                      {/* Contact Info */}
                      <div className="space-y-1.5 mb-3">
                        <div className="flex items-center gap-2 text-xs text-gray-600">
                          <Mail className="w-3.5 h-3.5" />
                          <span className="truncate">{enquiry.email}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-600">
                          <Phone className="w-3.5 h-3.5" />
                          <span>{enquiry.phone}</span>
                        </div>
                        <div className="flex items-center gap-2 text-xs text-gray-600">
                          <Calendar className="w-3.5 h-3.5" />
                          <span>{enquiry.date}</span>
                        </div>
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 pt-3 border-t border-gray-100">
                        <button
                          onClick={() => handleView(enquiry.id)}
                          className="flex-1 flex items-center justify-center gap-2 px-3 py-1.5 text-xs font-medium text-blue-600 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors"
                        >
                          <Eye className="w-3.5 h-3.5" />
                          View
                        </button>
                        <button
                          onClick={() => handleDelete(enquiry.id)}
                          className="flex items-center justify-center gap-2 px-3 py-1.5 text-xs font-medium text-red-600 bg-red-50 hover:bg-red-100 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <AlertCircle className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                  <p className="text-gray-500">No enquiries found</p>
                </div>
              )}

              {/* Pagination */}
              {filteredEnquiries.length > 0 && (
                <div className="flex flex-col sm:flex-row justify-between items-center mt-6 pt-4 border-t border-gray-200 gap-3">
                  <p className="text-sm text-gray-600">
                    Showing {startIndex + 1} to{" "}
                    {Math.min(endIndex, filteredEnquiries.length)} of{" "}
                    {filteredEnquiries.length} enquiries
                  </p>
                  <div className="flex gap-2 items-center">
                    <button
                      onClick={handlePrevPage}
                      disabled={currentPage === 1}
                      className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
                    >
                      Previous
                    </button>
                    <span className="text-sm text-gray-600">
                      Page {currentPage} of {totalPages}
                    </span>
                    <button
                      onClick={handleNextPage}
                      disabled={currentPage === totalPages}
                      className="px-3 py-1.5 border border-gray-300 rounded-lg text-sm hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:bg-white"
                    >
                      Next
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          <style jsx>{`
            .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .scrollbar-hide::-webkit-scrollbar {
              display: none;
            }
          `}</style>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default AllEnquiries;
