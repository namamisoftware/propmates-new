import React, { useState } from "react";
import {
  Home,
  User,
  LogOut,
  HelpCircle,
  ChevronDown,
  ChevronRight,
  Calendar,
  Mail,
  Phone,
  FileText,
  AlertCircle,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const EnquiryView = () => {
  // Sample enquiry data - in real app, this would come from props or API
  const enquiryData = {
    id: "ENQ-2024-001",
    name: "John Doe",
    phone: "+91 98765 43210",
    email: "john.doe@example.com",
    issue: "Problem with My Property Listing",
    details:
      "I am unable to edit my property listing. When I click on the edit button, the page doesn't load properly and shows an error message. This has been happening for the past 2 days.",
    status: "Open",
    submittedDate: "November 10, 2025",
    lastUpdated: "November 13, 2025",
  };

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const getStatusColor = (status) => {
    switch (status.toLowerCase()) {
      case "open":
        return "bg-blue-100 text-blue-800";
      case "in progress":
        return "bg-yellow-100 text-yellow-800";
      case "resolved":
        return "bg-green-100 text-green-800";
      case "closed":
        return "bg-gray-100 text-gray-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <>
      <Header />
      <div className="max-w-6xl mx-auto my-10 p-4">
        <div className="flex gap-4 items-start">
          {/* Sidebar */}
          <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded shadow-sm sticky top-8 max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-hide">
            <div className="p-4">
              <nav className="space-y-0.5">
                {/* My Listings */}
                <div>
                  <button
                    onClick={() => toggleMenu("mylistings")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>My Listings</span>
                    </div>
                    {openMenu === "mylistings" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "mylistings" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/mylistings/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/mylistings/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/mylistings/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/mylistings/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/mylistings/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/mylistings/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* List Property */}
                <div>
                  <button
                    onClick={() => toggleMenu("listproperty")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>List Property</span>
                    </div>
                    {openMenu === "listproperty" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "listproperty" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/listproperty/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/listproperty/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/listproperty/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/listproperty/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/listproperty/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/listproperty/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* Profile */}
                <Link
                  to="/profile"
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </Link>

                {/* Enquiry */}
                <div>
                  <button
                    onClick={() => toggleMenu("enquiry")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <HelpCircle className="w-4 h-4" />
                      <span>Enquiry/Ticket</span>
                    </div>
                    {openMenu === "enquiry" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "enquiry" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/enquiry/addenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Add Enquiry
                      </Link>
                      <Link
                        to="/enquiry/newenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        New Enquiry
                      </Link>
                      <Link
                        to="/enquiry/allenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        All Enquiry
                      </Link>
                    </div>
                  )}
                </div>
              </nav>
            </div>
          </div>

          {/* Main Content - View Enquiry */}
          <div className="flex-1 bg-white rounded shadow-sm">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm p-8">
              {/* Header */}
              <div className="flex justify-between items-start mb-8">
                <div>
                  <h1 className="text-3xl font-bold text-[#0b154f] mb-2">
                    Enquiry Details
                  </h1>
                  <p className="text-gray-600">Ticket ID: {enquiryData.id}</p>
                </div>
                <span
                  className={`px-4 py-2 rounded-full text-sm font-semibold ${getStatusColor(
                    enquiryData.status
                  )}`}
                >
                  {enquiryData.status}
                </span>
              </div>

              {/* Enquiry Information */}
              <div className="space-y-6">
                {/* Contact Information Card */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-lg font-semibold text-[#0b154f] mb-4">
                    Contact Information
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="flex items-start gap-3">
                      <User className="w-5 h-5 text-gray-600 mt-1" />
                      <div>
                        <p className="text-sm text-gray-600">Name</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.name}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Phone className="w-5 h-5 text-gray-600 mt-1" />
                      <div>
                        <p className="text-sm text-gray-600">Phone</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.phone}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Mail className="w-5 h-5 text-gray-600 mt-1" />
                      <div>
                        <p className="text-sm text-gray-600">Email</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.email}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Issue Details Card */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-lg font-semibold text-[#0b154f] mb-4">
                    Issue Details
                  </h2>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <AlertCircle className="w-5 h-5 text-gray-600 mt-1" />
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 mb-1">Issue Type</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.issue}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <FileText className="w-5 h-5 text-gray-600 mt-1" />
                      <div className="flex-1">
                        <p className="text-sm text-gray-600 mb-1">
                          Description
                        </p>
                        <p className="text-gray-900 leading-relaxed">
                          {enquiryData.details}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Admin Reply Card */}
                <div className="bg-blue-50 rounded-lg p-6 border-l-4 border-blue-500">
                  <h2 className="text-lg font-semibold text-[#0b154f] mb-4">
                    Admin Reply
                  </h2>
                  <div className="space-y-3">
                    <div className="flex items-center gap-2 text-sm text-gray-600">
                      <User className="w-4 h-4" />
                      <span className="font-medium">Support Team</span>
                      <span>•</span>
                      <Calendar className="w-4 h-4" />
                      <span>November 12, 2025 at 2:30 PM</span>
                    </div>
                    <div className="bg-white rounded-lg p-4">
                      <p className="text-gray-900 leading-relaxed">
                        Thank you for reaching out to us. We have identified the
                        issue with your property listing. Our technical team is
                        currently working on a fix and it should be resolved
                        within the next 24 hours. You will receive an email
                        notification once the issue is fixed. In the meantime,
                        please try clearing your browser cache and cookies,
                        which may help resolve the issue temporarily.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Timeline Card */}
                <div className="bg-gray-50 rounded-lg p-6">
                  <h2 className="text-lg font-semibold text-[#0b154f] mb-4">
                    Timeline
                  </h2>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="flex items-start gap-3">
                      <Calendar className="w-5 h-5 text-gray-600 mt-1" />
                      <div>
                        <p className="text-sm text-gray-600">Submitted On</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.submittedDate}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <Calendar className="w-5 h-5 text-gray-600 mt-1" />
                      <div>
                        <p className="text-sm text-gray-600">Last Updated</p>
                        <p className="font-medium text-gray-900">
                          {enquiryData.lastUpdated}
                        </p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Action Buttons */}
                {/* <div className="flex gap-4 pt-4">
              <button className="px-6 py-3 bg-[#0b154f] text-white font-semibold rounded-lg hover:bg-indigo-900 transition-colors duration-200">
                Back to All Enquiries
              </button>
              <button className="px-6 py-3 border-2 border-[#0b154f] text-[#0b154f] font-semibold rounded-lg hover:bg-gray-50 transition-colors duration-200">
                Edit Enquiry
              </button>
            </div> */}
              </div>
            </div>
          </div>
          <style jsx>{`
            .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .scrollbar-hide::-webkit-scrollbar {
              display: none;
            }
          `}</style>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default EnquiryView;
