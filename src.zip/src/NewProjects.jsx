// import React, { useEffect, useState } from "react";
// import {
//   ChevronDown,
//   Search,
//   ChevronLeft,
//   Heart,
//   Phone,
//   Mail,
//   MessageCircle,
//   MapPin,
//   User,
//   Bed,
//   Bath,
//   Maximize,
// } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import Navbar from "./Components/Navbar";
// import searchbg from "./assets/searchbg.png";
// import calc from "./assets/calc.png";
// import { Link, useNavigate } from "react-router-dom";

// const Commercial = () => {
//   const navigate = useNavigate();
//   const [likedProperties, setLikedProperties] = useState({});
//   const [selectedTab, setSelectedTab] = useState("Buy");
//   const [isPropertyTypeDropdownOpen, setIsPropertyTypeDropdownOpen] =
//     useState(false);
//   const [isBedsDropdownOpen, setIsBedsDropdownOpen] = useState(false);
//   const [selectedPropertyType, setSelectedPropertyType] = useState("");
//   const [selectedBeds, setSelectedBeds] = useState("");
//   const [activeTab, setActiveTab] = useState("Abu Dhabi");
//   const [properties, setproperties]=useState([])

//   const locations = ["Ras Al Khaimah", "Dubai", "Abu Dhabi", "Sharjah"];

//     useEffect(() => {
//       fetch('https://propmatez.shop/api/properties/type/5')
//         .then((res) => res.json())
//         .then((data) => {
//           setproperties(data)
//           console.log(data)
//         })
//         .catch((err) => console.error("Error fetching countries:", err));
//     }, []);

//   // Multiple properties per location
//   const locationData = {
//     "Abu Dhabi": [
//       {
//         id: 1,
//         tag: "Villa",
//         agent: {
//           name: "Ahmed Al-Mansouri",
//           avatar:
//             "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Abu Dhabi",
//         propertyType: "Villa",
//         price: "AED 4,200,000",
//         period: "Yearly",
//         description: "4 Beds Villa For Rent in Al Raha Beach",
//         postedDate: "15 Aug 2025",
//         address: "Al Raha Beach, Mudon Community, Abu Dhabi",
//         beds: 4,
//         baths: 3,
//         area: "2850 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 2,
//         tag: "Apartment",
//         agent: {
//           name: "Layla Hassan",
//           avatar:
//             "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Abu Dhabi",
//         propertyType: "Apartment",
//         price: "AED 2,800,000",
//         period: "Yearly",
//         description: "2 Beds Apartment For Rent in Marina Square",
//         postedDate: "18 Aug 2025",
//         address: "Corniche Area, Marina Square, Abu Dhabi",
//         beds: 2,
//         baths: 2,
//         area: "1200 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 3,
//         tag: "Townhouse",
//         agent: {
//           name: "Omar Al-Rashid",
//           avatar:
//             "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Abu Dhabi",
//         propertyType: "Townhouse",
//         price: "AED 3,600,000",
//         period: "Yearly",
//         description: "3 Beds Townhouse For Rent in Golf Gardens",
//         postedDate: "20 Aug 2025",
//         address: "Yas Island, Golf Gardens, Abu Dhabi",
//         beds: 3,
//         baths: 3,
//         area: "1850 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//     ],
//     Dubai: [
//       {
//         id: 4,
//         tag: "Apartment",
//         agent: {
//           name: "Sarah Johnson",
//           avatar:
//             "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Dubai",
//         propertyType: "Apartment",
//         price: "AED 5,800,000",
//         period: "Yearly",
//         description: "2 Beds Apartment For Rent in Downtown Dubai",
//         postedDate: "28 Aug 2025",
//         address: "Al Habtoor City, Downtown Apartments, near Jumeirah, Dubai",
//         beds: 2,
//         baths: 2,
//         area: "1400 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 5,
//         tag: "Villa",
//         agent: {
//           name: "Michael Chen",
//           avatar:
//             "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Dubai",
//         propertyType: "Villa",
//         price: "AED 8,500,000",
//         period: "Yearly",
//         description: "5 Beds Villa For Rent in Palm Jumeirah",
//         postedDate: "25 Aug 2025",
//         address: "Palm Jumeirah, Frond M, Dubai",
//         beds: 5,
//         baths: 4,
//         area: "4200 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 6,
//         tag: "Penthouse",
//         agent: {
//           name: "Priya Sharma",
//           avatar:
//             "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Dubai",
//         propertyType: "Penthouse",
//         price: "AED 12,000,000",
//         period: "Yearly",
//         description: "Penthouse For Rent in Burj Khalifa District",
//         postedDate: "30 Aug 2025",
//         address: "Burj Khalifa District, Downtown Dubai",
//         beds: 3,
//         baths: 4,
//         area: "3200 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//     ],
//     Sharjah: [
//       {
//         id: 7,
//         tag: "Townhouse",
//         agent: {
//           name: "Mohammed Hassan",
//           avatar:
//             "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Sharjah",
//         propertyType: "Townhouse",
//         price: "AED 2,800,000",
//         period: "Yearly",
//         description: "3 Beds Townhouse For Rent in Al Zahia",
//         postedDate: "22 Aug 2025",
//         address: "Al Zahia, Sharjah Waterfront City, Sharjah",
//         beds: 3,
//         baths: 3,
//         area: "1650 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 8,
//         tag: "Apartment",
//         agent: {
//           name: "Aisha Al-Mansoori",
//           avatar:
//             "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Sharjah",
//         propertyType: "Apartment",
//         price: "AED 1,500,000",
//         period: "Yearly",
//         description: "2 Beds Apartment For Rent in Al Khan Area",
//         postedDate: "26 Aug 2025",
//         address: "Al Khan Area, Sharjah Corniche Residences",
//         beds: 2,
//         baths: 2,
//         area: "950 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 9,
//         tag: "Villa",
//         agent: {
//           name: "Khalid Rahman",
//           avatar:
//             "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Sharjah",
//         propertyType: "Villa",
//         price: "AED 4,200,000",
//         period: "Yearly",
//         description: "4 Beds Villa For Rent in Heritage Village",
//         postedDate: "29 Aug 2025",
//         address: "Al Qasimia, Heritage Village, Sharjah",
//         beds: 4,
//         baths: 3,
//         area: "2400 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//     ],
//     "Ras Al Khaimah": [
//       {
//         id: 10,
//         tag: "Penthouse",
//         agent: {
//           name: "Fatima Al-Zahra",
//           avatar:
//             "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Ras Al Khaimah",
//         propertyType: "Penthouse",
//         price: "AED 3,500,000",
//         period: "Yearly",
//         description: "Penthouse For Rent in Al Marjan Island",
//         postedDate: "10 Sep 2025",
//         address: "Al Marjan Island, Ras Al Khaimah Marina, RAK",
//         beds: 3,
//         baths: 3,
//         area: "2200 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 11,
//         tag: "Villa",
//         agent: {
//           name: "Hassan Al-Qasimi",
//           avatar:
//             "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Ras Al Khaimah",
//         propertyType: "Villa",
//         price: "AED 2,200,000",
//         period: "Yearly",
//         description: "3 Beds Villa For Rent in Al Hamra Village",
//         postedDate: "05 Sep 2025",
//         address: "Al Hamra Village, Beachfront Villas, RAK",
//         beds: 3,
//         baths: 2,
//         area: "1800 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//       {
//         id: 12,
//         tag: "Apartment",
//         agent: {
//           name: "Nadia Khalil",
//           avatar:
//             "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
//         },
//         location: "Ras Al Khaimah",
//         propertyType: "Apartment",
//         price: "AED 950,000",
//         period: "Yearly",
//         description: "Studio Apartment For Rent in Resort Residences",
//         postedDate: "08 Sep 2025",
//         address: "Al Marjan Island, Resort Residences, RAK",
//         beds: 0,
//         baths: 1,
//         area: "580 Sq.Ft",
//         image:
//           "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
//       },
//     ],
//   };

//   // Get current properties based on active tab
//   const currentProperties = locationData[activeTab] || [];

//   // Toggle like for specific property
//   const toggleLike = (propertyId) => {
//     setLikedProperties((prev) => ({
//       ...prev,
//       [propertyId]: !prev[propertyId],
//     }));
//   };

//   // Dynamic content based on selected tab
//   const getTabContent = (tab) => {
//     switch (tab) {
//       case "Buy":
//         return {
//           searchPlaceholder: "City, community or building",
//           propertyTypeOptions: [
//             { value: "apartment", label: "Apartment" },
//             { value: "villa", label: "Villa" },
//             { value: "townhouse", label: "Townhouse" },
//             { value: "penthouse", label: "Penthouse" },
//             { value: "plot", label: "Plot/Land" },
//           ],
//           bedsLabel: "Beds & Baths",
//           bedsOptions: [
//             { value: "1-bed", label: "1 Bed" },
//             { value: "2-bed", label: "2 Beds" },
//             { value: "3-bed", label: "3 Beds" },
//             { value: "4-bed", label: "4+ Beds" },
//             { value: "studio", label: "Studio" },
//           ],
//         };
//       case "Rent":
//         return {
//           searchPlaceholder: "City, community or building",
//           propertyTypeOptions: [
//             { value: "apartment", label: "Apartment" },
//             { value: "villa", label: "Villa" },
//             { value: "studio", label: "Studio" },
//             { value: "shared", label: "Shared Space" },
//             { value: "office", label: "Office Space" },
//           ],
//           bedsLabel: "Beds & Baths",
//           bedsOptions: [
//             { value: "1-bed", label: "1 Bed" },
//             { value: "2-bed", label: "2 Beds" },
//             { value: "3-bed", label: "3 Beds" },
//             { value: "4-bed", label: "4+ Beds" },
//             { value: "studio", label: "Studio" },
//           ],
//         };
//       case "New projects":
//         return {
//           searchPlaceholder: "Location, Project, Developer",
//           propertyTypeOptions: [
//             { value: "residential", label: "Residential" },
//             { value: "mixed-use", label: "Mixed Use" },
//             { value: "luxury", label: "Luxury" },
//             { value: "affordable", label: "Affordable Housing" },
//           ],
//           bedsLabel: "Bedrooms",
//           bedsOptions: [
//             { value: "1-bedroom", label: "1 Bedroom" },
//             { value: "2-bedroom", label: "2 Bedrooms" },
//             { value: "3-bedroom", label: "3 Bedrooms" },
//             { value: "4-bedroom", label: "4+ Bedrooms" },
//           ],
//         };
//       case "Commercial":
//         return {
//           searchPlaceholder: "City, community or building",
//           propertyTypeOptions: [
//             { value: "office", label: "Office Space" },
//             { value: "retail", label: "Retail Space" },
//             { value: "warehouse", label: "Warehouse" },
//             { value: "industrial", label: "Industrial" },
//             { value: "coworking", label: "Co-working Space" },
//           ],
//           bedsLabel: "Area (sqft)",
//           bedsOptions: [
//             { value: "500-1000", label: "500-1000 sqft" },
//             { value: "1000-2000", label: "1000-2000 sqft" },
//             { value: "2000-5000", label: "2000-5000 sqft" },
//             { value: "5000+", label: "5000+ sqft" },
//           ],
//         };
//       default:
//         return {
//           searchPlaceholder: "City, community or building",
//           propertyTypeOptions: [],
//           bedsLabel: "Beds & Baths",
//           bedsOptions: [],
//         };
//     }
//   };

//   const currentContent = getTabContent(selectedTab);

//   const togglePropertyTypeDropdown = () => {
//     setIsPropertyTypeDropdownOpen(!isPropertyTypeDropdownOpen);
//     setIsBedsDropdownOpen(false);
//   };

//   const toggleBedsDropdown = () => {
//     setIsBedsDropdownOpen(!isBedsDropdownOpen);
//     setIsPropertyTypeDropdownOpen(false);
//   };

//   const handlePropertyTypeSelect = (option) => {
//     setSelectedPropertyType(option.label);
//     setIsPropertyTypeDropdownOpen(false);
//   };

//   const handleBedsSelect = (option) => {
//     setSelectedBeds(option.label);
//     setIsBedsDropdownOpen(false);
//   };

//   const handleTabChange = (tab) => {
//     setSelectedTab(tab);
//     setSelectedPropertyType("");
//     setSelectedBeds("");
//     setIsPropertyTypeDropdownOpen(false);
//     setIsBedsDropdownOpen(false);
//   };

//   const popularSearches = [
//     "Furnished Properties for rent in UAE",
//     "Offices for rent in UAE",
//     "Warehouses for rent in UAE",
//     "Shops for rent in UAE",
//     "Business Centres for rent in UAE",
//     "Retail Spaces for rent in UAE",
//     "Properties for rent in UAE monthly",
//     "Furnished Properties for rent in UAE monthly",
//   ];

//   const nearbyAreas = [
//     "Properties for rent in Dubai",
//     "Properties for rent in Sharjah",
//     "Properties for rent in Ajman",
//     "Properties for rent in Umm Al Quwain",
//     "Properties for rent in Abu Dhabi",
//   ];

//   const propertiesForSale = ["Properties for sale in UAE"];

//   return (
//     <div className="min-h-screen">
//       <Header />
//       <Navbar />

//       {/* Hero Section with Search Form */}
//       <div className="relative">
//         {/* Background Image */}
//         <div className="w-full h-[300px] sm:h-[400px] md:h-[500px] lg:h-[450px] text-white relative overflow-hidden">
//           <img src={searchbg} className="w-full h-full object-cover" alt="" />
//           <div
//             className="absolute inset-0"
//             style={{
//               background:
//                 "linear-gradient(to top, white 5%, rgba(255,255,255,0) 100%)",
//               pointerEvents: "none",
//             }}
//           />
//         </div>

//         {/* Search Form Section - Responsive positioning */}
//         <div className="w-[90%] sm:w-[85%] lg:w-[85%] bg-[#0b154f] z-20 absolute top-[40%] sm:top-[50%] md:top-[60%] lg:top-[40%] left-1/2 transform -translate-x-1/2 rounded-lg px-4 sm:px-6 md:px-10 lg:px-20 py-4 sm:py-6 md:py-8 lg:py-16">
//           {/* Mobile/Tablet: Stack all elements */}
//           <div className="flex flex-col gap-3 sm:gap-4 items-stretch lg:hidden">
//             {/* Location Search Input */}
//             <div className="relative">
//               <input
//                 type="text"
//                 placeholder={currentContent.searchPlaceholder}
//                 className="w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-sm md:placeholder:text-base bg-transparent"
//               />
//               <Search className="absolute right-3 sm:right-4 md:right-6 top-1/2 transform -translate-y-1/2 text-white w-4 h-4 md:w-5 md:h-5" />
//             </div>

//             {/* Property Type Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={togglePropertyTypeDropdown}
//                 className="flex items-center justify-between w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none bg-transparent"
//               >
//                 <span
//                   className={selectedPropertyType ? "text-white" : "text-white"}
//                 >
//                   {selectedPropertyType || "Property type"}
//                 </span>
//                 <ChevronDown
//                   className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
//                     isPropertyTypeDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isPropertyTypeDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2 max-h-48 overflow-y-auto">
//                     {currentContent.propertyTypeOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handlePropertyTypeSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors text-sm"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Beds & Baths Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={toggleBedsDropdown}
//                 className="flex items-center justify-between w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none bg-transparent"
//               >
//                 <span className={selectedBeds ? "text-white" : "text-white"}>
//                   {selectedBeds || currentContent.bedsLabel}
//                 </span>
//                 <ChevronDown
//                   className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
//                     isBedsDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isBedsDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2 max-h-48 overflow-y-auto">
//                     {currentContent.bedsOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handleBedsSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors text-sm"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Search Button */}
//             <button className="bg-white text-[#0b154f] px-6 sm:px-8 md:px-12 py-3 sm:py-4 md:py-5 rounded-xl sm:rounded-2xl font-semibold text-sm md:text-base hover:bg-gray-50 transition-colors">
//               Search
//             </button>
//           </div>

//           {/* Desktop: All elements in same row */}
//           <div className="hidden lg:flex flex-row gap-4 items-stretch">
//             {/* Location Search Input */}
//             <div className="flex-1 relative">
//               <input
//                 type="text"
//                 placeholder={currentContent.searchPlaceholder}
//                 className="w-full px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-lg bg-transparent"
//               />
//               <Search className="absolute right-10 top-1/2 transform -translate-y-1/2 text-white w-5 h-6" />
//             </div>

//             {/* Property Type Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={togglePropertyTypeDropdown}
//                 className="flex items-center justify-between px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
//               >
//                 <span
//                   className={selectedPropertyType ? "text-white" : "text-white"}
//                 >
//                   {selectedPropertyType || "Property type"}
//                 </span>
//                 <ChevronDown
//                   className={`w-5 h-5 text-white transition-transform ml-2 ${
//                     isPropertyTypeDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isPropertyTypeDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2">
//                     {currentContent.propertyTypeOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handlePropertyTypeSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Beds & Baths Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={toggleBedsDropdown}
//                 className="flex items-center justify-between px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
//               >
//                 <span className={selectedBeds ? "text-white" : "text-white"}>
//                   {selectedBeds || currentContent.bedsLabel}
//                 </span>
//                 <ChevronDown
//                   className={`w-5 h-5 text-white transition-transform ml-2 ${
//                     isBedsDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isBedsDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2">
//                     {currentContent.bedsOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handleBedsSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Search Button */}
//             <button className="bg-white text-[#0b154f] px-14 py-3 rounded-2xl font-semibold text-lg hover:bg-gray-50 transition-colors">
//               Search
//             </button>
//           </div>
//         </div>
//       </div>

//       {/* Content Section */}
//       <div className="bg-white pt-24 sm:pt-34 md:pt-50 lg:pt-0">
//         {/* Header Section - Responsive layout */}
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
//           <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-30 md:gap-40 lg:gap-90 mb-6 lg:mb-8">
//             {/* Back button */}
//             <div className="flex items-center">
//               <button
//                 onClick={() => navigate(-1)}
//                 className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
//               >
//                 <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 mr-1" />
//                 <span className="text-base sm:text-lg font-medium">Back</span>
//               </button>
//             </div>

//             {/* Main heading */}
//             <div className="text-center sm:text-right">
//               <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-[#0B154F]">
//                 Properties for sale in
//               </h1>
//             </div>
//           </div>

//           {/* Location tabs - Horizontal scroll on mobile */}
//           {/* <div className="mb-8 overflow-x-auto">
//             <div className="flex items-center justify-center gap-4 sm:gap-6 md:gap-8 min-w-max px-4">
//               {locations.map((location) => (
//                 <button
//                   key={location}
//                   onClick={() => setActiveTab(location)}
//                   className={`pb-2 text-sm sm:text-base font-medium transition-all duration-200 relative whitespace-nowrap ${
//                     activeTab === location
//                       ? "text-[#0B154F] border-b-2 border-[#0B154F]"
//                       : "text-gray-600 hover:text-gray-800"
//                   }`}
//                 >
//                   {location}
//                 </button>
//               ))}
//             </div>
//           </div> */}
//         </div>

//         {/* Main Content Grid */}
//         <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
//           <div className="flex flex-col xl:flex-row gap-8">
//             {/* Properties List - Takes full width on smaller screens */}
//             <div className="flex-1 xl:w-3/4 space-y-8">
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {properties.map((property) => (
//                   <Link to="/details">
//                     <div
//                       key={property.id}
//                       className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300"
//                     >
//                       {/* Image Section */}
//                       <div className="relative overflow-hidden">
//                         <img
//                           src={`https://propmatez.shop/${property.images}`}
//                           alt={property.name}
//                           className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105 hover:rotate-3"
//                         />

//                         {/* Property Logo */}
//                         <div className="absolute top-3 left-3">
//                             <img src='https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face'
//                               className="w-12 h-12 rounded object-cover" />
//                         </div>

//                         {/* Like Button */}
//                         <button
//                           onClick={() => toggleLike(property.id)}
//                           className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
//                         >
//                           <Heart
//                             className={`w-4 h-4 ${
//                               likedProperties[property.id]
//                                 ? "text-red-500 fill-red-500"
//                                 : "text-gray-400"
//                             }`}
//                           />
//                         </button>
//                       </div>

//                       {/* Content Section */}
//                       <div className="p-4">
//                         {/* Title */}
//                         <h3 className="text-sm text-gray-500 mb-2 line-clamp-2">
//                           {property.name}
//                         </h3>

//                         {/* Price */}
//                         <div className="mb-3">
//                           <div className="flex items-baseline gap-1">
//                             <span className="text-xl font-bold text-gray-900">
//                               {property.expected_price}M AED
//                             </span>
//                             <span className="text-sm text-gray-500">
//                               Yearly
//                             </span>
//                           </div>
//                         </div>

//                         {/* Property Details */}
//                         <div className="flex items-center gap-4 mb-3 text-sm font-bold text-[#0f57d1]">
//                           <div className="flex items-center gap-1">
//                             <Bed className="w-4 h-4" />
//                             <span>{property.bedrooms}</span>
//                           </div>
//                           <div className="flex items-center gap-1">
//                             <Bath className="w-4 h-4" />
//                             <span>{property.bathrooms}</span>
//                           </div>
//                           <div className="flex items-center gap-1">
//                             <Maximize className="w-4 h-4" />
//                             <span>{property.carpet_area} Sq.Ft</span>
//                           </div>
//                         </div>

//                         {/* Location */}
//                         <div className="flex items-start mb-4">
//                           <MapPin className="w-4 h-4 text-[#0B154F] mt-0.5 mr-2 flex-shrink-0" />
//                           <p className="text-xs text-gray-500 leading-relaxed line-clamp-1">
//                             {property.locality} {property.sub_locality} {property.city}
//                           </p>
//                         </div>

//                         {/* Agent and Contact Section */}
//                         <div className="flex items-center justify-between pt-3 border-t border-gray-100">
//                           {/* Agent Info */}
//                            <div className="flex items-center gap-2">
//                             <img
//                               src='https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face'
//                               className="w-8 h-8 rounded-full object-cover"
//                             />
//                             <div>
//                               <span className="text-xs text-gray-700 font-medium">
//                                 Listed by <br />
//                               </span>
//                               <span className="text-sm text-gray-700 font-medium">
//                                 Layla Hassan
//                               </span>
//                             </div>
//                           </div>

//                           {/* Contact Buttons */}
//                           <div className="flex items-center gap-2">
//                             <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
//                               <Phone className="w-4 h-4 text-green-600" />
//                             </button>
//                             <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
//                               <MessageCircle className="w-4 h-4 text-green-600" />
//                             </button>
//                           </div>
//                         </div>
//                       </div>
//                     </div>
//                   </Link>
//                 ))}
//               </div>

//             </div>

//             {/* Sidebar - Hidden on mobile and tablet, shown on desktop */}
//             <div className="hidden xl:block xl:w-1/4">
//               <div className="sticky top-8 space-y-6">
//                 {/* Popular Searches Section */}
//                 <div className="bg-white p-6 rounded-lg border border-gray-200">
//                   <h3 className="text-lg font-semibold text-gray-800 mb-4">
//                     Popular Searches
//                   </h3>
//                   <div className="space-y-3">
//                     {popularSearches.map((search, index) => (
//                       <div key={index}>
//                         <a
//                           href="#"
//                           className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
//                         >
//                           {search}
//                         </a>
//                       </div>
//                     ))}
//                   </div>
//                 </div>

//                 {/* Nearby Areas Section */}
//                 <div className="bg-white p-6 rounded-lg border border-gray-200">
//                   <h3 className="text-lg font-semibold text-gray-800 mb-4">
//                     Nearby Areas
//                   </h3>
//                   <div className="space-y-3">
//                     {nearbyAreas.map((area, index) => (
//                       <div key={index}>
//                         <a
//                           href="#"
//                           className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
//                         >
//                           {area}
//                         </a>
//                       </div>
//                     ))}
//                   </div>
//                 </div>

//                 {/* Properties for Sale Section */}
//                 <div className="bg-white p-6 rounded-lg border border-gray-200">
//                   <h3 className="text-lg font-semibold text-gray-800 mb-4">
//                     Properties for Sale
//                   </h3>
//                   <div className="space-y-3">
//                     {propertiesForSale.map((property, index) => (
//                       <div key={index}>
//                         <a
//                           href="#"
//                           className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
//                         >
//                           {property}
//                         </a>
//                       </div>
//                     ))}
//                   </div>
//                 </div>

//                 {/* Calculator Image */}
//                 <div className="flex justify-center">
//                   <img
//                     src={calc}
//                     alt="Calculator"
//                     className="w-full max-w-[250px] h-auto"
//                   />
//                 </div>
//               </div>
//             </div>
//           </div>
//         </div>
//       </div>

//       <Footer />
//     </div>
//   );
// };

// export default Commercial;

import React, { useEffect, useState } from "react";
import {
  ChevronDown,
  Search,
  ChevronLeft,
  Heart,
  Phone,
  Mail,
  MessageCircle,
  MapPin,
  User,
  Bed,
  Bath,
  Maximize,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import searchbg from "./assets/searchbg.png";
import calc from "./assets/calc.png";
import { Link, useNavigate } from "react-router-dom";

const API_BASE = "https://propmatez.shop";

const Commercial = () => {
  const navigate = useNavigate();
  const [likedProperties, setLikedProperties] = useState({});
  const [selectedTab, setSelectedTab] = useState("Buy");
  const [isPropertyTypeDropdownOpen, setIsPropertyTypeDropdownOpen] =
    useState(false);
  const [isBedsDropdownOpen, setIsBedsDropdownOpen] = useState(false);
  const [selectedPropertyType, setSelectedPropertyType] = useState("");
  const [selectedBeds, setSelectedBeds] = useState("");
  const [activeTab, setActiveTab] = useState("Abu Dhabi");
  const [properties, setproperties] = useState([]);
  const [companyLogos, setCompanyLogos] = useState({});

  const locations = ["Ras Al Khaimah", "Dubai", "Abu Dhabi", "Sharjah"];

  useEffect(() => {
    fetch(`${API_BASE}/api/properties/type/5`)
      .then((res) => res.json())
      .then((data) => {
        setproperties(data);
        console.log(data);
      })
      .catch((err) => console.error("Error fetching countries:", err));
  }, []);

  // Fetch company details when properties change
  useEffect(() => {
    if (!properties || properties.length === 0) return;

    const companyIds = [
      ...new Set(
        properties
          .map((p) => p.company)
          .filter((id) => id !== undefined && id !== null && id !== "")
      ),
    ];

    if (companyIds.length === 0) {
      console.log("No company_id fields found in properties.");
      return;
    }

    const fetchCompanies = async () => {
      for (const id of companyIds) {
        if (companyLogos[id]) {
          console.log(
            `Logo for company ${id} is already cached:`,
            companyLogos[id]
          );
          continue;
        }

        try {
          console.log(`Fetching company ${id}...`);
          const res = await fetch(`${API_BASE}/api/company/${id}`);
          if (!res.ok) {
            console.error(
              `Failed to fetch company ${id} - status: ${res.status}`
            );
            continue;
          }

          const data = await res.json();
          console.log(`Fetched company ${id}:`, data);

          const company = Array.isArray(data) ? data[0] : data;
          let logoUrl = company?.image || "";
          console.log(`Company ${id} logo path:`, logoUrl);

          if (logoUrl && !/^https?:\/\//i.test(logoUrl)) {
            logoUrl = `${API_BASE}/${logoUrl.replace(/^\/+/, "")}`;
          }

          setCompanyLogos((prev) => ({ ...prev, [id]: logoUrl }));
        } catch (err) {
          console.error(`Error fetching company ${id}:`, err);
        }
      }
    };

    fetchCompanies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [properties]);

  // Get logo for property
  const getLogoForProperty = (property) => {
    const companyLogo = property.company
      ? companyLogos[property.company]
      : null;
    if (companyLogo) return companyLogo;

    if (property.logo) {
      return /^https?:\/\//i.test(property.logo)
        ? property.logo
        : `${API_BASE}/${String(property.logo).replace(/^\/+/, "")}`;
    }

    // Return a default fallback image
    return "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face";
  };

  // Multiple properties per location
  const locationData = {
    "Abu Dhabi": [
      {
        id: 1,
        tag: "Villa",
        agent: {
          name: "Ahmed Al-Mansouri",
          avatar:
            "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
        },
        location: "Abu Dhabi",
        propertyType: "Villa",
        price: "AED 4,200,000",
        period: "Yearly",
        description: "4 Beds Villa For Rent in Al Raha Beach",
        postedDate: "15 Aug 2025",
        address: "Al Raha Beach, Mudon Community, Abu Dhabi",
        beds: 4,
        baths: 3,
        area: "2850 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 2,
        tag: "Apartment",
        agent: {
          name: "Layla Hassan",
          avatar:
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
        },
        location: "Abu Dhabi",
        propertyType: "Apartment",
        price: "AED 2,800,000",
        period: "Yearly",
        description: "2 Beds Apartment For Rent in Marina Square",
        postedDate: "18 Aug 2025",
        address: "Corniche Area, Marina Square, Abu Dhabi",
        beds: 2,
        baths: 2,
        area: "1200 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 3,
        tag: "Townhouse",
        agent: {
          name: "Omar Al-Rashid",
          avatar:
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
        },
        location: "Abu Dhabi",
        propertyType: "Townhouse",
        price: "AED 3,600,000",
        period: "Yearly",
        description: "3 Beds Townhouse For Rent in Golf Gardens",
        postedDate: "20 Aug 2025",
        address: "Yas Island, Golf Gardens, Abu Dhabi",
        beds: 3,
        baths: 3,
        area: "1850 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
    ],
    Dubai: [
      {
        id: 4,
        tag: "Apartment",
        agent: {
          name: "Sarah Johnson",
          avatar:
            "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
        },
        location: "Dubai",
        propertyType: "Apartment",
        price: "AED 5,800,000",
        period: "Yearly",
        description: "2 Beds Apartment For Rent in Downtown Dubai",
        postedDate: "28 Aug 2025",
        address: "Al Habtoor City, Downtown Apartments, near Jumeirah, Dubai",
        beds: 2,
        baths: 2,
        area: "1400 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 5,
        tag: "Villa",
        agent: {
          name: "Michael Chen",
          avatar:
            "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face",
        },
        location: "Dubai",
        propertyType: "Villa",
        price: "AED 8,500,000",
        period: "Yearly",
        description: "5 Beds Villa For Rent in Palm Jumeirah",
        postedDate: "25 Aug 2025",
        address: "Palm Jumeirah, Frond M, Dubai",
        beds: 5,
        baths: 4,
        area: "4200 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 6,
        tag: "Penthouse",
        agent: {
          name: "Priya Sharma",
          avatar:
            "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=40&h=40&fit=crop&crop=face",
        },
        location: "Dubai",
        propertyType: "Penthouse",
        price: "AED 12,000,000",
        period: "Yearly",
        description: "Penthouse For Rent in Burj Khalifa District",
        postedDate: "30 Aug 2025",
        address: "Burj Khalifa District, Downtown Dubai",
        beds: 3,
        baths: 4,
        area: "3200 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
    ],
    Sharjah: [
      {
        id: 7,
        tag: "Townhouse",
        agent: {
          name: "Mohammed Hassan",
          avatar:
            "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
        },
        location: "Sharjah",
        propertyType: "Townhouse",
        price: "AED 2,800,000",
        period: "Yearly",
        description: "3 Beds Townhouse For Rent in Al Zahia",
        postedDate: "22 Aug 2025",
        address: "Al Zahia, Sharjah Waterfront City, Sharjah",
        beds: 3,
        baths: 3,
        area: "1650 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1568605114967-8130f3a36994?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 8,
        tag: "Apartment",
        agent: {
          name: "Aisha Al-Mansoori",
          avatar:
            "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=40&h=40&fit=crop&crop=face",
        },
        location: "Sharjah",
        propertyType: "Apartment",
        price: "AED 1,500,000",
        period: "Yearly",
        description: "2 Beds Apartment For Rent in Al Khan Area",
        postedDate: "26 Aug 2025",
        address: "Al Khan Area, Sharjah Corniche Residences",
        beds: 2,
        baths: 2,
        area: "950 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 9,
        tag: "Villa",
        agent: {
          name: "Khalid Rahman",
          avatar:
            "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
        },
        location: "Sharjah",
        propertyType: "Villa",
        price: "AED 4,200,000",
        period: "Yearly",
        description: "4 Beds Villa For Rent in Heritage Village",
        postedDate: "29 Aug 2025",
        address: "Al Qasimia, Heritage Village, Sharjah",
        beds: 4,
        baths: 3,
        area: "2400 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
    ],
    "Ras Al Khaimah": [
      {
        id: 10,
        tag: "Penthouse",
        agent: {
          name: "Fatima Al-Zahra",
          avatar:
            "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face",
        },
        location: "Ras Al Khaimah",
        propertyType: "Penthouse",
        price: "AED 3,500,000",
        period: "Yearly",
        description: "Penthouse For Rent in Al Marjan Island",
        postedDate: "10 Sep 2025",
        address: "Al Marjan Island, Ras Al Khaimah Marina, RAK",
        beds: 3,
        baths: 3,
        area: "2200 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 11,
        tag: "Villa",
        agent: {
          name: "Hassan Al-Qasimi",
          avatar:
            "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
        },
        location: "Ras Al Khaimah",
        propertyType: "Villa",
        price: "AED 2,200,000",
        period: "Yearly",
        description: "3 Beds Villa For Rent in Al Hamra Village",
        postedDate: "05 Sep 2025",
        address: "Al Hamra Village, Beachfront Villas, RAK",
        beds: 3,
        baths: 2,
        area: "1800 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1613977257363-707ba9348227?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
      {
        id: 12,
        tag: "Apartment",
        agent: {
          name: "Nadia Khalil",
          avatar:
            "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
        },
        location: "Ras Al Khaimah",
        propertyType: "Apartment",
        price: "AED 950,000",
        period: "Yearly",
        description: "Studio Apartment For Rent in Resort Residences",
        postedDate: "08 Sep 2025",
        address: "Al Marjan Island, Resort Residences, RAK",
        beds: 0,
        baths: 1,
        area: "580 Sq.Ft",
        image:
          "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=1000&q=80",
      },
    ],
  };

  // Get current properties based on active tab
  const currentProperties = locationData[activeTab] || [];

  // Toggle like for specific property
  const toggleLike = (propertyId) => {
    setLikedProperties((prev) => ({
      ...prev,
      [propertyId]: !prev[propertyId],
    }));
  };

  // Dynamic content based on selected tab
  const getTabContent = (tab) => {
    switch (tab) {
      case "Buy":
        return {
          searchPlaceholder: "Search",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "townhouse", label: "Townhouse" },
            { value: "penthouse", label: "Penthouse" },
            { value: "plot", label: "Plot/Land" },
          ],
          bedsLabel: "Beds & Baths",
          bedsOptions: [
            { value: "1-bed", label: "1 Bed" },
            { value: "2-bed", label: "2 Beds" },
            { value: "3-bed", label: "3 Beds" },
            { value: "4-bed", label: "4+ Beds" },
            { value: "studio", label: "Studio" },
          ],
        };
      case "Rent":
        return {
          searchPlaceholder: "City, community or building",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "studio", label: "Studio" },
            { value: "shared", label: "Shared Space" },
            { value: "office", label: "Office Space" },
          ],
          bedsLabel: "Beds & Baths",
          bedsOptions: [
            { value: "1-bed", label: "1 Bed" },
            { value: "2-bed", label: "2 Beds" },
            { value: "3-bed", label: "3 Beds" },
            { value: "4-bed", label: "4+ Beds" },
            { value: "studio", label: "Studio" },
          ],
        };
      case "New projects":
        return {
          searchPlaceholder: "Location, Project, Developer",
          propertyTypeOptions: [
            { value: "residential", label: "Residential" },
            { value: "mixed-use", label: "Mixed Use" },
            { value: "luxury", label: "Luxury" },
            { value: "affordable", label: "Affordable Housing" },
          ],
          bedsLabel: "Bedrooms",
          bedsOptions: [
            { value: "1-bedroom", label: "1 Bedroom" },
            { value: "2-bedroom", label: "2 Bedrooms" },
            { value: "3-bedroom", label: "3 Bedrooms" },
            { value: "4-bedroom", label: "4+ Bedrooms" },
          ],
        };
      case "Commercial":
        return {
          searchPlaceholder: "City, community or building",
          propertyTypeOptions: [
            { value: "office", label: "Office Space" },
            { value: "retail", label: "Retail Space" },
            { value: "warehouse", label: "Warehouse" },
            { value: "industrial", label: "Industrial" },
            { value: "coworking", label: "Co-working Space" },
          ],
          bedsLabel: "Area (sqft)",
          bedsOptions: [
            { value: "500-1000", label: "500-1000 sqft" },
            { value: "1000-2000", label: "1000-2000 sqft" },
            { value: "2000-5000", label: "2000-5000 sqft" },
            { value: "5000+", label: "5000+ sqft" },
          ],
        };
      default:
        return {
          searchPlaceholder: "City, community or building",
          propertyTypeOptions: [],
          bedsLabel: "Beds & Baths",
          bedsOptions: [],
        };
    }
  };

  const currentContent = getTabContent(selectedTab);

  const togglePropertyTypeDropdown = () => {
    setIsPropertyTypeDropdownOpen(!isPropertyTypeDropdownOpen);
    setIsBedsDropdownOpen(false);
  };

  const toggleBedsDropdown = () => {
    setIsBedsDropdownOpen(!isBedsDropdownOpen);
    setIsPropertyTypeDropdownOpen(false);
  };

  const handlePropertyTypeSelect = (option) => {
    setSelectedPropertyType(option.label);
    setIsPropertyTypeDropdownOpen(false);
  };

  const handleBedsSelect = (option) => {
    setSelectedBeds(option.label);
    setIsBedsDropdownOpen(false);
  };

  const handleTabChange = (tab) => {
    setSelectedTab(tab);
    setSelectedPropertyType("");
    setSelectedBeds("");
    setIsPropertyTypeDropdownOpen(false);
    setIsBedsDropdownOpen(false);
  };

  const popularSearches = [
    "Furnished Properties for rent in UAE",
    "Offices for rent in UAE",
    "Warehouses for rent in UAE",
    "Shops for rent in UAE",
    "Business Centres for rent in UAE",
    "Retail Spaces for rent in UAE",
    "Properties for rent in UAE monthly",
    "Furnished Properties for rent in UAE monthly",
  ];

  const nearbyAreas = [
    "Properties for rent in Dubai",
    "Properties for rent in Sharjah",
    "Properties for rent in Ajman",
    "Properties for rent in Umm Al Quwain",
    "Properties for rent in Abu Dhabi",
  ];

  const propertiesForSale = ["Properties for sale in UAE"];

  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Section with Search Form */}
      <div className="relative">
        {/* Background Image */}
        <div className="w-full h-[100px] sm:h-[100px] md:h-[200px] lg:h-[200px] text-white relative overflow-hidden">
          <img src={searchbg} className="w-full h-full object-cover" alt="" />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, white 5%, rgba(255,255,255,0) 100%)",
              pointerEvents: "none",
            }}
          />
        </div>

        {/* Search Form Section - Responsive positioning */}
        {/* <div className="w-[90%] sm:w-[85%] lg:w-[85%] bg-[#0b154f] z-20 absolute top-[40%] sm:top-[50%] md:top-[60%] lg:top-[40%] left-1/2 transform -translate-x-1/2 rounded-lg px-4 sm:px-6 md:px-10 lg:px-20 py-4 sm:py-6 md:py-8 lg:py-16">
         
          <div className="flex flex-col gap-3 sm:gap-4 items-stretch lg:hidden">
           
            <div className="relative">
              <input
                type="text"
                placeholder={currentContent.searchPlaceholder}
                className="w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-sm md:placeholder:text-base bg-transparent"
              />
              <Search className="absolute right-3 sm:right-4 md:right-6 top-1/2 transform -translate-y-1/2 text-white w-4 h-4 md:w-5 md:h-5" />
            </div>

          
            <div className="relative">
              <button
                onClick={togglePropertyTypeDropdown}
                className="flex items-center justify-between w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none bg-transparent"
              >
                <span
                  className={selectedPropertyType ? "text-white" : "text-white"}
                >
                  {selectedPropertyType || "Property type"}
                </span>
                <ChevronDown
                  className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
                    isPropertyTypeDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isPropertyTypeDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2 max-h-48 overflow-y-auto">
                    {currentContent.propertyTypeOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handlePropertyTypeSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors text-sm"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

           
            <div className="relative">
              <button
                onClick={toggleBedsDropdown}
                className="flex items-center justify-between w-full px-3 sm:px-4 md:px-6 py-3 sm:py-4 md:py-5 text-white text-sm md:text-base rounded-xl sm:rounded-2xl border-2 border-white focus:outline-none bg-transparent"
              >
                <span className={selectedBeds ? "text-white" : "text-white"}>
                  {selectedBeds || currentContent.bedsLabel}
                </span>
                <ChevronDown
                  className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
                    isBedsDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isBedsDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2 max-h-48 overflow-y-auto">
                    {currentContent.bedsOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handleBedsSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors text-sm"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

           
            <button className="bg-white text-[#0b154f] px-6 sm:px-8 md:px-12 py-3 sm:py-4 md:py-5 rounded-xl sm:rounded-2xl font-semibold text-sm md:text-base hover:bg-gray-50 transition-colors">
              Search
            </button>
          </div>

        
          <div className="hidden lg:flex flex-row gap-4 items-stretch justify-center">
         
            <div className=" relative min-w-[200px]">
              <input
                type="text"
                placeholder={currentContent.searchPlaceholder}
                className="w-full px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-base bg-transparent"
              />
              <Search className="absolute right-10 top-1/2 transform -translate-y-1/2 text-white w-5 h-5" />
            </div>

            
            <div className="relative">
              <button
                onClick={togglePropertyTypeDropdown}
                className="flex items-center justify-between px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
              >
                <span
                  className={selectedPropertyType ? "text-white" : "text-white"}
                >
                  {selectedPropertyType || "Property type"}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-white transition-transform ml-2 ${
                    isPropertyTypeDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isPropertyTypeDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2">
                    {currentContent.propertyTypeOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handlePropertyTypeSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

     
            <div className="relative">
              <button
                onClick={toggleBedsDropdown}
                className="flex items-center justify-between px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
              >
                <span className={selectedBeds ? "text-white" : "text-white"}>
                  {selectedBeds || currentContent.bedsLabel}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-white transition-transform ml-2 ${
                    isBedsDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isBedsDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2">
                    {currentContent.bedsOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handleBedsSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

          
            <button className="bg-white text-[#0b154f] px-14 py-3 rounded-2xl font-semibold text-lg hover:bg-gray-50 transition-colors">
              Search
            </button>
          </div>
        </div> */}
      </div>

      {/* Content Section */}
      <div className="bg-white">
        {/* Header Section - Responsive layout */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-30 md:gap-40 lg:gap-90 mb-6 lg:mb-8">
            {/* Back button */}
            <div className="flex items-center">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 mr-1" />
                <span className="text-base sm:text-lg font-medium">Back</span>
              </button>
            </div>

            {/* Main heading */}
            <div className="text-center sm:text-right">
              <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-[#0B154F]">
                Properties for sale in
              </h1>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <div className="flex flex-col xl:flex-row gap-8">
            {/* Properties List - Takes full width on smaller screens */}
            <div className="flex-1 xl:w-3/4 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {properties.map((property) => (
                  <Link key={property.id} to={`/details/${property.id}`}>
                    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300">
                      {/* Image Section */}
                      <div className="relative overflow-hidden">
                        <img
                          src={`${API_BASE}/${property.images}`}
                          alt={property.name}
                          className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105 hover:rotate-3"
                        />

                        {/* Property Logo */}
                        <div className="absolute top-3 left-3">
                          <img
                            src={getLogoForProperty(property)}
                            alt={`${property.name} logo`}
                            className="w-12 h-12 rounded object-cover"
                            onError={(e) => {
                              e.currentTarget.src =
                                "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face";
                            }}
                          />
                        </div>

                        {/* Like Button */}
                        <button
                          onClick={() => toggleLike(property.id)}
                          className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
                        >
                          <Heart
                            className={`w-4 h-4 ${
                              likedProperties[property.id]
                                ? "text-red-500 fill-red-500"
                                : "text-gray-400"
                            }`}
                          />
                        </button>
                      </div>

                      {/* Content Section */}
                      <div className="p-4">
                        {/* Title */}
                        <h3 className="text-sm text-gray-500 mb-2 line-clamp-2">
                          {property.name}
                        </h3>

                        {/* Price */}
                        <div className="mb-3">
                          <div className="flex items-baseline gap-1">
                            <span className="text-xl font-bold text-gray-900">
                              {property.expected_price}M AED
                            </span>
                            <span className="text-sm text-gray-500">
                              Yearly
                            </span>
                          </div>
                        </div>

                        {/* Property Details */}
                        <div className="flex items-center gap-4 mb-3 text-sm font-bold text-[#0f57d1]">
                          <div className="flex items-center gap-1">
                            <Bed className="w-4 h-4" />
                            <span>{property.bedrooms}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Bath className="w-4 h-4" />
                            <span>{property.bathrooms}</span>
                          </div>
                          <div className="flex items-center gap-1">
                            <Maximize className="w-4 h-4" />
                            <span>{property.carpet_area} Sq.Ft</span>
                          </div>
                        </div>

                        {/* Location */}
                        <div className="flex items-start mb-4">
                          <MapPin className="w-4 h-4 text-[#0B154F] mt-0.5 mr-2 flex-shrink-0" />
                          <p className="text-xs text-gray-500 leading-relaxed line-clamp-1">
                            {property.locality} {property.sub_locality}{" "}
                            {property.city}
                          </p>
                        </div>

                        {/* Agent and Contact Section */}
                        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                          {/* Agent Info */}
                          <div className="flex items-center gap-2">
                            <img
                              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
                              className="w-8 h-8 rounded-full object-cover"
                            />
                            <div>
                              <span className="text-xs text-gray-700 font-medium">
                                Listed by <br />
                              </span>
                              <span className="text-sm text-gray-700 font-medium">
                                Layla Hassan
                              </span>
                            </div>
                          </div>

                          {/* Contact Buttons */}
                          <div className="flex items-center gap-2">
                            <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
                              <Phone className="w-4 h-4 text-green-600" />
                            </button>
                            <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
                              <MessageCircle className="w-4 h-4 text-green-600" />
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {properties.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500 text-lg">
                    No properties available
                  </p>
                </div>
              )}
            </div>

            {/* Sidebar - Hidden on mobile and tablet, shown on desktop */}
            <div className="hidden xl:block xl:w-1/4">
              <div className="sticky top-8 space-y-6">
                {/* Popular Searches Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Popular Searches
                  </h3>
                  <div className="space-y-3">
                    {popularSearches.map((search, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {search}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Nearby Areas Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Nearby Areas
                  </h3>
                  <div className="space-y-3">
                    {nearbyAreas.map((area, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {area}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Properties for Sale Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Properties for Sale
                  </h3>
                  <div className="space-y-3">
                    {propertiesForSale.map((property, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {property}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Calculator Image */}
                <div className="flex justify-center">
                  <img
                    src={calc}
                    alt="Calculator"
                    className="w-full max-w-[250px] h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Commercial;
