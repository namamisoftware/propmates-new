// import React, { useState, useEffect, useRef } from "react";
// import { ChevronLeft, ChevronRight } from "lucide-react";

// const RealEstateDevelopers = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [isAutoPlaying, setIsAutoPlaying] = useState(true);
//   const scrollContainerRef = useRef(null);
//   const intervalRef = useRef(null);

//   const developers = [
//     {
//       name: "EMAAR",
//       logo: "EMAAR",
//       description: "Emaar Properties",
//       style: "text-2xl font-bold text-gray-800",
//     },
//     {
//       name: "AZIZI",
//       logo: "AZIZI",
//       description: "Azizi Developments",
//       style: "text-xl font-medium text-blue-600",
//     },
//     {
//       name: "ALDAR",
//       logo: "ALDAR",
//       description: "Aldar Properties PJSC",
//       style: "text-xl font-bold text-gray-900",
//     },
//     {
//       name: "DAMAC",
//       logo: "DAMAC",
//       description: "Damac Properties",
//       style: "text-xl font-bold text-gray-800",
//     },
//     {
//       name: "SOBHA",
//       logo: "SOBHA",
//       description: "Sobha Realty",
//       style: "text-xl font-bold text-gray-800",
//     },
//     {
//       name: "MERAAS",
//       logo: "MERAAS",
//       description: "Meraas Holding",
//       style: "text-xl font-bold text-gray-800",
//     },
//   ];

//   // Triple the developers for seamless infinite scroll
//   const duplicatedDevelopers = [...developers, ...developers, ...developers];

//   const startAutoScroll = () => {
//     if (intervalRef.current) {
//       clearInterval(intervalRef.current);
//     }

//     intervalRef.current = setInterval(() => {
//       if (scrollContainerRef.current && isAutoPlaying) {
//         const container = scrollContainerRef.current;
//         const scrollAmount = 1; // pixels to scroll each time

//         container.scrollLeft += scrollAmount;

//         // Calculate when to reset (when we've scrolled past the first set)
//         const maxScrollLeft = container.scrollWidth / 3; // Since we have 3 sets

//         if (container.scrollLeft >= maxScrollLeft) {
//           container.scrollLeft = 0;
//         }
//       }
//     }, 16); // ~60fps
//   };

//   const stopAutoScroll = () => {
//     if (intervalRef.current) {
//       clearInterval(intervalRef.current);
//       intervalRef.current = null;
//     }
//   };

//   const scrollToIndex = (index) => {
//     if (scrollContainerRef.current) {
//       const container = scrollContainerRef.current;
//       const cardWidth = 200; // approximate card width
//       const gap = 24;
//       const scrollAmount = (cardWidth + gap) * index;

//       container.scrollTo({
//         left: scrollAmount,
//         behavior: "smooth",
//       });
//       setCurrentIndex(index);
//     }
//   };

//   const handlePrevious = () => {
//     const newIndex =
//       currentIndex > 0 ? currentIndex - 1 : developers.length - 1;
//     scrollToIndex(newIndex);
//     setIsAutoPlaying(false);
//     setTimeout(() => setIsAutoPlaying(true), 3000);
//   };

//   const handleNext = () => {
//     const newIndex =
//       currentIndex < developers.length - 1 ? currentIndex + 1 : 0;
//     scrollToIndex(newIndex);
//     setIsAutoPlaying(false);
//     setTimeout(() => setIsAutoPlaying(true), 3000);
//   };

//   // Auto-scroll effect
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       if (isAutoPlaying) {
//         startAutoScroll();
//       } else {
//         stopAutoScroll();
//       }
//     }, 1000);

//     return () => {
//       clearTimeout(timer);
//       stopAutoScroll();
//     };
//   }, [isAutoPlaying]);

//   // Initial start
//   useEffect(() => {
//     const timer = setTimeout(() => {
//       startAutoScroll();
//     }, 2000);

//     return () => {
//       clearTimeout(timer);
//       stopAutoScroll();
//     };
//   }, []);

//   // Pause on hover
//   const handleMouseEnter = () => {
//     setIsAutoPlaying(false);
//   };

//   const handleMouseLeave = () => {
//     setIsAutoPlaying(true);
//   };

//   return (
//     <div className="bg-white py-4 sm:py-6 lg:py-8 px-4 sm:px-6 lg:px-12 max-w-8xl mx-auto">
//       {/* Section Title */}
//       <div className="text-center mb-6 sm:mb-8 lg:mb-12">
//         <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-2 px-4">
//           Real Estate Developers in UAE
//         </h2>
//       </div>

//       {/* Developer Carousel */}
//       <div className="relative">
//         {/* Left Arrow */}
//         <button
//           onClick={handlePrevious}
//           className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 -ml-4 sm:-ml-6"
//           aria-label="Previous developer"
//         >
//           <ChevronLeft className="w-6 h-6 text-gray-600" />
//         </button>

//         {/* Right Arrow */}
//         <button
//           onClick={handleNext}
//           className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 -mr-4 sm:-mr-6"
//           aria-label="Next developer"
//         >
//           <ChevronRight className="w-6 h-6 text-gray-600" />
//         </button>

//         {/* Developers Scroll Container */}
//         <div
//           ref={scrollContainerRef}
//           className="flex gap-6 overflow-x-auto scrollbar-hide pb-4"
//           style={{
//             scrollbarWidth: "none",
//             msOverflowStyle: "none",
//           }}
//           onMouseEnter={handleMouseEnter}
//           onMouseLeave={handleMouseLeave}
//         >
//           {duplicatedDevelopers.map((developer, index) => (
//             <div
//               key={`${developer.name}-${index}`}
//               className="flex flex-col items-center group cursor-pointer transform transition-all duration-300 hover:scale-105 flex-shrink-0 w-32 sm:w-40 lg:w-48"
//             >
//               {/* Logo Container */}
//               <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 bg-white rounded-lg shadow-md border border-gray-100 flex items-center justify-center mb-3 sm:mb-4 lg:mb-5 group-hover:shadow-lg transition-all duration-300">
//                 {developer.name === "ALDAR" ? (
//                   <div className="w-14 h-14 sm:w-16 sm:h-16 lg:w-18 lg:h-18 bg-black rounded-sm flex items-center justify-center">
//                     <span className="text-white font-bold text-sm sm:text-base">
//                       ALDAR
//                     </span>
//                   </div>
//                 ) : developer.name === "AZIZI" ? (
//                   <div className="flex items-center">
//                     <div className="w-2 h-7 sm:w-2 sm:h-8 lg:w-2 lg:h-9 bg-blue-600 mr-1"></div>
//                     <span className={`${developer.style} text-xl sm:text-2xl`}>
//                       {developer.logo}
//                     </span>
//                   </div>
//                 ) : (
//                   <span
//                     className={`${developer.style} text-xl sm:text-2xl lg:text-3xl`}
//                   >
//                     {developer.logo}
//                   </span>
//                 )}
//               </div>

//               {/* Developer Name */}
//               <p className="text-sm sm:text-base text-gray-700 text-center font-medium hover:text-[#0b154f] transition-colors px-1">
//                 {developer.description}
//               </p>
//             </div>
//           ))}
//         </div>
//       </div>

//       {/* Hide scrollbar styles */}
//       <style jsx>{`
//         .scrollbar-hide {
//           -webkit-overflow-scrolling: touch;
//         }
//         .scrollbar-hide::-webkit-scrollbar {
//           display: none;
//         }
//       `}</style>
//     </div>
//   );
// };

// export default RealEstateDevelopers;

import React, { useState, useEffect, useRef } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { useNavigate } from "react-router-dom";

const RealEstateDevelopers = () => {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const scrollContainerRef = useRef(null);
  const intervalRef = useRef(null);

  const developers = [
    {
      name: "EMAAR",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/79ca4333-9975-4672-b05f-bb7329de75e9/logo/image/SXDm9h3dbO4shNsEGYyX31DwTU98MpFSxR1sEuT7LsE=/original.png", // Replace with your actual image path
      description: "Emaar Properties",
      alt: "Emaar Properties Logo",
    },
    {
      name: "AZIZI",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/90728d48-7a7d-4d3a-ba4a-145890eae6c1/logo/image/kpf_u25SHOtCx90RtXSL54DHw_0a9IOoPP9S2MAgWtA=/original.png", // Replace with your actual image path
      description: "Azizi Developments",
      alt: "Azizi Developments Logo",
    },
    {
      name: "ALDAR",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/d0853b8e-c92f-4b7e-a4e2-a5b67955ba7d/logo/image/k1MoKKBF5CIZjwQ0XbOWkxs3heXc0pV6lcQMvgLaKws=/original.png", // Replace with your actual image path
      description: "Aldar Properties PJSC",
      alt: "Aldar Properties Logo",
    },
    {
      name: "DAMAC",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/1063a07c-d94f-496b-9a24-5ea7409fe3d1/logo/image/O3p2VHWzQX9-Duzqi1vbOjp2tSlHIwJ1sjRjvTA7h68=/original.png", // Replace with your actual image path
      description: "Damac Properties",
      alt: "Damac Properties Logo",
    },
    {
      name: "SOBHA",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png", // Replace with your actual image path
      description: "Sobha Realty",
      alt: "Sobha Realty Logo",
    },
    {
      name: "MERAAS",
      logoUrl:
        "https://new-projects-media.propertyfinder.com/developer/831c8b0f-8adb-4fa5-94e9-0b123aa91a1a/logo/image/Khm513Li-0EP7_xCCxbyA3QlHudwwiTkvOG5Rz5KI1Y=/original.png", // Replace with your actual image path
      description: "Meraas Holding",
      alt: "Meraas Holding Logo",
    },
  ];

  // Triple the developers for seamless infinite scroll
  const duplicatedDevelopers = [...developers, ...developers, ...developers];

  const startAutoScroll = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    intervalRef.current = setInterval(() => {
      if (scrollContainerRef.current && isAutoPlaying) {
        const container = scrollContainerRef.current;
        const scrollAmount = 1; // pixels to scroll each time

        container.scrollLeft += scrollAmount;

        // Calculate when to reset (when we've scrolled past the first set)
        const maxScrollLeft = container.scrollWidth / 3; // Since we have 3 sets

        if (container.scrollLeft >= maxScrollLeft) {
          container.scrollLeft = 0;
        }
      }
    }, 16); // ~60fps
  };

  const stopAutoScroll = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const scrollToIndex = (index) => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const cardWidth = 200; // approximate card width
      const gap = 24;
      const scrollAmount = (cardWidth + gap) * index;

      container.scrollTo({
        left: scrollAmount,
        behavior: "smooth",
      });
      setCurrentIndex(index);
    }
  };

  const handlePrevious = () => {
    const newIndex =
      currentIndex > 0 ? currentIndex - 1 : developers.length - 1;
    scrollToIndex(newIndex);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 3000);
  };

  const handleNext = () => {
    const newIndex =
      currentIndex < developers.length - 1 ? currentIndex + 1 : 0;
    scrollToIndex(newIndex);
    setIsAutoPlaying(false);
    setTimeout(() => setIsAutoPlaying(true), 3000);
  };

  // Auto-scroll effect
  useEffect(() => {
    const timer = setTimeout(() => {
      if (isAutoPlaying) {
        startAutoScroll();
      } else {
        stopAutoScroll();
      }
    }, 1000);

    return () => {
      clearTimeout(timer);
      stopAutoScroll();
    };
  }, [isAutoPlaying]);

  // Initial start
  useEffect(() => {
    const timer = setTimeout(() => {
      startAutoScroll();
    }, 2000);

    return () => {
      clearTimeout(timer);
      stopAutoScroll();
    };
  }, []);

  // Pause on hover
  const handleMouseEnter = () => {
    setIsAutoPlaying(false);
  };

  const handleMouseLeave = () => {
    setIsAutoPlaying(true);
  };

  return (
    <div className="bg-white py-4 sm:py-6 lg:py-8 px-4 sm:px-6 lg:px-12 max-w-8xl mx-auto">
      {/* Section Title */}
      <div className="text-center mb-6 sm:mb-8 lg:mb-12">
        <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-2 px-4">
          Real Estate Developers in UAE
        </h2>
      </div>

      {/* Developer Carousel */}
      <div className="relative">
        {/* Left Arrow */}
        {/* <button
          onClick={handlePrevious}
          className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 -ml-4 sm:-ml-6"
          aria-label="Previous developer"
        >
          <ChevronLeft className="w-6 h-6 text-gray-600" />
        </button> */}

        {/* Right Arrow */}
        {/* <button
          onClick={handleNext}
          className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 -mr-4 sm:-mr-6"
          aria-label="Next developer"
        >
          <ChevronRight className="w-6 h-6 text-gray-600" />
        </button> */}

        {/* Developers Scroll Container */}
        <div
          ref={scrollContainerRef}
          className="flex gap-6 overflow-x-auto scrollbar-hide pb-4"
          style={{
            scrollbarWidth: "none",
            msOverflowStyle: "none",
          }}
          onMouseEnter={handleMouseEnter}
          onMouseLeave={handleMouseLeave}
        >
          {duplicatedDevelopers.map((developer, index) => (
            <div
              key={`${developer.name}-${index}`}
              onClick={() => navigate("/companypage")}
              className="flex flex-col items-center group cursor-pointer transform transition-all duration-300 hover:scale-105 flex-shrink-0 w-32 sm:w-40 lg:w-48"
            >
              {/* Logo Container */}
              <div className="w-20 h-20 sm:w-24 sm:h-24 lg:w-28 lg:h-28 bg-white rounded-lg shadow-md border border-gray-100 flex items-center justify-center mb-3 sm:mb-4 lg:mb-5 group-hover:shadow-lg transition-all duration-300 p-2">
                <img
                  src={developer.logoUrl}
                  alt={developer.alt}
                  className="max-w-full max-h-full object-contain"
                  onError={(e) => {
                    // Fallback to text if image fails to load
                    e.target.style.display = "none";
                    e.target.nextSibling.style.display = "block";
                  }}
                />
                {/* Fallback text (hidden by default) */}
                <span
                  className="text-lg sm:text-xl font-bold text-gray-800 hidden"
                  style={{ display: "none" }}
                >
                  {developer.name}
                </span>
              </div>

              {/* Developer Name */}
              <p className="text-sm sm:text-base text-gray-700 text-center font-medium hover:text-[#0b154f] transition-colors px-1">
                {developer.description}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Hide scrollbar styles */}
      <style jsx>{`
        .scrollbar-hide {
          -webkit-overflow-scrolling: touch;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
};

export default RealEstateDevelopers;
