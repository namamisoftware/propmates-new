import React, { useState, useRef, useEffect } from "react";
import {
  ChevronDown,
  X,
  Menu,
  User,
  Settings,
  Heart,
  Home,
  LogOut,
  HelpCircle,
  ChevronRight,
  Search,
} from "lucide-react";
import logo from "../assets/logo.png";
import LoginModal from "./Login";
import SignModal from "./Sign";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "./AuthContext";

// Contact Form Modal Component
const ContactFormModal = ({ onClose }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    propertyType: "",
    jobTitle: "",
    phone: "",
    bedRooms: [],
    bathRooms: [],
    city: "",
    licenseStatus: "",
    terms: false,
  });

  const modalRef = useRef(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data:", formData);
    alert("Form Submitted!");
    onClose();
  };

  // Close modal when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);

  // Prevent background scroll when modal is open
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, []);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-2 sm:p-4">
      <div
        ref={modalRef}
        className="bg-white shadow-lg rounded-xl w-full max-w-sm sm:max-w-md md:max-w-2xl lg:max-w-4xl max-h-[95vh] overflow-y-auto relative"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-3 right-3 sm:top-4 sm:right-4 text-gray-600 hover:text-gray-800 z-10 bg-white rounded-full p-1 shadow-sm"
          aria-label="Close modal"
        >
          <X size={20} className="sm:w-6 sm:h-6" />
        </button>

        <div className="p-4 sm:p-6 md:p-8">
          <h2 className="text-center text-lg sm:text-xl md:text-2xl font-semibold text-[#0b154f] mb-6 sm:mb-8 md:mb-10 pr-8">
            Submit your details and <br className="hidden sm:block" />
            <span className="sm:hidden"> </span>we will get in touch
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 md:gap-6">
            {/* First Name */}
            <Field
              label="First Name*"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
              required
            />

            {/* Last Name */}
            <Field
              label="Last Name*"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
              required
            />

            {/* Email */}
            <Field
              label="Email*"
              name="email"
              type="email"
              value={formData.email}
              onChange={handleChange}
              required
            />

            {/* Company Name */}
            <Field
              label="Company name"
              name="propertyType"
              value={formData.propertyType}
              onChange={handleChange}
            />

            {/* Job Title */}
            <Field
              label="Job Title"
              name="jobTitle"
              value={formData.jobTitle}
              onChange={handleChange}
            />

            {/* Phone */}
            <Field
              label="Phone"
              name="phone"
              type="tel"
              value={formData.phone}
              onChange={handleChange}
            />

            {/* License Status */}
            <Field
              label="Real Estate Trade License Status"
              name="licenseStatus"
              value={formData.licenseStatus}
              onChange={handleChange}
            />

            {/* City */}
            <Field
              label="City"
              name="city"
              value={formData.city}
              onChange={handleChange}
            />

            {/* Terms and Conditions */}
            <div className="flex items-start col-span-1 md:col-span-2 mt-2 sm:mt-4">
              <input
                type="checkbox"
                name="terms"
                checked={formData.terms}
                onChange={handleChange}
                className="w-4 h-4 text-[#0b154f] border-gray-300 rounded focus:ring-[#0b154f] mt-0.5 flex-shrink-0"
                required
              />
              <label className="ml-2 text-gray-600 text-xs sm:text-sm leading-relaxed">
                I accept the terms and conditions in the creation of my Property
                Finder account.{" "}
                <span className="text-[#0b154f] underline cursor-pointer hover:text-blue-700">
                  View our Terms of Use
                </span>
                .
              </label>
            </div>

            {/* Submit Button */}
            <div className="col-span-1 md:col-span-2 flex justify-center mt-4 sm:mt-6">
              <button
                type="submit"
                onClick={handleSubmit}
                className="w-full sm:w-3/4 md:w-1/2 bg-[#0b154f] text-white py-2.5 sm:py-3 rounded-lg shadow-xl transition font-semibold hover:bg-[#0f1a5f] focus:outline-none focus:ring-2 focus:ring-[#0b154f] focus:ring-offset-2"
              >
                Submit
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// Reusable Input Field Component
const Field = ({
  label,
  name,
  value,
  onChange,
  type = "text",
  required = false,
}) => (
  <div className="relative">
    <label className="absolute -top-2.5 sm:-top-3 left-3 sm:left-4 bg-white px-1 text-gray-600 text-xs sm:text-sm z-10">
      {label}
    </label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      className="border border-gray-300 rounded-lg p-2 sm:p-2.5 md:p-3 w-full focus:ring-2 focus:ring-[#0b154f] outline-none text-sm sm:text-base transition-all duration-200"
      placeholder=""
    />
  </div>
);

export default function BuildNavbar() {
  const navigate = useNavigate();
  const { isLoggedIn, userProfile, login, logout } = useAuth();
  const [openDropdown, setOpenDropdown] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignOpen, setIsSignOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [openSubmenu, setOpenSubmenu] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [residentialPropertyTypes, setResidentialPropertyTypes] = useState([]);
  const [rentresidentialPropertyTypes, setRentResidentialPropertyTypes] =
    useState([]);
  const [commercialPropertyTypes, setCommercialPropertyTypes] = useState([]);
  const [rentcommercialPropertyTypes, setRentCommercialPropertyTypes] =
    useState([]);
  const [allProperties, setAllProperties] = useState([]);

  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = "hidden";
      document.documentElement.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "unset";
      document.documentElement.style.overflow = "unset";
    }
    return () => {
      document.body.style.overflow = "unset";
      document.documentElement.style.overflow = "unset";
    };
  }, [isMobileMenuOpen]);

  const toggleDropdown = (menu) => {
    setOpenDropdown(openDropdown === menu ? null : menu);
  };

  const handleLoginSuccess = (userData) => {
    login(userData);
    setIsLoginOpen(false);
  };

  const handleLogout = () => {
    logout();
    setOpenDropdown(null);
  };

  // Fetch property types for Buy > Residential
  useEffect(() => {
    const fetchPropertyTypes = async () => {
      try {
        const response = await fetch(
          "http://72.60.219.2/api/propertytype/looking_to/1"
        );
        const data = await response.json();

        // console.log("API Response:", data);

        if (data && Array.isArray(data)) {
          const formattedTypes = data.map((item) => ({
            name: item.name,
            link: `/search?propertyTypeId=${item.id}`,
            id: item.id,
          }));
          setResidentialPropertyTypes(formattedTypes);
          // console.log("Formatted Property Types:", formattedTypes);
        }
      } catch (error) {
        console.error("Error fetching property types:", error);
      }
    };

    fetchPropertyTypes();
  }, []);

  useEffect(() => {
    const fetchRentPropertyTypes = async () => {
      try {
        const response = await fetch(
          "http://72.60.219.2/api/propertytype/looking_to/2"
        );
        const data = await response.json();

        // console.log("API buy Response:", data);

        if (data && Array.isArray(data)) {
          const formattedTypes = data.map((item) => ({
            name: item.name,
            link: `/rent?propertyTypeId=${item.id}`,
            id: item.id,
          }));
          setRentResidentialPropertyTypes(formattedTypes);
          // console.log("Formatted Property Types:", formattedTypes);
        }
      } catch (error) {
        console.error("Error fetching property types:", error);
      }
    };

    fetchRentPropertyTypes();
  }, []);

  useEffect(() => {
    const fetchCommercialPropertyTypes = async () => {
      try {
        const response = await fetch(
          "http://72.60.219.2/api/propertytype/looking_to/3"
        );
        const data = await response.json();

        // console.log("API commercial Response:", data);

        if (data && Array.isArray(data)) {
          const formattedTypes = data.map((item) => ({
            name: item.name,
            link: `/search?propertyTypeId=${item.id}`,
            id: item.id,
          }));
          setCommercialPropertyTypes(formattedTypes);
          // console.log("Formatted commercial Property Types:", formattedTypes);
        }
      } catch (error) {
        console.error("Error fetching property types:", error);
      }
    };

    fetchCommercialPropertyTypes();
  }, []);

  useEffect(() => {
    const fetchRentCommercialPropertyTypes = async () => {
      try {
        const response = await fetch(
          "http://72.60.219.2/api/propertytype/looking_to/4"
        );
        const data = await response.json();

        // console.log("API rent commercial Response:", data);

        if (data && Array.isArray(data)) {
          const formattedTypes = data.map((item) => ({
            name: item.name,
            link: `/rent?propertyTypeId=${item.id}`,
            id: item.id,
          }));
          setRentCommercialPropertyTypes(formattedTypes);
          // console.log("Formatted commercial Property Types:", formattedTypes);
        }
      } catch (error) {
        console.error("Error fetching property types:", error);
      }
    };

    fetchRentCommercialPropertyTypes();
  }, []);

  useEffect(() => {
    if (isMobileMenuOpen) return; // Don't apply click-outside in mobile menu

    const handleClickOutside = (event) => {
      if (openDropdown && !event.target.closest(".dropdown-container")) {
        setOpenDropdown(null);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [openDropdown, isMobileMenuOpen]);

  const navItems = [
    // {
    //   name: "Country",
    //   hasDropdown: true,
    //   link: "#",
    //   dropdownItems: [
    //     { name: "India", link: "#" },
    //     { name: "United States", link: "#" },
    //     { name: "United Kingdom", link: "#" },
    //     { name: "Canada", link: "#" },
    //     { name: "Australia", link: "#" },
    //   ],
    // },
    {
      name: "Buy",
      hasDropdown: true,
      link: "/search",
      type: "Buy",
      dropdownItems: [
        {
          name: "Residential",
          hasDropdown: true,
          link: "/search",
          category: "residential",
          dropdownItems: [
            { name: "Apartments", link: "/search", subtype: "apartment" },
            { name: "Villas", link: "/search", subtype: "villa" },
            {
              name: "Townhouse",
              link: "/search",
              subtype: "townhouse",
            },
            { name: "Plots / Land", link: "/search", subtype: "plot" },
            { name: "Studio Flats", link: "/search", subtype: "studio" },
            { name: "Penthouse", link: "/search", subtype: "penthouse" },
            { name: "Duplex", link: "/search", subtype: "duplex" },
            { name: "Compound", link: "/search", subtype: "compound" },
          ],
        },
        {
          name: "Commercial",
          hasDropdown: true,
          link: "/search",
          category: "commercial",
          dropdownItems: [
            { name: "Office Spaces", link: "/search", subtype: "office" },
            { name: "Shops", link: "/search", subtype: "shop" },
            { name: "Showroom", link: "/search", subtype: "showroom" },
            { name: "Warehouses", link: "/search", subtype: "warehouse" },
            { name: "Factory", link: "/search", subtype: "factory" },
            { name: "Plots/Land", link: "/search", subtype: "commercial_land" },
          ],
        },
      ],
    },
    {
      name: "Rent",
      hasDropdown: true,
      link: "/rent",
      type: "Rent",
      dropdownItems: [
        {
          name: "Residential",
          hasDropdown: true,
          link: "/rent",
          category: "residential",
          dropdownItems: [
            { name: "Apartments", link: "/search", subtype: "apartment" },
            { name: "Villas", link: "/search", subtype: "villa" },
            {
              name: "Townhouse",
              link: "/search",
              subtype: "townhouse",
            },
            { name: "Plots / Land", link: "/search", subtype: "plot" },
            { name: "Studio Flats", link: "/search", subtype: "studio" },
            { name: "Penthouse", link: "/search", subtype: "penthouse" },
            { name: "Duplex", link: "/search", subtype: "duplex" },
            { name: "Compound", link: "/search", subtype: "compound" },
          ],
        },
        {
          name: "Commercial",
          hasDropdown: true,
          link: "/rent",
          category: "commercial",
          dropdownItems: [
            { name: "Office Spaces", link: "/search", subtype: "office" },
            { name: "Shops", link: "/search", subtype: "shop" },
            { name: "Showroom", link: "/search", subtype: "showroom" },
            { name: "Warehouses", link: "/search", subtype: "warehouse" },
            { name: "Factory", link: "/search", subtype: "factory" },
            { name: "Plots/Land", link: "/search", subtype: "commercial_land" },
          ],
        },
      ],
    },
    // { name: "Buy", hasDropdown: false, link: "/search" },
    // { name: "Rent", hasDropdown: false, link: "/rent" },
    // { name: "Temporary Rent", hasDropdown: false, link: "#" },
    // { name: "Commercial", hasDropdown: false, link: "/commercial" },
    { name: "Holiday Rent", hasDropdown: false, link: "/holidayrent" },
    { name: "PG", hasDropdown: false, link: "/pg" },
    // { name: "New Project", hasDropdown: false, link: "/newprojects" },
    { name: "Propmates Team", hasDropdown: false, link: "/ourteam" },
    { name: "Business for Sale", hasDropdown: false, link: "/businessforsale" },
    { name: "Agriculture & Farms", hasDropdown: false, link: "/agriculture" },
    // {
    //   name: "Explore",
    //   hasDropdown: true,
    //   link: "#",
    //   dropdownItems: [
    //     { name: "Find Developers", link: "/developers" },
    //     { name: "Explore with DataGuru", link: "#" },
    //     { name: "Property Blog", link: "/blog" },
    //     { name: "Insights Hub", link: "#" },
    //     { name: "Know your rights", link: "#" },
    //   ],
    // },
    // { name: "Mortgages", hasDropdown: false, link: "#" },
  ];

  const buildPropertyLink = (baseLink, type, category, subtype) => {
    const params = new URLSearchParams();
    if (category) params.append("category", category);
    if (type) params.append("type", type);
    if (subtype) params.append("subtype", subtype);
    return `${baseLink}?${params.toString()}`;
  };

  const profileDropdownItems = [
    { name: "My Listings", link: "/mylistings", icon: User },
    { name: "List Property", link: "/listproperty", icon: Home },
    { name: "Profile", link: "/profile", icon: Heart },
    { name: "Enquiry", link: "/enquiry", icon: HelpCircle },
  ];

  useEffect(() => {
    fetch(`http://72.60.219.2/api/properties`)
      .then((res) => res.json())
      .then((data) => {
        setAllProperties(data);
      })
      .catch((err) => console.error("Error fetching properties:", err));
  }, []);

  // const handleSearch = () => {
  //   if (!searchQuery.trim()) return;

  //   const query = searchQuery.toLowerCase().trim();
  //   console.log("Search Query:", query);
  //   console.log("All Properties:", allProperties);

  //   const filtered = allProperties.filter((property) => {
  //     // Convert to strings for comparison
  //     const carpetArea = String(property.carpet_area || "");
  //     const price = String(property.expected_price || "");
  //     const builtupArea = String(property.builtup_area || "");
  //     const city = String(property.city || "").toLowerCase();
  //     const bedrooms = String(property.bedrooms || "");
  //     const bathrooms = String(property.bathrooms || "");
  //     const furnishingStatus = String(
  //       property.furnishing_status || ""
  //     ).toLowerCase();
  //     const rentPrice = String(property.rent_price || "");
  //     const name = String(property.name || "").toLowerCase();
  //     const locality = String(property.locality || "").toLowerCase();
  //     const subLocality = String(property.sub_locality || "").toLowerCase();
  //     const apartmentName = String(property.apartment_name || "").toLowerCase();
  //     const balconies = String(property.balconies || "");

  //     // Check if query is a number for price filtering
  //     const queryAsNumber = Number(query);
  //     const isQueryNumber = !isNaN(queryAsNumber) && query !== "";

  //     // Exact match for numbers, partial match for text fields
  //     const carpetMatch = carpetArea === query;
  //     // Price match: if query is a number, match prices <= query, otherwise exact match
  //     const priceMatch = isQueryNumber
  //       ? property.expected_price && property.expected_price <= queryAsNumber
  //       : price === query;
  //     const builtupMatch = builtupArea === query;
  //     const cityMatch = city.includes(query);
  //     const bedroomsMatch = bedrooms === query;
  //     const bathroomsMatch = bathrooms === query;
  //     const furnishingMatch = furnishingStatus.includes(query);
  //     // Rent price match: if query is a number, match rent prices <= query, otherwise exact match
  //     const rentPriceMatch = isQueryNumber
  //       ? property.rent_price && property.rent_price <= queryAsNumber
  //       : rentPrice === query;
  //     const nameMatch = name.includes(query);
  //     const localityMatch = locality.includes(query);
  //     const subLocalityMatch = subLocality.includes(query);
  //     const apartmentNameMatch = apartmentName.includes(query);
  //     const balconiesMatch = balconies === query;

  //     console.log(`Property ${property.id}:`, {
  //       carpetArea,
  //       price,
  //       builtupArea,
  //       city,
  //       bedrooms,
  //       bathrooms,
  //       furnishingStatus,
  //       rentPrice,
  //       name,
  //       locality,
  //       subLocality,
  //       apartmentName,
  //       balconies,
  //       matches: {
  //         carpetMatch,
  //         priceMatch,
  //         builtupMatch,
  //         cityMatch,
  //         bedroomsMatch,
  //         bathroomsMatch,
  //         furnishingMatch,
  //         rentPriceMatch,
  //         nameMatch,
  //         localityMatch,
  //         subLocalityMatch,
  //         apartmentNameMatch,
  //         balconiesMatch,
  //       },
  //     });

  //     return (
  //       carpetMatch ||
  //       priceMatch ||
  //       builtupMatch ||
  //       cityMatch ||
  //       bedroomsMatch ||
  //       bathroomsMatch ||
  //       furnishingMatch ||
  //       rentPriceMatch ||
  //       nameMatch ||
  //       localityMatch ||
  //       subLocalityMatch ||
  //       apartmentNameMatch ||
  //       balconiesMatch
  //     );
  //   });

  //   console.log("Filtered Results:", filtered);
  //   console.log("Filtered Count:", filtered.length);

  //   navigate("/searchnewpage", {
  //     state: { filteredProperties: filtered, query: searchQuery },
  //   });
  // };

  const handleSearch = () => {
    if (!searchQuery.trim()) return;

    let query = searchQuery.toLowerCase().trim();
    console.log("Original Search Query:", query);

    // Extract numeric value if query contains "under"
    let queryAsNumber = null;
    let isQueryNumber = false;

    if (query.includes("under")) {
      // Remove "under" and any spaces, extract the number
      const numericValue = query.replace(/under\s*/gi, "").trim();
      queryAsNumber = Number(numericValue);
      isQueryNumber = !isNaN(queryAsNumber) && numericValue !== "";
      console.log("Extracted number from 'under' query:", queryAsNumber);
    } else {
      // Original logic for direct number queries
      queryAsNumber = Number(query);
      isQueryNumber = !isNaN(queryAsNumber) && query !== "";
    }

    console.log("Processed Query:", query);
    console.log("Query as Number:", queryAsNumber);
    console.log("Is Query Number:", isQueryNumber);
    console.log("All Properties:", allProperties);

    const filtered = allProperties.filter((property) => {
      // Convert to strings for comparison
      const carpetArea = String(property.carpet_area || "");
      const price = String(property.expected_price || "");
      const builtupArea = String(property.builtup_area || "");
      const city = String(property.city || "").toLowerCase();
      const bedrooms = String(property.bedrooms || "");
      const bathrooms = String(property.bathrooms || "");
      const furnishingStatus = String(
        property.furnishing_status || ""
      ).toLowerCase();
      const rentPrice = String(property.rent_price || "");
      const name = String(property.name || "").toLowerCase();
      const locality = String(property.locality || "").toLowerCase();
      const subLocality = String(property.sub_locality || "").toLowerCase();
      const apartmentName = String(property.apartment_name || "").toLowerCase();
      const balconies = String(property.balconies || "");

      // Exact match for numbers, partial match for text fields
      const carpetMatch = carpetArea === query;

      // Price match: if query is a number or contains "under", match prices <= query
      const priceMatch = isQueryNumber
        ? property.expected_price && property.expected_price <= queryAsNumber
        : price === query;

      const builtupMatch = builtupArea === query;
      const cityMatch = city.includes(query);
      const bedroomsMatch = bedrooms === query;
      const bathroomsMatch = bathrooms === query;
      const furnishingMatch = furnishingStatus.includes(query);

      // Rent price match: if query is a number or contains "under", match rent prices <= query
      const rentPriceMatch = isQueryNumber
        ? property.rent_price && property.rent_price <= queryAsNumber
        : rentPrice === query;

      const nameMatch = name.includes(query);
      const localityMatch = locality.includes(query);
      const subLocalityMatch = subLocality.includes(query);
      const apartmentNameMatch = apartmentName.includes(query);
      const balconiesMatch = balconies === query;

      console.log(`Property ${property.id}:`, {
        carpetArea,
        price,
        builtupArea,
        city,
        bedrooms,
        bathrooms,
        furnishingStatus,
        rentPrice,
        name,
        locality,
        subLocality,
        apartmentName,
        balconies,
        matches: {
          carpetMatch,
          priceMatch,
          builtupMatch,
          cityMatch,
          bedroomsMatch,
          bathroomsMatch,
          furnishingMatch,
          rentPriceMatch,
          nameMatch,
          localityMatch,
          subLocalityMatch,
          apartmentNameMatch,
          balconiesMatch,
        },
      });

      return (
        carpetMatch ||
        priceMatch ||
        builtupMatch ||
        cityMatch ||
        bedroomsMatch ||
        bathroomsMatch ||
        furnishingMatch ||
        rentPriceMatch ||
        nameMatch ||
        localityMatch ||
        subLocalityMatch ||
        apartmentNameMatch ||
        balconiesMatch
      );
    });

    console.log("Filtered Results:", filtered);
    console.log("Filtered Count:", filtered.length);

    navigate("/searchnewpage", {
      state: { filteredProperties: filtered, query: searchQuery },
    });
  };

  return (
    <>
      <nav className="bg-white border-b-2 border-gray-200">
        <div className="flex items-center justify-between px-4 md:px-0 xl:px-14 py-3 sm:py-4">
          {/* Logo */}
          <div className="flex items-center md:gap-26 xl:gap-46">
            <Link to="/" className="flex items-center space-x-2">
              <img src={logo} alt="Logo" className="absolute h-24 w-28" />
            </Link>

            <div className="hidden lg:flex items-center space-x-4 2xl:space-x-6">
              {navItems.map((item) => (
                <div
                  key={item.name}
                  className="relative dropdown-container"
                  onClick={() => item.hasDropdown && toggleDropdown(item.name)}
                >
                  {item.hasDropdown ? (
                    <button className="flex items-center space-x-1 text-[#0b154f] hover:text-black font-medium transition-colors text-sm 2xl:text-base">
                      <span>{item.name}</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          openDropdown === item.name ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                  ) : (
                    <Link
                      to={item.link}
                      className="flex items-center space-x-1 text-[#0b154f] hover:text-black font-medium transition-colors text-sm 2xl:text-base"
                    >
                      <span>{item.name}</span>
                    </Link>
                  )}

                  {/* Dropdown Menu */}
                  {item.hasDropdown && openDropdown === item.name && (
                    <div className="absolute top-full left-0 mt-0 w-48 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                      <div className="py-2">
                        {item.dropdownItems.map((dropdownItem, index) => (
                          <div key={index} className="relative group">
                            {dropdownItem.hasDropdown ? (
                              <>
                                <button className="w-full text-left flex items-center justify-between px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors">
                                  {dropdownItem.name}
                                  <ChevronRight className="w-4 h-4" />
                                </button>

                                {/* Nested Dropdown */}
                                <div className="absolute top-0 left-full ml-1 hidden group-hover:block bg-white border border-[#0b154f] rounded-xl shadow-lg w-48 z-50">
                                  <div className="py-2">
                                    {dropdownItem.dropdownItems.map(
                                      (subItem, subIndex) => (
                                        <Link
                                          key={subIndex}
                                          to={buildPropertyLink(
                                            subItem.link,
                                            item.type,
                                            dropdownItem.category,
                                            subItem.subtype
                                          )}
                                          className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                                          onClick={() => setOpenDropdown(null)}
                                        >
                                          {subItem.name}
                                        </Link>
                                      )
                                    )}
                                  </div>
                                </div>
                              </>
                            ) : (
                              <Link
                                to={dropdownItem.link}
                                className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                                onClick={() => setOpenDropdown(null)}
                              >
                                {dropdownItem.name}
                              </Link>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Right Side Buttons */}
          <div className="flex items-center space-x-2 sm:space-x-4">
            {/* Search Input - Desktop */}
            <div className="hidden lg:flex items-center relative">
              <Search className="absolute left-3 text-gray-400 w-5 h-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSearch();
                  }
                }}
                placeholder="Search properties..."
                className="pl-10 pr-4 py-2 border-2 border-gray-300 rounded-xl focus:border-[#0b154f] focus:outline-none text-[#0b154f] placeholder-gray-400 w-64"
              />
            </div>
            {/* <button
              onClick={() => setIsModalOpen(true)}
              className="hidden lg:block bg-[#0b154f] text-white font-semibold px-3 xl:px-6 py-2 rounded-xl hover:bg-opacity-90 transition-colors text-xs xl:text-sm whitespace-nowrap"
            >
              List your property
            </button> */}
            {/* {!isLoggedIn && (
              <button
                onClick={() => setIsSignOpen(true)}
                className="hidden lg:block bg-[#0b154f] text-white font-semibold px-4 sm:px-6 py-2 rounded-xl hover:bg-opacity-90 transition-colors text-xs sm:text-sm"
              >
                Sign in
              </button>
            )} */}

            {/* Profile/Login Button */}
            {/* {isLoggedIn ? (
              <div
                className="relative"
                onMouseEnter={() => setOpenDropdown("profile")}
                onMouseLeave={() => setOpenDropdown(null)}
              >
                <button className="hidden lg:flex items-center space-x-2 bg-[#0b154f] text-white font-semibold px-4 sm:px-6 py-2 rounded-xl hover:bg-opacity-90 transition-colors text-xs sm:text-sm">
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                  <ChevronDown
                    className={`w-4 h-4 transition-transform ${
                      openDropdown === "profile" ? "rotate-180" : ""
                    }`}
                  />
                </button>

               
                {openDropdown === "profile" && (
                  <div className="absolute top-full right-0 mt-0 w-56 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                    <div className="py-2">
                      
                      <div className="px-4 py-3 border-b border-gray-200">
                        <p className="text-sm font-semibold text-[#0b154f]">
                          {userProfile?.phoneNumber || "User"}
                        </p>
                        
                      </div>

                  
                      {profileDropdownItems.map((item, index) => {
                        const Icon = item.icon;
                        return (
                          <Link
                            key={index}
                            to={item.link}
                            className="flex items-center space-x-3 px-4 py-2.5 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                            onClick={() => setOpenDropdown(null)}
                          >
                            <Icon className="w-4 h-4" />
                            <span className="text-sm">{item.name}</span>
                          </Link>
                        );
                      })}

                     
                      <button
                        onClick={handleLogout}
                        className="flex items-center space-x-3 w-full px-4 py-2.5 text-red-600 hover:text-red-700 hover:bg-red-50 transition-colors border-t border-gray-200"
                      >
                        <LogOut className="w-4 h-4" />
                        <span className="text-sm">Logout</span>
                      </button>
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <button
                onClick={() => setIsLoginOpen(true)}
                className="hidden lg:block bg-[#0b154f] text-white font-semibold px-4 sm:px-6 py-2 rounded-xl hover:bg-opacity-90 transition-colors text-xs sm:text-sm"
              >
                Login
              </button>
            )} */}

            {/* Search Input - Mobile */}
            <div className="lg:hidden flex items-center relative">
              <Search className="absolute left-3 text-gray-400 w-4 h-4" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    handleSearch();
                  }
                }}
                placeholder="Search..."
                className="pl-9 pr-3 py-2 border-2 border-gray-300 rounded-xl focus:border-[#0b154f] focus:outline-none text-[#0b154f] placeholder-gray-400 w-32 text-sm"
              />
            </div>
            {/* Mobile Menu Button */}
            <button
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="lg:hidden text-[#0b154f] p-2"
              aria-label="Toggle menu"
            >
              {isMobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden border-t border-gray-200 bg-white min-h-screen overflow-y-auto">
            <div className="px-4 py-3 space-y-2">
              {navItems.map((item, itemIndex) => (
                <div key={item.name + itemIndex}>
                  {item.hasDropdown ? (
                    <button
                      onClick={() => {
                        // e.stopPropagation();
                        toggleDropdown(item.name);
                        setOpenSubmenu(null); // Close any open submenu when toggling parent
                      }}
                      className="flex items-center justify-between w-full text-[#0b154f] hover:text-black font-medium py-2 transition-colors"
                    >
                      <span>{item.name}</span>
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          openDropdown === item.name ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                  ) : (
                    <Link
                      to={item.link}
                      onClick={() => setIsMobileMenuOpen(false)}
                      className="flex items-center justify-between w-full text-[#0b154f] hover:text-black font-medium py-2 transition-colors"
                    >
                      <span>{item.name}</span>
                    </Link>
                  )}

                  {/* Mobile Dropdown */}
                  {item.hasDropdown && openDropdown === item.name && (
                    <div className="pl-4 space-y-1 pb-2">
                      {item.dropdownItems.map((dropdownItem, index) => (
                        <div key={index}>
                          {dropdownItem.hasDropdown ? (
                            <>
                              {/* Submenu button (Residential / Commercial) */}
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  const subKey = `${item.name}-${index}-${dropdownItem.name}`;
                                  setOpenSubmenu(
                                    openSubmenu === subKey ? null : subKey
                                  );
                                }}
                                className="flex items-center justify-between w-full text-[#0b154f] hover:text-black font-medium py-2 transition-colors"
                              >
                                <span>{dropdownItem.name}</span>
                                <ChevronRight
                                  className={`w-4 h-4 transition-transform ${
                                    openSubmenu ===
                                    `${item.name}-${index}-${dropdownItem.name}`
                                      ? "rotate-90 text-black"
                                      : ""
                                  }`}
                                />
                              </button>

                              {/* Nested submenu (Countries) */}
                              {openSubmenu ===
                                `${item.name}-${index}-${dropdownItem.name}` && (
                                <div className="pl-4 space-y-1 pb-2 border-l border-gray-200">
                                  {dropdownItem.dropdownItems.map(
                                    (subItem, subIndex) => (
                                      <Link
                                        key={subIndex}
                                        to={buildPropertyLink(
                                          subItem.link,
                                          item.type,
                                          dropdownItem.category,
                                          subItem.subtype
                                        )}
                                        onClick={() => {
                                          setOpenDropdown(null);
                                          setOpenSubmenu(null);
                                          setIsMobileMenuOpen(false);
                                        }}
                                        className="block py-2 text-sm text-[#0b154f] hover:text-black transition-colors"
                                      >
                                        {subItem.name}
                                      </Link>
                                    )
                                  )}
                                </div>
                              )}
                            </>
                          ) : (
                            <Link
                              to={dropdownItem.link}
                              className="block py-2 text-[#0b154f] hover:text-black transition-colors text-sm"
                              onClick={() => {
                                setOpenDropdown(null);
                                setOpenSubmenu(null);
                                setIsMobileMenuOpen(false);
                              }}
                            >
                              {dropdownItem.name}
                            </Link>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              ))}

              {/* Mobile Action Buttons */}
              <div className="pt-3 space-y-2 border-t border-gray-200">
                {/* {!isLoggedIn && (
                  <button
                    onClick={() => setIsSignOpen(true)}
                    className="lg:hidden w-full bg-[#0b154f] text-white font-semibold py-2 rounded-xl hover:bg-opacity-90 transition-colors"
                  >
                    Sign in
                  </button>
                )} */}

                {/* {isLoggedIn ? (
                  <>
          
                    <div className="space-y-1 pt-2 border-t border-gray-200">
                      <div className="px-3 py-2 bg-gray-50 rounded-lg">
                        <p className="text-sm font-semibold text-[#0b154f]">
                          {userProfile?.phoneNumber || "User"}
                        </p>
                      </div>
                      {profileDropdownItems.map((item, index) => {
                        const Icon = item.icon;
                        return (
                          <Link
                            key={index}
                            to={item.link}
                            className="flex items-center space-x-3 w-full px-3 py-2 text-[#0b154f] hover:bg-gray-50 rounded-lg transition-colors"
                            onClick={() => setIsMobileMenuOpen(false)}
                          >
                            <Icon className="w-4 h-4" />
                            <span className="text-sm">{item.name}</span>
                          </Link>
                        );
                      })}
                      <button
                        onClick={() => {
                          handleLogout();
                          setIsMobileMenuOpen(false);
                        }}
                        className="flex items-center space-x-3 w-full px-3 py-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <LogOut className="w-4 h-4" />
                        <span className="text-sm">Logout</span>
                      </button>
                    </div>
                  </>
                ) : (
                  <button
                    onClick={() => {
                      setIsLoginOpen(true);
                      setIsMobileMenuOpen(false);
                    }}
                    className="lg:hidden w-full bg-[#0b154f] text-white font-semibold py-2 rounded-xl hover:bg-opacity-90 transition-colors"
                  >
                    Login
                  </button>
                )} */}
              </div>
            </div>
          </div>
        )}
      </nav>

      {/* Modal for Contact Form */}
      {isModalOpen && (
        <ContactFormModal onClose={() => setIsModalOpen(false)} />
      )}
      {isLoginOpen && (
        <LoginModal
          onClose={() => setIsLoginOpen(false)}
          onLoginSuccess={handleLoginSuccess}
        />
      )}
      {isSignOpen && <SignModal onClose={() => setIsSignOpen(false)} />}
    </>
  );
}
