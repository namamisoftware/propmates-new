import React, { useEffect, useState } from "react";
import { Phone } from "lucide-react";
import img1 from "../assets/recentprojects/1.png";
import img2 from "../assets/recentprojects/2.png";
import img3 from "../assets/recentprojects/3.png";
import img4 from "../assets/recentprojects/4.png";
import img5 from "../assets/recentprojects/5.png";
import img6 from "../assets/recentprojects/6.png";
import logoFallback from "../assets/recentprojects/logo1.png"; // fallback if company logo missing
import { Link } from "react-router-dom";

const API_BASE = "https://propmatez.shop";

const RecentProjects = () => {
  const [hoveredProject, setHoveredProject] = useState(null);
  const [countries, setCountries] = useState([]);
  const [projects, setProjects] = useState([]);
  const [activeCountry, setActiveCountry] = useState(null);
  const [companyLogos, setCompanyLogos] = useState({}); // { [companyId]: logoUrl }

  // Fetch countries
  useEffect(() => {
    fetch(`${API_BASE}/api/countries/`)
      .then((res) => res.json())
      .then((data) => {
        setCountries(data);
        if (data.length > 0) setActiveCountry(data[0].id);
      })
      .catch((err) => console.error("Error fetching countries:", err));
  }, []);

  // Fetch projects for active country
  useEffect(() => {
    if (!activeCountry) return;
    fetch(`${API_BASE}/api/properties/country/${activeCountry}`)
      .then((res) => res.json())
      .then((data) => {
        console.log("Projects API response:", data);
        setProjects(data);
      })
      .catch((err) => console.error("Error fetching projects:", err));
  }, [activeCountry]);

  // When projects change, fetch company details (unique list of company_ids)
  useEffect(() => {
    if (!projects || projects.length === 0) return;

    const companyIds = [
      ...new Set(
        projects
          .map((p) => p.company)
          .filter((id) => id !== undefined && id !== null && id !== "")
      ),
    ];

    if (companyIds.length === 0) {
      console.log("No company_id fields found in projects.");
      return;
    }

    const fetchCompanies = async () => {
      for (const id of companyIds) {
        // Skip if already fetched
        if (companyLogos[id]) {
          console.log(
            `Logo for company ${id} is already cached:`,
            companyLogos[id]
          );
          continue;
        }

        try {
          console.log(`Fetching company ${id}...`);
          const res = await fetch(`${API_BASE}/api/company/${id}`);
          if (!res.ok) {
            console.error(
              `Failed to fetch company ${id} - status: ${res.status}`
            );
            continue;
          }

          const data = await res.json();
          console.log(`Fetched company ${id}:`, data);

          // If API returns an array, grab the first object
          const company = Array.isArray(data) ? data[0] : data;

          // Extract the image field
          let logoUrl = company?.image || "";
          console.log(`Company ${id} logo path:`, logoUrl);

          // Normalize relative paths → absolute URLs
          if (logoUrl && !/^https?:\/\//i.test(logoUrl)) {
            logoUrl = `${API_BASE}/${logoUrl.replace(/^\/+/, "")}`;
          }

          // Store in state
          setCompanyLogos((prev) => ({ ...prev, [id]: logoUrl }));
        } catch (err) {
          console.error(`Error fetching company ${id}:`, err);
        }
      }
    };

    fetchCompanies();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projects]); // intentionally not depending on companyLogos to avoid re-loop

  const handleLocationClick = (location) => {
    setActiveCountry(location);
    setHoveredProject(null);
  };

  const getLogoForProject = (project) => {
    // prefer fetched company logo, then project.logo (if present), then fallback
    const companyLogo = project.company ? companyLogos[project.company] : null;
    if (companyLogo) return companyLogo;

    if (project.logo) {
      // project.logo might be relative
      return /^https?:\/\//i.test(project.logo)
        ? project.logo
        : `${API_BASE}/${String(project.logo).replace(/^\/+/, "")}`;
    }

    return logoFallback;
  };

  return (
    <div className="max-w-8xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10">
      <div className="text-center mb-8 md:mb-12">
        <p className="text-sm md:text-base mb-2">Best Project of the Years</p>
        <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-6 md:mb-10">
          Our recent projects
        </h2>

        <div className="flex flex-wrap justify-center gap-4 sm:gap-6 md:gap-8 lg:gap-14 mb-8 md:mb-12">
          {countries.map((country) => (
            <button
              key={country.id}
              onClick={() => handleLocationClick(country.id)}
              className={`text-[#0b154f] text-sm sm:text-base md:text-lg transition-all duration-300 hover:font-bold ${
                activeCountry === country.id ? "font-bold underline" : ""
              }`}
            >
              {country.name}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 lg:gap-7 mb-8 md:mb-12">
        {projects.map((project, index) => {
          const logoSrc = getLogoForProject(project);
          return (
            <Link key={project.id} to={`/details/${project.id}`}>
              <div
                className="rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative animate-fadeIn"
                style={{
                  height:
                    window.innerWidth >= 1024
                      ? "480px"
                      : window.innerWidth >= 768
                      ? "400px"
                      : "350px",
                  animationDelay: `${index * 100}ms`,
                }}
                onMouseEnter={() => setHoveredProject(project.id)}
                onMouseLeave={() => setHoveredProject(null)}
              >
                <div
                  className={`absolute inset-0 transition-opacity duration-500 ease-in-out ${
                    hoveredProject === project.id ? "opacity-0" : "opacity-100"
                  }`}
                  style={{
                    backgroundImage: `linear-gradient(to top, rgba(0,0,0,0.6) 20%, rgba(0,0,0,0) 100%), url(${API_BASE}/${String(
                      project.images
                    ).replace(/^\/+/, "")})`,
                    backgroundSize: "cover",
                    backgroundPosition: "bottom",
                  }}
                />

                <video
                  className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ease-in-out ${
                    hoveredProject === project.id ? "opacity-100" : "opacity-0"
                  }`}
                  autoPlay
                  muted
                  loop
                  playsInline
                  preload="metadata"
                >
                  <source
                    src={`${API_BASE}/${String(project.video).replace(
                      /^\/+/,
                      ""
                    )}`}
                    type="video/mp4"
                  />
                </video>

                <div
                  className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent transition-opacity duration-500 ease-in-out ${
                    hoveredProject === project.id ? "opacity-100" : "opacity-0"
                  }`}
                />

                {/* Top section with logos */}
                <div className="absolute top-2 right-2 sm:top-3 sm:right-3 md:top-4 md:right-4 z-10">
                  <img
                    src={logoSrc}
                    alt={`${project.name} logo`}
                    className="w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 lg:w-22 lg:h-22"
                    // onError={(e) => {
                    //   e.currentTarget.src = logoFallback;
                    // }}
                  />
                </div>

                <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-5 lg:p-6 text-white z-10">
                  <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl mb-1 md:mb-2">
                    {project.name}
                  </h3>
                  <p className="text-sm md:text-base mb-1">
                    {project.bedrooms} Bedrooms
                  </p>
                  <p className="text-sm md:text-base mb-4 md:mb-6">
                    Launch price {project.expected_price}M AED
                  </p>

                  <button className="w-full bg-white text-gray-900 font-medium py-2 sm:py-2.5 md:py-3 px-3 sm:px-4 rounded-full transition-all duration-300 flex items-center justify-center hover:bg-gray-100 text-sm md:text-base">
                    <Phone className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                    WhatsApp
                  </button>
                </div>
              </div>
            </Link>
          );
        })}
      </div>

      {projects.length === 0 && (
        <div className="text-center py-12">
          <p className="text-gray-500 text-lg">No projects available</p>
        </div>
      )}

      <div className="text-center">
        <button className="text-base md:text-lg text-[#0b154f] underline transition-colors duration-300">
          View more Projects
        </button>
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default RecentProjects;
