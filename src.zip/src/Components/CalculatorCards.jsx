import React from "react";
import { Calculator, Home, CheckCircle, RefreshCw } from "lucide-react";
import calc1 from "../assets/calc1.png";
import calc2 from "../assets/calc2.png";
import calc3 from "../assets/calc3.png";
import BudgetCalculator from "../Calculator/BudgetCalculator";
import EMICalculator from "../Calculator/EMICalculator";
import LoanEligibility from "../Calculator/LoanEligibility";
import AreaConvertor from "../Calculator/AreaConvertor";
import { Link } from "react-router-dom";

const FinancialCalculatorDashboard = () => {
  const calculators = [
    {
      title: "Budget Calculator",
      description: "Check your affordability range for buying home",
      path: "/budgetCalculator",
      icon: (
        <img
          src={calc1}
          alt="Budget Calculator"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "EMI Calculator",
      description: "Calculate your home loan EMI",
      path: "/emiCalculator",
      icon: (
        <img
          src={calc1}
          alt="EMI Calculator"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "Loan Eligibility",
      description: "See what you can borrow for your home",
      path: "/loanEligibility",
      icon: (
        <img
          src={calc2}
          alt="Loan Eligibility"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "Area Converter",
      description: "Convert one area into any other easily",
      path: "/areaConverter",
      icon: (
        <img
          src={calc3}
          alt="Area Converter"
          className="w-25 h-25 object-contain"
        />
      ),
    },
  ];

  return (
    <div className="flex justify-center items-center bg-red-400">
      <div className="bg-[#a0a7ff] rounded-b-2xl p-8 w-[82%] lg:w-[88%] max-w-7xl">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {calculators.map((calc, index) => (
            <Link
              to={calc.path}
              key={index}
              className="bg-white rounded-xl text-center p-6 shadow-sm hover:shadow-md transition-shadow duration-300 cursor-pointer group"
            >
              <div className="flex justify-center mb-2">
                <div
                  className={`rounded-lg p-3 group-hover:scale-110 transition-transform duration-300`}
                >
                  {/* Use icon from calculators array */}
                  {calc.icon}
                </div>
              </div>

              <h3 className="font-semibold text-gray-800 text-2xl mb-2 group-hover:text-[#7d85f4] transition-colors">
                {calc.title}
              </h3>

              <p className="text-gray-600 text-sm leading-relaxed">
                {calc.description}
              </p>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
};

export default FinancialCalculatorDashboard;
