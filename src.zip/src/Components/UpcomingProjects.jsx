import React from "react";
import img1 from "../assets/upcomingprojects/img1.png";
import img2 from "../assets/upcomingprojects/img2.png";
import img3 from "../assets/upcomingprojects/img3.png";
import img4 from "../assets/upcomingprojects/img4.png";
import barcode from "../assets/upcomingprojects/barcode.png";
import phone from "../assets/upcomingprojects/phone.png";
import playstore from "../assets/footer/playstore.png";
import appstore from "../assets/footer/appstore.png";

const PropertyFinderUI = () => {
  return (
    <div className="  px-4 sm:px-8 lg:px-14 pt-0">
      {/* Header */}
      <div className="text-center mb-6 sm:mb-8 lg:mb-10">
        <h1 className="text-2xl sm:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-2">
          Upcoming Projects
        </h1>
      </div>

      {/* Main Content Container */}
      <div className="flex flex-col xl:flex-row gap-8 lg:gap-12 xl:gap-16">
        {/* Left Section - Property Images */}
        <div className="w-full xl:w-1/2">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {/* Left Column - Large Image */}
            <div className="lg:col-span-2 grid grid-rows-2 gap-4">
              {/* Top Large Image */}
              <div className="relative overflow-hidden rounded-lg shadow-lg group cursor-pointer h-64 lg:h-auto">
                <img
                  src="https://images.unsplash.com/photo-1480714378408-67cf0d13bc1b?w=1200&h=400&fit=crop"
                  alt="Singapore Skyline"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/20"></div>
                <div className="absolute top-6 left-6 text-white">
                  <h2 className="text-3xl font-bold mb-1">Passcode Big</h2>
                  <p className="text-lg opacity-90">Life City</p>
                </div>
              </div>

              {/* Bottom Row - Two Images */}
              <div className="grid grid-cols-2 gap-4">
                {/* Bottom Left Image */}
                <div className="relative overflow-hidden rounded-lg shadow-lg group cursor-pointer h-48 lg:h-auto">
                  <img
                    src="https://images.unsplash.com/photo-1449824913935-59a10b8d2000?w=600&h=400&fit=crop"
                    alt="City View"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/20"></div>
                  <div className="absolute top-4 left-4 text-white">
                    <h3 className="text-xl font-bold">Passcode Big</h3>
                    <p className="text-sm opacity-90">Life City</p>
                  </div>
                </div>

                {/* Bottom Right Image */}
                <div className="relative overflow-hidden rounded-lg shadow-lg group cursor-pointer h-48 lg:h-auto">
                  <img
                    src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&h=400&fit=crop"
                    alt="Modern Architecture"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-b from-black/50 to-black/20"></div>
                  <div className="absolute top-4 left-4 text-white">
                    <h3 className="text-xl font-bold">Passcode Big</h3>
                    <p className="text-sm opacity-90">Life City</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Right Column */}
            <div className="flex flex-col gap-4">
              {/* Top Right - Building Image (Takes more space) */}
              <div className="relative overflow-hidden rounded-lg shadow-lg group cursor-pointer h-64 lg:h-auto lg:flex-grow">
                <img
                  src="https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&h=600&fit=crop"
                  alt="Modern Building"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-blue-900/30"></div>
                <div className="absolute top-6 left-6 text-white">
                  <h3 className="text-2xl font-bold">Passcode Big</h3>
                  <p className="text-base opacity-90">Life City</p>
                </div>
              </div>

              {/* Bottom Right - Know More Button (Smaller height) */}
              <div className="relative overflow-hidden flex items-end justify-end py-8 lg:py-12">
                <button className="border-2 border-gray-800 text-gray-800 px-10 py-3 rounded-full font-semibold hover:bg-gray-800 hover:text-white transition-all duration-300 text-base">
                  Know More
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Right Section - App Download */}
        <div className="w-full xl:w-1/2 mt-8 xl:mt-0">
          <div className="flex flex-row items-center gap-6 lg:gap-8">
            {/* Text and QR Code Section */}
            <div className="flex-1 text-center lg:text-left">
              {/* QR Code */}
              <div className="mb-6 flex justify-center lg:justify-start">
                <img
                  src={barcode}
                  alt="QR Code"
                  className="w-20 sm:w-24 lg:w-28"
                />
              </div>

              {/* Download Text */}
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-bold text-gray-800 mb-4 leading-tight">
                Download the UAE's
                <br />
                most trusted property
                <br />
                search app
              </h2>

              <p className="text-gray-600 text-sm sm:text-base lg:text-lg mb-6 leading-relaxed">
                Install the Property Finder app and
                <br />
                start searching smarter.
              </p>

              {/* App Store Buttons */}
              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 items-center lg:items-start justify-center lg:justify-start">
                <a href="#" className="block">
                  <img
                    src={playstore}
                    alt="Google Play"
                    className="w-32 sm:w-36 lg:w-40 h-auto"
                  />
                </a>
                <a href="#" className="block">
                  <img
                    src={appstore}
                    alt="App Store"
                    className="w-32 sm:w-36 lg:w-40 h-auto"
                  />
                </a>
              </div>
            </div>

            {/* Phone Mockup */}
            <div className="flex justify-center lg:justify-end">
              <img
                src={phone}
                alt="Phone Mockup"
                className="w-48 sm:w-64 lg:w-72 xl:w-80 h-auto max-w-full"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PropertyFinderUI;
