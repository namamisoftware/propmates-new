import React, { createContext, useContext, useState, useEffect } from "react";
import axios from "axios";

const GEOAPIFY_API_KEY = "7cb4a231b8d7445e817a708878a5a5cc";

const LocationContext = createContext();

export const useLocation = () => {
  const context = useContext(LocationContext);
  if (!context) {
    throw new Error("useLocation must be used within LocationProvider");
  }
  return context;
};

export const LocationProvider = ({ children }) => {
  const [selectedCountry, setSelectedCountry] = useState(null);
  const [selectedCity, setSelectedCity] = useState(null);
  const [userLocation, setUserLocation] = useState(null);

  // Auto-detect user location on mount
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          try {
            const res = await axios.get(
              `https://api.geoapify.com/v1/geocode/reverse`,
              {
                params: {
                  lat: latitude,
                  lon: longitude,
                  apiKey: GEOAPIFY_API_KEY,
                },
              }
            );
            const place = res.data.features[0].properties;
            const location = {
              city: place.city || place.county || "Unknown City",
              country: place.country || "Unknown Country",
              lat: latitude,
              lon: longitude,
            };
            setUserLocation(location);
            setSelectedCountry(location.country);
            setSelectedCity(location.city);
          } catch (err) {
            console.error("Error fetching location:", err);
          }
        },
        (err) => {
          console.error("Location permission denied:", err);
        }
      );
    }
  }, []);

  return (
    <LocationContext.Provider
      value={{
        selectedCountry,
        setSelectedCountry,
        selectedCity,
        setSelectedCity,
        userLocation,
      }}
    >
      {children}
    </LocationContext.Provider>
  );
};
