import React, { useState } from "react";
import { X, ChevronLeft, ChevronRight } from "lucide-react";

export default function GalleryModal({ isOpen, onClose, images }) {
  const [selectedCategory, setSelectedCategory] = useState("All");
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isFullView, setIsFullView] = useState(false);

  if (!isOpen) return null;

  // Group images by category
  const imageCategories = {
    "Exterior View": images?.exteriorView || [],
    "Living Room": images?.livingRoom || [],
    Bedroom: images?.bedroom || [],
    Bathroom: images?.bathroom || [],
    Kitchen: images?.kitchen || [],
    "Floor Plan": images?.floorPlan || [],
    "Master Plan": images?.masterPlan || [],
    "Location Map": images?.locationMap || [],
    Other: images?.other || [],
  };

  // Get all images for "All" category
  const allImages = Object.values(imageCategories).flat();

  // Get filtered images based on selected category
  const displayImages =
    selectedCategory === "All"
      ? allImages
      : imageCategories[selectedCategory] || [];

  const categories = [
    "All",
    ...Object.keys(imageCategories).filter(
      (cat) => imageCategories[cat].length > 0
    ),
  ];

  const handlePrevious = () => {
    setCurrentImageIndex((prev) =>
      prev === 0 ? displayImages.length - 1 : prev - 1
    );
  };

  const handleNext = () => {
    setCurrentImageIndex((prev) =>
      prev === displayImages.length - 1 ? 0 : prev + 1
    );
  };

  const handleImageClick = (index) => {
    setCurrentImageIndex(index);
    setIsFullView(true);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#000000e2] bg-opacity-95 overflow-hidden">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-gradient-to-b from-black/80 to-transparent p-4">
        <div className="flex items-center justify-between max-w-8xl mx-auto px-4">
          <h2 className="text-white text-2xl font-semibold">
            Property Gallery
          </h2>
          <button
            onClick={onClose}
            className="text-white hover:bg-white/10 p-2 rounded-full transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      {!isFullView ? (
        // Grid View
        <div className="h-full pt-20 pb-6 px-4 overflow-y-auto scrollbar-hide">
          <div className="max-w-8xl mx-auto px-4">
            {/* Category Tabs */}
            <div className="mb-6 overflow-x-auto scrollbar-hide">
              <div className=" flex gap-2 min-w-max">
                {categories.map((category) => (
                  <button
                    key={category}
                    onClick={() => setSelectedCategory(category)}
                    className={`px-4 py-2 rounded-lg font-medium whitespace-nowrap transition-colors ${
                      selectedCategory === category
                        ? "bg-white text-gray-900"
                        : "bg-white/10 text-white hover:bg-white/20"
                    }`}
                  >
                    {category}
                    {category !== "All" && imageCategories[category] && (
                      <span className="ml-2 text-sm opacity-75">
                        ({imageCategories[category].length})
                      </span>
                    )}
                    {category === "All" && (
                      <span className="ml-2 text-sm opacity-75">
                        ({allImages.length})
                      </span>
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Image Grid */}
            {displayImages.length > 0 ? (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {displayImages.map((image, index) => (
                  <div
                    key={index}
                    onClick={() => handleImageClick(index)}
                    className="aspect-square rounded-lg overflow-hidden cursor-pointer group relative"
                  >
                    <img
                      src={image}
                      alt={`Property image ${index + 1}`}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors" />
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-20">
                <p className="text-white/60 text-lg">
                  No images available in this category
                </p>
              </div>
            )}
          </div>
        </div>
      ) : (
        // Full Image View
        <div className="h-full flex items-center justify-center pt-20 pb-6">
          {/* Navigation Buttons */}
          {displayImages.length > 1 && (
            <>
              <button
                onClick={handlePrevious}
                className="absolute left-4 top-1/2 -translate-y-1/2 z-20 bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
              >
                <ChevronLeft className="w-8 h-8 text-white" />
              </button>
              <button
                onClick={handleNext}
                className="absolute right-4 top-1/2 -translate-y-1/2 z-20 bg-white/10 hover:bg-white/20 p-3 rounded-full transition-colors"
              >
                <ChevronRight className="w-8 h-8 text-white" />
              </button>
            </>
          )}

          {/* Main Image */}
          <div className="max-w-6xl max-h-full px-4">
            <img
              src={displayImages[currentImageIndex]}
              alt={`Property image ${currentImageIndex + 1}`}
              className="max-w-full max-h-[80vh] object-contain rounded-lg"
            />
            <div className="text-center mt-4">
              <p className="text-white/60">
                {currentImageIndex + 1} / {displayImages.length}
              </p>
              <button
                onClick={() => setIsFullView(false)}
                className="mt-2 text-white/80 hover:text-white underline"
              >
                Back to Grid
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Keyboard Navigation */}
      <div
        className="absolute inset-0 -z-10"
        onKeyDown={(e) => {
          if (e.key === "ArrowLeft") handlePrevious();
          if (e.key === "ArrowRight") handleNext();
          if (e.key === "Escape") {
            if (isFullView) setIsFullView(false);
            else onClose();
          }
        }}
        tabIndex={0}
      />

      <style>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
