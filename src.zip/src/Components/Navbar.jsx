import React, { useState } from "react";
import { ChevronDown, Menu, X } from "lucide-react";
import logo from "../assets/logo.png";
import LoginModal from "./Login";
import SignModal from "./Sign";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isExploreDropdownOpen, setIsExploreDropdownOpen] = useState(false);
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isSignOpen, setIsSignOpen] = useState(false);

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen);
  };

  const toggleExploreDropdown = () => {
    setIsExploreDropdownOpen(!isExploreDropdownOpen);
  };

  return (
    <div className="w-full max-w-8xl mx-auto py-5 px-5">
      <div className="lg:bg-[#fafafa] lg:border lg:border-[#0b154f] rounded-full px-10 py-5">
        <div className="relative flex items-center justify-between">
          {/* Logo Section */}
          <Link to="/">
            <img
              src={logo}
              alt="Company Logo"
              className="absolute -top-[40px] -left-[40px] lg:left-[0px] lg:-top-[30px] w-32 h-26"
            />
          </Link>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center space-x-5 2xl:space-x-15 text-lg">
            <Link
              to="/search"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              Buy
            </Link>
            <Link
              to="/rent"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              Rent
            </Link>
            <Link
              to="/commercial"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              Commercial
            </Link>
            <Link
              to="/newprojects"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              New Projects
            </Link>
            <Link
              to="/ourteam"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              Our Team
            </Link>
            <div className="relative flex items-center space-x-1">
              <button
                onClick={toggleExploreDropdown}
                className="flex items-center space-x-1 text-[#0b154f] hover:text-black transition-colors"
              >
                <span>Explore</span>
                <ChevronDown
                  className={`w-4 h-4 text-[#0b154f] transition-transform ${
                    isExploreDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isExploreDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-48 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2">
                    <Link
                      to="/developers"
                      className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      onClick={() => setIsExploreDropdownOpen(false)}
                    >
                      Find Developers
                    </Link>
                    <a
                      href="#"
                      className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      onClick={() => setIsExploreDropdownOpen(false)}
                    >
                      Explore with DataGuru
                    </a>
                    <a
                      href="#"
                      className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      onClick={() => setIsExploreDropdownOpen(false)}
                    >
                      Property Blog
                    </a>
                    <a
                      href="#"
                      className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      onClick={() => setIsExploreDropdownOpen(false)}
                    >
                      Insights Hub
                    </a>
                    <a
                      href="#"
                      className="block px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      onClick={() => setIsExploreDropdownOpen(false)}
                    >
                      Know your rights
                    </a>
                  </div>
                </div>
              )}
            </div>
            <a
              href="#"
              className="text-[#0b154f] hover:text-black transition-colors"
            >
              Mortgages
            </a>
          </nav>

          {/* Desktop Auth Buttons */}
          <div className="hidden lg:flex items-center space-x-3">
            <button
              onClick={() => setIsLoginOpen(true)}
              className="bg-[#0b154f] text-[#e5e9f2] text-lg px-6 py-1 rounded-xl"
            >
              Log in
            </button>
            <button
              onClick={() => setIsSignOpen(true)}
              className="text-[#0b154f] border border-[#0b154f] text-lg px-7 py-1 rounded-xl transition-colors"
            >
              Sign in
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            className="lg:hidden text-[#0b154f] hover:text-black transition-colors"
            onClick={toggleMobileMenu}
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="lg:hidden mt-4 pt-4 border-t border-[#0b154f]">
            <nav className="flex flex-col space-y-3">
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Buy
              </a>
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Rent
              </a>
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Commercial
              </a>
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                New Projects
              </a>
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Our Team
              </a>
              <div className="py-2">
                <button
                  onClick={toggleExploreDropdown}
                  className="flex items-center space-x-1 text-[#0b154f] hover:text-black transition-colors text-lg w-full text-left"
                >
                  <span>Explore</span>
                  <ChevronDown
                    className={`w-4 h-4 text-[#0b154f] transition-transform ${
                      isExploreDropdownOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {isExploreDropdownOpen && (
                  <div className="ml-4 mt-2 space-y-2">
                    <a
                      href="#"
                      className="block text-[#0b154f] hover:text-black transition-colors py-1"
                      onClick={() => {
                        setIsExploreDropdownOpen(false);
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Market Trends
                    </a>
                    <a
                      href="#"
                      className="block text-[#0b154f] hover:text-black transition-colors py-1"
                      onClick={() => {
                        setIsExploreDropdownOpen(false);
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Neighborhood Guide
                    </a>
                    <a
                      href="#"
                      className="block text-[#0b154f] hover:text-black transition-colors py-1"
                      onClick={() => {
                        setIsExploreDropdownOpen(false);
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Investment Tips
                    </a>
                    <a
                      href="#"
                      className="block text-[#0b154f] hover:text-black transition-colors py-1"
                      onClick={() => {
                        setIsExploreDropdownOpen(false);
                        setIsMobileMenuOpen(false);
                      }}
                    >
                      Home Valuation
                    </a>
                  </div>
                )}
              </div>
              <a
                href="#"
                className="text-[#0b154f] hover:text-black transition-colors text-lg py-2"
                onClick={() => setIsMobileMenuOpen(false)}
              >
                Mortgages
              </a>
            </nav>

            {/* Mobile Auth Buttons */}
            <div className="flex flex-col space-y-3 mt-6 pt-4 border-t border-[#0b154f]">
              <button
                className="bg-[#0b154f] text-[#e5e9f2] text-lg px-6 py-2 rounded-xl w-full"
                onClick={() => setIsLoginOpen(true)}
              >
                Log in
              </button>
              <button
                className="text-[#0b154f] border border-[#0b154f] text-lg px-7 py-2 rounded-xl transition-colors w-full"
                onClick={() => setIsSignOpen(true)}
              >
                Sign in
              </button>
            </div>
          </div>
        )}
      </div>

      {/* ✅ Show Login Modal */}
      {isLoginOpen && <LoginModal onClose={() => setIsLoginOpen(false)} />}
      {isSignOpen && <SignModal onClose={() => setIsSignOpen(false)} />}
    </div>
  );
};

export default Navbar;
