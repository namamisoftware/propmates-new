// import { useState } from "react";

// export default function CityPropertyNav() {
//   const [activeCity, setActiveCity] = useState("Mumbai");

//   const cityData = {
//     Mumbai: [
//       "Apartments at Dubai Maritime City",
//       "Apartments at Dubai Sport City",
//       "Apartments at Dubai Island City",
//       "Apartments at Dubai Hills Estate",
//       "Apartments at Dubai Creek Harbour",
//     ],
//     Bangalore: [
//       "Apartments at Whitefield",
//       "Apartments at Electronic City",
//       "Apartments at Hebbal",
//       "Apartments at Sarjapur Road",
//       "Apartments at Marathahalli",
//     ],
//     Gurgaon: [
//       "Apartments at Golf Course Road",
//       "Apartments at Sohna Road",
//       "Apartments at MG Road",
//       "Apartments at Dwarka Expressway",
//       "Apartments at Sector 57",
//     ],
//     Pune: [
//       "Apartments at Hinjewadi",
//       "Apartments at Kharadi",
//       "Apartments at Baner",
//       "Apartments at Wakad",
//       "Apartments at Viman Nagar",
//     ],
//     Noida: [
//       "Apartments at Sector 62",
//       "Apartments at Greater Noida West",
//       "Apartments at Sector 137",
//       "Apartments at Sector 150",
//       "Apartments at Tech Zone 4",
//     ],
//     Hyderabad: [
//       "Apartments at Hitech City",
//       "Apartments at Gachibowli",
//       "Apartments at Kondapur",
//       "Apartments at Kukatpally",
//       "Apartments at Madhapur",
//     ],
//     Thane: [
//       "Apartments at Ghodbunder Road",
//       "Apartments at Pokhran Road",
//       "Apartments at Majiwada",
//       "Apartments at Kolshet Road",
//       "Apartments at Manpada",
//     ],
//     "Navi Mumbai": [
//       "Apartments at Kharghar",
//       "Apartments at Panvel",
//       "Apartments at Nerul",
//       "Apartments at Vashi",
//       "Apartments at Airoli",
//     ],
//     Delhi: [
//       "Apartments at Dwarka",
//       "Apartments at Rohini",
//       "Apartments at Janakpuri",
//       "Apartments at Vasant Kunj",
//       "Apartments at Saket",
//     ],
//   };

//   const cities = Object.keys(cityData);

//   return (
//     <div className="w-full max-w-8xl mx-auto px-14  mb-14">
//       <div className="flex flex-wrap gap-3 mb-8">
//         {cities.map((city) => (
//           <button
//             key={city}
//             onClick={() => setActiveCity(city)}
//             className={`px-6 py-3 rounded-lg font-medium transition-all ${
//               activeCity === city
//                 ? "bg-gray-800 text-white shadow-md"
//                 : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
//             }`}
//           >
//             {city}
//           </button>
//         ))}
//       </div>

//       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//         {[...Array(4)].map((_, colIndex) => (
//           <div key={colIndex} className="space-y-4">
//             {cityData[activeCity].map((property, idx) => (
//               <div
//                 key={`${colIndex}-${idx}`}
//                 className="bg-white p-4 rounded-lg text-gray-500 hover:text-gray-700 hover:shadow-md transition-all cursor-pointer border border-gray-100"
//               >
//                 {property}
//               </div>
//             ))}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// import { useState } from "react";

// export default function CityPropertyNav() {
//   const [activeCity, setActiveCity] = useState("Mumbai");

//   const cityData = {
//     Mumbai: [
//       "Apartments at Dubai Maritime City",
//       "Apartments at Dubai Sport City",
//       "Apartments at Dubai Island City",
//       "Apartments at Dubai Hills Estate",
//       "Apartments at Dubai Creek Harbour",
//     ],
//     Bangalore: [
//       "Apartments at Whitefield",
//       "Apartments at Electronic City",
//       "Apartments at Hebbal",
//       "Apartments at Sarjapur Road",
//       "Apartments at Marathahalli",
//     ],
//     Gurgaon: [
//       "Apartments at Golf Course Road",
//       "Apartments at Sohna Road",
//       "Apartments at MG Road",
//       "Apartments at Dwarka Expressway",
//       "Apartments at Sector 57",
//     ],
//     Pune: [
//       "Apartments at Hinjewadi",
//       "Apartments at Kharadi",
//       "Apartments at Baner",
//       "Apartments at Wakad",
//       "Apartments at Viman Nagar",
//     ],
//     Noida: [
//       "Apartments at Sector 62",
//       "Apartments at Greater Noida West",
//       "Apartments at Sector 137",
//       "Apartments at Sector 150",
//       "Apartments at Tech Zone 4",
//     ],
//     Hyderabad: [
//       "Apartments at Hitech City",
//       "Apartments at Gachibowli",
//       "Apartments at Kondapur",
//       "Apartments at Kukatpally",
//       "Apartments at Madhapur",
//     ],
//     Thane: [
//       "Apartments at Ghodbunder Road",
//       "Apartments at Pokhran Road",
//       "Apartments at Majiwada",
//       "Apartments at Kolshet Road",
//       "Apartments at Manpada",
//     ],
//     "Navi Mumbai": [
//       "Apartments at Kharghar",
//       "Apartments at Panvel",
//       "Apartments at Nerul",
//       "Apartments at Vashi",
//       "Apartments at Airoli",
//     ],
//     Delhi: [
//       "Apartments at Dwarka",
//       "Apartments at Rohini",
//       "Apartments at Janakpuri",
//       "Apartments at Vasant Kunj",
//       "Apartments at Saket",
//     ],
//   };

//   const cities = Object.keys(cityData);

//   return (
//     <div className="w-full max-w-8xl mx-auto px-4 sm:px-6 lg:px-14 py-6 mb-8 sm:mb-14">
//       {/* City Navigation Buttons */}
//       <div className="flex flex-wrap gap-2 sm:gap-3 mb-6 sm:mb-8">
//         {cities.map((city) => (
//           <button
//             key={city}
//             onClick={() => setActiveCity(city)}
//             className={`px-3 py-2 sm:px-6 sm:py-3 rounded-lg text-sm sm:text-base font-medium transition-all ${
//               activeCity === city
//                 ? "bg-gray-800 text-white shadow-md"
//                 : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
//             }`}
//           >
//             {city}
//           </button>
//         ))}
//       </div>

//       {/* Property Grid */}
//       <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
//         {cityData[activeCity].map((property, idx) => (
//           <div
//             key={idx}
//             className="bg-white p-3 sm:p-4 rounded-lg text-sm sm:text-base text-gray-500 hover:text-gray-700 hover:shadow-md transition-all cursor-pointer border border-gray-100"
//           >
//             {property}
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

import { useState } from "react";

export default function CityPropertyNav() {
  const [activeCity, setActiveCity] = useState("Mumbai");

  const cityData = {
    Mumbai: [
      "Apartments at Dubai Maritime City",
      "Apartments at Dubai Sport City",
      "Apartments at Dubai Island City",
      "Apartments at Dubai Hills Estate",
      "Apartments at Dubai Creek Harbour",
    ],
    Bangalore: [
      "Apartments at Whitefield",
      "Apartments at Electronic City",
      "Apartments at Hebbal",
      "Apartments at Sarjapur Road",
      "Apartments at Marathahalli",
    ],
    Gurgaon: [
      "Apartments at Golf Course Road",
      "Apartments at Sohna Road",
      "Apartments at MG Road",
      "Apartments at Dwarka Expressway",
      "Apartments at Sector 57",
    ],
    Pune: [
      "Apartments at Hinjewadi",
      "Apartments at Kharadi",
      "Apartments at Baner",
      "Apartments at Wakad",
      "Apartments at Viman Nagar",
    ],
    Noida: [
      "Apartments at Sector 62",
      "Apartments at Greater Noida West",
      "Apartments at Sector 137",
      "Apartments at Sector 150",
      "Apartments at Tech Zone 4",
    ],
    Hyderabad: [
      "Apartments at Hitech City",
      "Apartments at Gachibowli",
      "Apartments at Kondapur",
      "Apartments at Kukatpally",
      "Apartments at Madhapur",
    ],
    Thane: [
      "Apartments at Ghodbunder Road",
      "Apartments at Pokhran Road",
      "Apartments at Majiwada",
      "Apartments at Kolshet Road",
      "Apartments at Manpada",
    ],
    "Navi Mumbai": [
      "Apartments at Kharghar",
      "Apartments at Panvel",
      "Apartments at Nerul",
      "Apartments at Vashi",
      "Apartments at Airoli",
    ],
    Delhi: [
      "Apartments at Dwarka",
      "Apartments at Rohini",
      "Apartments at Janakpuri",
      "Apartments at Vasant Kunj",
      "Apartments at Saket",
    ],
  };

  const cities = Object.keys(cityData);

  return (
    <div className="w-full max-w-8xl mx-auto px-4 sm:px-6 lg:px-14 py-6 mb-8 sm:mb-14">
      {/* City Navigation Buttons */}
      <div className="flex flex-wrap gap-2 sm:gap-3 mb-6 sm:mb-8">
        {cities.map((city) => (
          <button
            key={city}
            onClick={() => setActiveCity(city)}
            className={`px-3 py-2 sm:px-6 sm:py-3 rounded-lg text-sm sm:text-base font-medium transition-all ${
              activeCity === city
                ? "bg-gray-800 text-white shadow-md"
                : "bg-white text-gray-700 hover:bg-gray-100 border border-gray-200"
            }`}
          >
            {city}
          </button>
        ))}
      </div>

      {/* Property Grid - Showing properties repeated in 4 columns */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-3 sm:gap-4 lg:gap-6">
        {[...Array(4)].map((_, colIndex) => (
          <div key={colIndex} className="space-y-3 sm:space-y-4">
            {cityData[activeCity].map((property, idx) => (
              <div
                key={`${colIndex}-${idx}`}
                className="bg-white p-3 sm:p-4 rounded-lg text-sm sm:text-base text-gray-500 hover:text-gray-700 hover:shadow-md transition-all cursor-pointer border border-gray-100"
              >
                {property}
              </div>
            ))}
          </div>
        ))}
      </div>
    </div>
  );
}
