import React from "react";
import { useState, useEffect, useRef } from "react";
import {
  ChevronDown,
  Search,
  ChevronLeft,
  ChevronRight,
  X,
} from "lucide-react";
import { Calculator, Home, CheckCircle, RefreshCw } from "lucide-react";
import calc1 from "../assets/calc1.png";
import calc2 from "../assets/calc2.png";
import calc3 from "../assets/calc3.png";
import BudgetCalculator from "../Calculator/BudgetCalculator";
import EMICalculator from "../Calculator/EMICalculator";
import LoanEligibility from "../Calculator/LoanEligibility";
import AreaConvertor from "../Calculator/AreaConvertor";
import { Link, useNavigate } from "react-router-dom";
import { useLocation } from "./LocationContext";
import axios from "axios";

const Herosection = () => {
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedTab, setSelectedTab] = useState("Buy");
  const [isPropertyTypeDropdownOpen, setIsPropertyTypeDropdownOpen] =
    useState(false);
  const [isBedsDropdownOpen, setIsBedsDropdownOpen] = useState(false);
  const [selectedPropertyType, setSelectedPropertyType] = useState("");
  const [selectedBedRooms, setSelectedBedRooms] = useState([]);
  const [selectedBathRooms, setSelectedBathRooms] = useState([]);

  const { selectedCity } = useLocation();
  const [searchLocations, setSearchLocations] = useState([]);
  const [currentSearchInput, setCurrentSearchInput] = useState("");
  const [showLocationSuggestions, setShowLocationSuggestions] = useState(false);

  const [localitySuggestions, setLocalitySuggestions] = useState([]);
  const [isLoadingLocalities, setIsLoadingLocalities] = useState(false);

  useEffect(() => {
    if (selectedCity) {
      setSearchLocations([selectedCity]);
    }
  }, [selectedCity]);

  useEffect(() => {
    const fetchLocalitySuggestions = async () => {
      if (!selectedCity || currentSearchInput.length < 2) {
        setLocalitySuggestions([]);
        return;
      }

      setIsLoadingLocalities(true);

      try {
        const GEOAPIFY_API_KEY = "7cb4a231b8d7445e817a708878a5a5cc";

        // Use geocode search with bias towards city
        const res = await axios.get(
          `https://api.geoapify.com/v1/geocode/search`,
          {
            params: {
              text: `${currentSearchInput}, ${selectedCity}, India`,
              limit: 10,
              apiKey: GEOAPIFY_API_KEY,
            },
          }
        );

        console.log("Search API Response:", res.data);

        if (res.data.features && res.data.features.length > 0) {
          const localities = res.data.features
            .map((feature) => {
              const props = feature.properties;
              return {
                name:
                  props.name ||
                  props.street ||
                  props.suburb ||
                  props.neighbourhood ||
                  props.formatted,
                locality: props.neighbourhood || props.suburb || props.locality,
                city: props.city || props.county,
                fullAddress: props.formatted,
              };
            })
            .filter((loc) => loc.name);

          setLocalitySuggestions(localities);
        } else {
          setLocalitySuggestions([]);
        }
      } catch (err) {
        console.error("Error fetching locality suggestions:", err);
        setLocalitySuggestions([]);
      } finally {
        setIsLoadingLocalities(false);
      }
    };

    const delayDebounce = setTimeout(fetchLocalitySuggestions, 600);
    return () => clearTimeout(delayDebounce);
  }, [currentSearchInput, selectedCity]);

  const handleAddLocation = (location) => {
    // Accept both string and object formats
    const locationName =
      typeof location === "string" ? location : location.name;

    if (locationName && !searchLocations.includes(locationName)) {
      setSearchLocations([...searchLocations, locationName]);
      setCurrentSearchInput("");
      setShowLocationSuggestions(false);
      setLocalitySuggestions([]);
    }
  };

  const handleRemoveLocation = (locationToRemove) => {
    setSearchLocations(
      searchLocations.filter((loc) => loc !== locationToRemove)
    );
  };

  const handleSearchInputChange = (e) => {
    setCurrentSearchInput(e.target.value);
    setShowLocationSuggestions(e.target.value.length > 0);
  };

  const handleSearchInputKeyDown = (e) => {
    if (e.key === "Enter" && currentSearchInput.trim()) {
      handleAddLocation(currentSearchInput.trim());
    }
  };

  const dropdownRef = useRef(null);

  const tabs = ["Buy", "Rent", "Holiday Rent", "PG", "Commercial"];

  // Dynamic content based on selected tab
  const getTabContent = (tab) => {
    switch (tab) {
      case "Buy":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "townhouse", label: "Townhouse" },
            { value: "penthouse", label: "Penthouse" },
            { value: "plot", label: "Plot/Land" },
          ],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
      case "Rent":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "studio", label: "Studio" },
            { value: "shared", label: "Shared Space" },
            { value: "office", label: "Office Space" },
          ],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
      case "Holiday Rent":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "residential", label: "Residential" },
            { value: "mixed-use", label: "Mixed Use" },
            { value: "luxury", label: "Luxury" },
            { value: "affordable", label: "Affordable Housing" },
          ],
          bedsLabel: "Bedrooms",
          showBedsAndBaths: true,
        };
      case "PG":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "residential", label: "Residential" },
            { value: "mixed-use", label: "Mixed Use" },
            { value: "luxury", label: "Luxury" },
            { value: "affordable", label: "Affordable Housing" },
          ],
          bedsLabel: "Bedrooms",
          showBedsAndBaths: true,
        };
      case "Commercial":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "office", label: "Office Space" },
            { value: "retail", label: "Retail Space" },
            { value: "warehouse", label: "Warehouse" },
            { value: "industrial", label: "Industrial" },
            { value: "coworking", label: "Co-working Space" },
          ],
          bedsLabel: "Area (sqft)",
          showBedsAndBaths: false,
          areaOptions: [
            { value: "500-1000", label: "500-1000 sqft" },
            { value: "1000-2000", label: "1000-2000 sqft" },
            { value: "2000-5000", label: "2000-5000 sqft" },
            { value: "5000+", label: "5000+ sqft" },
          ],
        };
      default:
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
    }
  };

  const currentContent = getTabContent(selectedTab);

  const bedroomOptions = ["Studio", "1", "2", "3", "4", "5", "6", "7", "8+"];
  const bathroomOptions = ["Bedrooms", "1", "2", "3", "4", "5", "6", "7", "8+"];

  // For commercial area selection
  const [selectedArea, setSelectedArea] = useState("");

  const togglePropertyTypeDropdown = () => {
    setIsPropertyTypeDropdownOpen(!isPropertyTypeDropdownOpen);
    setIsBedsDropdownOpen(false);
  };

  const toggleBedsDropdown = () => {
    setIsBedsDropdownOpen(!isBedsDropdownOpen);
    setIsPropertyTypeDropdownOpen(false);
  };

  const handlePropertyTypeSelect = (option) => {
    setSelectedPropertyType(option.label);
    setIsPropertyTypeDropdownOpen(false);
  };

  const toggleBedBathSelection = (type, value) => {
    if (type === "bedRooms") {
      setSelectedBedRooms((prev) => {
        if (prev.includes(value)) {
          return prev.filter((item) => item !== value);
        } else {
          return [...prev, value];
        }
      });
    } else if (type === "bathRooms") {
      setSelectedBathRooms((prev) => {
        if (prev.includes(value)) {
          return prev.filter((item) => item !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleAreaSelect = (option) => {
    setSelectedArea(option.label);
    setIsBedsDropdownOpen(false);
  };

  // Reset selections when tab changes
  const handleTabChange = (tab) => {
    setSelectedTab(tab);
    setSelectedPropertyType("");
    setSelectedBedRooms([]);
    setSelectedBathRooms([]);
    setSelectedArea("");
    setIsPropertyTypeDropdownOpen(false);
    setIsBedsDropdownOpen(false);
    setSearchLocations([]);
    setCurrentSearchInput("");
  };

  // Generate display value for beds & baths dropdown
  const getBedsAndBathsDisplayValue = () => {
    if (selectedTab === "Commercial") {
      return selectedArea || currentContent.bedsLabel;
    }

    if (selectedBedRooms.length || selectedBathRooms.length) {
      const bedsText = selectedBedRooms.length
        ? `Beds: ${selectedBedRooms.join(", ")}`
        : "";
      const bathsText = selectedBathRooms.length
        ? `Baths: ${selectedBathRooms.join(", ")}`
        : "";
      return [bedsText, bathsText].filter(Boolean).join(" | ");
    }
    return currentContent.bedsLabel;
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsBedsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Sample slider images
  const sliderImages = [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      title: "Modern Luxury Homes",
      subtitle: "Premium Properties",
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80",
      title: "Contemporary Living",
      subtitle: "Stylish Interiors",
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2053&q=80",
      title: "Elegant Residences",
      subtitle: "Your Perfect Home",
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      title: "Dream Properties",
      subtitle: "Exceptional Quality",
    },
  ];

  // Auto-slide functionality
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [sliderImages.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide(
      (prev) => (prev - 1 + sliderImages.length) % sliderImages.length
    );
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  const calculators = [
    {
      title: "Budget Calculator",
      description: "Check your affordability range for buying home",
      path: "/budgetCalculator",
      icon: (
        <img
          src={calc1}
          alt="Budget Calculator"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "EMI Calculator",
      description: "Calculate your home loan EMI",
      path: "/emiCalculator",
      icon: (
        <img
          src={calc1}
          alt="EMI Calculator"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "Loan Eligibility",
      description: "See what you can borrow for your home",
      path: "/loanEligibility",
      icon: (
        <img
          src={calc2}
          alt="Loan Eligibility"
          className="w-25 h-25 object-contain"
        />
      ),
    },
    {
      title: "Area Converter",
      description: "Convert one area into any other easily",
      path: "/areaConverter",
      icon: (
        <img
          src={calc3}
          alt="Area Converter"
          className="w-25 h-25 object-contain"
        />
      ),
    },
  ];

  return (
    <div className="min-h-screen pb-[1440px] sm:pb-[750px] md:pb-[1400px] lg:pb-[600px] xl:pb-[500px]">
      <div className=" px-4 md:px-8 py-1 relative mt-6 ">
        {/* Hero Section with Slider */}
        <div className="w-full h-[400px] md:h-[500px] lg:h-[600px] text-white rounded-2xl relative overflow-hidden">
          {/* Slider Images */}
          <div className="relative w-full h-full">
            {sliderImages.map((image, index) => (
              <div
                key={image.id}
                className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                  index === currentSlide ? "opacity-100" : "opacity-0"
                }`}
              >
                <img
                  src={image.url}
                  alt={image.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-opacity-40"></div>
              </div>
            ))}
          </div>

          {/* Content Overlay */}
          <div className="absolute inset-0 flex flex-col md:flex-row items-center justify-between px-6 md:px-10 lg:px-13 py-8 lg:py-0 z-10">
            <div className="space-y-2 text-left">
              <p className="text-sm md:text-base lg:text-lg">
                Home Buying Will Never Be The Same
              </p>
              <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
                Find your
              </h1>
              <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
                Dream Home
              </h1>
              <p className="text-sm md:text-base lg:text-lg">
                India's first consumer centric real{" "}
                <br className="hidden lg:block" />
                estate buying platform
              </p>
            </div>
          </div>
        </div>

        {/* Search Form Section */}
        <div className=" w-[83%] md:w-[90%] lg:w-[84%] bg-[#0b154f] z-20 absolute top-[50%] md:top-[70%] lg:top-[70%] xl:top-[76%] left-[8%] md:left-[5%] lg:left-[8%] rounded-t-2xl rounded-b-2xl overflow-hidden">
          <div className="w-full bg-[#0b154f] px-4 md:px-10 lg:px-20 py-4 md:py-5 lg:py-10">
            <div className="">
              {/* Tab Navigation */}
              <div className="flex flex-wrap gap-2 md:gap-4 lg:gap-8 mb-4 justify-center">
                {tabs.map((tab) => (
                  <button
                    key={tab}
                    onClick={() => handleTabChange(tab)}
                    className={`px-3 md:px-4 lg:px-6 py-1 rounded-xl text-sm md:text-base lg:text-lg font-medium transition-all duration-200 whitespace-nowrap ${
                      selectedTab === tab
                        ? "border-2 text-white border-white"
                        : "text-[#737580] border-2 border-[#737580]"
                    }`}
                  >
                    {tab}
                  </button>
                ))}
              </div>

              {/* Search Form */}
              <div className="">
                {/* Mobile/Tablet: Stack all elements */}
                <div className="flex flex-col gap-3 items-stretch lg:hidden">
                  {/* Location Search Input */}
                  {/* <div className="flex-1 relative">
                    <input
                      type="text"
                      placeholder={currentContent.searchPlaceholder}
                      className="w-full px-6 py-3.5 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-sm md:placeholder:text-base bg-transparent"
                    />
                    <Search className="absolute right-6 top-1/2 transform -translate-y-1/2 text-white w-5 h-5" />
                  </div> */}
                  {/* Location Search Input with Multiple Selection */}
                  <div className="flex-1 relative">
                    <div className="flex flex-wrap gap-2 px-4 py-2 text-white text-sm md:text-base rounded-2xl border-2 border-white bg-transparent min-h-[50px]">
                      {/* Selected Locations */}
                      {searchLocations.map((location, index) => (
                        <span
                          key={index}
                          className="flex items-center gap-1 bg-white text-[#0b154f] px-3 py-1 rounded-lg text-sm"
                        >
                          {location}
                          <button
                            onClick={() => handleRemoveLocation(location)}
                            className="hover:bg-gray-200 rounded-full p-0.5"
                          >
                            <X className="w-4 h-4" />
                          </button>
                        </span>
                      ))}

                      {/* Input Field */}
                      <input
                        type="text"
                        value={currentSearchInput}
                        onChange={handleSearchInputChange}
                        onKeyDown={handleSearchInputKeyDown}
                        onFocus={() =>
                          setShowLocationSuggestions(
                            currentSearchInput.length > 0
                          )
                        }
                        placeholder={
                          searchLocations.length === 0
                            ? selectedCity
                              ? `Search localities in ${selectedCity}...`
                              : "Select a city first"
                            : "Add more localities..."
                        }
                        className="flex-1 min-w-[150px] bg-transparent focus:outline-none placeholder:text-white text-white"
                      />
                    </div>

                    {/* Location Suggestions Dropdown */}
                    {showLocationSuggestions && (
                      <div className="absolute top-full left-0 mt-2 w-full bg-white border border-gray-300 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
                        {/* Show loading state */}
                        {isLoadingLocalities && (
                          <div className="px-4 py-3 text-center text-gray-500 text-sm">
                            Searching localities in {selectedCity}...
                          </div>
                        )}

                        {/* Show no city selected message */}
                        {!selectedCity && currentSearchInput.length >= 2 && (
                          <div className="px-4 py-3 text-center text-gray-500 text-sm">
                            Please select a city first from the header
                          </div>
                        )}

                        {/* Show localities */}
                        {!isLoadingLocalities &&
                        selectedCity &&
                        localitySuggestions.length > 0 ? (
                          <div>
                            <div className="px-4 py-2 bg-gray-100 text-xs text-gray-600 font-semibold">
                              Localities in {selectedCity}
                            </div>
                            {localitySuggestions.map((locality, index) => (
                              <button
                                key={index}
                                onClick={() => handleAddLocation(locality)}
                                className="block w-full text-left px-4 py-3 text-[#0b154f] hover:bg-gray-100 transition-colors border-b border-gray-100 last:border-b-0"
                              >
                                <div className="font-medium">
                                  {locality.locality || locality.name}
                                </div>
                                <div className="text-xs text-gray-500 mt-0.5">
                                  {locality.fullAddress}
                                </div>
                              </button>
                            ))}
                          </div>
                        ) : !isLoadingLocalities &&
                          selectedCity &&
                          currentSearchInput.length >= 2 &&
                          localitySuggestions.length === 0 ? (
                          <div className="px-4 py-3 text-center text-gray-500 text-sm">
                            No localities found in {selectedCity}
                          </div>
                        ) : null}
                      </div>
                    )}
                  </div>

                  {/* Property Type Dropdown */}
                  <div className="relative">
                    <button
                      onClick={togglePropertyTypeDropdown}
                      className="flex items-center justify-between w-full px-8 py-3.5 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
                    >
                      <span
                        className={
                          selectedPropertyType ? "text-white" : "text-white"
                        }
                      >
                        {selectedPropertyType || "Property type"}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-white transition-transform ${
                          isPropertyTypeDropdownOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {isPropertyTypeDropdownOpen && (
                      <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                        <div className="py-2">
                          {currentContent.propertyTypeOptions.map((option) => (
                            <button
                              key={option.value}
                              onClick={() => handlePropertyTypeSelect(option)}
                              className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Beds & Baths / Area Dropdown */}
                  <div className="relative" ref={dropdownRef}>
                    <button
                      onClick={toggleBedsDropdown}
                      className="flex items-center justify-between w-full px-6 py-3.5 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
                    >
                      <span className="text-white truncate pr-2">
                        {getBedsAndBathsDisplayValue()}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-white transition-transform ${
                          isBedsDropdownOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>

                    {isBedsDropdownOpen && (
                      <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                        <div className="p-3 md:p-4 max-h-64 overflow-y-auto">
                          {currentContent.showBedsAndBaths ? (
                            <>
                              {/* Bedrooms */}
                              <div className="mb-4">
                                <div className="flex flex-col gap-3 mb-3">
                                  <div className="flex flex-wrap gap-2">
                                    {bedroomOptions.map((item) => (
                                      <button
                                        key={item}
                                        type="button"
                                        onClick={() =>
                                          toggleBedBathSelection(
                                            "bedRooms",
                                            item
                                          )
                                        }
                                        className={`px-3 py-2 rounded-md text-sm ${
                                          selectedBedRooms.includes(item)
                                            ? "bg-[#0b154f] text-white"
                                            : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                        }`}
                                      >
                                        {item}
                                      </button>
                                    ))}
                                  </div>
                                </div>

                                {/* Bathrooms */}
                                <div className="flex flex-col gap-3">
                                  <div className="flex flex-wrap gap-2">
                                    {bathroomOptions.map((item) => (
                                      <button
                                        key={item}
                                        type="button"
                                        onClick={() =>
                                          toggleBedBathSelection(
                                            "bathRooms",
                                            item
                                          )
                                        }
                                        className={`px-3 py-2 rounded-md text-sm ${
                                          selectedBathRooms.includes(item)
                                            ? "bg-[#0b154f] text-white"
                                            : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                        }`}
                                      >
                                        {item}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </>
                          ) : (
                            // Commercial Area Options
                            <div className="py-2">
                              {currentContent.areaOptions?.map((option) => (
                                <button
                                  key={option.value}
                                  onClick={() => handleAreaSelect(option)}
                                  className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                                >
                                  {option.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Search Button */}
                  <button className="bg-white text-[#0b154f] px-8 md:px-12 py-3.5 rounded-2xl font-semibold text-sm md:text-base">
                    Search
                  </button>
                </div>

                {/* Desktop: All elements in same row */}
                <div className="hidden lg:flex flex-row gap-4 items-start justify-center">
                  {/* Location Search Input */}
                  <div className="flex-1 relative max-w-[400px]">
                    {/* Location Search Input with Multiple Selection */}
                    <div className="">
                      <div className="flex flex-wrap gap-2 px-4 py-2 text-white text-sm md:text-base rounded-2xl border-2 border-white bg-transparent min-h-[50px]">
                        {/* Selected Locations */}
                        {searchLocations.map((location, index) => (
                          <span
                            key={index}
                            className="flex items-center gap-1 bg-white text-[#0b154f] px-3 py-1 rounded-lg text-sm"
                          >
                            {location}
                            <button
                              onClick={() => handleRemoveLocation(location)}
                              className="hover:bg-gray-200 rounded-full p-0.5"
                            >
                              <X className="w-4 h-4" />
                            </button>
                          </span>
                        ))}

                        {/* Input Field */}
                        <input
                          type="text"
                          value={currentSearchInput}
                          onChange={handleSearchInputChange}
                          onKeyDown={handleSearchInputKeyDown}
                          onFocus={() =>
                            setShowLocationSuggestions(
                              currentSearchInput.length > 0
                            )
                          }
                          placeholder={
                            searchLocations.length === 0
                              ? selectedCity
                                ? `Search localities in ${selectedCity}...`
                                : "Select a city first"
                              : "Add more localities..."
                          }
                          className="flex-1 min-w-[150px] bg-transparent focus:outline-none placeholder:text-white text-white"
                        />
                      </div>

                      {/* Location Suggestions Dropdown - Desktop */}
                      {showLocationSuggestions && (
                        <div className="absolute top-full left-0 mt-2 w-full bg-white border border-gray-300 rounded-xl shadow-lg z-50 max-h-60 overflow-y-auto">
                          {/* Show loading state */}
                          {isLoadingLocalities && (
                            <div className="px-4 py-3 text-center text-gray-500 text-sm">
                              Searching localities in {selectedCity}...
                            </div>
                          )}

                          {/* Show no city selected message */}
                          {!selectedCity && currentSearchInput.length >= 2 && (
                            <div className="px-4 py-3 text-center text-gray-500 text-sm">
                              Please select a city first from the header
                            </div>
                          )}

                          {/* Show localities */}
                          {!isLoadingLocalities &&
                          selectedCity &&
                          localitySuggestions.length > 0 ? (
                            <div>
                              <div className="px-4 py-2 bg-gray-100 text-xs text-gray-600 font-semibold">
                                Localities in {selectedCity}
                              </div>
                              {localitySuggestions.map((locality, index) => (
                                <button
                                  key={index}
                                  onClick={() => handleAddLocation(locality)}
                                  className="block w-full text-left px-4 py-3 text-[#0b154f] hover:bg-gray-100 transition-colors border-b border-gray-100 last:border-b-0"
                                >
                                  <div className="font-medium">
                                    {locality.locality || locality.name}
                                  </div>
                                  <div className="text-xs text-gray-500 mt-0.5">
                                    {locality.fullAddress}
                                  </div>
                                </button>
                              ))}
                            </div>
                          ) : !isLoadingLocalities &&
                            selectedCity &&
                            currentSearchInput.length >= 2 &&
                            localitySuggestions.length === 0 ? (
                            <div className="px-4 py-3 text-center text-gray-500 text-sm">
                              No localities found in {selectedCity}
                            </div>
                          ) : null}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Property Type Dropdown */}
                  <div className="relative min-w-[200px]">
                    <button
                      onClick={togglePropertyTypeDropdown}
                      className="flex items-center justify-between w-full px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
                    >
                      <span
                        className={
                          selectedPropertyType ? "text-white" : "text-white"
                        }
                      >
                        {selectedPropertyType || "Property type"}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-white transition-transform ml-2 ${
                          isPropertyTypeDropdownOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>
                    {isPropertyTypeDropdownOpen && (
                      <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                        <div className="py-2">
                          {currentContent.propertyTypeOptions.map((option) => (
                            <button
                              key={option.value}
                              onClick={() => handlePropertyTypeSelect(option)}
                              className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                            >
                              {option.label}
                            </button>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Beds & Baths / Area Dropdown */}
                  <div className="relative min-w-[200px]" ref={dropdownRef}>
                    <button
                      onClick={toggleBedsDropdown}
                      className="flex items-center justify-between px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent w-full"
                    >
                      <span className="text-white truncate pr-2">
                        {getBedsAndBathsDisplayValue()}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-white transition-transform ml-2 ${
                          isBedsDropdownOpen ? "rotate-180" : ""
                        }`}
                      />
                    </button>

                    {isBedsDropdownOpen && (
                      <div
                        className={`absolute top-full left-0 mt-2 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50 ${
                          currentContent.showBedsAndBaths
                            ? "w-full md:w-[500px]"
                            : "w-full"
                        }`}
                      >
                        <div className="p-4 max-h-64 overflow-y-auto">
                          {currentContent.showBedsAndBaths ? (
                            <>
                              {/* Bedrooms */}
                              <div className="mb-4">
                                <div className="flex flex-col gap-3 mb-3">
                                  <div className="flex flex-wrap gap-2">
                                    {bedroomOptions.map((item) => (
                                      <button
                                        key={item}
                                        type="button"
                                        onClick={() =>
                                          toggleBedBathSelection(
                                            "bedRooms",
                                            item
                                          )
                                        }
                                        className={`px-3 py-2 rounded-md ${
                                          selectedBedRooms.includes(item)
                                            ? "bg-[#0b154f] text-white"
                                            : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                        }`}
                                      >
                                        {item}
                                      </button>
                                    ))}
                                  </div>
                                </div>

                                {/* Bathrooms */}
                                <div className="flex flex-col gap-3">
                                  <div className="flex flex-wrap gap-2">
                                    {bathroomOptions.map((item) => (
                                      <button
                                        key={item}
                                        type="button"
                                        onClick={() =>
                                          toggleBedBathSelection(
                                            "bathRooms",
                                            item
                                          )
                                        }
                                        className={`px-3 py-2 rounded-md ${
                                          selectedBathRooms.includes(item)
                                            ? "bg-[#0b154f] text-white"
                                            : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                        }`}
                                      >
                                        {item}
                                      </button>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </>
                          ) : (
                            // Commercial Area Options
                            <div className="py-2">
                              {currentContent.areaOptions?.map((option) => (
                                <button
                                  key={option.value}
                                  onClick={() => handleAreaSelect(option)}
                                  className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                                >
                                  {option.label}
                                </button>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* Search Button */}
                  <button className="bg-white text-[#0b154f] px-10 py-3.5 rounded-2xl font-semibold text-base whitespace-nowrap">
                    Search
                  </button>
                </div>
              </div>
            </div>
          </div>
          <div className=" bg-gradient-to-r from-gray-700 to-gray-600  shadow-lg px-6 py-6 ">
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full sm:w-auto">
                {/* Professional Image */}
                <div className="w-16 h-16 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-4 border-white shadow-md flex-shrink-0">
                  <img
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop"
                    alt="Professional"
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Text Content */}
                <div className="flex flex-col text-center sm:text-left">
                  <h2 className="text-white text-xl sm:text-2xl font-bold mb-1">
                    Connect with a Professional
                  </h2>
                  <p className="text-gray-200 text-sm sm:text-base">
                    Find trusted experts to guide your real estate journey.
                  </p>
                </div>
              </div>

              {/* CTA Button */}
              <button
                onClick={() => navigate("/contactus")}
                className="bg-white text-gray-800 font-semibold px-5 py-2.5 sm:px-6 sm:py-3 rounded-lg hover:bg-gray-100 transition-colors duration-200 flex items-center gap-2 whitespace-nowrap shadow-md w-full sm:w-auto justify-center"
              >
                Meet Our Experts
                <svg
                  className="w-5 h-5"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button>
            </div>
          </div>
          <div className="bg-[#a0a7ff] p-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {calculators.map((calc, index) => (
                <Link
                  to={calc.path}
                  key={index}
                  className="bg-white rounded-xl text-center p-4 shadow-sm hover:shadow-md transition-shadow duration-300 cursor-pointer group"
                >
                  <div className="flex justify-center mb-2">
                    <div
                      className={`rounded-lg p-3 group-hover:scale-110 transition-transform duration-300`}
                    >
                      {/* Use icon from calculators array */}
                      {calc.icon}
                    </div>
                  </div>

                  <h3 className="font-semibold text-gray-800 text-2xl mb-2 group-hover:text-[#7d85f4] transition-colors">
                    {calc.title}
                  </h3>

                  {/* <p className="text-gray-600 text-sm leading-relaxed">
                    {calc.description}
                  </p> */}
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Herosection;
