// import React, { useState, useRef } from "react";
// import { X, Phone, Eye, EyeOff } from "lucide-react";
// import login from "../assets/login.png";
// import img2 from "../assets/loginbg.png";

// import PhoneInput from "react-phone-number-input";
// import "react-phone-number-input/style.css";

// const SignModal = ({ onClose, onLoginSuccess }) => {
//   const [step, setStep] = useState("form");
//   const [user_type, setuser_type] = useState("individual");

//   // New state variables for form fields
//   const [companyName, setCompanyName] = useState("");
//   const [companyType, setCompanyType] = useState("");
//   const [companyEmail, setCompanyEmail] = useState("");
//   const [contactPersonName, setContactPersonName] = useState("");
//   const [firstName, setFirstName] = useState("");
//   const [lastName, setLastName] = useState("");
//   const [email, setEmail] = useState("");
//   const [phone, setphone] = useState("");
//   const [country, setCountry] = useState("");
//   const [password, setPassword] = useState("");
//   const [confirmPassword, setConfirmPassword] = useState("");

//   // State for password visibility
//   const [showPassword, setShowPassword] = useState(false);
//   const [showConfirmPassword, setShowConfirmPassword] = useState(false);

//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const otpInputs = useRef([]);

//   const handleContinue = () => {
//     // Validation for Individual
//     if (user_type === "individual") {
//       if (
//         !firstName ||
//         !lastName ||
//         !email ||
//         !phone ||
//         !country ||
//         !password ||
//         !confirmPassword
//       ) {
//         alert("Please fill all required fields!");
//         return;
//       }
//     }

//     // Validation for Company
//     if (user_type === "company") {
//       if (
//         !companyName ||
//         !companyType ||
//         !companyEmail ||
//         !contactPersonName ||
//         !phone ||
//         !country ||
//         !password ||
//         !confirmPassword
//       ) {
//         alert("Please fill all required fields!");
//         return;
//       }
//     }

//     if (password !== confirmPassword) {
//       alert("Passwords do not match!");
//       return;
//     }
//     if (password.length < 6) {
//       alert("Password must be at least 6 characters long!");
//       return;
//     }
//     setStep("otp");
//   };

//   const handleOtpChange = (index, value) => {
//     if (value.length > 1) {
//       value = value.slice(-1);
//     }

//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);

//     if (value && index < 5) {
//       otpInputs.current[index + 1]?.focus();
//     }
//   };

//   const handleOtpKeyDown = (index, e) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       otpInputs.current[index - 1]?.focus();
//     }
//   };

//   const handleVerifyOtp = () => {
//     const otpValue = otp.join("");
//     if (otpValue.length === 6) {
//       const userData =
//         user_type === "individual"
//           ? {
//               firstName,
//               lastName,
//               email,
//               phone: phone,
//               country: country,
//               user_type: user_type,
//             }
//           : {
//               companyName,
//               companyType,
//               companyEmail,
//               contactPersonName,
//               phone: phone,
//               country: country,
//               user_type: user_type,
//             };
//       onLoginSuccess(userData);
//       console.log("OTP Verified:", otpValue);
//     }
//   };

//   const handleResendOtp = () => {
//     setOtp(["", "", "", "", "", ""]);
//     console.log("OTP Resent");
//   };

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-[#00000067] bg-opacity-50 z-50">
//       <div
//         style={{
//           backgroundImage: `url(${login})`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//         }}
//         className="relative flex flex-col lg:flex-row items-center justify-center lg:justify-evenly bg-gradient-to-br from-pink-50 via-white to-blue-50 w-full max-w-xs sm:max-w-md md:max-w-2xl lg:max-w-5xl rounded-xl shadow-2xl p-6 sm:p-8 md:p-10 overflow-y-auto max-h-[95vh]"
//       >
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
//         >
//           <X className="w-5 h-5" />
//         </button>

//         {step === "form" ? (
//           <>
//             <div className="flex flex-col gap-12">
//               {" "}
//               {/* Changed from gap-28 to gap-12 */}
//               <div className="">
//                 <h1 className="text-[#0b154f] font-semibold text-2xl">
//                   {" "}
//                   {/* Changed from text-3xl to text-2xl */}
//                   Post your Property
//                 </h1>
//                 <p className="text-xs mb-2">Rent, Sale, Buy Property</p>{" "}
//                 {/* Changed from text-sm to text-xs, added mb-2 */}
//               </div>
//               <img className="hidden lg:block w-64" src={img2} alt="" />{" "}
//               {/* Added w-64 to make image smaller */}
//             </div>

//             {/* Card - Compact design to fit all fields */}
//             <div className="border-1 border-[#0b154f] rounded-3xl relative w-full sm:w-[400px] lg:w-[420px]">
//               <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

//               <div className="relative z-10 px-6 py-4">
//                 {" "}
//                 {/* Changed from px-8 py-6 to px-6 py-4 */}
//                 <h1 className="text-lg font-bold text-[#0b154f] mb-3">
//                   {" "}
//                   {/* Changed from text-xl to text-lg, mb-4 to mb-3 */}
//                   Let's get you started
//                 </h1>
//                 {/* User Type Selection */}
//                 <div className="relative mb-2">
//                   {" "}
//                   {/* Changed from mb-3 to mb-2 */}
//                   <label className="text-[10px]">You are :</label>{" "}
//                   {/* Changed from text-xs to text-[10px] */}
//                   <div className="relative mt-1 flex gap-2">
//                     {" "}
//                     {/* Changed from mt-1.5 gap-3 to mt-1 gap-2 */}
//                     <button
//                       onClick={() => setuser_type("individual")}
//                       className={`w-fit text-[10px] font-medium rounded-lg px-2.5 py-1 transition-colors shadow-sm ${
//                         user_type === "individual"
//                           ? "bg-[#0b154f] text-white"
//                           : "border border-[#0b154f] text-[#0b154f]"
//                       }`}
//                     >
//                       Individual
//                     </button>
//                     <button
//                       onClick={() => setuser_type("company")}
//                       className={`w-fit text-[10px] font-medium rounded-lg px-2.5 py-1 transition-colors shadow-sm ${
//                         user_type === "company"
//                           ? "bg-[#0b154f] text-white"
//                           : "border border-[#0b154f] text-[#0b154f]"
//                       }`}
//                     >
//                       Company
//                     </button>
//                   </div>
//                 </div>
//                 {/* Conditional Fields based on user_type */}
//                 {user_type === "individual" ? (
//                   <>
//                     {/* First Name and Last Name - Side by Side */}
//                     <div className="flex gap-2 mb-2">
//                       {" "}
//                       {/* Changed from gap-3 mb-3 to gap-2 mb-2 */}
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">First Name:</label>
//                         <input
//                           type="text"
//                           placeholder="First name"
//                           value={firstName}
//                           onChange={(e) => setFirstName(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">Last Name:</label>
//                         <input
//                           type="text"
//                           placeholder="Last name"
//                           value={lastName}
//                           onChange={(e) => setLastName(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                     </div>

//                     {/* Email */}
//                     <div className="relative mb-2">
//                       <label className="text-[10px]">Email:</label>
//                       <input
//                         type="email"
//                         placeholder="Enter your email"
//                         value={email}
//                         onChange={(e) => setEmail(e.target.value)}
//                         className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                       />
//                     </div>
//                   </>
//                 ) : (
//                   <>
//                     {/* Company Name and Type - Side by Side */}
//                     <div className="flex gap-2 mb-2">
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">Company Name:</label>
//                         <input
//                           type="text"
//                           placeholder="Company name"
//                           value={companyName}
//                           onChange={(e) => setCompanyName(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">Company Type:</label>
//                         <input
//                           type="text"
//                           placeholder="LLC, Corp, etc."
//                           value={companyType}
//                           onChange={(e) => setCompanyType(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                     </div>

//                     {/* Company Email and Contact Person - Side by Side */}
//                     <div className="flex gap-2 mb-2">
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">Company Email:</label>
//                         <input
//                           type="email"
//                           placeholder="company@example.com"
//                           value={companyEmail}
//                           onChange={(e) => setCompanyEmail(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                       <div className="relative flex-1">
//                         <label className="text-[10px]">Contact Person:</label>
//                         <input
//                           type="text"
//                           placeholder="Full name"
//                           value={contactPersonName}
//                           onChange={(e) => setContactPersonName(e.target.value)}
//                           className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                         />
//                       </div>
//                     </div>
//                   </>
//                 )}
//                 {/* Phone Number and Country - Side by Side (Common for both) */}
//                 <div className="flex gap-2 mb-2">
//                   <div className="relative flex-1">
//                     <label className="text-[10px]">Contact No.:</label>
//                     <div className="rounded-xl mt-0.5">
//                       <PhoneInput
//                         international
//                         defaultCountry="IN"
//                         value={phone}
//                         onChange={setphone}
//                         className="phone-input-custom-compact"
//                         placeholder="Phone number"
//                       />
//                     </div>
//                   </div>
//                   <div className="relative flex-1">
//                     <label className="text-[10px]">Country:</label>
//                     <input
//                       type="text"
//                       placeholder="Country"
//                       value={country}
//                       onChange={(e) => setCountry(e.target.value)}
//                       className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px] mt-0.5"
//                     />
//                   </div>
//                 </div>
//                 {/* Password and Confirm Password - Side by Side (Common for both) */}
//                 <div className="flex gap-2 mb-2">
//                   <div className="relative flex-1">
//                     <label className="text-[10px]">Password:</label>
//                     <div className="relative mt-0.5">
//                       <input
//                         type={showPassword ? "text" : "password"}
//                         placeholder="Password"
//                         value={password}
//                         onChange={(e) => setPassword(e.target.value)}
//                         className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 pr-7 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px]"
//                       />
//                       <button
//                         type="button"
//                         onClick={() => setShowPassword(!showPassword)}
//                         className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800"
//                       >
//                         {showPassword ? (
//                           <Eye size={12} />
//                         ) : (
//                           <EyeOff size={12} />
//                         )}
//                       </button>
//                     </div>
//                   </div>
//                   <div className="relative flex-1">
//                     <label className="text-[10px]">Confirm:</label>
//                     <div className="relative mt-0.5">
//                       <input
//                         type={showConfirmPassword ? "text" : "password"}
//                         placeholder="Confirm"
//                         value={confirmPassword}
//                         onChange={(e) => setConfirmPassword(e.target.value)}
//                         className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-2.5 py-1.5 pr-7 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-[10px]"
//                       />
//                       <button
//                         type="button"
//                         onClick={() =>
//                           setShowConfirmPassword(!showConfirmPassword)
//                         }
//                         className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800"
//                       >
//                         {showConfirmPassword ? (
//                           <Eye size={12} />
//                         ) : (
//                           <EyeOff size={12} />
//                         )}
//                       </button>
//                     </div>
//                   </div>
//                 </div>
//                 {confirmPassword && password !== confirmPassword && (
//                   <p className="text-[9px] text-red-500 -mt-1 mb-1">
//                     Passwords do not match
//                   </p>
//                 )}
//                 {/* Continue Button */}
//                 <button
//                   onClick={handleContinue}
//                   disabled={
//                     user_type === "individual"
//                       ? !firstName ||
//                         !lastName ||
//                         !email ||
//                         !phone ||
//                         !country ||
//                         !password ||
//                         !confirmPassword
//                       : !companyName ||
//                         !companyType ||
//                         !companyEmail ||
//                         !contactPersonName ||
//                         !phone ||
//                         !country ||
//                         !password ||
//                         !confirmPassword
//                   }
//                   className="w-full bg-[#0b154f] text-white text-[10px] font-medium rounded-lg py-2 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed mt-1"
//                 >
//                   Continue
//                 </button>
//               </div>
//             </div>
//           </>
//         ) : (
//           <>
//             {/* OTP Screen - Left Side */}
//             <div className="md:border-1 border-[#0b154f] rounded-3xl relative w-[330px] overflow-hidden">
//               <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

//               <div className="relative z-10 px-8 py-10">
//                 <h1 className="text-2xl font-bold text-[#0b154f] mb-2">
//                   Verify OTP
//                 </h1>
//                 <p className="text-sm text-gray-600 mb-6">
//                   We've sent a code to {phone}
//                 </p>

//                 <div className="mb-6">
//                   <label className="text-sm mb-3 block">Enter OTP:</label>
//                   <div className="flex gap-2">
//                     {otp.map((digit, index) => (
//                       <input
//                         key={index}
//                         ref={(el) => (otpInputs.current[index] = el)}
//                         type="text"
//                         maxLength="1"
//                         value={digit}
//                         onChange={(e) => handleOtpChange(index, e.target.value)}
//                         onKeyDown={(e) => handleOtpKeyDown(index, e)}
//                         className="w-10 h-12 text-center text-xl font-semibold rounded-lg bg-pink-100/60 border border-gray-700 text-gray-800 focus:outline-none focus:ring-1 focus:ring-pink-300"
//                       />
//                     ))}
//                   </div>
//                 </div>

//                 <button
//                   onClick={handleVerifyOtp}
//                   disabled={otp.join("").length !== 6}
//                   className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   Verify OTP
//                 </button>

//                 <div className="text-center mb-4">
//                   <button
//                     onClick={handleResendOtp}
//                     className="text-sm text-[#0b154f] hover:underline"
//                   >
//                     Resend OTP
//                   </button>
//                 </div>

//                 <button
//                   onClick={() => setStep("form")}
//                   className="w-full text-sm text-gray-600 hover:text-gray-800"
//                 >
//                   ← Back
//                 </button>
//               </div>
//             </div>

//             {/* Right Side - Keep same as original */}
//             <div className="hidden lg:flex flex-col gap-28">
//               <div className="">
//                 <h1 className="text-[#0b154f] font-semibold text-3xl">
//                   Post your Property
//                 </h1>
//                 <p className="text-sm">Rent, Sale, Buy Property</p>
//               </div>
//               <img src={img2} alt="" />
//             </div>
//           </>
//         )}

//         <style jsx>{`
//           .phone-input-custom,
//           .phone-input-custom-compact {
//             width: 100%;
//           }
//           .phone-input-custom input,
//           .phone-input-custom-compact input {
//             width: 100%;
//             border-radius: 0.75rem;
//             background-color: rgba(252, 231, 243, 0.6);
//             border: 1px solid #374151;
//             color: #1f2937;
//           }
//           .phone-input-custom input {
//             padding: 0.875rem 1rem;
//             padding-left: 3rem;
//             font-size: 0.875rem;
//           }
//           .phone-input-custom-compact input {
//             padding: 0.5rem 0.75rem;
//             padding-left: 2.8rem;
//             font-size: 0.75rem;
//           }
//           .phone-input-custom input:focus,
//           .phone-input-custom-compact input:focus {
//             outline: none;
//             box-shadow: 0 0 0 1px rgba(249, 168, 212, 1);
//           }
//           .phone-input-custom input::placeholder,
//           .phone-input-custom-compact input::placeholder {
//             color: #4b5563;
//           }
//           .phone-input-custom .PhoneInputCountry,
//           .phone-input-custom-compact .PhoneInputCountry {
//             position: absolute;
//             top: 55%;
//             // transform: translateY(55%);
//             z-index: 1;
//           }
//           .phone-input-custom .PhoneInputCountry {
//             left: 1rem;
//           }
//           .phone-input-custom-compact .PhoneInputCountry {
//             left: 0.6rem;
//           }
//         `}</style>
//       </div>
//     </div>
//   );
// };

// export default SignModal;

import React, { useState, useRef } from "react";
import { X, Phone, Eye, EyeOff } from "lucide-react";
import login from "../assets/login.png";
import img2 from "../assets/loginbg.png";

import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";

const SignModal = ({ onClose, onLoginSuccess }) => {
  const [step, setStep] = useState("form");
  const [loading, setLoading] = useState(false);

  // New state variables for form fields
  const [name, setname] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setphone] = useState("");
  const [country, setCountry] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");

  // State for password visibility
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  const otpInputs = useRef([]);

  const handleContinue = async () => {
    // Validation check for all required fields
    if (name && email && phone && country && password && confirmPassword) {
      if (password !== confirmPassword) {
        alert("Passwords do not match!");
        return;
      }
      if (password.length < 6) {
        alert("Password must be at least 6 characters long!");
        return;
      }
      setStep("otp");
    }

    setLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/send-otp/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: name,
          email: email,
          phone: phone,
          country: country,
          password: password,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log("Registration successful:", data);
        setStep("otp"); // Move to OTP screen
      } else {
        alert(data.message || "Registration failed");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleOtpChange = (index, value) => {
    if (value.length > 1) {
      value = value.slice(-1);
    }

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpInputs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpInputs.current[index - 1]?.focus();
    }
  };

  // const handleVerifyOtp = async () => {
  //   const otpValue = otp.join("");

  //   if (otpValue.length !== 6) {
  //     alert("Please enter complete OTP");
  //     return;
  //   }

  //   setLoading(true);

  //   try {
  //     const response = await fetch("http://127.0.0.1:8000/api/verify-otp/", {
  //       method: "POST",
  //       headers: {
  //         "Content-Type": "application/json",
  //       },
  //       body: JSON.stringify({
  //         email: email,
  //         otp: otpValue,
  //       }),
  //     });

  //     const data = await response.json();

  //     if (response.ok) {
  //       console.log("OTP Verified:", data);
  //       const userData = {
  //         name,
  //         email,
  //         phone: phone,
  //         country: country,
  //       };
  //       onLoginSuccess(userData);
  //     } else {
  //       alert(data.message || "Invalid OTP");
  //     }
  //   } catch (error) {
  //     console.error("Error:", error);
  //     alert("An error occurred. Please try again.");
  //   } finally {
  //     setLoading(false);
  //   }
  // };

  const handleVerifyOtp = async () => {
    const otpValue = otp.join("");

    if (otpValue.length !== 6) {
      alert("Please enter complete OTP");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/verify-otp/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          otp: otpValue,
        }),
      });

      let data = {};

      // 🛡️ Protect against HTML response
      try {
        data = await response.json();
      } catch (e) {
        console.error("Non-JSON response from backend:", e);
        alert("Server error. Check backend logs.");
        return;
      }

      if (response.ok) {
        console.log("OTP Verified:", data);
        const userData = {
          name,
          email,
          phone,
          country,
        };
        onLoginSuccess(userData);
      } else {
        alert(data.message || "Invalid OTP");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("Registration Successful. Please Login.");
      onLoginSuccess(userData);
      onClose()
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = () => {
    setOtp(["", "", "", "", "", ""]);
    console.log("OTP Resent");
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#00000067] bg-opacity-50 z-50">
      <div
        style={{
          backgroundImage: `url(${login})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
        className="relative flex flex-col lg:flex-row items-center justify-center lg:justify-evenly bg-gradient-to-br from-pink-50 via-white to-blue-50 w-full max-w-xs sm:max-w-md md:max-w-2xl lg:max-w-5xl rounded-xl shadow-2xl p-6 sm:p-8 md:p-10 overflow-y-auto max-h-[95vh]"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>

        {step === "form" ? (
          <>
            <div className="flex flex-col gap-28">
              <div className="">
                <h1 className="text-[#0b154f] font-semibold text-3xl">
                  Post your Property
                </h1>
                <p className="text-sm mb-4">Rent, Sale, Buy Property</p>
              </div>
              <img className="hidden lg:block" src={img2} alt="" />
            </div>

            {/* Card - Compact design to fit all fields */}
            <div className="border-1 border-[#0b154f] rounded-3xl relative w-full sm:w-[400px] lg:w-[420px]">
              <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

              <div className="relative z-10 px-8 py-6">
                <h1 className="text-xl font-bold text-[#0b154f] mb-4">
                  Let's get you started
                </h1>

                {/* First Name and Last Name - Side by Side */}
                <div className="flex gap-3 mb-3">
                  <div className="relative flex-1">
                    <label className="text-xs">Full Name:</label>
                    <input
                      type="text"
                      placeholder="Full Name"
                      value={name}
                      onChange={(e) => setname(e.target.value)}
                      className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-3 py-2 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-xs mt-1"
                    />
                  </div>
                </div>

                {/* Email */}
                <div className="relative mb-3">
                  <label className="text-xs">Email:</label>
                  <input
                    type="email"
                    placeholder="Enter your email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-3 py-2 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-xs mt-1"
                  />
                </div>

                {/* Phone Number and Country - Side by Side */}
                <div className="flex flex-col md:flex-row gap-4 mb-3">
                  <div className="relative flex-1">
                    <label className="text-xs">Contact No.:</label>
                    <div className=" rounded-xl">
                      <PhoneInput
                        international
                        defaultCountry="IN"
                        value={phone}
                        onChange={setphone}
                        className="phone-input-custom-compact"
                        placeholder="Phone number"
                      />
                    </div>
                  </div>
                  <div className="relative flex-1">
                    <label className="text-xs">Country:</label>
                    <input
                      type="text"
                      placeholder="Country Name"
                      value={country}
                      onChange={(e) => setCountry(e.target.value)}
                      className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-3 py-2 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-xs mt-1"
                    />
                  </div>
                </div>

                {/* Password and Confirm Password - Side by Side */}
                <div className="flex gap-3 mb-3">
                  <div className="relative flex-1">
                    <label className="text-xs">Password:</label>
                    <div className="relative mt-1">
                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-3 py-2 pr-8 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800"
                      >
                        {showPassword ? (
                          <EyeOff size={14} />
                        ) : (
                          <Eye size={14} />
                        )}
                      </button>
                    </div>
                  </div>
                  <div className="relative flex-1">
                    <label className="text-xs">Confirm:</label>
                    <div className="relative mt-1">
                      <input
                        type={showConfirmPassword ? "text" : "password"}
                        placeholder="Confirm"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-3 py-2 pr-8 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-xs"
                      />
                      <button
                        type="button"
                        onClick={() =>
                          setShowConfirmPassword(!showConfirmPassword)
                        }
                        className="absolute right-2 top-1/2 -translate-y-1/2 text-gray-600 hover:text-gray-800"
                      >
                        {showConfirmPassword ? (
                          <EyeOff size={14} />
                        ) : (
                          <Eye size={14} />
                        )}
                      </button>
                    </div>
                  </div>
                </div>
                {confirmPassword && password !== confirmPassword && (
                  <p className="text-[10px] text-red-500 -mt-2 mb-2">
                    Passwords do not match
                  </p>
                )}

                {/* Continue Button */}
                <button
                  onClick={handleContinue}
                  disabled={
                    !name ||
                    !email ||
                    !phone ||
                    !country ||
                    !password ||
                    !confirmPassword ||
                    loading
                  }
                  className="w-full bg-[#0b154f] text-white text-xs font-medium rounded-lg py-2.5 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed mt-2"
                >
                  {loading ? "Please wait..." : "Continue"}
                </button>
              </div>
            </div>
          </>
        ) : (
          <>
            {/* OTP Screen - Left Side */}
            <div className="md:border-1 border-[#0b154f] rounded-3xl relative w-[330px] overflow-hidden">
              <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

              <div className="relative z-10 px-8 py-10">
                <h1 className="text-2xl font-bold text-[#0b154f] mb-2">
                  Verify OTP
                </h1>
                <p className="text-sm text-gray-600 mb-6">
                  We've sent a code to {email}
                </p>

                <div className="mb-6">
                  <label className="text-sm mb-3 block">Enter OTP:</label>
                  <div className="flex gap-2">
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        ref={(el) => (otpInputs.current[index] = el)}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(index, e)}
                        className="w-10 h-12 text-center text-xl font-semibold rounded-lg bg-pink-100/60 border border-gray-700 text-gray-800 focus:outline-none focus:ring-1 focus:ring-pink-300"
                      />
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleVerifyOtp}
                  disabled={otp.join("").length !== 6 || loading}
                  className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {loading ? "Verifying..." : "Verify OTP"}
                </button>

                {/* <div className="text-center mb-4">
                  <button
                    onClick={handleResendOtp}
                    className="text-sm text-[#0b154f] hover:underline"
                  >
                    Resend OTP
                  </button>
                </div> */}

                <button
                  onClick={() => setStep("form")}
                  className="w-full text-sm text-gray-600 hover:text-gray-800"
                >
                  ← Back
                </button>
              </div>
            </div>

            {/* Right Side - Keep same as original */}
            <div className="hidden lg:flex flex-col gap-28">
              <div className="">
                <h1 className="text-[#0b154f] font-semibold text-3xl">
                  Post your Property
                </h1>
                <p className="text-sm">Rent, Sale, Buy Property</p>
              </div>
              <img src={img2} alt="" />
            </div>
          </>
        )}

        <style jsx>{`
          .phone-input-custom,
          .phone-input-custom-compact {
            width: 100%;
          }
          .phone-input-custom input,
          .phone-input-custom-compact input {
            width: 100%;
            border-radius: 0.75rem;
            background-color: rgba(252, 231, 243, 0.6);
            border: 1px solid #374151;
            color: #1f2937;
          }
          .phone-input-custom input {
            padding: 0.875rem 1rem;
            padding-left: 3rem;
            font-size: 0.875rem;
          }
          .phone-input-custom-compact input {
            padding: 0.5rem 0.75rem;
            padding-left: 2.8rem;
            font-size: 0.75rem;
          }
          .phone-input-custom input:focus,
          .phone-input-custom-compact input:focus {
            outline: none;
            box-shadow: 0 0 0 1px rgba(249, 168, 212, 1);
          }
          .phone-input-custom input::placeholder,
          .phone-input-custom-compact input::placeholder {
            color: #4b5563;
          }
          .phone-input-custom .PhoneInputCountry,
          .phone-input-custom-compact .PhoneInputCountry {
            position: absolute;
            top: 55%;
            // transform: translateY(55%);
            z-index: 1;
          }
          .phone-input-custom .PhoneInputCountry {
            left: 1rem;
          }
          .phone-input-custom-compact .PhoneInputCountry {
            left: 0.6rem;
          }
        `}</style>
      </div>
    </div>
  );
};

export default SignModal;

// import React, { useState, useRef } from "react";
// import { X, Phone } from "lucide-react";
// import login from "../assets/login.png";
// import img2 from "../assets/loginbg.png";

// import PhoneInput from "react-phone-number-input";
// import "react-phone-number-input/style.css";

// const SignModal = ({ onClose }) => {
//   const [step, setStep] = useState("form");
//   const [user_type, setuser_type] = useState("individual");
//   const [phone, setphone] = useState("");
//   const [country, setCountry] = useState("");
//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState("");
//   const [success, setSuccess] = useState("");
//   const otpInputs = useRef([]);

//   const handleContinue = async () => {
//     if (phone && country) {
//       setError("");
//       setSuccess("");
//       setLoading(true);

//       const payload = {
//         phone: phone,
//         country: country,
//         user_type: user_type === "individual" ? 0 : 1,
//         action: "send_otp",
//       };

//       console.log("Sending payload:", payload);

//       try {
//         const response = await fetch("https://propmatez.shop/api/register/", {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify(payload),
//         });

//         const data = await response.json();
//         console.log("Response status:", response.status);
//         console.log("Response data:", data);

//         if (response.ok) {
//           setStep("otp");
//         } else {
//           setError(data.message || "Failed to send OTP. Please try again.");
//         }
//       } catch (err) {
//         setError("Network error. Please check your connection.");
//         console.error("Error sending OTP:", err);
//       } finally {
//         setLoading(false);
//       }
//     }
//   };

//   const handleOtpChange = (index, value) => {
//     if (value.length > 1) {
//       value = value.slice(-1);
//     }

//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);

//     if (value && index < 5) {
//       otpInputs.current[index + 1]?.focus();
//     }
//   };

//   const handleOtpKeyDown = (index, e) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       otpInputs.current[index - 1]?.focus();
//     }
//   };

//   const handleVerifyOtp = async () => {
//     const otpValue = otp.join("");
//     if (otpValue.length === 6) {
//       setError("");
//       setSuccess("");
//       setLoading(true);

//       try {
//         const response = await fetch("https://propmatez.shop/api/verify-otp/", {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({
//             phone: phone,
//             country: country,
//             user_type: user_type === "individual" ? 0 : 1,
//             otp: otpValue,
//             action: "verify_otp",
//           }),
//         });

//         const data = await response.json();

//         if (response.ok) {
//           setSuccess("Registration successful! You can now close this modal.");
//           console.log("User registered successfully:", otpValue);

//           // Close modal after 2 seconds
//           setTimeout(() => {
//             onClose();
//           }, 2000);
//         } else {
//           setError(data.message || "Invalid OTP. Please try again.");
//         }
//       } catch (err) {
//         setError("Network error. Please check your connection.");
//         console.error("Error verifying OTP:", err);
//       } finally {
//         setLoading(false);
//       }
//     }
//   };

//   const handleResendOtp = async () => {
//     setError("");
//     setSuccess("");
//     setLoading(true);

//     try {
//       const response = await fetch("https://propmatez.shop/api/register/", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({
//           phone: phone,
//           country: country,
//           user_type: user_type === "individual" ? 0 : 1,
//           action: "resend_otp",
//         }),
//       });

//       const data = await response.json();

//       if (response.ok) {
//         setOtp(["", "", "", "", "", ""]);
//         setSuccess("OTP resent successfully!");
//       } else {
//         setError(data.message || "Failed to resend OTP");
//       }
//     } catch (err) {
//       setError("Network error. Please check your connection.");
//       console.error("Error resending OTP:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-[#00000067] bg-opacity-50 z-50">
//       <div
//         style={{
//           backgroundImage: `url(${login})`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//         }}
//         className="relative flex flex-col md:flex-row items-center justify-evenly bg-white max-w-4xl w-full mx-4 md:mx-0 rounded-xl shadow-lg p-6 md:p-10 overflow-hidden"
//       >
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
//         >
//           <X className="w-5 h-5" />
//         </button>

//         {step === "form" ? (
//           <>
//             <div className="flex flex-col gap-28">
//               <div className="">
//                 <h1 className="text-[#0b154f] font-semibold text-3xl">
//                   Post your Property
//                 </h1>
//                 <p className="text-sm mb-4">Rent, Sale, Buy Property</p>
//               </div>
//               <img className="hidden lg:block" src={img2} alt="" />
//             </div>

//             {/* Card */}
//             <div className="border-1 border-[#0b154f] rounded-3xl relative w-[330px] overflow-hidden">
//               {/* Large Blue Blur Circle - Top Left */}
//               <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

//               <div className="relative z-10 px-8 py-10">
//                 <h1 className="text-2xl font-bold text-[#0b154f] mb-6">
//                   Let's get you started
//                 </h1>

//                 <div className="relative mb-4">
//                   <label className="">You are :</label>
//                   <div className="relative mt-2 flex gap-4">
//                     <button
//                       onClick={() => setuser_type("individual")}
//                       className={`w-fit text-sm font-medium rounded-lg px-4 py-2 transition-colors shadow-sm ${
//                         user_type === "individual"
//                           ? "bg-[#0b154f] text-white"
//                           : "border border-[#0b154f] text-[#0b154f]"
//                       }`}
//                     >
//                       Individual
//                     </button>
//                     <button
//                       onClick={() => setuser_type("company")}
//                       className={`w-fit text-sm font-medium rounded-lg px-4 py-2 transition-colors shadow-sm ${
//                         user_type === "company"
//                           ? "bg-[#0b154f] text-white"
//                           : "border border-[#0b154f] text-[#0b154f]"
//                       }`}
//                     >
//                       Company
//                     </button>
//                   </div>
//                 </div>

//                 {/* Phone Number Input with Country Code */}
//                 <div className="relative mb-4">
//                   <label className="">Your Contact No. :</label>
//                   <div className="relative mt-2 border border-gray-700 rounded-xl">
//                     <PhoneInput
//                       international
//                       defaultCountry="IN"
//                       value={phone}
//                       onChange={setphone}
//                       className="phone-input-custom"
//                       placeholder="Enter phone number"
//                     />
//                   </div>
//                 </div>

//                 {/* Country Input */}
//                 <div className="relative mb-4">
//                   <label className="">Property Country:</label>
//                   <div className="relative mt-2">
//                     <input
//                       type="text"
//                       placeholder="Please Enter Country Name"
//                       value={country}
//                       onChange={(e) => setCountry(e.target.value)}
//                       className="w-full rounded-xl bg-pink-100/60 border border-gray-700 px-4 py-3.5 text-gray-800 placeholder:text-gray-600 focus:outline-none focus:ring-1 focus:ring-pink-300 text-sm"
//                     />
//                   </div>
//                 </div>

//                 {error && (
//                   <div className="mb-4 p-2 bg-red-100 border border-red-400 text-red-700 text-xs rounded">
//                     {error}
//                   </div>
//                 )}

//                 {/* Continue Button */}
//                 <button
//                   onClick={handleContinue}
//                   disabled={!phone || !country || loading}
//                   className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   {loading ? "Sending OTP..." : "Continue"}
//                 </button>
//               </div>
//             </div>
//           </>
//         ) : (
//           <>
//             {/* OTP Screen - Left Side */}
//             <div className="border-1 border-[#0b154f] rounded-3xl relative w-[330px] overflow-hidden">
//               <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

//               <div className="relative z-10 px-8 py-10">
//                 <h1 className="text-2xl font-bold text-[#0b154f] mb-2">
//                   Verify OTP
//                 </h1>
//                 <p className="text-sm text-gray-600 mb-6">
//                   We've sent a code to {phone}
//                 </p>

//                 <div className="mb-6">
//                   <label className="text-sm mb-3 block">Enter OTP:</label>
//                   <div className="flex gap-2">
//                     {otp.map((digit, index) => (
//                       <input
//                         key={index}
//                         ref={(el) => (otpInputs.current[index] = el)}
//                         type="text"
//                         maxLength="1"
//                         value={digit}
//                         onChange={(e) => handleOtpChange(index, e.target.value)}
//                         onKeyDown={(e) => handleOtpKeyDown(index, e)}
//                         className="w-10 h-12 text-center text-xl font-semibold rounded-lg bg-pink-100/60 border border-gray-700 text-gray-800 focus:outline-none focus:ring-1 focus:ring-pink-300"
//                       />
//                     ))}
//                   </div>
//                 </div>

//                 {error && (
//                   <div className="mb-4 p-2 bg-red-100 border border-red-400 text-red-700 text-xs rounded">
//                     {error}
//                   </div>
//                 )}

//                 {success && (
//                   <div className="mb-4 p-2 bg-green-100 border border-green-400 text-green-700 text-xs rounded">
//                     {success}
//                   </div>
//                 )}

//                 <button
//                   onClick={handleVerifyOtp}
//                   disabled={otp.join("").length !== 6 || loading}
//                   className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   {loading ? "Verifying..." : "Verify OTP"}
//                 </button>

//                 <div className="text-center mb-4">
//                   <button
//                     onClick={handleResendOtp}
//                     disabled={loading}
//                     className="text-sm text-[#0b154f] hover:underline disabled:opacity-50"
//                   >
//                     Resend OTP
//                   </button>
//                 </div>

//                 <button
//                   onClick={() => {
//                     setStep("form");
//                     setError("");
//                     setSuccess("");
//                   }}
//                   className="w-full text-sm text-gray-600 hover:text-gray-800"
//                 >
//                   ← Back
//                 </button>
//               </div>
//             </div>

//             {/* Right Side - Keep same as original */}
//             <div className="hidden lg:flex flex-col gap-28">
//               <div className="">
//                 <h1 className="text-[#0b154f] font-semibold text-3xl">
//                   Post your Property
//                 </h1>
//                 <p className="text-sm">Rent, Sale, Buy Property</p>
//               </div>
//               <img src={img2} alt="" />
//             </div>
//           </>
//         )}

//         <style jsx>{`
//           .phone-input-custom {
//             width: 100%;
//           }
//           .phone-input-custom input {
//             width: 100%;
//             border-radius: 0.75rem;
//             background-color: rgba(252, 231, 243, 0.6);
//             border: 1px solid #374151;
//             padding: 0.875rem 1rem;
//             padding-left: 3rem;
//             color: #1f2937;
//             font-size: 0.875rem;
//           }
//           .phone-input-custom input:focus {
//             outline: none;
//             box-shadow: 0 0 0 1px rgba(249, 168, 212, 1);
//           }
//           .phone-input-custom input::placeholder {
//             color: #4b5563;
//           }
//           .phone-input-custom .PhoneInputCountry {
//             position: absolute;
//             left: 1rem;
//             top: 50%;
//             transform: translateY(-50%);
//             z-index: 1;
//           }
//         `}</style>
//       </div>
//     </div>
//   );
// };

// export default SignModal;
