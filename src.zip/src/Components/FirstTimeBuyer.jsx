// import React, { useState, useRef, useEffect } from "react";
// import { ArrowRight, ChevronDown, X } from "lucide-react";
// import first from "../assets/first.png";

// const FirstTimeBuyerSection = () => {
//   const [isModalOpen, setIsModalOpen] = useState(false);

//   return (
//     <div className="w-full max-w-8xl mx-auto py-12 px-10">
//       <div className="bg-[#606d76] rounded-2xl px-36 py-14">
//         <div className="flex flex-row items-center justify-between">
//           {/* Left Content */}
//           <div className="flex-1 text-white mb-0 pr-8">
//             <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold mb-4 leading-tight">
//               First time Buyer
//               <br />
//               in UAE?
//             </h2>

//             <p className="text-white text-lg md:text-xl mb-20 max-w-md leading-relaxed">
//               Register your interest and connect to approved developers in Dubai
//             </p>

//             <button
//               onClick={() => setIsModalOpen(true)}
//               className="bg-[#0b154f] text-white px-8 py-4 rounded-lg font-medium text-xl transition-all duration-300 hover:shadow-lg hover:scale-105 flex items-center gap-3 group"
//             >
//               Get in touch
//               <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
//             </button>
//           </div>

//           {/* Right Image */}
//           <div>
//             <img src={first} alt="First Time Buyer" />
//           </div>
//         </div>
//       </div>

//       {/* Modal for Contact Form */}
//       {isModalOpen && (
//         <ContactFormModal onClose={() => setIsModalOpen(false)} />
//       )}
//     </div>
//   );
// };

// const ContactFormModal = ({ onClose }) => {
//   const [formData, setFormData] = useState({
//     firstName: "",
//     lastName: "",
//     email: "",
//     propertyType: "",
//     jobTitle: "",
//     phone: "",
//     bedRooms: [],
//     bathRooms: [],
//     city: "",
//     terms: false,
//   });

//   const [isOpen, setIsOpen] = useState(false);
//   const dropdownRef = useRef(null);
//   const modalRef = useRef(null);

//   const handleChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData({
//       ...formData,
//       [name]: type === "checkbox" ? checked : value,
//     });
//   };

//   const toggleSelection = (type, value) => {
//     setFormData((prev) => {
//       const current = [...prev[type]];
//       if (current.includes(value)) {
//         return { ...prev, [type]: current.filter((item) => item !== value) };
//       } else {
//         return { ...prev, [type]: [...current, value] };
//       }
//     });
//   };

//   const handleSubmit = (e) => {
//     e.preventDefault();
//     console.log("Form Data:", formData);
//     alert("Form Submitted!");
//     onClose();
//   };

//   const bedroomOptions = ["Studio", "1", "2", "3", "4", "5", "6", "7", "8+"];
//   const bathroomOptions = ["1", "2", "3", "4", "5", "6", "7", "8+"];

//   const displayValue =
//     formData.bedRooms.length || formData.bathRooms.length
//       ? `Bedrooms: ${formData.bedRooms.join(
//           ", "
//         )} | Bathrooms: ${formData.bathRooms.join(", ")}`
//       : "Select Bed & Bath";

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setIsOpen(false);
//       }
//       if (modalRef.current && !modalRef.current.contains(event.target)) {
//         onClose();
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, [onClose]);

//   return (
//     <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
//       <div
//         ref={modalRef}
//         className="bg-white shadow-lg rounded-xl p-6 md:p-8 w-full max-w-4xl relative"
//       >
//         {/* Close Button */}
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-gray-600 hover:text-gray-800"
//         >
//           <X size={24} />
//         </button>

//         <h2 className="text-center text-2xl font-semibold text-[#0b154f] mb-10">
//           Submit your details and <br /> we will get in touch
//         </h2>

//         <form
//           onSubmit={handleSubmit}
//           className="grid grid-cols-1 md:grid-cols-2 gap-4"
//         >
//           {/* First Name */}
//           <Field
//             label="First Name*"
//             name="firstName"
//             value={formData.firstName}
//             onChange={handleChange}
//             required
//           />
//           {/* Last Name */}
//           <Field
//             label="Last Name*"
//             name="lastName"
//             value={formData.lastName}
//             onChange={handleChange}
//             required
//           />
//           {/* Email */}
//           <Field
//             label="Email*"
//             name="email"
//             type="email"
//             value={formData.email}
//             onChange={handleChange}
//             required
//           />
//           {/* Property Type */}
//           <Field
//             label="Property Type"
//             name="propertyType"
//             value={formData.propertyType}
//             onChange={handleChange}
//           />
//           {/* Job Title */}
//           <Field
//             label="Job Title"
//             name="jobTitle"
//             value={formData.jobTitle}
//             onChange={handleChange}
//           />
//           {/* Phone */}
//           <Field
//             label="Phone"
//             name="phone"
//             value={formData.phone}
//             onChange={handleChange}
//           />
//           {/* Bed & Bath and City in one row */}
//           <div className="flex flex-col md:flex-row gap-4 col-span-1 md:col-span-2">
//             {/* Custom Bed & Bath Dropdown */}
//             <div className="relative flex-1" ref={dropdownRef}>
//               <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
//                 Bed And Baths
//               </label>
//               <div
//                 className="border border-gray-300 rounded-lg p-3 w-full flex justify-between items-center cursor-pointer bg-white"
//                 onClick={() => setIsOpen(!isOpen)}
//               >
//                 <span>{displayValue}</span>
//                 <ChevronDown size={20} className="text-gray-500" />
//               </div>

//               {isOpen && (
//                 <div className="absolute top-full w-[550px] left-0  bg-white border border-gray-300 rounded-lg shadow-md mt-2 z-10 p-4">
//                   {/* Bedrooms */}
//                   <div className="mb-4">
//                     <div className="flex gap-3 mb-3">
//                       <div className="bg-[#0b154f] text-white font-semibold px-4 py-2 rounded-md w-28">
//                         Studio
//                       </div>
//                       <div className="flex flex-wrap gap-2">
//                         {bedroomOptions.slice(1).map((item) => (
//                           <button
//                             key={item}
//                             type="button"
//                             onClick={() => toggleSelection("bedRooms", item)}
//                             className={`w-10 h-10 flex items-center justify-center rounded-md ${
//                               formData.bedRooms.includes(item)
//                                 ? "bg-[#0b154f] text-white"
//                                 : "bg-[#0b154f] text-white hover:bg-[#0b154f]"
//                             }`}
//                           >
//                             {item}
//                           </button>
//                         ))}
//                       </div>
//                     </div>

//                     {/* Bathrooms */}
//                     <div className="flex gap-3">
//                       <div className="bg-[#0b154f] text-white font-semibold px-4 py-2 rounded-md w-28">
//                         Bathrooms
//                       </div>
//                       <div className="flex flex-wrap gap-2">
//                         {bathroomOptions.map((item) => (
//                           <button
//                             key={item}
//                             type="button"
//                             onClick={() => toggleSelection("bathRooms", item)}
//                             className={`w-10 h-10 flex items-center justify-center rounded-md ${
//                               formData.bathRooms.includes(item)
//                                 ? "bg-[#0b154f] text-white"
//                                 : "bg-[#0b154f] text-white hover:bg-[#0b154f]"
//                             }`}
//                           >
//                             {item}
//                           </button>
//                         ))}
//                       </div>
//                     </div>
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* City */}
//             <div className="relative flex-1">
//               <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
//                 City
//               </label>
//               <select
//                 name="city"
//                 value={formData.city}
//                 onChange={handleChange}
//                 className="border border-gray-300 rounded-lg p-3 w-full focus:ring-2 focus:ring-[#0b154f] outline-none bg-white"
//               >
//                 <option value="">Select</option>
//                 <option value="Ras Al Khaimah">Ras Al Khaimah</option>
//                 <option value="Dubai">Dubai</option>
//                 <option value="Abu Dhabi">Abu Dhabi</option>
//                 <option value="Sharjah">Sharjah</option>
//               </select>
//             </div>
//           </div>

//           <div className="flex items-center col-span-1 md:col-span-2 mt-4">
//             <input
//               type="checkbox"
//               name="terms"
//               checked={formData.terms}
//               onChange={handleChange}
//               className="w-4 h-4 text-[#0b154f] border-gray-300 rounded focus:ring-[#0b154f]"
//             />
//             <label className="ml-2 text-gray-600 text-sm">
//               I accept the terms and conditions in the creation of my Property
//               Finder account. View our Terms of Use.
//             </label>
//           </div>
//           {/* Submit */}
//           <div className="col-span-1 md:col-span-2 flex justify-center">
//             <button
//               type="submit"
//               className="w-[50%] bg-[#0b154f] text-white py-3 rounded-lg shadow-xl mt-6 transition font-semibold"
//             >
//               Submit
//             </button>
//           </div>
//         </form>
//       </div>
//     </div>
//   );
// };

// // Reusable Input Field Component
// const Field = ({
//   label,
//   name,
//   value,
//   onChange,
//   type = "text",
//   required = false,
// }) => (
//   <div className="relative">
//     <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
//       {label}
//     </label>
//     <input
//       type={type}
//       name={name}
//       value={value}
//       onChange={onChange}
//       required={required}
//       className="border border-gray-300 rounded-lg p-2 w-full focus:ring-2 focus:ring-[#0b154f] outline-none"
//     />
//   </div>
// );

// export default FirstTimeBuyerSection;

import React, { useState, useRef, useEffect } from "react";
import { ArrowRight, ChevronDown, X } from "lucide-react";
import first from "../assets/first.png";

const FirstTimeBuyerSection = () => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <div className="w-full max-w-8xl mx-auto py-6 md:py-8 lg:py-12 px-4 md:px-6 lg:px-10">
      <div className="bg-[#606d76] rounded-xl md:rounded-2xl px-4 md:px-8 lg:px-36 py-8 md:py-10 lg:py-14">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-0">
          {/* Left Content */}
          <div className="flex-1 text-white mb-0 text-center lg:text-left lg:pr-8">
            <h2 className="text-2xl md:text-3xl lg:text-5xl font-bold mb-4 leading-tight">
              First time Buyer
              <br />    
            </h2>

            <p className="text-white text-base md:text-lg lg:text-xl mb-8 md:mb-12 lg:mb-20 max-w-md mx-auto lg:mx-0 leading-relaxed">
              Register your interest and connect to approved developers in Dubai
            </p>

            <button
              onClick={() => setIsModalOpen(true)}
              className="bg-[#0b154f] text-white px-6 md:px-8 py-3 md:py-4 rounded-lg font-medium text-lg md:text-xl transition-all duration-300 hover:shadow-lg hover:scale-105 flex items-center gap-3 group mx-auto lg:mx-0"
            >
              Get in touch
              <ArrowRight className="w-4 h-4 md:w-5 md:h-5 group-hover:translate-x-1 transition-transform duration-300" />
            </button>
          </div>

          {/* Right Image */}
          <div className="flex-shrink-0">
            <div className="w-48 h-48 md:w-64 md:h-64 lg:w-auto lg:h-auto flex items-center justify-center">
              <img src={first} alt="First Time Buyer" />
            </div>
          </div>
        </div>
      </div>

      {/* Modal for Contact Form */}
      {isModalOpen && (
        <ContactFormModal onClose={() => setIsModalOpen(false)} />
      )}
    </div>
  );
};

const ContactFormModal = ({ onClose }) => {
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    propertyType: "",
    jobTitle: "",
    phone: "",
    bedRooms: [],
    bathRooms: [],
    city: "",
    terms: false,
  });

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef(null);
  const modalRef = useRef(null);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData({
      ...formData,
      [name]: type === "checkbox" ? checked : value,
    });
  };

  const toggleSelection = (type, value) => {
    setFormData((prev) => {
      const current = [...prev[type]];
      if (current.includes(value)) {
        return { ...prev, [type]: current.filter((item) => item !== value) };
      } else {
        return { ...prev, [type]: [...current, value] };
      }
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log("Form Data:", formData);
    alert("Form Submitted!");
    onClose();
  };

  const bedroomOptions = ["Studio", "1", "2", "3", "4", "5", "6", "7", "8+"];
  const bathroomOptions = ["1", "2", "3", "4", "5", "6", "7", "8+"];

  const displayValue =
    formData.bedRooms.length || formData.bathRooms.length
      ? `Bedrooms: ${formData.bedRooms.join(
          ", "
        )} | Bathrooms: ${formData.bathRooms.join(", ")}`
      : "Select Bed & Bath";

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        onClose();
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [onClose]);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div
        ref={modalRef}
        className="bg-white shadow-lg rounded-xl p-4 md:p-6 lg:p-8 w-full max-w-sm md:max-w-2xl lg:max-w-4xl relative max-h-[90vh] overflow-y-auto"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-600 hover:text-gray-800 z-10"
        >
          <X size={20} className="md:w-6 md:h-6" />
        </button>

        <h2 className="text-center text-lg md:text-xl lg:text-2xl font-semibold text-[#0b154f] mb-6 md:mb-8 lg:mb-10 pr-8">
          Submit your details and <br /> we will get in touch
        </h2>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
          {/* First Name */}
          <Field
            label="First Name*"
            name="firstName"
            value={formData.firstName}
            onChange={handleChange}
            required
          />
          {/* Last Name */}
          <Field
            label="Last Name*"
            name="lastName"
            value={formData.lastName}
            onChange={handleChange}
            required
          />
          {/* Email */}
          <Field
            label="Email*"
            name="email"
            type="email"
            value={formData.email}
            onChange={handleChange}
            required
          />
          {/* Property Type */}
          <Field
            label="Property Type"
            name="propertyType"
            value={formData.propertyType}
            onChange={handleChange}
          />
          {/* Job Title */}
          <Field
            label="Job Title"
            name="jobTitle"
            value={formData.jobTitle}
            onChange={handleChange}
          />
          {/* Phone */}
          <Field
            label="Phone"
            name="phone"
            value={formData.phone}
            onChange={handleChange}
          />
          {/* Bed & Bath and City in one row */}
          <div className="flex flex-col lg:flex-row gap-4 col-span-1 lg:col-span-2">
            {/* Custom Bed & Bath Dropdown */}
            <div className="relative flex-1" ref={dropdownRef}>
              <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
                Bed And Baths
              </label>
              <div
                className="border border-gray-300 rounded-lg p-3 w-full flex justify-between items-center cursor-pointer bg-white"
                onClick={() => setIsOpen(!isOpen)}
              >
                <span className="text-sm md:text-base truncate pr-2">
                  {displayValue}
                </span>
                <ChevronDown
                  size={20}
                  className="text-gray-500 flex-shrink-0"
                />
              </div>

              {isOpen && (
                <div className="absolute top-full w-full md:w-[500px] lg:w-[550px] left-0 bg-white border border-gray-300 rounded-lg shadow-md mt-2 z-10 p-3 md:p-4 max-h-64 overflow-y-auto">
                  {/* Bedrooms */}
                  <div className="mb-4">
                    <div className="flex flex-col md:flex-row gap-3 mb-3">
                      <div className="bg-[#0b154f] text-white font-semibold px-3 md:px-4 py-2 rounded-md w-full md:w-28 text-center text-sm md:text-base">
                        Studio
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {bedroomOptions.slice(1).map((item) => (
                          <button
                            key={item}
                            type="button"
                            onClick={() => toggleSelection("bedRooms", item)}
                            className={`w-8 h-8 md:w-10 md:h-10 flex items-center justify-center rounded-md text-sm md:text-base ${
                              formData.bedRooms.includes(item)
                                ? "bg-[#0b154f] text-white"
                                : "bg-[#0b154f] text-white hover:bg-[#0b154f]"
                            }`}
                          >
                            {item}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Bathrooms */}
                    <div className="flex flex-col md:flex-row gap-3">
                      <div className="bg-[#0b154f] text-white font-semibold px-3 md:px-4 py-2 rounded-md w-full md:w-28 text-center text-sm md:text-base">
                        Bathrooms
                      </div>
                      <div className="flex flex-wrap gap-2">
                        {bathroomOptions.map((item) => (
                          <button
                            key={item}
                            type="button"
                            onClick={() => toggleSelection("bathRooms", item)}
                            className={`w-8 h-8 md:w-10 md:h-10 flex items-center justify-center rounded-md text-sm md:text-base ${
                              formData.bathRooms.includes(item)
                                ? "bg-[#0b154f] text-white"
                                : "bg-[#0b154f] text-white hover:bg-[#0b154f]"
                            }`}
                          >
                            {item}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* City */}
            <div className="relative flex-1">
              <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
                City
              </label>
              <select
                name="city"
                value={formData.city}
                onChange={handleChange}
                className="border border-gray-300 rounded-lg p-3 w-full focus:ring-2 focus:ring-[#0b154f] outline-none bg-white text-sm md:text-base"
              >
                <option value="">Select</option>
                <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                <option value="Dubai">Dubai</option>
                <option value="Abu Dhabi">Abu Dhabi</option>
                <option value="Sharjah">Sharjah</option>
              </select>
            </div>
          </div>

          <div className="flex items-start col-span-1 lg:col-span-2 mt-4">
            <input
              type="checkbox"
              name="terms"
              checked={formData.terms}
              onChange={handleChange}
              className="w-4 h-4 text-[#0b154f] border-gray-300 rounded focus:ring-[#0b154f] mt-0.5 flex-shrink-0"
            />
            <label className="ml-2 text-gray-600 text-xs md:text-sm">
              I accept the terms and conditions in the creation of my Property
              Finder account. View our Terms of Use.
            </label>
          </div>
          {/* Submit */}
          <div className="col-span-1 lg:col-span-2 flex justify-center">
            <button
              type="submit"
              onClick={handleSubmit}
              className="w-full md:w-[70%] lg:w-[50%] bg-[#0b154f] text-white py-3 rounded-lg shadow-xl mt-6 transition font-semibold text-sm md:text-base"
            >
              Submit
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

// Reusable Input Field Component
const Field = ({
  label,
  name,
  value,
  onChange,
  type = "text",
  required = false,
}) => (
  <div className="relative">
    <label className="absolute -top-3 left-4 bg-white px-1 text-gray-600 text-sm">
      {label}
    </label>
    <input
      type={type}
      name={name}
      value={value}
      onChange={onChange}
      required={required}
      className="border border-gray-300 rounded-lg p-2 md:p-3 w-full focus:ring-2 focus:ring-[#0b154f] outline-none text-sm md:text-base"
    />
  </div>
);

export default FirstTimeBuyerSection;
