// import React, { useState, useRef, useEffect } from "react";
// import { Star, ChevronLeft, ChevronRight } from "lucide-react";

// const TestimonialsSection = () => {
//   const [currentIndex, setCurrentIndex] = useState(0);
//   const [showScrolling, setShowScrolling] = useState(false);
//   const scrollContainerRef = useRef(null);

//   const testimonials = [
//     {
//       id: 1,
//       name: "Pushpa Kumar Arora",
//       role: "CEO, Let's Connect",
//       image:
//         "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150&h=150&fit=crop&crop=face",
//       rating: 4,
//       text: "Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint. Velit officia consequat duis enim velit mollit. ",
//     },
//     {
//       id: 2,
//       name: "Sarah Johnson",
//       role: "CTO, TechFlow",
//       image:
//         "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
//       rating: 5,
//       text: "Exceptional service and outstanding results. The team exceeded our expectations in every way possible. Highly recommended! ",
//     },
//     {
//       id: 3,
//       name: "Michael Chen",
//       role: "Founder, InnovateLab",
//       image:
//         "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&h=150&fit=crop&crop=face",
//       rating: 4,
//       text: "Professional, reliable, and innovative. They delivered exactly what we needed on time and within budget. Great experience! ",
//     },
//     {
//       id: 4,
//       name: "Emily Rodriguez",
//       role: "Director, GrowthCo",
//       image:
//         "https://images.unsplash.com/photo-1519244703995-f4e0f30006d5?w=150&h=150&fit=crop&crop=face",
//       rating: 5,
//       text: "Outstanding quality and attention to detail. The collaboration was smooth and the final results were beyond our expectations. ",
//     },
//     {
//       id: 5,
//       name: "David Thompson",
//       role: "VP Marketing, Brand Plus",
//       image:
//         "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
//       rating: 4,
//       text: "Incredible team with amazing expertise. They transformed our vision into reality with precision and creativity. Absolutely fantastic! ",
//     },
//   ];

//   // Check if scrolling is needed based on screen size
//   useEffect(() => {
//     const checkScrollNeed = () => {
//       const isDesktop = window.innerWidth >= 1024; // lg breakpoint
//       const needsScrolling = !isDesktop;
//       setShowScrolling(needsScrolling);
//     };

//     checkScrollNeed();
//     window.addEventListener("resize", checkScrollNeed);

//     return () => {
//       window.removeEventListener("resize", checkScrollNeed);
//     };
//   }, []);

//   const StarRating = ({ rating }) => {
//     return (
//       <div className="flex gap-1">
//         {[1, 2, 3, 4, 5].map((star) => (
//           <Star
//             key={star}
//             className={`w-4 h-4 ${
//               star <= rating
//                 ? "fill-yellow-400 text-yellow-400"
//                 : "fill-gray-200 text-gray-200"
//             }`}
//           />
//         ))}
//       </div>
//     );
//   };

//   const scrollToIndex = (index) => {
//     if (scrollContainerRef.current) {
//       const container = scrollContainerRef.current;

//       if (showScrolling) {
//         // Mobile: scroll by container width
//         const containerWidth = container.offsetWidth;
//         const scrollPosition = index * containerWidth;

//         container.scrollTo({
//           left: scrollPosition,
//           behavior: "smooth",
//         });
//       } else {
//         // Desktop: scroll by card width + gap
//         const cardWidth = container.children[0]?.offsetWidth || 0;
//         const gap = 24;
//         const scrollAmount = (cardWidth + gap) * index;

//         container.scrollTo({
//           left: scrollAmount,
//           behavior: "smooth",
//         });
//       }

//       setCurrentIndex(index);
//     }
//   };

//   const handlePrevious = () => {
//     const newIndex =
//       currentIndex > 0 ? currentIndex - 1 : testimonials.length - 1;
//     scrollToIndex(newIndex);
//   };

//   const handleNext = () => {
//     const newIndex =
//       currentIndex < testimonials.length - 1 ? currentIndex + 1 : 0;
//     scrollToIndex(newIndex);
//   };

//   const handleCardClick = (clickedIndex) => {
//     if (!showScrolling) {
//       // Desktop behavior: if clicked card is the current one, go to next
//       if (clickedIndex === currentIndex) {
//         handleNext();
//       } else {
//         scrollToIndex(clickedIndex);
//       }
//     } else {
//       // Mobile behavior: always go to next card
//       handleNext();
//     }
//   };

//   return (
//     <div className="px-4 sm:px-6 md:px-8 lg:px-12 py-6 sm:py-8 lg:py-10">
//       <div className="max-w-8xl mx-auto bg-[#e8eaff] px-4 sm:px-6 md:px-8 lg:px-10 pt-6 sm:pt-8 lg:pt-10 pb-8 sm:pb-12 lg:pb-16 rounded-2xl">
//         {/* Header */}
//         <div className="text-center mb-8 sm:mb-12 md:mb-16 lg:mb-20">
//           <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-4">
//             Testimonials
//           </h2>
//         </div>

//         {/* Navigation and Testimonials Container */}
//         <div className="relative">
//           {/* Left Arrow */}
//           <button
//             onClick={handlePrevious}
//             className={`absolute top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 ${
//               showScrolling ? "left-2" : "left-0 -ml-4 sm:-ml-6"
//             }`}
//             aria-label="Previous testimonial"
//           >
//             <ChevronLeft className="w-6 h-6 text-gray-600" />
//           </button>

//           {/* Right Arrow */}
//           <button
//             onClick={handleNext}
//             className={`absolute top-1/2 -translate-y-1/2 z-10 bg-white shadow-lg rounded-full p-2 hover:bg-gray-50 transition-colors duration-200 ${
//               showScrolling ? "right-2" : "right-0 -mr-4 sm:-mr-6"
//             }`}
//             aria-label="Next testimonial"
//           >
//             <ChevronRight className="w-6 h-6 text-gray-600" />
//           </button>

//           {/* Testimonials Scroll Container */}
//           <div
//             ref={scrollContainerRef}
//             className={`flex pb-4 ${
//               showScrolling
//                 ? "overflow-x-auto scrollbar-hide snap-x snap-mandatory"
//                 : "gap-6 overflow-x-auto scrollbar-hide"
//             }`}
//             style={{
//               scrollbarWidth: "none",
//               msOverflowStyle: "none",
//             }}
//           >
//             {testimonials.map((testimonial, index) => (
//               <div
//                 key={testimonial.id}
//                 className={`${
//                   showScrolling
//                     ? "snap-start flex-shrink-0 px-6"
//                     : "flex-shrink-0"
//                 }`}
//                 style={{
//                   width: showScrolling ? "100%" : "auto",
//                 }}
//               >
//                 <div
//                   className={`bg-white relative rounded-xl px-6 sm:px-8 lg:px-10 py-8 sm:py-9 lg:py-10 shadow-lg transition-all duration-300 cursor-pointer ${
//                     showScrolling ? "w-full max-w-sm mx-auto" : "w-80 sm:w-96"
//                   } ${
//                     index === currentIndex
//                       ? "shadow-xl ring-2 ring-blue-200 scale-105 hover:scale-110"
//                       : "hover:shadow-xl hover:scale-105"
//                   }`}
//                   onClick={() => handleCardClick(index)}
//                 >
//                   {/* Profile Section */}
//                   <div className="mb-4 -mt-2">
//                     <img
//                       src={testimonial.image}
//                       alt={testimonial.name}
//                       className="w-14 h-14 sm:w-16 sm:h-16 lg:w-18 lg:h-18 rounded-full object-cover mr-3"
//                     />
//                   </div>

//                   {/* Testimonial Text */}
//                   <p className="text-gray-600 text-sm leading-relaxed mb-8 sm:mb-9 lg:mb-10 mt-4 sm:mt-2 lg:mt-0">
//                     {testimonial.text}
//                   </p>

//                   <div className="flex items-center">
//                     <div className="flex-1">
//                       <h3 className="font-semibold text-gray-800 text-sm">
//                         {testimonial.name}
//                       </h3>
//                       <p className="text-gray-500 text-xs">
//                         {testimonial.role}
//                       </p>
//                     </div>
//                     {/* Rating */}
//                     <div className="flex justify-end">
//                       <StarRating rating={testimonial.rating} />
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {/* Hide scrollbar styles */}
//       <style jsx>{`
//         .scrollbar-hide {
//           -webkit-overflow-scrolling: touch;
//         }
//         .scrollbar-hide::-webkit-scrollbar {
//           display: none;
//         }
//       `}</style>
//     </div>
//   );
// };

// export default TestimonialsSection;

import React, { useState, useEffect } from "react";
import { ChevronRight, ChevronLeft } from "lucide-react";

export default function CustomerReviews() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [itemsPerSlide, setItemsPerSlide] = useState(4);

  const reviews = [
    {
      name: "Rene Aparicio Rivas",
      initial: "R",
      verified: true,
      daysAgo: 7,
      rating: 5,
      text: "Its a very good experience",
      hasMore: false,
      bgColor: "bg-blue-600",
    },
    {
      name: "robert newton",
      initial: "R",
      verified: true,
      daysAgo: 2,
      rating: 5,
      text: "Great place with great views and easy to get to with public transportation 🚍 🚇 ...",
      hasMore: true,
      bgColor: "bg-red-900",
    },
    {
      name: "Ken Fox",
      initial: "K",
      verified: true,
      daysAgo: 4,
      rating: 5,
      text: "Great place, beautiful view!",
      hasMore: false,
      bgColor: "bg-orange-600",
    },
    {
      name: "Rene Aparicio Rivas",
      initial: "R",
      verified: true,
      daysAgo: 7,
      rating: 5,
      text: "Its a very good experience",
      hasMore: false,
      bgColor: "bg-blue-600",
    },
    {
      name: "volodymyr furman",
      initial: "V",
      verified: true,
      daysAgo: 3,
      rating: 5,
      text: "amazing place",
      hasMore: false,
      bgColor: "bg-gray-300",
    },
    {
      name: "Ken Fox",
      initial: "K",
      verified: true,
      daysAgo: 4,
      rating: 5,
      text: "Great place, beautiful view!",
      hasMore: false,
      bgColor: "bg-orange-600",
    },
    {
      name: "Rene Aparicio Rivas",
      initial: "R",
      verified: true,
      daysAgo: 7,
      rating: 5,
      text: "Its a very good experience",
      hasMore: false,
      bgColor: "bg-blue-600",
    },
    {
      name: "robert newton",
      initial: "R",
      verified: true,
      daysAgo: 2,
      rating: 5,
      text: "Great place with great views and easy to get to with public transportation 🚍 🚇 ...",
      hasMore: true,
      bgColor: "bg-red-900",
    },
  ];

  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setItemsPerSlide(4);
      } else if (window.innerWidth >= 768) {
        setItemsPerSlide(2);
      } else {
        setItemsPerSlide(1);
      }
      setCurrentIndex(0);
    };

    handleResize();
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, []);

  const totalSlides = Math.ceil(reviews.length / itemsPerSlide);

  const nextSlide = () => {
    setCurrentIndex((prev) => (prev + 1) % totalSlides);
  };

  const prevSlide = () => {
    setCurrentIndex((prev) => (prev - 1 + totalSlides) % totalSlides);
  };

  const goToSlide = (index) => {
    setCurrentIndex(index);
  };

  const StarRating = ({ rating }) => (
    <div className="flex gap-0.5 mb-3">
      {[...Array(5)].map((_, i) => (
        <span key={i} className="text-yellow-400 text-lg">
          ★
        </span>
      ))}
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <h2 className="text-3xl font-bold text-center mb-8">
        What Our Customers Say
      </h2>

      {/* Google Reviews Header */}
      <div className="bg-gray-50 rounded-lg p-4 md:p-6 mb-8 flex flex-col md:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <svg
            className="w-16 md:w-20 h-6 md:h-8"
            viewBox="0 0 80 26"
            fill="none"
          >
            <text
              x="0"
              y="20"
              fontFamily="Arial"
              fontSize="20"
              fontWeight="bold"
            >
              <tspan fill="#4285F4">G</tspan>
              <tspan fill="#EA4335">o</tspan>
              <tspan fill="#FBBC05">o</tspan>
              <tspan fill="#4285F4">g</tspan>
              <tspan fill="#34A853">l</tspan>
              <tspan fill="#EA4335">e</tspan>
            </text>
          </svg>
          <span className="text-lg md:text-xl font-medium">Reviews</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-2xl md:text-3xl font-bold">4.7</span>
          <div className="flex">
            {[...Array(5)].map((_, i) => (
              <span key={i} className="text-yellow-400 text-lg md:text-xl">
                ★
              </span>
            ))}
          </div>
          <span className="text-gray-500 text-sm">(16,950)</span>
        </div>
        <button className="bg-blue-600 text-white px-4 md:px-6 py-2 rounded-md hover:bg-blue-700 transition text-sm md:text-base">
          Review us on Google
        </button>
      </div>

      {/* Reviews Carousel */}
      <div className="relative px-8 md:px-12">
        <div className="overflow-hidden">
          <div
            className="flex transition-transform duration-300 ease-in-out gap-4"
            style={{ transform: `translateX(-${currentIndex * 100}%)` }}
          >
            {Array.from({ length: totalSlides }).map((_, slideIndex) => (
              <div
                key={slideIndex}
                className="min-w-full flex flex-col md:flex-row gap-4"
              >
                {reviews
                  .slice(
                    slideIndex * itemsPerSlide,
                    (slideIndex + 1) * itemsPerSlide
                  )
                  .map((review, idx) => (
                    <div
                      key={idx}
                      className="flex-1 bg-white rounded-lg p-4 md:p-6 shadow-sm border border-gray-200 min-w-0"
                    >
                      <div className="flex items-start gap-3 mb-3">
                        <div
                          className={`${review.bgColor} w-10 h-10 rounded-full flex items-center justify-center text-white font-semibold relative flex-shrink-0`}
                        >
                          {review.initial}
                          <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-0.5">
                            <svg
                              className="w-4 h-4"
                              viewBox="0 0 16 16"
                              fill="none"
                            >
                              <text
                                x="0"
                                y="13"
                                fontFamily="Arial"
                                fontSize="12"
                                fontWeight="bold"
                                fill="#4285F4"
                              >
                                G
                              </text>
                            </svg>
                          </div>
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="font-medium text-gray-900 truncate">
                              {review.name}
                            </span>
                            {review.verified && (
                              <svg
                                className="w-4 h-4 text-blue-500 flex-shrink-0"
                                fill="currentColor"
                                viewBox="0 0 20 20"
                              >
                                <path
                                  fillRule="evenodd"
                                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                  clipRule="evenodd"
                                />
                              </svg>
                            )}
                          </div>
                          <span className="text-sm text-gray-500">
                            {review.daysAgo} days ago
                          </span>
                        </div>
                      </div>

                      <StarRating rating={review.rating} />

                      <p className="text-gray-700 text-sm md:text-base">
                        {review.text}
                      </p>
                      {review.hasMore && (
                        <button className="text-blue-600 text-sm mt-2 hover:underline">
                          Read more
                        </button>
                      )}
                    </div>
                  ))}
              </div>
            ))}
          </div>
        </div>

        {/* Navigation Arrows */}
        {totalSlides > 1 && (
          <>
            <button
              onClick={prevSlide}
              disabled={currentIndex === 0}
              className={`absolute left-0 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-lg transition z-10 ${
                currentIndex === 0
                  ? "opacity-50 cursor-not-allowed"
                  : "hover:bg-gray-50"
              }`}
              aria-label="Previous reviews"
            >
              <ChevronLeft className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
            </button>
            <button
              onClick={nextSlide}
              disabled={currentIndex === totalSlides - 1}
              className={`absolute right-0 top-1/2 -translate-y-1/2 bg-white rounded-full p-2 shadow-lg transition z-10 ${
                currentIndex === totalSlides - 1
                  ? "opacity-50 cursor-not-allowed"
                  : "hover:bg-gray-50"
              }`}
              aria-label="Next reviews"
            >
              <ChevronRight className="w-5 h-5 md:w-6 md:h-6 text-gray-600" />
            </button>
          </>
        )}

        {/* Dots Indicator */}
        {totalSlides > 1 && (
          <div className="flex justify-center gap-2 mt-6">
            {Array.from({ length: totalSlides }).map((_, index) => (
              <button
                key={index}
                onClick={() => goToSlide(index)}
                className={`w-2 h-2 rounded-full transition-all ${
                  index === currentIndex ? "bg-gray-800 w-6" : "bg-gray-300"
                }`}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
