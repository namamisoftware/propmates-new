import React, { useState, useRef, useEffect } from "react";
import img1 from "../assets/latestnews/img1.png";
import img2 from "../assets/latestnews/img2.png";
import img3 from "../assets/latestnews/img3.png";
import { Link, useNavigate } from "react-router-dom";

const NewsCard = ({
  image,
  headline,
  description,
  category,
  onClick,
  isActive,
}) => {
  return (
    <Link
      to="/blogdetails"
      className={`relative group cursor-pointer overflow-hidden transition-all duration-300 transform hover:-translate-y-2 flex-shrink-0 ${
        isActive ? "" : ""
      }`}
      onClick={onClick}
      style={{
        width: window.innerWidth >= 1024 ? "auto" : "calc(100vw - 80px)", // Full width minus padding on mobile
        minWidth: window.innerWidth >= 1024 ? "320px" : "calc(100vw - 80px)",
      }}
    >
      <div className="relative h-64 overflow-hidden rounded-2xl">
        <img
          src={image}
          alt={headline}
          className="w-full h-full object-cover rounded-2xl transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-6 ">
        <h3 className="text-xl font-bold text-[#0b154f] mb-3 line-clamp-2">
          {headline}
        </h3>
        <p className="text-gray-600 text-sm line-clamp-3">{description}</p>
      </div>
    </Link>
  );
};

const LatestUpdatedNews = () => {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [showScrolling, setShowScrolling] = useState(false);
  const [containerWidth, setContainerWidth] = useState(0);
  const scrollContainerRef = useRef(null);

  const newsData = [
    {
      id: 1,
      image: img1,
      headline: "Real Estate Market Shows Strong Growth in Downtown Area",
      description:
        "Latest market analysis reveals significant uptick in property values and investment opportunities in the central business district.",
      category: "Headlines",
    },
    {
      id: 2,
      image: img2,
      headline: "New Luxury Development Project Announced",
      description:
        "Premium residential complex featuring state-of-the-art amenities and sustainable design principles breaks ground this month.",
      category: "Headlines",
    },
    {
      id: 3,
      image: img3,
      headline: "Commercial Property Investment Trends 2024",
      description:
        "Industry experts discuss emerging opportunities and market predictions for commercial real estate investments.",
      category: "Headlines",
    },
  ];

  // Check if scrolling is needed based on screen size
  useEffect(() => {
    const checkScrollNeed = () => {
      const isDesktop = window.innerWidth >= 1024; // lg breakpoint
      const needsScrolling = !isDesktop;
      setShowScrolling(needsScrolling);
      setContainerWidth(window.innerWidth);
    };

    checkScrollNeed();
    window.addEventListener("resize", checkScrollNeed);

    return () => {
      window.removeEventListener("resize", checkScrollNeed);
    };
  }, []);

  const handleCardClick = (clickedIndex) => {
    if (!showScrolling) return; // Only handle clicks on smaller screens

    const nextIndex = (clickedIndex + 1) % newsData.length;
    setCurrentIndex(nextIndex);
    scrollToIndex(nextIndex);
  };

  const scrollToIndex = (index) => {
    if (scrollContainerRef.current) {
      const container = scrollContainerRef.current;
      const containerWidth = container.offsetWidth;
      const scrollPosition = index * containerWidth;

      container.scrollTo({
        left: scrollPosition,
        behavior: "smooth",
      });
    }
  };

  const handlePrevious = () => {
    const prevIndex =
      currentIndex === 0 ? newsData.length - 1 : currentIndex - 1;
    setCurrentIndex(prevIndex);
    scrollToIndex(prevIndex);
  };

  const handleNext = () => {
    const nextIndex = (currentIndex + 1) % newsData.length;
    setCurrentIndex(nextIndex);
    scrollToIndex(nextIndex);
  };

  return (
    <section className="py-16 bg-gray-50">
      <div className="max-w-8xl mx-auto px-4 sm:px-6 lg:px-16">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-4">
            Blog
          </h2>
        </div>

        {/* News Container */}
        <div className="relative">
          {/* Navigation arrows for mobile/tablet */}
          {showScrolling && (
            <>
              {/* <button
                onClick={handlePrevious}
                className="absolute left-2 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white rounded-full p-2 shadow-lg transition-all duration-200 hover:scale-110"
                aria-label="Previous news"
              >
                <svg
                  className="w-6 h-6 text-gray-700"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M15 19l-7-7 7-7"
                  />
                </svg>
              </button>

              <button
                onClick={handleNext}
                className="absolute right-2 top-1/2 -translate-y-1/2 z-10 bg-white/90 hover:bg-white rounded-full p-2 shadow-lg transition-all duration-200 hover:scale-110"
                aria-label="Next news"
              >
                <svg
                  className="w-6 h-6 text-gray-700"
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M9 5l7 7-7 7"
                  />
                </svg>
              </button> */}
            </>
          )}

          <div
            ref={scrollContainerRef}
            className={`flex pb-4 ${
              showScrolling
                ? "overflow-x-auto scrollbar-hide snap-x snap-mandatory"
                : "lg:justify-center lg:items-center lg:gap-6 overflow-hidden"
            }`}
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            {newsData.map((news, index) => (
              <div
                key={news.id}
                className={`${
                  showScrolling
                    ? "snap-start flex-shrink-0 px-6"
                    : "lg:flex-1 lg:max-w-sm"
                }`}
                style={{
                  width: showScrolling ? "100%" : "auto",
                }}
              >
                <NewsCard
                  image={news.image}
                  headline={news.headline}
                  description={news.description}
                  category={news.category}
                  onClick={() => handleCardClick(index)}
                  isActive={showScrolling && index === currentIndex}
                />
              </div>
            ))}
          </div>
        </div>

        <div className="text-center">
          <button
            onClick={() => navigate("/blog")}
            className="text-base sm:text-lg text-gray-800 underline hover:text-gray-600 transition-colors duration-300"
          >
            View more Blogs
          </button>
        </div>
      </div>

      {/* Hide scrollbar styles */}
      <style jsx>{`
        .scrollbar-hide {
          -webkit-overflow-scrolling: touch;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .line-clamp-2 {
          display: -webkit-box;
          -webkit-line-clamp: 2;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
        .line-clamp-3 {
          display: -webkit-box;
          -webkit-line-clamp: 3;
          -webkit-box-orient: vertical;
          overflow: hidden;
        }
      `}</style>
    </section>
  );
};

export default LatestUpdatedNews;
