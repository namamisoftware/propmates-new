import React, { useState, useRef } from "react";
import { X, Mail, Lock } from "lucide-react";
import login from "../assets/login.png";
import img2 from "../assets/loginbg.png";

const LoginModal = ({ onClose, onLoginSuccess }) => {
  // const [step, setStep] = useState("form");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  // const [otp, setOtp] = useState(["", "", "", "", "", ""]);
  // const otpInputs = useRef([]);
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!email || !password) {
      alert("Please fill all fields!");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8000/api/token/", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: email,
          password: password,
        }),
      });

      const data = await response.json();

      if (response.ok) {
        console.log("Login successful:", data);

        // Store token and user data in localStorage
        localStorage.setItem("accessToken", data.access);
        localStorage.setItem("userData", JSON.stringify(data.user));

        // Pass user data to parent
        onLoginSuccess(data.user);
      } else {
        alert(data.message || "Login failed");
      }
    } catch (error) {
      console.error("Error:", error);
      alert("An error occurred. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleOtpChange = (index, value) => {
    if (value.length > 1) {
      value = value.slice(-1);
    }

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);

    if (value && index < 5) {
      otpInputs.current[index + 1]?.focus();
    }
  };

  const handleOtpKeyDown = (index, e) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) {
      otpInputs.current[index - 1]?.focus();
    }
  };

  const handleVerifyOtp = () => {
    const otpValue = otp.join("");
    if (otpValue.length === 6) {
      const userData = {
        email: email,
      };
      onLoginSuccess(userData);
      console.log("OTP Verified:", otpValue);
    }
  };

  const handleResendOtp = () => {
    setOtp(["", "", "", "", "", ""]);
    console.log("OTP Resent");
  };

  return (
    <div className="fixed inset-0 flex items-center justify-center bg-[#00000067] bg-opacity-50 z-50">
      <div
        style={{
          backgroundImage: `url(${login})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
        className="relative flex flex-col md:flex-row items-center justify-evenly bg-white max-w-4xl w-full mx-4 md:mx-0 rounded-xl shadow-lg p-6 md:p-10 overflow-hidden"
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
        >
          <X className="w-5 h-5" />
        </button>

        {/* {step === "form" ? ( */}
        <>
          <div className="flex flex-col gap-28">
            <div className="">
              <h1 className="text-[#0b154f] font-semibold text-3xl">
                Post your Property
              </h1>
              <p className="text-sm mb-4">Rent, Sale, Buy Property</p>
            </div>
            <img className="hidden lg:block" src={img2} alt="" />
          </div>

          {/* Card */}
          <div className="border-1 border-[#0b154f] rounded-3xl relative w-[330px] h-100 overflow-hidden">
            {/* Large Blue Blur Circle - Top Left */}
            <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

            <div className="relative z-10 px-8 py-10">
              <h1 className="text-2xl font-bold text-[#0b154f] mb-6">
                Let's get you started
              </h1>

              {/* Email Input */}
              <div className="relative mb-4">
                <label className="text-sm">Your Email:</label>
                <div className="relative mt-2">
                  <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-pink-100/60 border border-gray-700 text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-pink-300"
                  />
                </div>
              </div>

              {/* Password Input */}
              <div className="relative mb-6">
                <label className="text-sm">Your Password:</label>
                <div className="relative mt-2">
                  <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-500" />
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    className="w-full pl-11 pr-4 py-3.5 rounded-xl bg-pink-100/60 border border-gray-700 text-gray-800 text-sm focus:outline-none focus:ring-1 focus:ring-pink-300"
                  />
                </div>
              </div>

              {/* Continue Button */}
              <button
                onClick={handleContinue}
                disabled={!email || !password || loading}
                className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? "Logging in..." : "Continue"}
              </button>
              {/* <button className="text-xs font-semibold mt-2 text-[#0b154f] cursor-pointer">
                  Forget Password
                </button> */}
            </div>
          </div>
        </>
        {/* ) : ( */}
        {/* <> */}
        {/* OTP Screen - Left Side */}
        {/* <div className="md:border-1 border-[#0b154f] rounded-3xl relative w-[360px] overflow-hidden">
              <div className="absolute -top-20 -left-20 w-40 h-40 opacity-60"></div>

              <div className="relative z-10 px-8 py-10">
                <h1 className="text-2xl font-bold text-[#0b154f] mb-2">
                  Verify OTP
                </h1>
                <p className="text-sm text-gray-600 mb-6">
                  We've sent a code to {email}
                </p>

                <div className="mb-6">
                  <label className="text-sm mb-3 block">Enter OTP:</label>
                  <div className="flex gap-2">
                    {otp.map((digit, index) => (
                      <input
                        key={index}
                        ref={(el) => (otpInputs.current[index] = el)}
                        type="text"
                        maxLength="1"
                        value={digit}
                        onChange={(e) => handleOtpChange(index, e.target.value)}
                        onKeyDown={(e) => handleOtpKeyDown(index, e)}
                        className="w-11 h-12 text-center text-xl font-semibold rounded-lg bg-pink-100/60 border border-gray-700 text-gray-800 focus:outline-none focus:ring-1 focus:ring-pink-300"
                      />
                    ))}
                  </div>
                </div>

                <button
                  onClick={handleVerifyOtp}
                  disabled={otp.join("").length !== 6}
                  className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Verify OTP
                </button>

                <div className="text-center mb-4">
                  <button
                    onClick={handleResendOtp}
                    className="text-sm text-[#0b154f] hover:underline"
                  >
                    Resend OTP
                  </button>
                </div>

                <button
                  onClick={() => setStep("form")}
                  className="w-full text-sm text-gray-600 hover:text-gray-800"
                >
                  ← Back
                </button>
              </div>
            </div> */}

        {/* Right Side - Keep same as original */}
        {/* <div className="hidden lg:flex flex-col gap-28">
              <div className="">
                <h1 className="text-[#0b154f] font-semibold text-3xl">
                  Post your Property
                </h1>
                <p className="text-sm">Rent, Sale, Buy Property</p>
              </div>
              <img src={img2} alt="" />
            </div> */}
        {/* </> */}
        {/* )} */}
      </div>
    </div>
  );
};

export default LoginModal;

// import React, { useState, useRef } from "react";
// import { X } from "lucide-react";
// import login from "../assets/login.png";
// import PhoneInput from "react-phone-number-input";
// import "react-phone-number-input/style.css";

// const LoginModal = ({ onClose, onLoginSuccess }) => {
//   const [step, setStep] = useState("form");
//   const [phone, setphone] = useState("");
//   const [otp, setOtp] = useState(["", "", "", "", "", ""]);
//   const [loading, setLoading] = useState(false);
//   const [error, setError] = useState("");
//   const otpInputs = useRef([]);

//   const handleContinue = async () => {
//     if (!phone) return;

//     setLoading(true);
//     setError("");

//     try {
//       const response = await fetch("https://propmatez.shop/api/login/", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ phone }),
//       });

//       const data = await response.json();

//       if (response.ok) {
//         setStep("otp");
//         setOtp(["", "", "", "", "", ""]);
//       } else {
//         setError(data.message || "Failed to send OTP. Please try again.");
//       }
//     } catch (err) {
//       setError("Network error. Please check your connection.");
//       console.error("Login error:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleOtpChange = (index, value) => {
//     if (value.length > 1) {
//       value = value.slice(-1);
//     }

//     const newOtp = [...otp];
//     newOtp[index] = value;
//     setOtp(newOtp);

//     if (value && index < 5) {
//       otpInputs.current[index + 1]?.focus();
//     }
//   };

//   const handleOtpKeyDown = (index, e) => {
//     if (e.key === "Backspace" && !otp[index] && index > 0) {
//       otpInputs.current[index - 1]?.focus();
//     }
//   };

//   const handleVerifyOtp = async () => {
//     const otpValue = otp.join("");
//     if (otpValue.length !== 6) return;

//     setLoading(true);
//     setError("");

//     try {
//       const response = await fetch(
//         "https://propmatez.shop/api/verify-login-otp/",
//         {
//           method: "POST",
//           headers: {
//             "Content-Type": "application/json",
//           },
//           body: JSON.stringify({ phone, otp: otpValue }),
//         }
//       );

//       const data = await response.json();

//       if (response.ok) {
//         const userData = {
//           phone: phone,
//           ...data,
//         };
//         sessionStorage.setItem("user", JSON.stringify(userData));

//         onLoginSuccess(userData);
//       } else {
//         setError(data.message || "OTP verification failed. Please try again.");
//       }
//     } catch (err) {
//       setError("Network error. Please check your connection.");
//       console.error("OTP verification error:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleResendOtp = async () => {
//     setLoading(true);
//     setError("");

//     try {
//       const response = await fetch("https://propmatez.shop/api/login", {
//         method: "POST",
//         headers: {
//           "Content-Type": "application/json",
//         },
//         body: JSON.stringify({ phone }),
//       });

//       const data = await response.json();

//       if (response.ok) {
//         setOtp(["", "", "", "", "", ""]);
//         otpInputs.current[0]?.focus();
//       } else {
//         setError(data.message || "Failed to resend OTP. Please try again.");
//       }
//     } catch (err) {
//       setError("Network error. Please check your connection.");
//       console.error("Resend OTP error:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <div className="fixed inset-0 flex items-center justify-center bg-[#00000067] bg-opacity-40 z-50">
//       <div
//         style={{
//           backgroundImage: `url(${login})`,
//           backgroundSize: "cover",
//           backgroundPosition: "center",
//         }}
//         className="relative flex flex-col md:flex-row items-center justify-evenly bg-white max-w-4xl w-full mx-4 md:mx-0 rounded-xl shadow-lg p-6 md:p-10 overflow-hidden"
//       >
//         <button
//           onClick={onClose}
//           className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
//         >
//           <X className="w-5 h-5" />
//         </button>

//         {step === "form" ? (
//           <>
//             <div className="flex flex-col gap-28">
//               <div>
//                 <h1 className="text-[#0b154f] font-semibold text-3xl">
//                   Post your Property
//                 </h1>
//                 <p className="text-sm mb-4">Rent, Sale, Buy Property</p>
//               </div>
//             </div>

//             <div className="border border-[#0b154f] rounded-3xl relative w-[330px] overflow-hidden">
//               <div className="relative z-10 px-8 py-10">
//                 <h1 className="text-2xl font-bold text-[#0b154f] mb-6">
//                   Let's get you started
//                 </h1>

//                 <div className="relative mb-4">
//                   <label className="text-sm">Your Contact No. :</label>
//                   <div className="relative mt-2 border border-gray-700 rounded-xl">
//                     <PhoneInput
//                       international
//                       defaultCountry="IN"
//                       value={phone}
//                       onChange={setphone}
//                       className="phone-input-custom"
//                       placeholder="Enter phone number"
//                     />
//                   </div>
//                 </div>

//                 {error && (
//                   <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
//                     {error}
//                   </div>
//                 )}

//                 <button
//                   onClick={handleContinue}
//                   disabled={!phone || loading}
//                   className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   {loading ? "Sending OTP..." : "Continue"}
//                 </button>
//               </div>
//             </div>
//           </>
//         ) : (
//           <>
//             <div className="border border-[#0b154f] rounded-3xl relative w-[380px] overflow-hidden">
//               <div className="relative z-10 px-8 py-10">
//                 <h1 className="text-2xl font-bold text-[#0b154f] mb-2">
//                   Verify OTP
//                 </h1>
//                 <p className="text-sm text-gray-600 mb-6">
//                   We've sent a code to {phone}
//                 </p>

//                 <div className="mb-6">
//                   <label className="text-sm mb-3 block">Enter OTP:</label>
//                   <div className="flex gap-2">
//                     {otp.map((digit, index) => (
//                       <input
//                         key={index}
//                         ref={(el) => (otpInputs.current[index] = el)}
//                         type="text"
//                         maxLength="1"
//                         value={digit}
//                         onChange={(e) => handleOtpChange(index, e.target.value)}
//                         onKeyDown={(e) => handleOtpKeyDown(index, e)}
//                         disabled={loading}
//                         className="w-11 h-12 text-center text-xl font-semibold rounded-lg bg-pink-100/60 border border-gray-700 text-gray-800 focus:outline-none focus:ring-1 focus:ring-pink-300 disabled:opacity-50"
//                       />
//                     ))}
//                   </div>
//                 </div>

//                 {error && (
//                   <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
//                     {error}
//                   </div>
//                 )}

//                 <button
//                   onClick={handleVerifyOtp}
//                   disabled={otp.join("").length !== 6 || loading}
//                   className="w-full bg-[#0b154f] text-white text-sm font-medium rounded-lg py-3.5 transition-colors shadow-sm mb-4 disabled:opacity-50 disabled:cursor-not-allowed"
//                 >
//                   {loading ? "Verifying..." : "Verify OTP"}
//                 </button>

//                 <div className="text-center mb-4">
//                   <button
//                     onClick={handleResendOtp}
//                     disabled={loading}
//                     className="text-sm text-[#0b154f] hover:underline disabled:opacity-50"
//                   >
//                     Resend OTP
//                   </button>
//                 </div>

//                 <button
//                   onClick={() => {
//                     setStep("form");
//                     setError("");
//                   }}
//                   className="w-full text-sm text-gray-600 hover:text-gray-800"
//                 >
//                   ← Back
//                 </button>
//               </div>
//             </div>

//             <div className="hidden lg:flex flex-col gap-28">
//               <div>
//                 <h1 className="text-[#0b154f] font-semibold text-3xl">
//                   Post your Property
//                 </h1>
//                 <p className="text-sm">Rent, Sale, Buy Property</p>
//               </div>
//             </div>
//           </>
//         )}

//         <style jsx>{`
//           .phone-input-custom {
//             width: 100%;
//           }
//           .phone-input-custom input {
//             width: 100%;
//             border-radius: 0.75rem;
//             background-color: rgba(252, 231, 243, 0.6);
//             border: 1px solid #374151;
//             padding: 0.875rem 1rem;
//             padding-left: 3rem;
//             color: #1f2937;
//             font-size: 0.875rem;
//           }
//           .phone-input-custom input:focus {
//             outline: none;
//             box-shadow: 0 0 0 1px rgba(249, 168, 212, 1);
//           }
//           .phone-input-custom input::placeholder {
//             color: #4b5563;
//           }
//           .phone-input-custom .PhoneInputCountry {
//             position: absolute;
//             left: 1rem;
//             top: 50%;
//             transform: translateY(-50%);
//             z-index: 1;
//           }
//         `}</style>
//       </div>
//     </div>
//   );
// };

// export default LoginModal;
