// import why1 from "../assets/why1.png";
// import why2 from "../assets/why2.png";
// import why3 from "../assets/why3.png";
// import why4 from "../assets/why4.png";
// import why5 from "../assets/why5.png";

// export default function WhyUsSection() {
//   const features = [
//     {
//       icon: <img src={why1} alt="Why Us 1" className="w-8 h-8" />,
//       title: "Exclusive Property",
//     },
//     {
//       icon: <img src={why2} alt="Why Us 2" className="w-10 h-8" />,
//       title: "Virtual Tour & Site",
//     },
//     {
//       icon: <img src={why3} alt="Why Us 3" className="w-8 h-8" />,
//       title: "0% Brokerage",
//     },
//     {
//       icon: <img src={why4} alt="Why Us 4" className="w-8 h-8" />,
//       title: "Constant Communication",
//     },
//     {
//       icon: <img src={why5} alt="Why Us 5" className="w-8 h-8" />,
//       title: "Online Booking",
//     },
//   ];

//   return (
//     <div className="bg-white py-16 px-14 mt-2">
//       <div className="max-w-8xl rounded-2xl py-10 px-20 mx-auto bg-[#ecefff]">
//         {/* Header */}
//         <div className="text-center mb-10">
//           <h2 className="text-5xl  font-bold text-[#0b154f]">Why US?</h2>
//         </div>

//         {/* Features Grid */}
//         <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-5">
//           {features.map((feature, index) => (
//             <div
//               key={index}
//               className="flex flex-col items-center text-center group hover:transform hover:-translate-y-2 transition-all duration-300"
//             >
//               {/* Icon Container */}
//               <div className="mb-4 transition-colors duration-300">
//                 {feature.icon}
//               </div>

//               {/* Title */}
//               <h3 className="text-xl text-[#94959b] w-1/2">{feature.title}</h3>
//             </div>
//           ))}
//         </div>
//       </div>
//     </div>
//   );
// }

import why1 from "../assets/why1.png";
import why2 from "../assets/why2.png";
import why3 from "../assets/why3.png";
import why4 from "../assets/why4.png";
import why5 from "../assets/why5.png";

export default function WhyUsSection() {
  const features = [
    {
      icon: <img src={why1} alt="Why Us 1" className="w-8 h-8" />,
      title: "Exclusive Property",
    },
    {
      icon: <img src={why2} alt="Why Us 2" className="w-10 h-8" />,
      title: "Virtual Tour & Site",
    },
    {
      icon: <img src={why3} alt="Why Us 3" className="w-8 h-8" />,
      title: "0% Brokerage",
    },
    {
      icon: <img src={why4} alt="Why Us 4" className="w-8 h-8" />,
      title: "Constant Communication",
    },
    {
      icon: <img src={why5} alt="Why Us 5" className="w-8 h-8" />,
      title: "Online Booking",
    },
  ];

  return (
    <div className="bg-white px-4 sm:px-8 lg:px-10 my-8">
      <div className="max-w-8xl rounded-2xl py-6 sm:py-8 lg:py-10 px-4 sm:px-8 md:px-12 lg:px-20 mx-auto bg-[#ecefff]">
        {/* Header */}
        <div className="text-center mb-6 sm:mb-8 lg:mb-10">
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-[#0b154f]">
            Why US?
          </h2>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 sm:gap-5">
          {features.map((feature, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center group hover:transform hover:-translate-y-2 transition-all duration-300"
            >
              {/* Icon Container */}
              <div className="mb-3 sm:mb-4 transition-colors duration-300">
                {feature.icon}
              </div>

              {/* Title */}
              <h3 className="text-lg sm:text-xl text-[#94959b] w-full sm:w-3/4 md:w-2/3 lg:w-1/2 px-2">
                {feature.title}
              </h3>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
