export default function Experts() {
  return (
    <div className="w-full px-8 lg:px-6 pt-2 mt-28 md:mt-42 lg:mt-0 bg-amber-400">
      <div className=" bg-gradient-to-r from-gray-700 to-gray-600  shadow-lg px-6 py-6 max-w-7xl mx-auto">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full sm:w-auto">
            {/* Professional Image */}
            <div className="w-16 h-16 sm:w-16 sm:h-16 md:w-20 md:h-20 rounded-full overflow-hidden border-4 border-white shadow-md flex-shrink-0">
              <img
                src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop"
                alt="Professional"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Text Content */}
            <div className="flex flex-col text-center sm:text-left">
              <h2 className="text-white text-xl sm:text-2xl font-bold mb-1">
                Connect with a Professional
              </h2>
              <p className="text-gray-200 text-sm sm:text-base">
                Find trusted experts to guide your real estate journey.
              </p>
            </div>
          </div>

          {/* CTA Button */}
          <button className="bg-white text-gray-800 font-semibold px-5 py-2.5 sm:px-6 sm:py-3 rounded-lg hover:bg-gray-100 transition-colors duration-200 flex items-center gap-2 whitespace-nowrap shadow-md w-full sm:w-auto justify-center">
            Meet Our Experts
            <svg
              className="w-5 h-5"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M9 5l7 7-7 7"
              />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
}
