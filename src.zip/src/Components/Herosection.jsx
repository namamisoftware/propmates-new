// import React from "react";
// import { useState, useEffect, useRef } from "react";
// import { ChevronDown, Search, ChevronLeft, ChevronRight } from "lucide-react";

// const Herosection = () => {
//   const [currentSlide, setCurrentSlide] = useState(0);
//   const [selectedTab, setSelectedTab] = useState("Buy");
//   const [isPropertyTypeDropdownOpen, setIsPropertyTypeDropdownOpen] =
//     useState(false);
//   const [isBedsDropdownOpen, setIsBedsDropdownOpen] = useState(false);
//   const [selectedPropertyType, setSelectedPropertyType] = useState("");
//   const [selectedBedRooms, setSelectedBedRooms] = useState([]);
//   const [selectedBathRooms, setSelectedBathRooms] = useState([]);

//   const dropdownRef = useRef(null);

//   const tabs = ["Buy", "Rent", "New projects", "Commercial"];

//   // Dynamic content based on selected tab
//   const getTabContent = (tab) => {
//     switch (tab) {
//       case "Buy":
//         return {
//           searchPlaceholder: "Search...",
//           propertyTypeOptions: [
//             { value: "apartment", label: "Apartment" },
//             { value: "villa", label: "Villa" },
//             { value: "townhouse", label: "Townhouse" },
//             { value: "penthouse", label: "Penthouse" },
//             { value: "plot", label: "Plot/Land" },
//           ],
//           bedsLabel: "Beds & Baths",
//           showBedsAndBaths: true,
//         };
//       case "Rent":
//         return {
//           searchPlaceholder: "Search...",
//           propertyTypeOptions: [
//             { value: "apartment", label: "Apartment" },
//             { value: "villa", label: "Villa" },
//             { value: "studio", label: "Studio" },
//             { value: "shared", label: "Shared Space" },
//             { value: "office", label: "Office Space" },
//           ],
//           bedsLabel: "Beds & Baths",
//           showBedsAndBaths: true,
//         };
//       case "New projects":
//         return {
//           searchPlaceholder: "Search...",
//           propertyTypeOptions: [
//             { value: "residential", label: "Residential" },
//             { value: "mixed-use", label: "Mixed Use" },
//             { value: "luxury", label: "Luxury" },
//             { value: "affordable", label: "Affordable Housing" },
//           ],
//           bedsLabel: "Bedrooms",
//           showBedsAndBaths: true,
//         };
//       case "Commercial":
//         return {
//           searchPlaceholder: "Search...",
//           propertyTypeOptions: [
//             { value: "office", label: "Office Space" },
//             { value: "retail", label: "Retail Space" },
//             { value: "warehouse", label: "Warehouse" },
//             { value: "industrial", label: "Industrial" },
//             { value: "coworking", label: "Co-working Space" },
//           ],
//           bedsLabel: "Area (sqft)",
//           showBedsAndBaths: false,
//           areaOptions: [
//             { value: "500-1000", label: "500-1000 sqft" },
//             { value: "1000-2000", label: "1000-2000 sqft" },
//             { value: "2000-5000", label: "2000-5000 sqft" },
//             { value: "5000+", label: "5000+ sqft" },
//           ],
//         };
//       default:
//         return {
//           searchPlaceholder: "Search...",
//           propertyTypeOptions: [],
//           bedsLabel: "Beds & Baths",
//           showBedsAndBaths: true,
//         };
//     }
//   };

//   const currentContent = getTabContent(selectedTab);

//   const bedroomOptions = ["Studio", "1", "2", "3", "4", "5", "6", "7", "8+"];
//   const bathroomOptions = ["Bedrooms", "1", "2", "3", "4", "5", "6", "7", "8+"];

//   // For commercial area selection
//   const [selectedArea, setSelectedArea] = useState("");

//   const togglePropertyTypeDropdown = () => {
//     setIsPropertyTypeDropdownOpen(!isPropertyTypeDropdownOpen);
//     setIsBedsDropdownOpen(false);
//   };

//   const toggleBedsDropdown = () => {
//     setIsBedsDropdownOpen(!isBedsDropdownOpen);
//     setIsPropertyTypeDropdownOpen(false);
//   };

//   const handlePropertyTypeSelect = (option) => {
//     setSelectedPropertyType(option.label);
//     setIsPropertyTypeDropdownOpen(false);
//   };

//   const toggleBedBathSelection = (type, value) => {
//     if (type === "bedRooms") {
//       setSelectedBedRooms((prev) => {
//         if (prev.includes(value)) {
//           return prev.filter((item) => item !== value);
//         } else {
//           return [...prev, value];
//         }
//       });
//     } else if (type === "bathRooms") {
//       setSelectedBathRooms((prev) => {
//         if (prev.includes(value)) {
//           return prev.filter((item) => item !== value);
//         } else {
//           return [...prev, value];
//         }
//       });
//     }
//   };

//   const handleAreaSelect = (option) => {
//     setSelectedArea(option.label);
//     setIsBedsDropdownOpen(false);
//   };

//   // Reset selections when tab changes
//   const handleTabChange = (tab) => {
//     setSelectedTab(tab);
//     setSelectedPropertyType("");
//     setSelectedBedRooms([]);
//     setSelectedBathRooms([]);
//     setSelectedArea("");
//     setIsPropertyTypeDropdownOpen(false);
//     setIsBedsDropdownOpen(false);
//   };

//   // Generate display value for beds & baths dropdown
//   const getBedsAndBathsDisplayValue = () => {
//     if (selectedTab === "Commercial") {
//       return selectedArea || currentContent.bedsLabel;
//     }

//     if (selectedBedRooms.length || selectedBathRooms.length) {
//       const bedsText = selectedBedRooms.length
//         ? `Beds: ${selectedBedRooms.join(", ")}`
//         : "";
//       const bathsText = selectedBathRooms.length
//         ? `Baths: ${selectedBathRooms.join(", ")}`
//         : "";
//       return [bedsText, bathsText].filter(Boolean).join(" | ");
//     }
//     return currentContent.bedsLabel;
//   };

//   // Close dropdown when clicking outside
//   useEffect(() => {
//     const handleClickOutside = (event) => {
//       if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
//         setIsBedsDropdownOpen(false);
//       }
//     };
//     document.addEventListener("mousedown", handleClickOutside);
//     return () => document.removeEventListener("mousedown", handleClickOutside);
//   }, []);

//   // Sample slider images
//   const sliderImages = [
//     {
//       id: 1,
//       url: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
//       title: "Modern Luxury Homes",
//       subtitle: "Premium Properties",
//     },
//     {
//       id: 2,
//       url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80",
//       title: "Contemporary Living",
//       subtitle: "Stylish Interiors",
//     },
//     {
//       id: 3,
//       url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2053&q=80",
//       title: "Elegant Residences",
//       subtitle: "Your Perfect Home",
//     },
//     {
//       id: 4,
//       url: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
//       title: "Dream Properties",
//       subtitle: "Exceptional Quality",
//     },
//   ];

//   // Auto-slide functionality
//   useEffect(() => {
//     const interval = setInterval(() => {
//       setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
//     }, 5000);

//     return () => clearInterval(interval);
//   }, [sliderImages.length]);

//   const nextSlide = () => {
//     setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
//   };

//   const prevSlide = () => {
//     setCurrentSlide(
//       (prev) => (prev - 1 + sliderImages.length) % sliderImages.length
//     );
//   };

//   const goToSlide = (index) => {
//     setCurrentSlide(index);
//   };

//   return (
//     <div className="min-h-screen px-4 md:px-8 py-1 relative mt-10">
//       {/* Hero Section with Slider */}
//       <div className="w-full h-[400px] md:h-[500px] lg:h-[600px] text-white rounded-2xl relative overflow-hidden">
//         {/* Slider Images */}
//         <div className="relative w-full h-full">
//           {sliderImages.map((image, index) => (
//             <div
//               key={image.id}
//               className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
//                 index === currentSlide ? "opacity-100" : "opacity-0"
//               }`}
//             >
//               <img
//                 src={image.url}
//                 alt={image.title}
//                 className="w-full h-full object-cover"
//               />
//               <div className="absolute inset-0 bg-opacity-40"></div>
//             </div>
//           ))}
//         </div>

//         {/* Content Overlay */}
//         <div className="absolute inset-0 flex flex-col md:flex-row items-center justify-between px-6 md:px-10 lg:px-13 py-8 lg:py-0 z-10">
//           <div className="space-y-2 text-left">
//             <p className="text-sm md:text-base lg:text-lg">
//               Home Buying Will Never Be The Same
//             </p>
//             <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
//               Find your
//             </h1>
//             <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
//               Dream Home
//             </h1>
//             <p className="text-sm md:text-base lg:text-lg">
//               India's first consumer centric real{" "}
//               <br className="hidden lg:block" />
//               estate buying platform
//             </p>
//           </div>
//         </div>
//       </div>

//       {/* Search Form Section */}
//       <div className="w-[85%] md:w-[90%] lg:w-[85%] bg-[#0b154f] z-20 absolute top-[50%] md:top-[70%] lg:top-[70%] xl:top-[70%] left-[7%] md:left-[5%] lg:left-[8%] rounded-2xl px-4 md:px-10 lg:px-20 py-4 md:py-6 lg:py-8">
//         {/* Tab Navigation */}
//         <div className="flex flex-wrap gap-2 md:gap-4 lg:gap-8 mb-6 justify-center">
//           {tabs.map((tab) => (
//             <button
//               key={tab}
//               onClick={() => handleTabChange(tab)}
//               className={`px-3 md:px-4 lg:px-6 py-1 rounded-xl text-sm md:text-base lg:text-lg font-medium transition-all duration-200 whitespace-nowrap ${
//                 selectedTab === tab
//                   ? "border-2 text-white border-white"
//                   : "text-[#737580] border-2 border-[#737580]"
//               }`}
//             >
//               {tab}
//             </button>
//           ))}
//         </div>

//         {/* Search Form */}
//         <div className="">
//           {/* Mobile/Tablet: Stack all elements */}
//           <div className="flex flex-col gap-4 items-stretch lg:hidden">
//             {/* Location Search Input */}
//             <div className="flex-1 relative">
//               <input
//                 type="text"
//                 placeholder={currentContent.searchPlaceholder}
//                 className="w-full px-4 md:px-6 py-3 md:py-4 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-sm md:placeholder:text-base bg-transparent"
//               />
//               <Search className="absolute right-4 md:right-6 top-1/2 transform -translate-y-1/2 text-white w-4 h-4 md:w-5 md:h-5" />
//             </div>

//             {/* Property Type Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={togglePropertyTypeDropdown}
//                 className="flex items-center justify-between w-full px-4 md:px-6 py-3 md:py-4 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
//               >
//                 <span
//                   className={selectedPropertyType ? "text-white" : "text-white"}
//                 >
//                   {selectedPropertyType || "Property type"}
//                 </span>
//                 <ChevronDown
//                   className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
//                     isPropertyTypeDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isPropertyTypeDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2">
//                     {currentContent.propertyTypeOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handlePropertyTypeSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Beds & Baths / Area Dropdown */}
//             <div className="relative" ref={dropdownRef}>
//               <button
//                 onClick={toggleBedsDropdown}
//                 className="flex items-center justify-between w-full px-4 md:px-6 py-3 md:py-4 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
//               >
//                 <span className="text-white truncate pr-2">
//                   {getBedsAndBathsDisplayValue()}
//                 </span>
//                 <ChevronDown
//                   className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
//                     isBedsDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>

//               {isBedsDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="p-3 md:p-4 max-h-64 overflow-y-auto">
//                     {currentContent.showBedsAndBaths ? (
//                       <>
//                         {/* Bedrooms */}
//                         <div className="mb-4">
//                           <div className="flex flex-col gap-3 mb-3">
//                             <div className="flex flex-wrap gap-2">
//                               {bedroomOptions.map((item) => (
//                                 <button
//                                   key={item}
//                                   type="button"
//                                   onClick={() =>
//                                     toggleBedBathSelection("bedRooms", item)
//                                   }
//                                   className={`px-3 py-2 rounded-md text-sm ${
//                                     selectedBedRooms.includes(item)
//                                       ? "bg-[#0b154f] text-white"
//                                       : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
//                                   }`}
//                                 >
//                                   {item}
//                                 </button>
//                               ))}
//                             </div>
//                           </div>

//                           {/* Bathrooms */}
//                           <div className="flex flex-col gap-3">
//                             <div className="flex flex-wrap gap-2">
//                               {bathroomOptions.map((item) => (
//                                 <button
//                                   key={item}
//                                   type="button"
//                                   onClick={() =>
//                                     toggleBedBathSelection("bathRooms", item)
//                                   }
//                                   className={`px-3 py-2 rounded-md text-sm ${
//                                     selectedBathRooms.includes(item)
//                                       ? "bg-[#0b154f] text-white"
//                                       : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
//                                   }`}
//                                 >
//                                   {item}
//                                 </button>
//                               ))}
//                             </div>
//                           </div>
//                         </div>
//                       </>
//                     ) : (
//                       // Commercial Area Options
//                       <div className="py-2">
//                         {currentContent.areaOptions?.map((option) => (
//                           <button
//                             key={option.value}
//                             onClick={() => handleAreaSelect(option)}
//                             className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                           >
//                             {option.label}
//                           </button>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Search Button */}
//             <button className="bg-white text-[#0b154f] px-8 md:px-12 py-3 md:py-4 rounded-2xl font-semibold text-sm md:text-base">
//               Search
//             </button>
//           </div>

//           {/* Desktop: All elements in same row */}
//           <div className="hidden lg:flex flex-row gap-4 items-stretch">
//             {/* Location Search Input */}
//             <div className="flex-1 relative">
//               <input
//                 type="text"
//                 placeholder={currentContent.searchPlaceholder}
//                 className="w-full px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-lg bg-transparent"
//               />
//               <Search className="absolute right-10 top-1/2 transform -translate-y-1/2 text-white w-5 h-6" />
//             </div>

//             {/* Property Type Dropdown */}
//             <div className="relative">
//               <button
//                 onClick={togglePropertyTypeDropdown}
//                 className="flex items-center justify-between px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
//               >
//                 <span
//                   className={selectedPropertyType ? "text-white" : "text-white"}
//                 >
//                   {selectedPropertyType || "Property type"}
//                 </span>
//                 <ChevronDown
//                   className={`w-5 h-5 text-white transition-transform ml-2 ${
//                     isPropertyTypeDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>
//               {isPropertyTypeDropdownOpen && (
//                 <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
//                   <div className="py-2">
//                     {currentContent.propertyTypeOptions.map((option) => (
//                       <button
//                         key={option.value}
//                         onClick={() => handlePropertyTypeSelect(option)}
//                         className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                       >
//                         {option.label}
//                       </button>
//                     ))}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Beds & Baths / Area Dropdown */}
//             <div className="relative min-w-[250px]" ref={dropdownRef}>
//               <button
//                 onClick={toggleBedsDropdown}
//                 className="flex items-center justify-between px-8 py-6 text-white text-lg rounded-2xl border-2 border-white focus:outline-none bg-transparent w-full"
//               >
//                 <span className="text-white truncate pr-2">
//                   {getBedsAndBathsDisplayValue()}
//                 </span>
//                 <ChevronDown
//                   className={`w-5 h-5 text-white transition-transform ml-2 ${
//                     isBedsDropdownOpen ? "rotate-180" : ""
//                   }`}
//                 />
//               </button>

//               {isBedsDropdownOpen && (
//                 <div
//                   className={`absolute top-full left-0 mt-2 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50 ${
//                     currentContent.showBedsAndBaths
//                       ? "w-full md:w-[500px]"
//                       : "w-full"
//                   }`}
//                 >
//                   <div className="p-4 max-h-64 overflow-y-auto">
//                     {currentContent.showBedsAndBaths ? (
//                       <>
//                         {/* Bedrooms */}
//                         <div className="mb-4">
//                           <div className="flex flex-col gap-3 mb-3">
//                             <div className="flex flex-wrap gap-2">
//                               {bedroomOptions.map((item) => (
//                                 <button
//                                   key={item}
//                                   type="button"
//                                   onClick={() =>
//                                     toggleBedBathSelection("bedRooms", item)
//                                   }
//                                   className={`px-3 py-2 rounded-md ${
//                                     selectedBedRooms.includes(item)
//                                       ? "bg-[#0b154f] text-white"
//                                       : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
//                                   }`}
//                                 >
//                                   {item}
//                                 </button>
//                               ))}
//                             </div>
//                           </div>

//                           {/* Bathrooms */}
//                           <div className="flex flex-col gap-3">
//                             <div className="flex flex-wrap gap-2">
//                               {bathroomOptions.map((item) => (
//                                 <button
//                                   key={item}
//                                   type="button"
//                                   onClick={() =>
//                                     toggleBedBathSelection("bathRooms", item)
//                                   }
//                                   className={`px-3 py-2 rounded-md ${
//                                     selectedBathRooms.includes(item)
//                                       ? "bg-[#0b154f] text-white"
//                                       : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
//                                   }`}
//                                 >
//                                   {item}
//                                 </button>
//                               ))}
//                             </div>
//                           </div>
//                         </div>
//                       </>
//                     ) : (
//                       // Commercial Area Options - Reduced width dropdown
//                       <div className="py-2">
//                         {currentContent.areaOptions?.map((option) => (
//                           <button
//                             key={option.value}
//                             onClick={() => handleAreaSelect(option)}
//                             className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
//                           >
//                             {option.label}
//                           </button>
//                         ))}
//                       </div>
//                     )}
//                   </div>
//                 </div>
//               )}
//             </div>

//             {/* Search Button */}
//             <button className="bg-white text-[#0b154f] px-14 py-3 rounded-2xl font-semibold text-lg">
//               Search
//             </button>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Herosection;

import React from "react";
import { useState, useEffect, useRef } from "react";
import { ChevronDown, Search, ChevronLeft, ChevronRight } from "lucide-react";

const Herosection = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [selectedTab, setSelectedTab] = useState("Buy");
  const [isPropertyTypeDropdownOpen, setIsPropertyTypeDropdownOpen] =
    useState(false);
  const [isBedsDropdownOpen, setIsBedsDropdownOpen] = useState(false);
  const [selectedPropertyType, setSelectedPropertyType] = useState("");
  const [selectedBedRooms, setSelectedBedRooms] = useState([]);
  const [selectedBathRooms, setSelectedBathRooms] = useState([]);

  const dropdownRef = useRef(null);

  const tabs = ["Buy", "Rent", "New projects", "Commercial"];

  // Dynamic content based on selected tab
  const getTabContent = (tab) => {
    switch (tab) {
      case "Buy":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "townhouse", label: "Townhouse" },
            { value: "penthouse", label: "Penthouse" },
            { value: "plot", label: "Plot/Land" },
          ],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
      case "Rent":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "apartment", label: "Apartment" },
            { value: "villa", label: "Villa" },
            { value: "studio", label: "Studio" },
            { value: "shared", label: "Shared Space" },
            { value: "office", label: "Office Space" },
          ],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
      case "New projects":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "residential", label: "Residential" },
            { value: "mixed-use", label: "Mixed Use" },
            { value: "luxury", label: "Luxury" },
            { value: "affordable", label: "Affordable Housing" },
          ],
          bedsLabel: "Bedrooms",
          showBedsAndBaths: true,
        };
      case "Commercial":
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [
            { value: "office", label: "Office Space" },
            { value: "retail", label: "Retail Space" },
            { value: "warehouse", label: "Warehouse" },
            { value: "industrial", label: "Industrial" },
            { value: "coworking", label: "Co-working Space" },
          ],
          bedsLabel: "Area (sqft)",
          showBedsAndBaths: false,
          areaOptions: [
            { value: "500-1000", label: "500-1000 sqft" },
            { value: "1000-2000", label: "1000-2000 sqft" },
            { value: "2000-5000", label: "2000-5000 sqft" },
            { value: "5000+", label: "5000+ sqft" },
          ],
        };
      default:
        return {
          searchPlaceholder: "Search...",
          propertyTypeOptions: [],
          bedsLabel: "Beds & Baths",
          showBedsAndBaths: true,
        };
    }
  };

  const currentContent = getTabContent(selectedTab);

  const bedroomOptions = ["Studio", "1", "2", "3", "4", "5", "6", "7", "8+"];
  const bathroomOptions = ["Bedrooms", "1", "2", "3", "4", "5", "6", "7", "8+"];

  // For commercial area selection
  const [selectedArea, setSelectedArea] = useState("");

  const togglePropertyTypeDropdown = () => {
    setIsPropertyTypeDropdownOpen(!isPropertyTypeDropdownOpen);
    setIsBedsDropdownOpen(false);
  };

  const toggleBedsDropdown = () => {
    setIsBedsDropdownOpen(!isBedsDropdownOpen);
    setIsPropertyTypeDropdownOpen(false);
  };

  const handlePropertyTypeSelect = (option) => {
    setSelectedPropertyType(option.label);
    setIsPropertyTypeDropdownOpen(false);
  };

  const toggleBedBathSelection = (type, value) => {
    if (type === "bedRooms") {
      setSelectedBedRooms((prev) => {
        if (prev.includes(value)) {
          return prev.filter((item) => item !== value);
        } else {
          return [...prev, value];
        }
      });
    } else if (type === "bathRooms") {
      setSelectedBathRooms((prev) => {
        if (prev.includes(value)) {
          return prev.filter((item) => item !== value);
        } else {
          return [...prev, value];
        }
      });
    }
  };

  const handleAreaSelect = (option) => {
    setSelectedArea(option.label);
    setIsBedsDropdownOpen(false);
  };

  // Reset selections when tab changes
  const handleTabChange = (tab) => {
    setSelectedTab(tab);
    setSelectedPropertyType("");
    setSelectedBedRooms([]);
    setSelectedBathRooms([]);
    setSelectedArea("");
    setIsPropertyTypeDropdownOpen(false);
    setIsBedsDropdownOpen(false);
  };

  // Generate display value for beds & baths dropdown
  const getBedsAndBathsDisplayValue = () => {
    if (selectedTab === "Commercial") {
      return selectedArea || currentContent.bedsLabel;
    }

    if (selectedBedRooms.length || selectedBathRooms.length) {
      const bedsText = selectedBedRooms.length
        ? `Beds: ${selectedBedRooms.join(", ")}`
        : "";
      const bathsText = selectedBathRooms.length
        ? `Baths: ${selectedBathRooms.join(", ")}`
        : "";
      return [bedsText, bathsText].filter(Boolean).join(" | ");
    }
    return currentContent.bedsLabel;
  };

  // Close dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsBedsDropdownOpen(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Sample slider images
  const sliderImages = [
    {
      id: 1,
      url: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      title: "Modern Luxury Homes",
      subtitle: "Premium Properties",
    },
    {
      id: 2,
      url: "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?ixlib=rb-4.0.3&auto=format&fit=crop&w=2075&q=80",
      title: "Contemporary Living",
      subtitle: "Stylish Interiors",
    },
    {
      id: 3,
      url: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?ixlib=rb-4.0.3&auto=format&fit=crop&w=2053&q=80",
      title: "Elegant Residences",
      subtitle: "Your Perfect Home",
    },
    {
      id: 4,
      url: "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?ixlib=rb-4.0.3&auto=format&fit=crop&w=2070&q=80",
      title: "Dream Properties",
      subtitle: "Exceptional Quality",
    },
  ];

  // Auto-slide functionality
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
    }, 5000);

    return () => clearInterval(interval);
  }, [sliderImages.length]);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % sliderImages.length);
  };

  const prevSlide = () => {
    setCurrentSlide(
      (prev) => (prev - 1 + sliderImages.length) % sliderImages.length
    );
  };

  const goToSlide = (index) => {
    setCurrentSlide(index);
  };

  return (
    <div className=" px-4 md:px-8 py-1 relative mt-6 ">
      {/* Hero Section with Slider */}
      <div className="w-full h-[400px] md:h-[500px] lg:h-[600px] text-white rounded-2xl relative overflow-hidden">
        {/* Slider Images */}
        <div className="relative w-full h-full">
          {sliderImages.map((image, index) => (
            <div
              key={image.id}
              className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                index === currentSlide ? "opacity-100" : "opacity-0"
              }`}
            >
              <img
                src={image.url}
                alt={image.title}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-opacity-40"></div>
            </div>
          ))}
        </div>

        {/* Content Overlay */}
        <div className="absolute inset-0 flex flex-col md:flex-row items-center justify-between px-6 md:px-10 lg:px-13 py-8 lg:py-0 z-10">
          <div className="space-y-2 text-left">
            <p className="text-sm md:text-base lg:text-lg">
              Home Buying Will Never Be The Same
            </p>
            <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
              Find your
            </h1>
            <h1 className="text-3xl md:text-5xl lg:text-6xl xl:text-7xl font-medium">
              Dream Home
            </h1>
            <p className="text-sm md:text-base lg:text-lg">
              India's first consumer centric real{" "}
              <br className="hidden lg:block" />
              estate buying platform
            </p>
          </div>
        </div>
      </div>

      {/* Search Form Section */}
      <div className="w-[83%] md:w-[90%] lg:w-[84%] bg-[#0b154f] z-20 absolute top-[50%] md:top-[70%] lg:top-[70%] xl:top-[70%] left-[8%] md:left-[5%] lg:left-[8%] rounded-t-2xl px-4 md:px-10 lg:px-20 py-4 md:py-5 lg:py-10">
        {/* Tab Navigation */}
        <div className="flex flex-wrap gap-2 md:gap-4 lg:gap-8 mb-4 justify-center">
          {tabs.map((tab) => (
            <button
              key={tab}
              onClick={() => handleTabChange(tab)}
              className={`px-3 md:px-4 lg:px-6 py-1 rounded-xl text-sm md:text-base lg:text-lg font-medium transition-all duration-200 whitespace-nowrap ${
                selectedTab === tab
                  ? "border-2 text-white border-white"
                  : "text-[#737580] border-2 border-[#737580]"
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Search Form */}
        <div className="">
          {/* Mobile/Tablet: Stack all elements */}
          <div className="flex flex-col gap-3 items-stretch lg:hidden">
            {/* Location Search Input */}
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder={currentContent.searchPlaceholder}
                className="w-full px-4 md:px-6 py-2.5 md:py-3 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-sm md:placeholder:text-base bg-transparent"
              />
              <Search className="absolute right-4 md:right-6 top-1/2 transform -translate-y-1/2 text-white w-4 h-4 md:w-5 md:h-5" />
            </div>

            {/* Property Type Dropdown */}
            <div className="relative">
              <button
                onClick={togglePropertyTypeDropdown}
                className="flex items-center justify-between w-full px-4 md:px-6 py-2.5 md:py-3 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
              >
                <span
                  className={selectedPropertyType ? "text-white" : "text-white"}
                >
                  {selectedPropertyType || "Property type"}
                </span>
                <ChevronDown
                  className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
                    isPropertyTypeDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isPropertyTypeDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2">
                    {currentContent.propertyTypeOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handlePropertyTypeSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Beds & Baths / Area Dropdown */}
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={toggleBedsDropdown}
                className="flex items-center justify-between w-full px-4 md:px-6 py-2.5 md:py-3 text-white text-sm md:text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent"
              >
                <span className="text-white truncate pr-2">
                  {getBedsAndBathsDisplayValue()}
                </span>
                <ChevronDown
                  className={`w-4 h-4 md:w-5 md:h-5 text-white transition-transform ${
                    isBedsDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {isBedsDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="p-3 md:p-4 max-h-64 overflow-y-auto">
                    {currentContent.showBedsAndBaths ? (
                      <>
                        {/* Bedrooms */}
                        <div className="mb-4">
                          <div className="flex flex-col gap-3 mb-3">
                            <div className="flex flex-wrap gap-2">
                              {bedroomOptions.map((item) => (
                                <button
                                  key={item}
                                  type="button"
                                  onClick={() =>
                                    toggleBedBathSelection("bedRooms", item)
                                  }
                                  className={`px-3 py-2 rounded-md text-sm ${
                                    selectedBedRooms.includes(item)
                                      ? "bg-[#0b154f] text-white"
                                      : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                  }`}
                                >
                                  {item}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Bathrooms */}
                          <div className="flex flex-col gap-3">
                            <div className="flex flex-wrap gap-2">
                              {bathroomOptions.map((item) => (
                                <button
                                  key={item}
                                  type="button"
                                  onClick={() =>
                                    toggleBedBathSelection("bathRooms", item)
                                  }
                                  className={`px-3 py-2 rounded-md text-sm ${
                                    selectedBathRooms.includes(item)
                                      ? "bg-[#0b154f] text-white"
                                      : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                  }`}
                                >
                                  {item}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      // Commercial Area Options
                      <div className="py-2">
                        {currentContent.areaOptions?.map((option) => (
                          <button
                            key={option.value}
                            onClick={() => handleAreaSelect(option)}
                            className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Search Button */}
            <button className="bg-white text-[#0b154f] px-8 md:px-12 py-2.5 md:py-3 rounded-2xl font-semibold text-sm md:text-base">
              Search
            </button>
          </div>

          {/* Desktop: All elements in same row */}
          <div className="hidden lg:flex flex-row gap-4 items-stretch">
            {/* Location Search Input */}
            <div className="flex-1 relative">
              <input
                type="text"
                placeholder={currentContent.searchPlaceholder}
                className="w-full px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none placeholder:text-white placeholder:text-base bg-transparent"
              />
              <Search className="absolute right-10 top-1/2 transform -translate-y-1/2 text-white w-5 h-5" />
            </div>

            {/* Property Type Dropdown */}
            <div className="relative">
              <button
                onClick={togglePropertyTypeDropdown}
                className="flex items-center justify-between px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent min-w-[200px]"
              >
                <span
                  className={selectedPropertyType ? "text-white" : "text-white"}
                >
                  {selectedPropertyType || "Property type"}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-white transition-transform ml-2 ${
                    isPropertyTypeDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>
              {isPropertyTypeDropdownOpen && (
                <div className="absolute top-full left-0 mt-2 w-full bg-white border border-[#0b154f] rounded-xl shadow-lg z-50">
                  <div className="py-2">
                    {currentContent.propertyTypeOptions.map((option) => (
                      <button
                        key={option.value}
                        onClick={() => handlePropertyTypeSelect(option)}
                        className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                      >
                        {option.label}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Beds & Baths / Area Dropdown */}
            <div className="relative min-w-[250px]" ref={dropdownRef}>
              <button
                onClick={toggleBedsDropdown}
                className="flex items-center justify-between px-8 py-3.5 text-white text-base rounded-2xl border-2 border-white focus:outline-none bg-transparent w-full"
              >
                <span className="text-white truncate pr-2">
                  {getBedsAndBathsDisplayValue()}
                </span>
                <ChevronDown
                  className={`w-5 h-5 text-white transition-transform ml-2 ${
                    isBedsDropdownOpen ? "rotate-180" : ""
                  }`}
                />
              </button>

              {isBedsDropdownOpen && (
                <div
                  className={`absolute top-full left-0 mt-2 bg-white border border-[#0b154f] rounded-xl shadow-lg z-50 ${
                    currentContent.showBedsAndBaths
                      ? "w-full md:w-[500px]"
                      : "w-full"
                  }`}
                >
                  <div className="p-4 max-h-64 overflow-y-auto">
                    {currentContent.showBedsAndBaths ? (
                      <>
                        {/* Bedrooms */}
                        <div className="mb-4">
                          <div className="flex flex-col gap-3 mb-3">
                            <div className="flex flex-wrap gap-2">
                              {bedroomOptions.map((item) => (
                                <button
                                  key={item}
                                  type="button"
                                  onClick={() =>
                                    toggleBedBathSelection("bedRooms", item)
                                  }
                                  className={`px-3 py-2 rounded-md ${
                                    selectedBedRooms.includes(item)
                                      ? "bg-[#0b154f] text-white"
                                      : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                  }`}
                                >
                                  {item}
                                </button>
                              ))}
                            </div>
                          </div>

                          {/* Bathrooms */}
                          <div className="flex flex-col gap-3">
                            <div className="flex flex-wrap gap-2">
                              {bathroomOptions.map((item) => (
                                <button
                                  key={item}
                                  type="button"
                                  onClick={() =>
                                    toggleBedBathSelection("bathRooms", item)
                                  }
                                  className={`px-3 py-2 rounded-md ${
                                    selectedBathRooms.includes(item)
                                      ? "bg-[#0b154f] text-white"
                                      : "bg-gray-100 text-[#0b154f] hover:bg-gray-200"
                                  }`}
                                >
                                  {item}
                                </button>
                              ))}
                            </div>
                          </div>
                        </div>
                      </>
                    ) : (
                      // Commercial Area Options
                      <div className="py-2">
                        {currentContent.areaOptions?.map((option) => (
                          <button
                            key={option.value}
                            onClick={() => handleAreaSelect(option)}
                            className="block w-full text-left px-4 py-2 text-[#0b154f] hover:text-black hover:bg-gray-50 transition-colors"
                          >
                            {option.label}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Search Button */}
            <button className="bg-white text-[#0b154f] px-14 py-3.5 rounded-2xl font-semibold text-base">
              Search
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Herosection;
