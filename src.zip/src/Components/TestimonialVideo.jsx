// import React, { useState, useEffect, useRef } from "react";
// import { Play, X } from "lucide-react";

// export default function TestimonialSection() {
//   const [selectedVideo, setSelectedVideo] = useState(null);
//   const [isAutoPlaying, setIsAutoPlaying] = useState(true);
//   const scrollContainerRef = useRef(null);
//   const intervalRef = useRef(null);

//   const videoReviews = [
//     {
//       name: "Nishant and Amrita",
//       color: "bg-red-500",
//       thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
//       videoId: "dQw4w9WgXcQ",
//     },
//     {
//       name: "Partiti De",
//       color: "bg-blue-400",
//       thumbnail: "https://img.youtube.com/vi/9bZkp7q19f0/mqdefault.jpg",
//       videoId: "9bZkp7q19f0",
//     },
//     {
//       name: "Dandin Vishwanath",
//       color: "bg-blue-500",
//       thumbnail: "https://img.youtube.com/vi/kJQP7kiw5Fk/mqdefault.jpg",
//       videoId: "kJQP7kiw5Fk",
//     },
//     {
//       name: "Guru Raj Tiwari",
//       color: "bg-orange-500",
//       thumbnail: "https://img.youtube.com/vi/ZZ5LpwO-An4/mqdefault.jpg",
//       videoId: "ZZ5LpwO-An4",
//     },
//     {
//       name: "Mr. Jaimin Desai",
//       color: "bg-blue-400",
//       thumbnail: "https://img.youtube.com/vi/L_jWHffIx5E/mqdefault.jpg",
//       videoId: "L_jWHffIx5E",
//     },
//     {
//       name: "Pawan",
//       color: "bg-blue-500",
//       thumbnail: "https://img.youtube.com/vi/2Vv-BfVoq4g/mqdefault.jpg",
//       videoId: "2Vv-BfVoq4g",
//     },
//   ];

//   // Triple the videos for seamless infinite scroll
//   const duplicatedVideos = [...videoReviews, ...videoReviews, ...videoReviews];

//   const handleVideoClick = (video) => {
//     setSelectedVideo(video);
//     setIsAutoPlaying(false);
//   };

//   const closeVideo = () => {
//     setSelectedVideo(null);
//     setIsAutoPlaying(true);
//   };

//   const startAutoScroll = () => {
//     if (intervalRef.current) {
//       clearInterval(intervalRef.current);
//     }

//     intervalRef.current = setInterval(() => {
//       if (scrollContainerRef.current && isAutoPlaying) {
//         const container = scrollContainerRef.current;
//         const scrollAmount = 1;

//         container.scrollLeft += scrollAmount;

//         const maxScrollLeft = container.scrollWidth / 3;

//         if (container.scrollLeft >= maxScrollLeft) {
//           container.scrollLeft = 0;
//         }
//       }
//     }, 16);
//   };

//   const stopAutoScroll = () => {
//     if (intervalRef.current) {
//       clearInterval(intervalRef.current);
//       intervalRef.current = null;
//     }
//   };

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       if (isAutoPlaying) {
//         startAutoScroll();
//       } else {
//         stopAutoScroll();
//       }
//     }, 1000);

//     return () => {
//       clearTimeout(timer);
//       stopAutoScroll();
//     };
//   }, [isAutoPlaying]);

//   useEffect(() => {
//     const timer = setTimeout(() => {
//       startAutoScroll();
//     }, 2000);

//     return () => {
//       clearTimeout(timer);
//       stopAutoScroll();
//     };
//   }, []);

//   const handleMouseEnter = () => {
//     setIsAutoPlaying(false);
//   };

//   const handleMouseLeave = () => {
//     setIsAutoPlaying(true);
//   };

//   return (
//     <div className="py-12 px-4 max-w-7xl mx-auto">
//       <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 lg:p-8">
//         <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">
//           We Deliver What We Promise.
//         </h2>

//         <div
//           ref={scrollContainerRef}
//           className="overflow-x-auto scrollbar-hide"
//           onMouseEnter={handleMouseEnter}
//           onMouseLeave={handleMouseLeave}
//         >
//           <div className="flex gap-3 sm:gap-4 pb-2">
//             {duplicatedVideos.map((video, index) => (
//               <div
//                 key={index}
//                 className="relative flex-shrink-0 w-48 sm:w-56 lg:w-64"
//               >
//                 <div
//                   onClick={() => handleVideoClick(video)}
//                   className={`${video.color} rounded-xl aspect-[16/9] relative overflow-hidden shadow-md cursor-pointer group transition-transform duration-300 hover:scale-105`}
//                 >
//                   <img
//                     src={video.thumbnail}
//                     alt={video.name}
//                     className="absolute inset-0 w-full h-full object-cover"
//                   />

//                   <div className="absolute inset-0 flex items-center justify-center">
//                     <div className="w-12 h-12 bg-white bg-opacity-95 rounded-full flex items-center justify-center group-hover:scale-110 transition shadow-xl">
//                       <Play className="w-6 h-6 text-gray-800 fill-gray-800 ml-0.5" />
//                     </div>
//                   </div>

//                   <div className="absolute bottom-0 left-0 right-0 h-10 bg-white transform -skew-y-12 origin-bottom-left opacity-90"></div>
//                 </div>

//                 <div className="mt-2 text-center">
//                   <p className="text-xs sm:text-sm font-medium text-gray-800">
//                     {video.name}
//                   </p>
//                 </div>
//               </div>
//             ))}
//           </div>
//         </div>
//       </div>

//       {selectedVideo && (
//         <div className="fixed inset-0 bg-[#000000ad] bg-opacity-75 flex items-center justify-center z-50 p-4">
//           <div className="relative w-full max-w-4xl bg-white rounded-lg overflow-hidden">
//             <button
//               onClick={closeVideo}
//               className="absolute top-4 right-4 z-10 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition shadow-lg"
//             >
//               <X className="w-6 h-6 text-gray-800" />
//             </button>

//             <div className="relative pt-[56.25%]">
//               <iframe
//                 className="absolute inset-0 w-full h-full"
//                 src={`https://www.youtube.com/embed/${selectedVideo.videoId}?autoplay=1`}
//                 title={selectedVideo.name}
//                 allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
//                 allowFullScreen
//               ></iframe>
//             </div>
//           </div>
//         </div>
//       )}

//       <style jsx>{`
//         .scrollbar-hide {
//           -webkit-overflow-scrolling: touch;
//         }
//         .scrollbar-hide::-webkit-scrollbar {
//           display: none;
//         }
//       `}</style>
//     </div>
//   );
// }

import React, { useState, useEffect, useRef } from "react";
import { Play, X, ChevronLeft, ChevronRight } from "lucide-react";

export default function TestimonialSection() {
  const [selectedVideo, setSelectedVideo] = useState(null);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const scrollContainerRef = useRef(null);
  const intervalRef = useRef(null);

  const videoReviews = [
    {
      name: "Nishant and Amrita",
      color: "bg-red-500",
      thumbnail: "https://img.youtube.com/vi/dQw4w9WgXcQ/mqdefault.jpg",
      videoId: "dQw4w9WgXcQ",
    },
    {
      name: "Partiti De",
      color: "bg-blue-400",
      thumbnail: "https://img.youtube.com/vi/9bZkp7q19f0/mqdefault.jpg",
      videoId: "9bZkp7q19f0",
    },
    {
      name: "Dandin Vishwanath",
      color: "bg-blue-500",
      thumbnail: "https://img.youtube.com/vi/kJQP7kiw5Fk/mqdefault.jpg",
      videoId: "kJQP7kiw5Fk",
    },
    {
      name: "Guru Raj Tiwari",
      color: "bg-orange-500",
      thumbnail: "https://img.youtube.com/vi/ZZ5LpwO-An4/mqdefault.jpg",
      videoId: "ZZ5LpwO-An4",
    },
    {
      name: "Mr. Jaimin Desai",
      color: "bg-blue-400",
      thumbnail: "https://img.youtube.com/vi/L_jWHffIx5E/mqdefault.jpg",
      videoId: "L_jWHffIx5E",
    },
    {
      name: "Pawan",
      color: "bg-blue-500",
      thumbnail: "https://img.youtube.com/vi/2Vv-BfVoq4g/mqdefault.jpg",
      videoId: "2Vv-BfVoq4g",
    },
  ];

  // Triple the videos for seamless infinite scroll
  const duplicatedVideos = [...videoReviews, ...videoReviews, ...videoReviews];

  const handleVideoClick = (video) => {
    setSelectedVideo(video);
    setIsAutoPlaying(false);
  };

  const closeVideo = () => {
    setSelectedVideo(null);
    setIsAutoPlaying(true);
  };

  const startAutoScroll = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }

    intervalRef.current = setInterval(() => {
      if (scrollContainerRef.current && isAutoPlaying) {
        const container = scrollContainerRef.current;
        const scrollAmount = 1;

        container.scrollLeft += scrollAmount;

        const maxScrollLeft = container.scrollWidth / 3;

        if (container.scrollLeft >= maxScrollLeft) {
          container.scrollLeft = 0;
        }
      }
    }, 30);
  };

  const stopAutoScroll = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      if (isAutoPlaying) {
        startAutoScroll();
      } else {
        stopAutoScroll();
      }
    }, 1000);

    return () => {
      clearTimeout(timer);
      stopAutoScroll();
    };
  }, [isAutoPlaying]);

  useEffect(() => {
    const timer = setTimeout(() => {
      startAutoScroll();
    }, 2000);

    return () => {
      clearTimeout(timer);
      stopAutoScroll();
    };
  }, []);

  const handleMouseEnter = () => {
    setIsAutoPlaying(false);
  };

  const handleMouseLeave = () => {
    setIsAutoPlaying(true);
  };

  const scrollLeft = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: -300, behavior: "smooth" });
    }
  };

  const scrollRight = () => {
    if (scrollContainerRef.current) {
      scrollContainerRef.current.scrollBy({ left: 300, behavior: "smooth" });
    }
  };

  return (
    <div className="py-12 px-4 max-w-7xl mx-auto">
      <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 lg:p-8">
        <h2 className="text-xl sm:text-2xl font-bold mb-4 sm:mb-6">
          We Deliver What We Promise.
        </h2>

        <div className="relative">
          <button
            onClick={scrollLeft}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition shadow-lg"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-6 h-6 text-gray-800" />
          </button>

          <button
            onClick={scrollRight}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition shadow-lg"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-6 h-6 text-gray-800" />
          </button>

          <div
            ref={scrollContainerRef}
            className="overflow-x-auto scrollbar-hide"
            onMouseEnter={handleMouseEnter}
            onMouseLeave={handleMouseLeave}
          >
            <div className="flex gap-3 sm:gap-4 pb-2">
              {duplicatedVideos.map((video, index) => (
                <div
                  key={index}
                  className="relative flex-shrink-0 w-48 sm:w-56 lg:w-64"
                >
                  <div
                    onClick={() => handleVideoClick(video)}
                    className={`${video.color} rounded-xl aspect-[16/9] relative overflow-hidden shadow-md cursor-pointer group transition-transform duration-300 hover:scale-105`}
                  >
                    <img
                      src={video.thumbnail}
                      alt={video.name}
                      className="absolute inset-0 w-full h-full object-cover"
                    />

                    <div className="absolute inset-0 flex items-center justify-center">
                      <div className="w-12 h-12 bg-white bg-opacity-95 rounded-full flex items-center justify-center group-hover:scale-110 transition shadow-xl">
                        <Play className="w-6 h-6 text-gray-800 fill-gray-800 ml-0.5" />
                      </div>
                    </div>

                    <div className="absolute bottom-0 left-0 right-0 h-10 bg-white transform -skew-y-12 origin-bottom-left opacity-90"></div>
                  </div>

                  <div className="mt-2 text-center">
                    <p className="text-xs sm:text-sm font-medium text-gray-800">
                      {video.name}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {selectedVideo && (
        <div className="fixed inset-0 bg-[#000000ad] bg-opacity-75 flex items-center justify-center z-50 p-4">
          <div className="relative w-full max-w-4xl bg-white rounded-lg overflow-hidden">
            <button
              onClick={closeVideo}
              className="absolute top-4 right-4 z-10 w-10 h-10 bg-white rounded-full flex items-center justify-center hover:bg-gray-100 transition shadow-lg"
            >
              <X className="w-6 h-6 text-gray-800" />
            </button>

            <div className="relative pt-[56.25%]">
              <iframe
                className="absolute inset-0 w-full h-full"
                src={`https://www.youtube.com/embed/${selectedVideo.videoId}?autoplay=1`}
                title={selectedVideo.name}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
              ></iframe>
            </div>
          </div>
        </div>
      )}

      <style jsx>{`
        .scrollbar-hide {
          -webkit-overflow-scrolling: touch;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
