import React, { useState, useRef, useEffect } from "react";
import { Phone, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { Link } from "react-router-dom";
import { useLocation } from "./LocationContext";

// Replace with your actual API endpoint
const API_ENDPOINT = "http://127.0.0.1:8000/main/properties/?category=PG";

const DUMMY_PROJECTS = [
  {
    id: 1,
    name: "Marina Heights",
    bedrooms: "2-3",
    expected_price: "1.5",
    city: "Bhopal",
    image1:
      "https://images.unsplash.com/photo-1508385082359-f38ae991e8f2?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OHx8YnVpbGRpbmdzfGVufDB8MXwwfHx8MA%3D%3D",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
  {
    id: 2,
    name: "Palm Residences",
    bedrooms: "3-4",
    expected_price: "2.8",
    city: "Bhopal",
    image1:
      "https://images.unsplash.com/photo-1446133132410-19df4d6610a1?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Nnx8YnVpbGRpbmdzfGVufDB8MXwwfHx8MA%3D%3D",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
  {
    id: 3,
    name: "Downtown Tower",
    bedrooms: "1-2",
    expected_price: "1.2",
    city: "Indore",
    image1:
      "https://plus.unsplash.com/premium_photo-1680836316227-ef17dbbcfb27?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8OXx8YnVpbGRpbmdzfGVufDB8MXwwfHx8MA%3D%3D",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
  {
    id: 4,
    name: "Corniche Plaza",
    bedrooms: "2-4",
    expected_price: "2.0",
    city: "Indore",
    image1:
      "https://images.unsplash.com/photo-1505819244306-ef53954f9648?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MjB8fGJ1aWxkaW5nc3xlbnwwfDF8MHx8fDA%3D",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
  {
    id: 5,
    name: "Bay View Apartments",
    bedrooms: "2-3",
    expected_price: "1.8",
    city: "Mumbai",
    image1:
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=60",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
  {
    id: 6,
    name: "Heritage Villas",
    bedrooms: "4-5",
    expected_price: "3.5",
    city: "Mumbai",
    image1:
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
    video: "https://www.w3schools.com/html/mov_bbb.mp4",
    logo: "https://new-projects-media.propertyfinder.com/developer/8a509d77-0b04-4669-9a78-d9fd5cdc78da/logo/image/L_UdmunePjPgB1sOpqj1TlbZ1NTOchKK8RtZ4QaqWa8=/original.png",
  },
];

export default function PropertiesForSale() {
  const { selectedCity } = useLocation();
  console.log(selectedCity);
  const [projects, setProjects] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [hoveredProject, setHoveredProject] = useState(null);
  const scrollContainerRef = useRef(null);

  const isValidData = (value) => {
    if (value === null || value === undefined) return false;
    if (typeof value === "string") {
      const trimmed = value.trim().toLowerCase();
      return (
        trimmed !== "" &&
        trimmed !== "n/a" &&
        trimmed !== "null" &&
        trimmed !== "undefined" &&
        trimmed !== "0"
      );
    }
    if (typeof value === "number") {
      return value !== 0;
    }
    return true;
  };

  // Fetch projects from API
  useEffect(() => {
    const fetchProjects = async () => {
      try {
        setLoading(true);
        setError(null);

        const response = await fetch(API_ENDPOINT);

        if (!response.ok) {
          throw new Error(`Failed to fetch projects: ${response.status}`);
        }

        const data = await response.json();
        console.log("API RAW ⇒ ", data);

        // 🔥 FORMAT DATA ACCORDING TO UI NEED
        const formatted = data.map((item) => ({
          id: item.id,
          name: item.title?.replace(/[()']/g, "") || "", // fix tuple title
          city: item.city,
          bedrooms: item.bedrooms,
          expected_price: item.price,
          currency: item.currency,   
          image1: item.images?.length
            ? "http://127.0.0.1:8000" + item.images[0]
            : null,
          video: item.video ? "http://127.0.0.1:8000" + item.video : null,
          logo: item.company_logo
            ? "http://127.0.0.1:8000" + item.company_logo
            : null,
        }));

        setProjects(formatted);
      } catch (err) {
        console.error("Error fetching projects:", err);
        setError(err.message);
        // setProjects(DUMMY_PROJECTS);
      } finally {
        setLoading(false);
      }
    };

    fetchProjects();
  }, []);

  // Filter projects by selected city
  const filteredProjects = selectedCity
    ? projects.filter(
        (project) => project.city.toLowerCase() === selectedCity.toLowerCase()
      )
    : projects;

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const containerWidth = scrollContainerRef.current.offsetWidth;
      const scrollAmount = containerWidth / 3;

      const newScrollLeft =
        scrollContainerRef.current.scrollLeft +
        (direction === "left" ? -scrollAmount : scrollAmount);
      scrollContainerRef.current.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });
    }
  };

  return (
    <div className=" p-4 sm:p-6 md:p-8">
      <div className="max-w-7xl mx-auto">
        <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-gray-900 mb-3 sm:mb-4">
          Properties for PG {selectedCity && `in ${selectedCity}`}
        </h1>

        {/* Loading State */}
        {loading && (
          <div className="flex justify-center items-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-gray-600" />
            <span className="ml-3 text-gray-600">Loading properties...</span>
          </div>
        )}

        {/* Scrollable Cards Container */}
        {!loading && filteredProjects.length > 0 && (
          <div className="relative mb-8 sm:mb-12">
            {/* Left Arrow */}
            <button
              onClick={() => scroll("left")}
              className="hidden lg:flex absolute left-0 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-gray-100 rounded-full p-3 shadow-lg transition-all duration-200 -ml-5"
              aria-label="Scroll left"
            >
              <ChevronLeft className="w-6 h-6 text-gray-800" />
            </button>

            {/* Right Arrow */}
            <button
              onClick={() => scroll("right")}
              className="hidden lg:flex absolute right-0 top-1/2 -translate-y-1/2 z-20 bg-white hover:bg-gray-100 rounded-full p-3 shadow-lg transition-all duration-200 -mr-5"
              aria-label="Scroll right"
            >
              <ChevronRight className="w-6 h-6 text-gray-800" />
            </button>

            {/* Scrollable Container */}
            <div
              ref={scrollContainerRef}
              className="grid auto-cols-[100%] sm:auto-cols-[calc(50%-0.625rem)] lg:auto-cols-[calc(33.333%-1.25rem)] grid-flow-col gap-4 sm:gap-5 md:gap-7 overflow-x-auto scrollbar-hide scroll-smooth pb-2"
              style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
            >
              {filteredProjects.map((project, index) => (
                <Link
                  key={project.id}
                  to={`/details/pg/${project.id}`}
                  className="rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative animate-fadeIn cursor-pointer"
                  style={{
                    height: "min(70vh, 480px)",
                    animationDelay: `${index * 100}ms`,
                  }}
                  onMouseEnter={() => setHoveredProject(project.id)}
                  onMouseLeave={() => setHoveredProject(null)}
                >
                  {/* Background Image - Only show if valid */}
                  {isValidData(project.image1) && (
                    <div
                      className={`absolute inset-0 transition-opacity duration-500 ease-in-out ${
                        hoveredProject === project.id
                          ? "opacity-0"
                          : "opacity-100"
                      }`}
                      style={{
                        backgroundImage: `linear-gradient(to top, rgba(0,0,0,0.6) 20%, rgba(0,0,0,0) 100%), url(${project.image1})`,
                        backgroundSize: "cover",
                        backgroundPosition: "center",
                      }}
                    />
                  )}

                  {/* Video on Hover - Only show if valid */}
                  {isValidData(project.video) && (
                    <video
                      className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-500 ease-in-out ${
                        hoveredProject === project.id
                          ? "opacity-100"
                          : "opacity-0"
                      }`}
                      autoPlay
                      muted
                      loop
                      playsInline
                      preload="metadata"
                    >
                      <source src={project.video} type="video/mp4" />
                    </video>
                  )}

                  {/* Gradient Overlay on Hover */}
                  <div
                    className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent transition-opacity duration-500 ease-in-out ${
                      hoveredProject === project.id
                        ? "opacity-100"
                        : "opacity-0"
                    }`}
                  />

                  {/* Company Logo - Only show if valid */}
                  {isValidData(project.logo) && (
                    <div className="absolute top-3 sm:top-4 right-3 sm:right-4 z-10">
                      <img
                        src={project.logo}
                        alt={`${project.name} logo`}
                        className="w-14 h-14 sm:w-20 sm:h-20 object-contain bg-white rounded-lg p-1"
                        onError={(e) => {
                          e.target.style.display = "none";
                        }}
                      />
                    </div>
                  )}

                  {/* Project Details */}
                  <div className="absolute bottom-0 left-0 right-0 p-4 sm:p-6 text-white z-10">
                    {/* Project Name - Only show if valid */}
                    {isValidData(project.name) && (
                      <h3 className="text-2xl sm:text-3xl font-bold mb-1 sm:mb-2">
                        {project.name}
                      </h3>
                    )}

                    {/* Bedrooms - Only show if valid */}
                    {isValidData(project.bedrooms) && (
                      <p className="text-sm sm:text-base mb-0.5 sm:mb-1">
                        {project.bedrooms} Bedrooms
                      </p>
                    )}

                    {/* Price - Only show if valid */}
                    {isValidData(project.expected_price) && (
                      <p className="text-sm sm:text-base mb-4 sm:mb-6">
                        Launch price {project.expected_price}M {project.currency}   
                      </p>
                    )}

                    {/* WhatsApp Button - Always show */}
                    <button className="w-full bg-white text-gray-900 font-medium py-2.5 sm:py-3 px-4 rounded-full text-sm sm:text-base transition-all duration-300 flex items-center justify-center hover:bg-gray-100">
                      <Phone className="w-4 h-4 sm:w-5 sm:h-5 mr-2" />
                      WhatsApp
                    </button>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {!loading && filteredProjects.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">
              No projects available {selectedCity && `in ${selectedCity}`}
            </p>
          </div>
        )}

        {!loading && filteredProjects.length > 0 && (
          <div className="text-center">  
           <a
             href="http://localhost:5173/finder/pg"  // ← yaha apna target URL daalein
             className="text-base sm:text-lg text-gray-800 underline hover:text-gray-600 transition-colors duration-300"
           >
             View more Projects
           </a>
         </div>

        )}
      </div>

      <style jsx>{`
        @keyframes fadeIn {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }

        .animate-fadeIn {
          animation: fadeIn 0.6s ease-out forwards;
        }

        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
}
