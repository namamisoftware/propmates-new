import React, { useState } from "react";
import { MapContainer, TileLayer, Polygon, Tooltip } from "react-leaflet";
import "leaflet/dist/leaflet.css";

const PropertyFinder = () => {
  const [activeTab, setActiveTab] = useState("Rent");
  const [language, setLanguage] = useState("en");
  const [isFullScreen, setIsFullScreen] = useState(false);

  // Dubai coordinates
  const center = [25.2048, 55.2708];

  // Translations object
  const translations = {
    en: {
      title: "UAE property prices by area",
      rent: "Rent",
      buy: "Buy",
      dubaiPrices: "Dubai prices",
      highest: "Highest:",
      average: "Average:",
      lowest: "Lowest:",
      disclaimer:
        "* The data displayed is based on listing price in last 3 months.",
      seeFullMap: "See full map",
      fullMap: "Full map",
      exitFullScreen: "Exit full screen",
      noData: "No data",
      areas: {
        "Mohammed Bin Rashid City": "Mohammed Bin Rashid City",
        "Al Warsan": "Al Warsan",
        "Nad Al Sheba": "Nad Al Sheba",
        "International City": "International City",
        "Dubai Silicon Oasis": "Dubai Silicon Oasis",
        "Al Barari": "Al Barari",
        "Wadi Al Safa 2": "Wadi Al Safa 2",
        "Dubai Hills Estate": "Dubai Hills Estate",
        "Living Legends": "Living Legends",
        "Dubai Land": "Dubai Land",
        "Dubai Media City": "Dubai Media City",
        "Al Barsha": "Al Barsha",
        "Dubai Science Park": "Dubai Science Park",
        Arjan: "Arjan",
        "Motor City": "Motor City",
        "Very Gardens": "Very Gardens",
      },
    },
    ar: {
      title: "أسعار العقارات الإماراتية حسب المنطقة",
      rent: "إيجار",
      buy: "شراء",
      dubaiPrices: "أسعار دبي",
      highest: "الأعلى:",
      average: "المتوسط:",
      lowest: "الأقل:",
      disclaimer:
        "* البيانات المعروضة تستند إلى أسعار الإعلانات في آخر 3 أشهر.",
      seeFullMap: "عرض الخريطة كاملة",
      fullMap: "خريطة كاملة",
      exitFullScreen: "إغلاق الشاشة الكاملة",
      noData: "لا توجد بيانات",
      areas: {
        "Mohammed Bin Rashid City": "مدينة محمد بن راشد",
        "Al Warsan": "الورسان",
        "Nad Al Sheba": "ند الشبا",
        "International City": "المدينة العالمية",
        "Dubai Silicon Oasis": "واحة دبي للسيليكون",
        "Al Barari": "البراري",
        "Wadi Al Safa 2": "وادي الصفا 2",
        "Dubai Hills Estate": "دبي هيلز استيت",
        "Living Legends": "ليفينغ ليجيندز",
        "Dubai Land": "دبي لاند",
        "Dubai Media City": "مدينة دبي للإعلام",
        "Al Barsha": "البرشاء",
        "Dubai Science Park": "مدينة دبي للعلوم",
        Arjan: "أرجان",
        "Motor City": "موتور سيتي",
        "Very Gardens": "فيري جاردنز",
      },
    },
  };

  const t = translations[language];
  const isRTL = language === "ar";

  // Define area polygons with different shades of blue based on price ranges
  const areas = [
    {
      name: "Mohammed Bin Rashid City",
      coordinates: [
        [25.15, 55.41],
        [25.18, 55.41],
        [25.18, 55.44],
        [25.15, 55.44],
      ],
      color: "#3B82F6",
      price: "125,000 AED/year",
    },
    {
      name: "Al Warsan",
      coordinates: [
        [25.16, 55.45],
        [25.19, 55.45],
        [25.19, 55.48],
        [25.16, 55.48],
      ],
      color: "#60A5FA",
      price: "85,000 AED/year",
    },
    {
      name: "Nad Al Sheba",
      coordinates: [
        [25.13, 55.35],
        [25.16, 55.35],
        [25.16, 55.38],
        [25.13, 55.38],
      ],
      color: "#93C5FD",
      price: "75,000 AED/year",
    },
    {
      name: "International City",
      coordinates: [
        [25.17, 55.42],
        [25.2, 55.42],
        [25.2, 55.45],
        [25.17, 55.45],
      ],
      color: "#BFDBFE",
      price: "55,000 AED/year",
    },
    {
      name: "Dubai Silicon Oasis",
      coordinates: [
        [25.11, 55.38],
        [25.14, 55.38],
        [25.14, 55.41],
        [25.11, 55.41],
      ],
      color: "#3B82F6",
      price: "95,000 AED/year",
    },
    {
      name: "Al Barari",
      coordinates: [
        [25.07, 55.23],
        [25.1, 55.23],
        [25.1, 55.26],
        [25.07, 55.26],
      ],
      color: "#1D4ED8",
      price: "180,000 AED/year",
    },
    {
      name: "Wadi Al Safa 2",
      coordinates: [
        [25.05, 55.36],
        [25.08, 55.36],
        [25.08, 55.39],
        [25.05, 55.39],
      ],
      color: "#60A5FA",
      price: "70,000 AED/year",
    },
    {
      name: "Dubai Hills Estate",
      coordinates: [
        [25.09, 55.24],
        [25.12, 55.24],
        [25.12, 55.27],
        [25.09, 55.27],
      ],
      color: "#1E40AF",
      price: "150,000 AED/year",
    },
    {
      name: "Living Legends",
      coordinates: [
        [25.04, 55.27],
        [25.07, 55.27],
        [25.07, 55.3],
        [25.04, 55.3],
      ],
      color: "#3B82F6",
      price: "110,000 AED/year",
    },
    {
      name: "Dubai Land",
      coordinates: [
        [25.06, 55.32],
        [25.09, 55.32],
        [25.09, 55.35],
        [25.06, 55.35],
      ],
      color: "#60A5FA",
      price: "85,000 AED/year",
    },
    {
      name: "Dubai Media City",
      coordinates: [
        [25.09, 55.15],
        [25.12, 55.15],
        [25.12, 55.18],
        [25.09, 55.18],
      ],
      color: "#1D4ED8",
      price: "160,000 AED/year",
    },
    {
      name: "Al Barsha",
      coordinates: [
        [25.11, 55.21],
        [25.14, 55.21],
        [25.14, 55.24],
        [25.11, 55.24],
      ],
      color: "#3B82F6",
      price: "120,000 AED/year",
    },
    {
      name: "Dubai Science Park",
      coordinates: [
        [25.08, 55.17],
        [25.11, 55.17],
        [25.11, 55.2],
        [25.08, 55.2],
      ],
      color: "#60A5FA",
      price: "90,000 AED/year",
    },
    {
      name: "Arjan",
      coordinates: [
        [25.06, 55.24],
        [25.09, 55.24],
        [25.09, 55.27],
        [25.06, 55.27],
      ],
      color: "#93C5FD",
      price: "75,000 AED/year",
    },
    {
      name: "Motor City",
      coordinates: [
        [25.04, 55.22],
        [25.07, 55.22],
        [25.07, 55.25],
        [25.04, 55.25],
      ],
      color: "#BFDBFE",
      price: "65,000 AED/year",
    },
    {
      name: "Very Gardens",
      coordinates: [
        [25.02, 55.16],
        [25.05, 55.16],
        [25.05, 55.19],
        [25.02, 55.19],
      ],
      color: "#93C5FD",
      price: "70,000 AED/year",
    },
  ];

  const toggleFullScreen = () => {
    setIsFullScreen(!isFullScreen);
  };

  return (
    <div
      className={`${
        isFullScreen
          ? "fixed inset-0 z-50 bg-[#f7f7fc]"
          : "px-4 sm:px-8 lg:px-12 mb-8 lg:mb-18 mt-4 lg:mt-8"
      } ${isRTL ? "rtl" : "ltr"}`}
      dir={isRTL ? "rtl" : "ltr"}
    >
      <div
        className={`${
          isFullScreen
            ? "h-screen w-full relative bg-[#f7f7fc] flex flex-col"
            : "h-screen relative w-full rounded-3xl shadow-lg bg-[#f7f7fc] flex flex-col pt-4"
        }`}
      >
        {/* Language Dropdown - Top Right */}
        <div className="absolute top-4 right-4 z-[1002]">
          <select
            value={language}
            onChange={(e) => setLanguage(e.target.value)}
            className="bg-white border border-gray-300 rounded-lg px-3 py-2 text-sm font-medium text-gray-700 shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
          >
            <option value="en">English</option>
            <option value="ar">العربية</option>
          </select>
        </div>

        {/* Floating Left Panel - Title and Tabs - Always stays on left */}
        <div
          className={`w-fit absolute ${
            isFullScreen ? "left-4 top-2" : "left-[2%] top-4"
          } z-[1001]`}
        >
          <div
            className={`${
              isFullScreen
                ? "bg-white shadow-lg rounded-lg p-3 border border-gray-200"
                : ""
            }`}
          >
            <h1
              className={`text-lg sm:text-xl font-semibold text-gray-900 mb-2 ${
                isRTL ? "text-right" : "text-left"
              }`}
            >
              {t.title}
            </h1>

            {/* Tab Buttons */}
            <div className="flex border border-gray-300 w-40 sm:w-50 rounded-lg p-1">
              <button
                onClick={() => setActiveTab("Rent")}
                className={`flex-1 py-1 px-2 sm:px-3 text-xs sm:text-sm font-medium rounded-md transition-all ${
                  activeTab === "Rent"
                    ? "bg-white text-[#0b154f] shadow-sm"
                    : "text-gray-600 hover:text-gray-800"
                }`}
              >
                {t.rent}
              </button>
              <button
                onClick={() => setActiveTab("Buy")}
                className={`flex-1 py-1 px-2 sm:px-3 text-xs sm:text-sm font-medium rounded-md transition-all ${
                  activeTab === "Buy"
                    ? "bg-white text-[#0b154f] shadow-sm"
                    : "text-gray-600 hover:text-gray-800"
                }`}
              >
                {t.buy}
              </button>
            </div>
          </div>
        </div>

        <div
          className={`${
            isFullScreen
              ? "h-full w-full mt-0 mb-0 mx-0 relative border-none overflow-hidden"
              : "h-[75%] sm:h-[75%] lg:h-[80%] w-full max-w-[95vw] sm:max-w-[92vw] lg:max-w-[90vw] mx-auto mt-20 sm:mt-24 lg:mt-26 mb-4 sm:mb-16 lg:mb-20 mx-2 sm:mx-auto relative border border-gray-300 rounded-lg overflow-hidden"
          }`}
        >
          {/* Map Container */}
          <MapContainer
            center={center}
            zoom={isFullScreen ? 12 : 11}
            className="h-full w-full"
            zoomControl={false}
            key={isFullScreen ? "fullscreen" : "normal"} // Force re-render when toggling
          >
            <TileLayer
              url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            />

            {areas.map((area, index) => (
              <Polygon
                key={index}
                positions={area.coordinates}
                pathOptions={{
                  fillColor: area.color,
                  fillOpacity: 0.7,
                  color: area.color,
                  weight: 2,
                  opacity: 0.8,
                }}
              >
                <Tooltip
                  permanent
                  direction="center"
                  className="custom-tooltip"
                  opacity={1}
                >
                  <div
                    className={`text-center ${isRTL ? "rtl" : "ltr"}`}
                    dir={isRTL ? "rtl" : "ltr"}
                  >
                    <div className="text-xs font-semibold text-gray-800">
                      {t.areas[area.name] || area.name}
                    </div>
                  </div>
                </Tooltip>
              </Polygon>
            ))}
          </MapContainer>

          {/* Floating Right Panel - Dubai Prices - Always stays on right */}
          <div
            className={`absolute  ${
              isFullScreen ? "left-4 top-30" : "left-[2%] top-4"
            } z-[1000]`}
          >
            <div className="bg-white shadow-lg rounded-lg p-2 sm:p-3 border border-gray-200 w-48 sm:w-56 lg:w-64">
              <h2
                className={`text-sm sm:text-base font-semibold text-gray-900 mb-2 sm:mb-3 ${
                  isRTL ? "text-right" : "text-left"
                }`}
              >
                {t.dubaiPrices}
              </h2>

              <div className="space-y-1 sm:space-y-2">
                <div
                  className={`flex items-center justify-between ${
                    isRTL ? "flex-row-reverse" : ""
                  }`}
                >
                  <div
                    className={`flex items-center space-x-1 sm:space-x-2 ${
                      isRTL ? "flex-row-reverse space-x-reverse" : ""
                    }`}
                  >
                    <div
                      className="w-2 h-2 sm:w-3 sm:h-3 rounded"
                      style={{ backgroundColor: "#1E40AF" }}
                    ></div>
                    <span className="text-gray-600 text-xs">{t.highest}</span>
                  </div>
                  <span className="text-gray-900 font-semibold text-xs">
                    4,000,000 AED/year
                  </span>
                </div>

                <div
                  className={`flex items-center justify-between ${
                    isRTL ? "flex-row-reverse" : ""
                  }`}
                >
                  <div
                    className={`flex items-center space-x-1 sm:space-x-2 ${
                      isRTL ? "flex-row-reverse space-x-reverse" : ""
                    }`}
                  >
                    <div
                      className="w-2 h-2 sm:w-3 sm:h-3 rounded"
                      style={{ backgroundColor: "#3B82F6" }}
                    ></div>
                    <span className="text-gray-600 text-xs">{t.average}</span>
                  </div>
                  <span className="text-gray-900 font-semibold text-xs">
                    89,888 AED/year
                  </span>
                </div>

                <div
                  className={`flex items-center justify-between ${
                    isRTL ? "flex-row-reverse" : ""
                  }`}
                >
                  <div
                    className={`flex items-center space-x-1 sm:space-x-2 ${
                      isRTL ? "flex-row-reverse space-x-reverse" : ""
                    }`}
                  >
                    <div
                      className="w-2 h-2 sm:w-3 sm:h-3 rounded"
                      style={{ backgroundColor: "#BFDBFE" }}
                    ></div>
                    <span className="text-gray-600 text-xs">{t.lowest}</span>
                  </div>
                  <span className="text-gray-900 font-semibold text-xs">
                    35,000 AED/year
                  </span>
                </div>
              </div>

              <p
                className={`text-xs text-gray-500 mt-2 sm:mt-3 leading-relaxed ${
                  isRTL ? "text-right" : "text-left"
                }`}
              >
                {t.disclaimer}
              </p>
            </div>
          </div>

          {/* Center Top - See Full Map / Exit Full Screen Button */}
          <div className="absolute top-2 left-1/2 transform -translate-x-1/2 z-[1000]">
            <button
              onClick={toggleFullScreen}
              className={`bg-white shadow-lg rounded-lg px-2 sm:px-3 py-1 text-blue-600 text-xs font-medium hover:bg-blue-50 transition-colors flex items-center space-x-1 border border-gray-200 ${
                isRTL ? "flex-row-reverse space-x-reverse" : ""
              }`}
            >
              <svg
                className="w-3 h-3"
                fill="none"
                stroke="currentColor"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d={
                    isFullScreen
                      ? "M9 9l6 6m0 0l-6 6m6-6l6-6M9 21V9l12-12"
                      : "M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"
                  }
                />
              </svg>
              <span className="hidden sm:inline">
                {isFullScreen ? t.exitFullScreen : t.seeFullMap}
              </span>
              <span className="sm:hidden">
                {isFullScreen ? "Exit" : t.fullMap}
              </span>
            </button>
          </div>

          {/* Zoom Controls - Always on right */}
          <div className="absolute bottom-2 right-2 z-[1000]">
            <div className="bg-white shadow-lg rounded-lg border border-gray-200 overflow-hidden">
              <button className="block w-6 h-6 sm:w-8 sm:h-8 flex items-center justify-center text-gray-600 hover:bg-gray-50 transition-colors border-b border-gray-200">
                <span className="text-xs sm:text-sm font-normal">+</span>
              </button>
              <button className="block w-6 h-6 sm:w-8 sm:h-8 flex items-center justify-center text-gray-600 hover:bg-gray-50 transition-colors">
                <span className="text-xs sm:text-sm font-normal">−</span>
              </button>
            </div>
          </div>

          {/* Legend - Always on left */}
          <div className="absolute bottom-2 left-2 z-[1000]">
            <div className="bg-white shadow-lg rounded-lg p-1 sm:p-2 border border-gray-200">
              <div className="text-xs text-gray-400 mb-1">{t.noData}</div>
              <div className="text-xs text-gray-500 font-medium">DXMAN</div>
            </div>
          </div>

          <style jsx global>{`
            .custom-tooltip {
              background: transparent !important;
              border: none !important;
              box-shadow: none !important;
              padding: 0 !important;
            }
            .custom-tooltip::before {
              display: none !important;
            }
            .leaflet-tooltip-top:before,
            .leaflet-tooltip-bottom:before,
            .leaflet-tooltip-left:before,
            .leaflet-tooltip-right:before {
              display: none !important;
            }

            .rtl {
              direction: rtl;
            }

            .ltr {
              direction: ltr;
            }

            /* Hide scrollbars in full screen */
            body:has(.fullscreen-map) {
              overflow: hidden;
            }

            /* Mobile specific adjustments */
            @media (max-width: 640px) {
              .leaflet-tooltip {
                font-size: 10px !important;
              }
            }
          `}</style>
        </div>
      </div>
    </div>
  );
};

export default PropertyFinder;
