// import React from "react";
// import facebook from "../assets/footer/facebook.png";
// import instagram from "../assets/footer/instagram.png";
// import linkdin from "../assets/footer/linkdin.png";
// import twitter from "../assets/footer/twitter.png";
// import playstore from "../assets/footer/playstore.png";
// import appstore from "../assets/footer/appstore.png";

// const PropertyFinderFooter = () => {
//   return (
//     <div className="bg-[#0b154f]">
//       <div className="max-w-7xl mx-auto text-white py-16 px-8">
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
//           {/* Our Name Section */}
//           <div>
//             <h3 className="text-xl font-semibold mb-6">Our Name</h3>
//             <ul className="space-y-3">
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Mobile Apps
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Our Services
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Price Trends
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Post your Property
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Real Estate Investment
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Builders in UAE
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Area Converter
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Articles
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Rent Receipt
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Customer Service
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Sitemap
//                 </a>
//               </li>
//             </ul>
//           </div>

//           {/* Company Section */}
//           <div>
//             <h3 className="text-xl font-semibold mb-6">Company</h3>
//             <ul className="space-y-3">
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Buy
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Rent
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Commercial
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   New Project
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Find Agent
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Explore
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Report & problem
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Testimonial
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Privacy Policy
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Summons/Notices
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Grievances
//                 </a>
//               </li>
//               <li>
//                 <a
//                   href="#"
//                   className="text-gray-300 hover:text-white transition-colors"
//                 >
//                   Safety Guide
//                 </a>
//               </li>
//             </ul>
//           </div>

//           {/* Our Partners Section */}
//           <div>
//             <h3 className="text-xl font-semibold mb-6">Our Partners</h3>
//             <ul className="space-y-3">
//               {Array(11)
//                 .fill(0)
//                 .map((_, index) => (
//                   <li key={index}>
//                     <a
//                       href="#"
//                       className="text-gray-300 hover:text-white transition-colors"
//                     >
//                       naukri.com-job in india
//                     </a>
//                   </li>
//                 ))}
//             </ul>
//           </div>

//           {/* Contact Us Section */}
//           <div>
//             <h3 className="text-xl font-semibold mb-6">Contact us</h3>

//             <div className="mb-6">
//               <h4 className="text-xl  mb-2">Toll Free - 1800 41 1980</h4>
//               <p className="text-gray-300 text-sm">9:00am to 7:00pm</p>
//             </div>

//             <div className="mb-6">
//               <h4 className="text-xl mb-2">Email ID-</h4>
//               <p className="text-gray-300">www@gmail.com</p>
//             </div>

//             <div className="mb-6">
//               <h4 className="text-xl mb-4">Connect With Us</h4>
//               <div className="flex space-x-3">
//                 {/* Instagram */}
//                 <a
//                   href="#"
//                   className="w-10 h-10 rounded-full bg-white flex items-center justify-center "
//                 >
//                   <img src={instagram} alt="Instagram" className="w-10 h-10" />
//                 </a>

//                 {/* Twitter */}
//                 <a
//                   href="#"
//                   className="w-10 h-10 rounded-full bg-white flex items-center justify-center "
//                 >
//                   <img src={twitter} alt="Twitter" className="w-10 h-10" />
//                 </a>

//                 {/* Facebook */}
//                 <a
//                   href="#"
//                   className="w-10 h-10 rounded-full  flex items-center justify-center "
//                 >
//                   <img src={facebook} alt="Facebook" className="w-10 h-10" />
//                 </a>

//                 {/* LinkedIn */}
//                 <a
//                   href="#"
//                   className="w-10 h-10 rounded-full bg-white flex items-center justify-center "
//                 >
//                   <img src={linkdin} alt="LinkedIn" className="w-10 h-10" />
//                 </a>
//               </div>
//             </div>

//             <div>
//               <h4 className="text-xl mb-4">Download the App</h4>
//               <div className="flex items-center gap-2">
//                 <a href="#" className="inline-block">
//                   <img src={playstore} alt="Google Play" className="w-32" />
//                 </a>
//                 <a href="#" className="inline-block">
//                   <img src={appstore} alt="App Store" className="w-32" />
//                 </a>
//               </div>
//               <p className="text-gray-300 text-base mt-3">
//                 Install the Property Finder app and start searching smarter.
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>
//       {/* Bottom Links */}

//       <div className="py-4 px-38 flex items-center gap-10 text-gray-300 text-base bg-[#060a23]">
//         <a href="#" className="hover:text-white transition-colors">
//           Terms & Conditions
//         </a>
//         <a href="#" className="hover:text-white transition-colors">
//           Privacy Policy
//         </a>
//         <a href="#" className="hover:text-white transition-colors">
//           Cookies Policy
//         </a>
//         <a href="#" className="hover:text-white transition-colors">
//           Sitemap
//         </a>
//       </div>
//     </div>
//   );
// };

// export default PropertyFinderFooter;

import React from "react";
import facebook from "../assets/footer/facebook.png";
import instagram from "../assets/footer/instagram.png";
import linkdin from "../assets/footer/linkdin.png";
import twitter from "../assets/footer/twitter.png";
import playstore from "../assets/footer/playstore.png";
import appstore from "../assets/footer/appstore.png";
import { Link } from "react-router-dom";

const PropertyFinderFooter = () => {
  return (
    <div className="bg-[#0b154f]">
      <div className="max-w-7xl mx-auto text-white py-16 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 lg:gap-6">
          {/* Our Name Section */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Our Name</h3>
            <ul className="space-y-3">
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Mobile Apps
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Our Services
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Price Trends
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Post your Property
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Real Estate Investment
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Builders in UAE
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Area Converter
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Articles
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Rent Receipt
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Customer Service
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Sitemap
                </a>
              </li>
            </ul>
          </div>

          {/* Company Section */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Company</h3>
            <ul className="space-y-3">
              <li>
                <Link
                  to="/search"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Buy
                </Link>
              </li>
              <li>
                <Link
                  to="/rent"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Rent
                </Link>
              </li>
              <li>
                <Link
                  to="/commercial"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Commercial
                </Link>
              </li>
              <li>
                <Link
                  to="/newprojects"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  New Project
                </Link>
              </li>
              <li>
                <Link
                  to="/ourteam"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Join Our Team
                </Link>
              </li>
              {/* <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Explore
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Report & problem
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Testimonial
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Summons/Notices
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Grievances
                </a>
              </li>
              <li>
                <a
                  href="#"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Safety Guide
                </a>
              </li> */}
              <li>
                <Link
                  to="/contactus"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Contact Us
                </Link>
              </li>
              <li>
                <Link
                  to="/blog"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Blog
                </Link>
              </li>
              <li>
                <Link
                  to="/help"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Help
                </Link>
              </li>
              <li>
                <Link
                  to="/buyourservices"
                  className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                >
                  Buy Our Services
                </Link>
              </li>
            </ul>
          </div>

          {/* Our Partners Section */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Our Partners</h3>
            <ul className="space-y-3">
              {Array(11)
                .fill(0)
                .map((_, index) => (
                  <li key={index}>
                    <a
                      href="#"
                      className="text-gray-300 hover:text-white transition-colors text-sm sm:text-base"
                    >
                      example-job in india
                    </a>
                  </li>
                ))}
            </ul>
          </div>

          {/* Contact Us Section */}
          <div>
            <h3 className="text-xl font-semibold mb-6">Contact us</h3>

            <div className="mb-6">
              <h4 className="text-lg sm:text-xl mb-2">
                Toll Free - 1800 41 1980
              </h4>
              <p className="text-gray-300 text-sm">9:00am to 7:00pm</p>
            </div>

            <div className="mb-6">
              <h4 className="text-lg sm:text-xl mb-2">Email ID-</h4>
              <p className="text-gray-300 text-sm sm:text-base">
                www@gmail.com
              </p>
            </div>

            <div className="mb-6">
              <h4 className="text-lg sm:text-xl mb-4">Connect With Us</h4>
              <div className="flex space-x-3">
                {/* Instagram */}
                <a
                  href="#"
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center"
                >
                  <img
                    src={instagram}
                    alt="Instagram"
                    className="w-8 h-8 sm:w-10 sm:h-10"
                  />
                </a>

                {/* Twitter */}
                <a
                  href="#"
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center"
                >
                  <img
                    src={twitter}
                    alt="Twitter"
                    className="w-8 h-8 sm:w-10 sm:h-10"
                  />
                </a>

                {/* Facebook */}
                <a
                  href="#"
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full flex items-center justify-center"
                >
                  <img
                    src={facebook}
                    alt="Facebook"
                    className="w-8 h-8 sm:w-10 sm:h-10"
                  />
                </a>

                {/* LinkedIn */}
                <a
                  href="#"
                  className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-white flex items-center justify-center"
                >
                  <img
                    src={linkdin}
                    alt="LinkedIn"
                    className="w-8 h-8 sm:w-10 sm:h-10"
                  />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg sm:text-xl mb-4">Download the App</h4>
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
                <a href="#" className="inline-block">
                  <img
                    src={playstore}
                    alt="Google Play"
                    className="w-24 sm:w-32"
                  />
                </a>
                <a href="#" className="inline-block">
                  <img
                    src={appstore}
                    alt="App Store"
                    className="w-24 sm:w-32"
                  />
                </a>
              </div>
              <p className="text-gray-300 text-sm sm:text-base mt-3">
                Install the Property Finder app and start searching smarter.
              </p>
            </div>
          </div>
        </div>
      </div>
      {/* Bottom Links */}

      <div className="py-4 px-4 sm:px-6 lg:px-38 grid grid-cols-2 sm:grid-cols-4 gap-4 sm:gap-10 text-gray-300 text-sm sm:text-base bg-[#060a23]">
        <Link
          to="/termsandconditions"
          className="hover:text-white transition-colors"
        >
          Terms & Conditions
        </Link>
        <Link
          to="/privacypolicy"
          className="hover:text-white transition-colors"
        >
          Privacy Policy
        </Link>
        <a href="#" className="hover:text-white transition-colors">
          Cookies Policy
        </a>
        <a href="#" className="hover:text-white transition-colors">
          Sitemap
        </a>
      </div>
    </div>
  );
};

export default PropertyFinderFooter;
