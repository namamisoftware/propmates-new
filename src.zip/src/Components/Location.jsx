import React, { useEffect, useState } from "react";
import axios from "axios";

const GEOAPIFY_API_KEY = "7cb4a231b8d7445e817a708878a5a5cc";

const LocationFinder = () => {
  const [userLocation, setUserLocation] = useState(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [suggestions, setSuggestions] = useState([]);
  const [selectedLocation, setSelectedLocation] = useState(null);
  const [error, setError] = useState(null);

  // Detect user's current location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        async (position) => {
          const { latitude, longitude } = position.coords;
          try {
            const res = await axios.get(
              `https://api.geoapify.com/v1/geocode/reverse`,
              {
                params: {
                  lat: latitude,
                  lon: longitude,
                  apiKey: GEOAPIFY_API_KEY,
                },
              }
            );
            const place = res.data.features[0].properties;
            setUserLocation({
              city: place.city || place.county || "Unknown City",
              country: place.country || "Unknown Country",
              lat: latitude,
              lon: longitude,
            });
          } catch (err) {
            console.error(err);
            setError("Unable to fetch your current location.");
          }
        },
        (err) => {
          console.error(err);
          setError("Location permission denied or unavailable.");
        }
      );
    } else {
      setError("Geolocation not supported by this browser.");
    }
  }, []);

  // Fetch search suggestions
  useEffect(() => {
    const fetchSuggestions = async () => {
      if (searchQuery.length < 3) return; // Minimum 3 characters
      try {
        const res = await axios.get(
          `https://api.geoapify.com/v1/geocode/autocomplete`,
          {
            params: {
              text: searchQuery,
              apiKey: GEOAPIFY_API_KEY,
            },
          }
        );
        setSuggestions(res.data.features);
      } catch (err) {
        console.error("Error fetching suggestions:", err);
      }
    };

    const delayDebounce = setTimeout(fetchSuggestions, 400);
    return () => clearTimeout(delayDebounce);
  }, [searchQuery]);

  const handleSelect = (place) => {
    setSelectedLocation({
      city: place.properties.city || place.properties.county || "Unknown City",
      country: place.properties.country || "Unknown Country",
      lat: place.properties.lat,
      lon: place.properties.lon,
    });
    setSearchQuery(place.properties.formatted);
    setSuggestions([]);
  };

  return (
    <div className="p-4 max-w-md mx-auto border rounded-xl shadow bg-white">
      <h2 className="text-xl font-bold mb-3 text-center">🌍 Location Finder</h2>

      {/* User's current location */}
      {error ? (
        <p className="text-red-500 text-center mb-2">{error}</p>
      ) : userLocation ? (
        <div className="text-center mb-4">
          <p className="text-gray-700 font-semibold">
            📍 Your Current Location:
          </p>
          <p className="text-green-600 text-lg font-medium">
            {userLocation.city}, {userLocation.country}
          </p>
        </div>
      ) : (
        <p className="text-center text-gray-500 mb-4">Detecting location...</p>
      )}

      {/* Search bar */}
      <input
        type="text"
        placeholder="Search another location..."
        className="w-full border p-2 rounded-lg mb-2"
        value={searchQuery}
        onChange={(e) => setSearchQuery(e.target.value)}
      />

      {/* Suggestions */}
      {suggestions.length > 0 && (
        <ul className="border rounded-lg max-h-48 overflow-y-auto shadow">
          {suggestions.map((item) => (
            <li
              key={item.properties.place_id}
              className="p-2 border-b last:border-none hover:bg-gray-100 cursor-pointer"
              onClick={() => handleSelect(item)}
            >
              {item.properties.formatted}
            </li>
          ))}
        </ul>
      )}

      {/* Selected Location Display */}
      {selectedLocation && (
        <div className="mt-4 text-center">
          <p className="text-gray-700 font-semibold">📌 Selected Location:</p>
          <p className="text-blue-600 text-lg font-medium">
            {selectedLocation.city}, {selectedLocation.country}
          </p>
        </div>
      )}
    </div>
  );
};

export default LocationFinder;
