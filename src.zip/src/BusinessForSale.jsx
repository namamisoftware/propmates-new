import React, { useEffect, useState } from "react";
import {
  ChevronLeft,
  Heart,
  Phone,
  MessageCircle,
  MapPin,
  Bed,
  Bath,
  Maximize,
  ChevronRight,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import searchbg from "./assets/searchbg.png";
import calc from "./assets/calc.png";
import { Link, useNavigate } from "react-router-dom";
import { useLocation } from "./Components/LocationContext";

// Dummy data
const DUMMY_PROPERTIES = [
  {
    id: 1,
    name: "Marina Heights",
    bedrooms: "2-3",
    bathrooms: "2",
    expected_price: "1.5",
    total_area: "2850",
    locality: "Marina",
    sub_locality: "Bay Area",
    city: "Bhopal",
    images:
      "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Ahmed Al-Mansouri",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 2,
    name: "Palm Residences",
    bedrooms: "3-4",
    bathrooms: "3",
    expected_price: "2.8",
    total_area: "3200",
    locality: "Palm Jumeirah",
    sub_locality: "Frond M",
    city: "Bhopal",
    images:
      "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Layla Hassan",
      avatar:
        "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 3,
    name: "Downtown Tower",
    bedrooms: "1-2",
    bathrooms: "2",
    expected_price: "1.2",
    total_area: "1400",
    locality: "Downtown",
    sub_locality: "Business Bay",
    city: "Bhopal",
    images:
      "https://images.unsplash.com/photo-1613977257363-707ba9348227?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Omar Al-Rashid",
      avatar:
        "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 4,
    name: "Corniche Plaza",
    bedrooms: "2-4",
    bathrooms: "3",
    expected_price: "2.0",
    total_area: "2400",
    locality: "Corniche Area",
    sub_locality: "Marina Square",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1505819244306-ef53954f9648?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Sarah Johnson",
      avatar:
        "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 5,
    name: "Bay View Apartments",
    bedrooms: "2-3",
    bathrooms: "2",
    expected_price: "1.8",
    total_area: "1950",
    locality: "Al Raha Beach",
    sub_locality: "Waterfront",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Michael Chen",
      avatar:
        "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 6,
    name: "Heritage Villas",
    bedrooms: "4-5",
    bathrooms: "4",
    expected_price: "3.5",
    total_area: "4200",
    locality: "Al Zahia",
    sub_locality: "Waterfront City",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Priya Sharma",
      avatar:
        "https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 7,
    name: "Sky Gardens",
    bedrooms: "3",
    bathrooms: "3",
    expected_price: "2.2",
    total_area: "2100",
    locality: "Al Khan Area",
    sub_locality: "Corniche",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1580587771525-78b9dba3b914?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Mohammed Hassan",
      avatar:
        "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 8,
    name: "Marina Bay Complex",
    bedrooms: "2",
    bathrooms: "2",
    expected_price: "1.6",
    total_area: "1650",
    locality: "Al Marjan Island",
    sub_locality: "Resort Residences",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Fatima Al-Zahra",
      avatar:
        "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 9,
    name: "Green Valley Estate",
    bedrooms: "4",
    bathrooms: "3",
    expected_price: "2.9",
    total_area: "3100",
    locality: "Al Hamra Village",
    sub_locality: "Beachfront",
    city: "Ras Al Khaimah",
    images:
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Hassan Al-Qasimi",
      avatar:
        "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 10,
    name: "Marina Bay Complex",
    bedrooms: "2",
    bathrooms: "2",
    expected_price: "1.6",
    total_area: "1650",
    locality: "Al Marjan Island",
    sub_locality: "Resort Residences",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Fatima Al-Zahra",
      avatar:
        "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=40&h=40&fit=crop&crop=face",
    },
  },
  {
    id: 11,
    name: "Green Valley Estate",
    bedrooms: "4",
    bathrooms: "3",
    expected_price: "2.9",
    total_area: "3100",
    locality: "Al Hamra Village",
    sub_locality: "Beachfront",
    city: "Indore",
    images:
      "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60",
    agent: {
      name: "Hassan Al-Qasimi",
      avatar:
        "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=40&h=40&fit=crop&crop=face",
    },
  },
];

const Commercial = () => {
  const navigate = useNavigate();
  const { selectedCity } = useLocation();
  console.log(selectedCity);
  const [likedProperties, setLikedProperties] = useState({});
  const [properties, setproperties] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [currentPage, setCurrentPage] = useState(1);
  const propertiesPerPage = 9;

  useEffect(() => {
    setIsLoading(true);
    fetch("http://127.0.0.1:8000/main/properties/?category=Business")
      .then((res) => {
        if (!res.ok) throw new Error("API request failed");
        return res.json();
      })
      .then((data) => {
        if (data && data.length > 0) {
          console.log(data);
          setproperties(data);
          setCurrentPage(1);
        } else {
          // setproperties(DUMMY_PROPERTIES);
          setCurrentPage(1);
        }
      })
      .catch((err) => {
        console.error("Error fetching properties:", err);
        // setproperties(DUMMY_PROPERTIES);
        setCurrentPage(1);
      })
      .finally(() => {
        setIsLoading(false);
      });
  }, []);

  // Helper function to check if data is valid
  // const isValidData = (value) => {
  //   return (
  //     value &&
  //     value !== "N/A" &&
  //     value !== "n/a" &&
  //     value !== "" &&
  //     value !== "0" &&
  //     value !== 0 &&
  //     value.toString().trim() !== ""
  //   );
  // };
  const isValidData = (value) => {
    if (!value && value !== 0) return false; // null, undefined, empty string

    const str = String(value).trim().toLowerCase();

    // List of invalid values
    const invalidValues = ["", "n/a", "0"];

    return !invalidValues.includes(str);
  };

  // After the useEffect that fetches properties, add:
  const filteredProperties = selectedCity
    ? properties.filter(
        (property) => property.city.toLowerCase() === selectedCity.toLowerCase()
      )
    : properties;

  useEffect(() => {
    setCurrentPage(1);
  }, [selectedCity]);

  // Toggle like for specific property
  const toggleLike = (propertyId) => {
    setLikedProperties((prev) => ({
      ...prev,
      [propertyId]: !prev[propertyId],
    }));
  };

  const popularSearches = [
    "Furnished Properties for rent in UAE",
    "Offices for rent in UAE",
    "Warehouses for rent in UAE",
    "Shops for rent in UAE",
    "Business Centres for rent in UAE",
    "Retail Spaces for rent in UAE",
    "Properties for rent in UAE monthly",
    "Furnished Properties for rent in UAE monthly",
  ];

  const nearbyAreas = [
    "Properties for rent in Bhopal",
    "Properties for rent in Sharjah",
    "Properties for rent in Ajman",
    "Properties for rent in Umm Al Quwain",
    "Properties for rent in Abu Dhabi",
  ];

  const propertiesForSale = ["Properties for sale in UAE"];

  const indexOfLastProperty = currentPage * propertiesPerPage;
  const indexOfFirstProperty = indexOfLastProperty - propertiesPerPage;
  const currentProperties = filteredProperties.slice(
    indexOfFirstProperty,
    indexOfLastProperty
  );
  const totalPages = Math.ceil(filteredProperties.length / propertiesPerPage);

  const goToPage = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage((prev) => prev + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const goToPrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage((prev) => prev - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };
  return (
    <div className="min-h-screen">
      <Header />

      {/* Hero Section with Search Form */}
      <div className="relative">
        {/* Background Image */}
        <div className="w-full h-[100px] sm:h-[100px] md:h-[200px] lg:h-[200px] text-white relative overflow-hidden">
          <img src={searchbg} className="w-full h-full object-cover" alt="" />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, white 5%, rgba(255,255,255,0) 100%)",
              pointerEvents: "none",
            }}
          />
        </div>
      </div>

      {/* Content Section */}
      <div className="bg-white pt-24 sm:pt-34 md:pt-50 lg:pt-0">
        {/* Header Section - Responsive layout */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-30 md:gap-40 lg:gap-90 mb-6 lg:mb-8">
            {/* Back button */}
            <div className="flex items-center">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 mr-1" />
                <span className="text-base sm:text-lg font-medium">Back</span>
              </button>
            </div>

            {/* Main heading */}
            <div className="text-center sm:text-right">
              <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl font-bold text-[#0B154F]">
                Properties for Business For Sale
              </h1>
            </div>
          </div>
        </div>

        {isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">Loading properties...</p>
          </div>
        )}

        {/* Main Content Grid */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
          <div className="flex flex-col xl:flex-row gap-8">
            {/* Properties List - Takes full width on smaller screens */}
            <div className="flex-1 xl:w-3/4 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentProperties.map((property) => (
                  <Link
                    key={property.id}
                    to={`/details/business/${property.id}`}
                    className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-all duration-300 cursor-pointer"
                  >
                    {/* Image Section */}
                    <div className="relative overflow-hidden">
                      <img
                        src={
                          isValidData(property.images)
                            ? `http://127.0.0.1:8000${property.images[0]}`
                            : "null"
                        }
                        alt={property.title || "Property"}
                        className="w-full h-48 object-cover transition-transform duration-300 hover:scale-110"
                        // onError={(e) => {
                        //   e.target.src =
                        //     "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=600&auto=format&fit=crop&q=60";
                        // }}
                      />

                      {/* Company Logo */}
                      <div className="absolute top-3 left-3">
                        <img
                          src={
                            property.company_logo
                              ? `http://127.0.0.1:8000${property.company_logo}`
                              : "https://via.placeholder.com/80?text=Logo"
                          }
                          alt="Company Logo"
                          className="w-12 h-12 rounded object-cover border-2 border-white"
                          onError={(e) => {
                            e.target.style.display = "none";
                          }}
                        />
                      </div>

                      {/* Like Button */}
                      <button
                        onClick={(e) => {
                          e.preventDefault();
                          toggleLike(property.id);
                        }}
                        className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
                      >
                        <Heart
                          className={`w-4 h-4 ${
                            likedProperties[property.id]
                              ? "text-red-500 fill-red-500"
                              : "text-gray-400"
                          }`}
                        />
                      </button>
                    </div>

                    {/* Content Section */}
                    <div className="p-4">
                      {/* Title - Only show if valid */}
                      {isValidData(property.title) && (
                        <h3 className="text-sm text-gray-500 mb-2 line-clamp-2">
                          {property.title}
                        </h3>
                      )}

                      {/* Price - Only show if valid */}
                      {isValidData(property.asking_price) && (
                        <div className="mb-3">
                          <div className="flex items-baseline gap-1">
                            <span className="text-xl font-bold text-gray-900">
                              {property.asking_price} {property.currency}
                            </span>
                          </div>
                        </div>
                      )}

                      {/* Property Details - Only show items with valid data */}
                      <div className="flex items-center gap-4 mb-3 text-sm font-bold text-[#0f57d1]">
                        {isValidData(property.bedrooms) && (
                          <div className="flex items-center gap-1">
                            <Bed className="w-4 h-4" />
                            <span>{property.bedrooms}</span>
                          </div>
                        )}
                        {isValidData(property.bathrooms) && (
                          <div className="flex items-center gap-1">
                            <Bath className="w-4 h-4" />
                            <span>{property.bathrooms}</span>
                          </div>
                        )}
                        {isValidData(property.total_area) && (
                          <div className="flex items-center gap-1">
                            <Maximize className="w-4 h-4" />
                            <span>{property.total_area} sqft.</span>
                          </div>
                        )}
                      </div>

                      {/* Location - Only show if valid data exists */}
                      {(isValidData(property.locality) ||
                        isValidData(property.sub_locality) ||
                        isValidData(property.city)) && (
                        <div className="flex items-start mb-4">
                          <MapPin className="w-4 h-4 text-[#0B154F] mt-0.5 mr-2 flex-shrink-0" />
                          <p className="text-xs text-gray-500 leading-relaxed line-clamp-1">
                            {[
                              property.locality,
                              property.sub_locality,
                              property.city,
                            ]
                              .filter((item) => isValidData(item))
                              .join(", ")}
                          </p>
                        </div>
                      )}

                      {/* Agent and Contact Section */}
                      {property.agent?.name && (
                        <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                          {/* Agent Info */}
                          <div className="flex items-center gap-2">
                            {property.agent?.avatar && (
                              <img
                                src={property.agent.avatar}
                                alt={property.agent.name}
                                className="w-8 h-8 rounded-full object-cover"
                                onError={(e) => {
                                  e.target.style.display = "none";
                                }}
                              />
                            )}
                            <div>
                              <span className="text-xs text-gray-700 font-medium">
                                Listed by <br />
                              </span>
                              <span className="text-sm text-gray-700 font-medium">
                                {property.agent.name}
                              </span>
                            </div>
                          </div>

                          {/* Contact Buttons */}
                          <div className="flex items-center gap-2">
                            <a
                              onClick={(e) => e.preventDefault()}
                              href={`tel:${property.agent?.phone}`}
                              className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors"
                            >
                              <Phone className="w-4 h-4 text-green-600" />
                            </a>
                            <a
                              onClick={(e) => e.preventDefault()}
                              href={`https://wa.me/${property.agent?.whatsapp}`}
                              target="_blank"
                              className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors"
                            >
                              <MessageCircle className="w-4 h-4 text-green-600" />
                            </a>
                          </div>
                        </div>
                      )}
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {filteredProperties.length > propertiesPerPage && (
                <div className="flex justify-center items-center gap-2 mt-8">
                  <button
                    onClick={goToPrevPage}
                    disabled={currentPage === 1}
                    className="px-4 py-2 rounded-lg border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                  >
                    <ChevronLeft className="w-5 h-5" />
                  </button>

                  {[...Array(totalPages)].map((_, index) => (
                    <button
                      key={index + 1}
                      onClick={() => goToPage(index + 1)}
                      className={`px-4 py-2 rounded-lg ${
                        currentPage === index + 1
                          ? "bg-[#0B154F] text-white"
                          : "border border-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      {index + 1}
                    </button>
                  ))}

                  <button
                    onClick={goToNextPage}
                    disabled={currentPage === totalPages}
                    className="px-4 py-2 rounded-lg border border-gray-300 disabled:opacity-50 disabled:cursor-not-allowed hover:bg-gray-50"
                  >
                    <ChevronRight className="w-5 h-5" />
                  </button>
                </div>
              )}

              {currentProperties.length === 0 && (
                <div className="text-center py-12">
                  <p className="text-gray-500 text-lg">
                    {selectedCity
                      ? `No properties available in ${selectedCity}`
                      : "No properties available"}
                  </p>
                </div>
              )}
            </div>

            {/* Sidebar - Hidden on mobile and tablet, shown on desktop */}
            <div className="hidden xl:block xl:w-1/4">
              <div className="sticky top-8 space-y-6">
                {/* Popular Searches Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Popular Searches
                  </h3>
                  <div className="space-y-3">
                    {popularSearches.map((search, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {search}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Nearby Areas Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Nearby Areas
                  </h3>
                  <div className="space-y-3">
                    {nearbyAreas.map((area, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {area}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Properties for Sale Section */}
                <div className="bg-white p-6 rounded-lg border border-gray-200">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">
                    Properties for Sale
                  </h3>
                  <div className="space-y-3">
                    {propertiesForSale.map((property, index) => (
                      <div key={index}>
                        <a
                          href="#"
                          className="text-sm text-[#0B154F] hover:underline transition-colors duration-200 block leading-relaxed"
                        >
                          {property}
                        </a>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Calculator Image */}
                <div className="flex justify-center">
                  <img
                    src={calc}
                    alt="Calculator"
                    className="w-full max-w-[250px] h-auto"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Commercial;
