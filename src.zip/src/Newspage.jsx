// import React, { useState } from "react";
// import { ArrowLeft, ChevronLeft } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import Navbar from "./Components/Navbar";
// import calc from "./assets/calc.png";
// import img1 from "./assets/details/img1.png";
// import img2 from "./assets/details/img2.png";
// import img3 from "./assets/details/img3.png";
// import LatestUpdatedNews from "./Components/LatestNews";

// export default function HomeBudgetCalculator() {
//   const navigate = useNavigate();
//   return (
//     <>
//       <Header />
//       <Navbar />
//       <div className="">
//         <div className="flex flex-col lg:flex-row px-4 sm:px-8">
//           {/* Left Column - Scrollable Content */}
//           <div className="flex-1 overflow-y-auto lg:w-[90%] w-full">
//             <div className="p-2 sm:p-4 lg:pr-8">
//               <div className="w-full">
//                 {/* Header */}
//                 <div
//                   onClick={() => navigate(-1)}
//                   className="flex items-center mb-6 sm:mb-8"
//                 >
//                   <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 mr-1" />
//                   <span className="text-lg sm:text-xl font-semibold">Back</span>
//                 </div>

//                 <div className="">
//                   <div className="flex gap-6">
//                     {/* Main Property Image */}
//                     <div className="flex-1 relative">
//                       <div className="absolute bottom-10 left-10 z-10 flex items-center gap-2">
//                         <span className="text-6xl text-white font-medium">
//                           News <br /> Headlines
//                         </span>
//                       </div>

//                       <div
//                         className="w-full h-[500px] rounded-2xl overflow-hidden bg-cover bg-center relative"
//                         style={{
//                           backgroundImage: `url(${img1})`,
//                         }}
//                       ></div>
//                     </div>

//                     {/* Right Side Images */}
//                     <div className="w-80 flex flex-col gap-6">
//                       {/* Aerial View 1 */}
//                       <div
//                         className="h-[240px] rounded-2xl overflow-hidden bg-cover bg-center"
//                         style={{
//                           backgroundImage: `url(${img2})`,
//                         }}
//                       ></div>

//                       {/* Aerial View 2 */}
//                       <div
//                         className="h-[240px] rounded-2xl overflow-hidden bg-cover bg-center"
//                         style={{
//                           backgroundImage: `url(${img3})`,
//                         }}
//                       ></div>
//                     </div>
//                   </div>
//                 </div>
//               </div>
//             </div>

//             <div className="max-w-4xl px-6 mt-10">
//               <h2 className="text-4xl font-bold text-gray-800 mb-4  pb-2">
//                 News Descriptions
//               </h2>

//               <div className="space-y-4">
//                 <p className="text-gray-500 leading-relaxed text-lg text-justify">
//                   <span className="font-semibold">Palm Jebel Ali Front C</span>,
//                   a prestigious real estate development by Nakheel Properties,
//                   is situated on Palm Jebel Ali, one of Dubai's most
//                   recognizable artificial islands. With a variety of
//                   breathtaking villas created for individuals seeking the
//                   ultimate in luxurious living, this unique project is poised to
//                   become a genuine emblem of luxury and sophistication. With its
//                   vast living areas, modern facilities, and peaceful beachfront
//                   access,{" "}
//                   <span className="font-semibold">Palm Jebel Ali Front C</span>{" "}
//                   offers an exceptional lifestyle in one of the most
//                   sought-after locations on earth.
//                 </p>
//               </div>
//             </div>
//           </div>

//           {/* Right Column - Fixed Sidebar */}
//           <div className="w-full lg:w-[20%] order-last mb-4 lg:mb-0">
//             <div className="lg:sticky lg:top-0 p-2 sm:p-4 lg:pb-32 overflow-y-auto flex justify-center lg:block">
//               <img
//                 src={calc}
//                 alt="Calculator"
//                 className="w-48 sm:w-64 lg:w-auto"
//               />
//             </div>
//           </div>
//         </div>
//         <LatestUpdatedNews />
//       </div>
//       <Footer />
//     </>
//   );
// }

import React, { useState } from "react";
import { ArrowLeft, ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import Navbar from "./Components/Navbar";
import calc from "./assets/calc.png";
import img1 from "./assets/latestnews/news1.png";
import img2 from "./assets/latestnews/news2.png";
import img3 from "./assets/latestnews/news3.png";
import LatestUpdatedNews from "./Components/LatestNews";

export default function HomeBudgetCalculator() {
  const navigate = useNavigate();
  return (
    <>
      <Header />

      <div className="min-h-screen">
        <div className="flex flex-col xl:flex-row px-4 sm:px-6 lg:px-8">
          {/* Left Column - Scrollable Content */}
          <div className="flex-1 overflow-y-auto xl:w-[75%] w-full">
            <div className="p-2 sm:p-4 lg:p-6 xl:pr-8">
              <div className="w-full">
                {/* Header */}
                <div
                  onClick={() => navigate(-1)}
                  className="flex items-center mb-4 sm:mb-6 lg:mb-8 cursor-pointer hover:text-[#0b154f] transition-colors"
                >
                  <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 lg:w-7 lg:h-7 mr-1 sm:mr-2" />
                  <span className="text-base sm:text-lg lg:text-xl font-semibold">
                    Back
                  </span>
                </div>

                {/* Image Gallery Section */}
                <div className="mb-6 sm:mb-8 lg:mb-10">
                  {/* Desktop Layout */}
                  <div className="hidden lg:flex gap-4 xl:gap-6">
                    {/* Main Property Image */}
                    <div className="flex-1 relative">
                      <div className="absolute bottom-6 left-6 xl:bottom-10 xl:left-10 z-10 flex items-center gap-2">
                        <span className="text-3xl xl:text-4xl 2xl:text-6xl text-white font-medium leading-tight">
                          News <br /> Headlines
                        </span>
                      </div>

                      <div
                        className="w-full h-[400px] xl:h-[500px] rounded-xl xl:rounded-2xl overflow-hidden bg-cover bg-center relative shadow-lg"
                        style={{
                          backgroundImage: `url(${img1})`,
                        }}
                      ></div>
                    </div>

                    {/* Right Side Images */}
                    <div className="w-64 xl:w-80 flex flex-col gap-4 xl:gap-6">
                      {/* Aerial View 1 */}
                      <div
                        className="h-[190px] xl:h-[240px] rounded-xl xl:rounded-2xl overflow-hidden bg-cover bg-center shadow-lg"
                        style={{
                          backgroundImage: `url(${img2})`,
                        }}
                      ></div>

                      {/* Aerial View 2 */}
                      <div
                        className="h-[190px] xl:h-[240px] rounded-xl xl:rounded-2xl overflow-hidden bg-cover bg-center shadow-lg"
                        style={{
                          backgroundImage: `url(${img3})`,
                        }}
                      ></div>
                    </div>
                  </div>

                  {/* Tablet and Mobile Layout */}
                  <div className="lg:hidden">
                    {/* Main Image with Title Overlay */}
                    <div className="relative mb-4">
                      <div className="absolute bottom-4 left-4 z-10 flex items-center gap-2">
                        <span className="text-2xl sm:text-3xl md:text-4xl text-white font-medium leading-tight">
                          News <br /> Headlines
                        </span>
                      </div>
                      <div
                        className="w-full h-[250px] sm:h-[300px] md:h-[350px] rounded-xl overflow-hidden bg-cover bg-center shadow-lg"
                        style={{
                          backgroundImage: `url(${img1})`,
                        }}
                      ></div>
                    </div>

                    {/* Secondary Images Grid */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div
                        className="h-[200px] sm:h-[180px] md:h-[220px] rounded-xl overflow-hidden bg-cover bg-center shadow-lg"
                        style={{
                          backgroundImage: `url(${img2})`,
                        }}
                      ></div>
                      <div
                        className="h-[200px] sm:h-[180px] md:h-[220px] rounded-xl overflow-hidden bg-cover bg-center shadow-lg"
                        style={{
                          backgroundImage: `url(${img3})`,
                        }}
                      ></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* News Description Section */}
            <div className="max-w-none lg:max-w-4xl px-4 sm:px-6 lg:px-6 mt-6 sm:mt-8 lg:mt-10">
              <h2 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-800 mb-3 sm:mb-4 pb-2">
                News Descriptions
              </h2>

              <div className="space-y-4">
                <p className="text-gray-500 leading-relaxed text-base sm:text-lg text-justify">
                  <span className="font-semibold">Palm Jebel Ali Front C</span>,
                  a prestigious real estate development by Nakheel Properties,
                  is situated on Palm Jebel Ali, one of Dubai's most
                  recognizable artificial islands. With a variety of
                  breathtaking villas created for individuals seeking the
                  ultimate in luxurious living, this unique project is poised to
                  become a genuine emblem of luxury and sophistication. With its
                  vast living areas, modern facilities, and peaceful beachfront
                  access,{" "}
                  <span className="font-semibold">Palm Jebel Ali Front C</span>{" "}
                  offers an exceptional lifestyle in one of the most
                  sought-after locations on earth.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column - Calculator Sidebar */}
          <div className="w-full hidden lg:block xl:w-[25%] order-first xl:order-last mb-6 xl:mb-0">
            <div className="xl:sticky xl:top-4 p-2 sm:p-4 lg:p-6 xl:pb-32 overflow-y-auto">
              {/* Mobile/Tablet: Horizontal centered layout */}
              <div className="flex justify-center xl:block">
                <div className="w-full max-w-xs sm:max-w-sm xl:max-w-none">
                  <img
                    src={calc}
                    alt="Calculator"
                    className="w-full h-auto object-contain"
                  />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Latest News Section */}
        <div className="mt-8 sm:mt-12 lg:mt-16">
          <LatestUpdatedNews />
        </div>
      </div>
      <Footer />
    </>
  );
}
