import React, { useState } from "react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const NewsCard = ({ image, headline, description, category }) => {
  return (
    <Link
      to="/blogdetails"
      className="relative group cursor-pointer overflow-hidden transition-all duration-300 transform hover:-translate-y-2 max-w-sm"
    >
      <div className="relative h-64 overflow-hidden rounded-2xl">
        <img
          src={image}
          alt={headline}
          className="w-full h-full object-cover rounded-2xl transition-transform duration-300 group-hover:scale-105"
        />
      </div>
      <div className="p-6">
        <h3 className="text-xl font-bold text-[#0b154f] mb-3 line-clamp-2">
          {headline}
        </h3>
        <p className="text-gray-600 text-sm line-clamp-3">{description}</p>
      </div>
    </Link>
  );
};

const NewsCardDemo = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6;

  const allNewsData = [
    {
      id: 1,
      image:
        "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800&h=600&fit=crop",
      headline: "Real Estate Market Shows Strong Growth in Downtown Area",
      description:
        "Latest market analysis reveals significant uptick in property values and investment opportunities in the central business district.",
      category: "Headlines",
    },
    {
      id: 2,
      image:
        "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop",
      headline: "New Luxury Development Project Announced",
      description:
        "Premium residential complex featuring state-of-the-art amenities and sustainable design principles breaks ground this month.",
      category: "Headlines",
    },
    {
      id: 3,
      image:
        "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&h=600&fit=crop",
      headline: "Commercial Property Investment Trends 2024",
      description:
        "Industry experts discuss emerging opportunities and market predictions for commercial real estate investments.",
      category: "Headlines",
    },
    {
      id: 4,
      image:
        "https://images.unsplash.com/photo-1582407947304-fd86f028f716?w=800&h=600&fit=crop",
      headline: "Sustainable Architecture: The Future of Building Design",
      description:
        "Exploring eco-friendly construction methods and green building certifications that are reshaping the industry.",
      category: "Trends",
    },
    {
      id: 5,
      image:
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&h=600&fit=crop",
      headline: "Urban Redevelopment Projects Transform City Skyline",
      description:
        "Major infrastructure improvements and mixed-use developments bring new life to historic neighborhoods.",
      category: "Development",
    },
    {
      id: 6,
      image:
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800&h=600&fit=crop",
      headline: "First-Time Homebuyers: Essential Tips for 2024",
      description:
        "Expert advice on navigating the current market, securing financing, and making smart investment decisions.",
      category: "Advice",
    },
    {
      id: 7,
      image:
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=800&h=600&fit=crop",
      headline: "Smart Home Technology Integration in Modern Properties",
      description:
        "Latest innovations in home automation and IoT devices that are becoming standard in luxury developments.",
      category: "Technology",
    },
    {
      id: 8,
      image:
        "https://images.unsplash.com/photo-1600566753190-17f0baa2a6c3?w=800&h=600&fit=crop",
      headline: "Rental Market Analysis: What Landlords Need to Know",
      description:
        "Comprehensive overview of rental trends, tenant expectations, and property management best practices.",
      category: "Market",
    },
    {
      id: 9,
      image:
        "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=800&h=600&fit=crop",
      headline: "Historic District Preservation Meets Modern Living",
      description:
        "Balancing architectural heritage with contemporary amenities in renovated historic properties.",
      category: "Renovation",
    },
    {
      id: 10,
      image:
        "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&h=600&fit=crop",
      headline: "Waterfront Properties: Investment Potential Analysis",
      description:
        "Examining the long-term value and unique considerations of coastal and lakefront real estate.",
      category: "Investment",
    },
    {
      id: 11,
      image:
        "https://images.unsplash.com/photo-1600607687644-c7171b42498b?w=800&h=600&fit=crop",
      headline: "Co-Working Spaces Revolutionize Commercial Real Estate",
      description:
        "How flexible workspace solutions are changing office property dynamics and tenant relationships.",
      category: "Commercial",
    },
    {
      id: 12,
      image:
        "https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?w=800&h=600&fit=crop",
      headline: "Mortgage Rate Trends and Buyer Impact Assessment",
      description:
        "Understanding current lending landscape and strategic timing for property purchases in shifting markets.",
      category: "Finance",
    },
    {
      id: 13,
      image:
        "https://images.unsplash.com/photo-1600585152915-d208bec867a1?w=800&h=600&fit=crop",
      headline: "Suburban Growth: Migration Patterns Post-2020",
      description:
        "Analysis of demographic shifts driving demand for suburban properties and community development.",
      category: "Trends",
    },
    {
      id: 14,
      image:
        "https://images.unsplash.com/photo-1600573472550-8090b5e0745e?w=800&h=600&fit=crop",
      headline: "Property Staging: Maximizing Home Sale Value",
      description:
        "Professional tips on presentation, photography, and creating emotional connections with potential buyers.",
      category: "Sales",
    },
    {
      id: 15,
      image:
        "https://images.unsplash.com/photo-1600566752355-35792bedcfea?w=800&h=600&fit=crop",
      headline: "Real Estate Investment Trusts: A Comprehensive Guide",
      description:
        "Exploring REIT opportunities, portfolio diversification strategies, and income generation potential.",
      category: "Investment",
    },
  ];

  const totalPages = Math.ceil(allNewsData.length / itemsPerPage);
  const indexOfLastItem = currentPage * itemsPerPage;
  const indexOfFirstItem = indexOfLastItem - itemsPerPage;
  const currentItems = allNewsData.slice(indexOfFirstItem, indexOfLastItem);

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePrevious = () => {
    if (currentPage > 1) {
      handlePageChange(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      handlePageChange(currentPage + 1);
    }
  };

  const getPageNumbers = () => {
    const pages = [];
    const maxVisible = 5;

    if (totalPages <= maxVisible) {
      for (let i = 1; i <= totalPages; i++) {
        pages.push(i);
      }
    } else {
      if (currentPage <= 3) {
        for (let i = 1; i <= 4; i++) {
          pages.push(i);
        }
        pages.push("...");
        pages.push(totalPages);
      } else if (currentPage >= totalPages - 2) {
        pages.push(1);
        pages.push("...");
        for (let i = totalPages - 3; i <= totalPages; i++) {
          pages.push(i);
        }
      } else {
        pages.push(1);
        pages.push("...");
        pages.push(currentPage - 1);
        pages.push(currentPage);
        pages.push(currentPage + 1);
        pages.push("...");
        pages.push(totalPages);
      }
    }

    return pages;
  };

  return (
    <>
      <Header />
      <div className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-[#0b154f] mb-4">
              Property Blog
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 justify-items-center mb-12">
            {currentItems.map((news) => (
              <NewsCard
                key={news.id}
                image={news.image}
                headline={news.headline}
                description={news.description}
                category={news.category}
              />
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-center gap-2 flex-wrap">
            <button
              onClick={handlePrevious}
              disabled={currentPage === 1}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                currentPage === 1
                  ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                  : "bg-white text-[#0b154f] hover:bg-[#0b154f] hover:text-white shadow-md hover:shadow-lg"
              }`}
            >
              Previous
            </button>

            {getPageNumbers().map((page, index) => (
              <button
                key={index}
                onClick={() =>
                  typeof page === "number" && handlePageChange(page)
                }
                disabled={page === "..."}
                className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                  page === currentPage
                    ? "bg-[#0b154f] text-white shadow-lg"
                    : page === "..."
                    ? "bg-transparent text-gray-400 cursor-default"
                    : "bg-white text-[#0b154f] hover:bg-[#0b154f] hover:text-white shadow-md hover:shadow-lg"
                }`}
              >
                {page}
              </button>
            ))}

            <button
              onClick={handleNext}
              disabled={currentPage === totalPages}
              className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
                currentPage === totalPages
                  ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                  : "bg-white text-[#0b154f] hover:bg-[#0b154f] hover:text-white shadow-md hover:shadow-lg"
              }`}
            >
              Next
            </button>
          </div>
        </div>

        <style jsx>{`
          .line-clamp-2 {
            display: -webkit-box;
            -webkit-line-clamp: 2;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }
          .line-clamp-3 {
            display: -webkit-box;
            -webkit-line-clamp: 3;
            -webkit-box-orient: vertical;
            overflow: hidden;
          }
        `}</style>
      </div>
      <Footer />
    </>
  );
};

export default NewsCardDemo;
