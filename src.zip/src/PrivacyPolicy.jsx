// import React from "react";
// import Header from "./Components/Header";
// import PropertyFinderFooter from "./Components/Footer";

// export default function PrivacyPolicy() {
//   return (
//     <div>
//       <Header />
//       <div className="min-h-screen bg-gray-50">
//         <div className="max-w-8xl mx-auto py-12 px-4 sm:px-6 lg:px-14 text-justify">
//           {/* Header */}
//           <div className="text-center mb-12">
//             <h1 className="text-4xl font-bold text-[#0b154f] mb-4">
//               Privacy Policy
//             </h1>
//           </div>

//           {/* Content */}
//           <div className=" space-y-8">
//             {/* Introduction */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Introduction
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 Property Finder respects your privacy and is committed to
//                 protecting it. We provide this Privacy Policy to inform you of
//                 our privacy procedures and practices, as well as to describe
//                 what information we collect about you, how we obtain your
//                 information, and how we use, share and otherwise process your
//                 information in the course of operating our business and our
//                 platforms.
//               </p>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 In this Privacy Policy, "we", "our" and "us" refers to
//                 Propertyfinder FZ-LLC, MF Mortgage Broker LLC (doing business as
//                 Mortgage Finder), PFQ Property Finder LLC (Qatar), PFB Bahrain
//                 W.L.L, Property Finder Real Estate Company, Property Finder
//                 Egypt LLC and their worldwide affiliates (collectively,
//                 "Property Finder"); "the website" refers to the Property Finder
//                 websites (including www.propertyfinder.ae and
//                 www.mortgagefinder.ae); the website and our mobile applications
//                 together are the "platforms"; and "you" and "your" refers to a
//                 specific individual accessing and using the platforms or the
//                 services that we provide.
//               </p>
//               <p className="text-gray-700 leading-relaxed">
//                 We may update or revise this Privacy Policy at any time and this
//                 page will always reflect the current version.
//               </p>
//             </section>

//             {/* Information We Collect */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 The information that we collect
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 For purposes of this Privacy Policy, Property Finder is a "data
//                 controller", which means that we are responsible for the
//                 personal information that we collect about you and how we
//                 process it.
//               </p>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 "Personal information" is any information that can be used to
//                 identify you or that we can link to you and which we have in our
//                 possession or control.
//               </p>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 The information we may collect from or about you includes:
//               </p>

//               <div className="space-y-6">
//                 <div>
//                   <h3 className="text-xl font-medium text-[#0b154f] mb-3">
//                     Personal data about you:
//                   </h3>
//                   <p className="text-gray-700 leading-relaxed">
//                     When you register on our platforms as a user or otherwise,
//                     update your information, take part in promotions or
//                     campaigns or contests, sign into our mobile application
//                     using your personal information or a social media account,
//                     send emails to us, send support requests, contact estate
//                     agents via forms or phone numbers made available on our
//                     platforms, provide feedback, or when you report a problem
//                     with our platforms, you provide us with information that we
//                     store and process. Such information may include your name,
//                     address, phone number, email address, nationality, residency
//                     status, device IP address, date of birth, passport or
//                     Emirates ID, spending limits and budget, survey
//                     participation, video and audio recordings and your interests
//                     (including preferred type of real estate), and any other
//                     information that you independently choose to provide to us.
//                   </p>
//                 </div>

//                 <div>
//                   <h3 className="text-xl font-medium text-[#0b154f] mb-3">
//                     Purchase information:
//                   </h3>
//                   <p className="text-gray-700 leading-relaxed">
//                     We may collect information relating to any purchases or
//                     potential purchases of our products, real estate listed on
//                     our website, or services that you make (such as records of
//                     purchase).
//                   </p>
//                 </div>

//                 <div>
//                   <h3 className="text-xl font-medium text-[#0b154f] mb-3">
//                     Website information:
//                   </h3>
//                   <p className="text-gray-700 leading-relaxed">
//                     We may receive information from you as a result of your
//                     visits to, and use of, the website. This information may
//                     include information such as your IP address, the date and
//                     time you access the website, length of time you spend on the
//                     website, your browsing history, and the Internet address of
//                     the website from which you redirected to our website.
//                   </p>
//                 </div>

//                 <div>
//                   <h3 className="text-xl font-medium text-[#0b154f] mb-3">
//                     Financial, payment and credit data:
//                   </h3>
//                   <p className="text-gray-700 leading-relaxed">
//                     We may collect payment data that you provide when you make
//                     online purchases. This may include your payment instrument
//                     number, your name and billing address, and the security code
//                     associated with your payment instrument. We may collect
//                     information relating to payment and transaction history and
//                     billing information. We may also collect personal credit
//                     information, credit reports provided by a credit reporting
//                     agency used to report on overdue credit payments and
//                     commercial credit information for the purpose of providing
//                     mortgages to you via Mortgage Finder.
//                   </p>
//                 </div>

//                 <div>
//                   <h3 className="text-xl font-medium text-[#0b154f] mb-3">
//                     Other information:
//                   </h3>
//                   <p className="text-gray-700 leading-relaxed">
//                     We may collect other information so that we, including our
//                     affiliates, customers, and associates, can provide services
//                     to you, such as credit scores, payslips and salary letters
//                     for the purpose of obtaining a mortgage. If you are a user
//                     of any of our products or services, we may collect
//                     information you have made publicly available.
//                   </p>
//                 </div>
//               </div>
//             </section>

//             {/* How We Obtain Information */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 How do we obtain and what are the sources of your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We may collect your information during the course of our
//                 engagement with you and will only use your personal information
//                 in accordance with applicable data protection laws.
//               </p>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We may obtain this information from a variety of sources,
//                 including:
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700">
//                 <li>
//                   from you (for example, when you access and use the platforms,
//                   when you make an inquiry about our platforms or services, send
//                   WhatsApp communications to us or agents and brokers via our
//                   platforms to enquire about a property, send emails or call our
//                   Customer Care team, or otherwise provide us with your personal
//                   information);
//                 </li>
//                 <li>
//                   from real estate developers, agents and brokers and government
//                   sources (such as Ejari);
//                 </li>
//                 <li>
//                   from our affiliates and business partners, such Mortgage
//                   Finder and banks; and
//                 </li>
//                 <li>
//                   from advertising networks, analytics providers and search
//                   information providers.
//                 </li>
//               </ul>
//             </section>

//             {/* How We Process Information */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 How do we process your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We will comply with applicable data protection laws that apply
//                 to our processing of your personal information. We will:
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700">
//                 <li>
//                   process your personal information in a lawful, fair,
//                   transparent and secure way;
//                 </li>
//                 <li>
//                   collect your personal information only for specific, explicit
//                   and legitimate purposes as explained to you when collecting
//                   your personal information;
//                 </li>
//                 <li>
//                   not use your personal information in any way that is
//                   incompatible with those purposes;
//                 </li>
//                 <li>
//                   process your personal information in a manner that is adequate
//                   and relevant to the purposes for which we have collected it
//                   and limited only to those purposes;
//                 </li>
//                 <li>
//                   keep your personal information accurate and, where necessary,
//                   up to date; and
//                 </li>
//                 <li>
//                   keep your personal information in a form that identifies you
//                   only as long as necessary for the purposes we have informed
//                   you and/or as permitted by law.
//                 </li>
//               </ul>
//             </section>

//             {/* How We Use Information */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 How do we use your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We may use or process your personal information for the
//                 following purposes:
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700">
//                 <li>to provide any services that you request from us;</li>
//                 <li>
//                   to provide a better service to you, and in particular, to keep
//                   internal records, as well as to improve our products, services
//                   and the platforms;
//                 </li>
//                 <li>
//                   to communicate with you (through various communication
//                   platforms, such as WhatsApp, SMS, phone and email) if you have
//                   ordered, purchased or participated in anything on the
//                   platforms;
//                 </li>
//                 <li>
//                   to assist third parties in providing services to you, such as
//                   real estate developers, agents, and brokers, or banks with
//                   respect of issuing mortgages;
//                 </li>
//                 <li>to contact you for market research purposes;</li>
//                 <li>
//                   to monitor communications in order to improve the services we
//                   provide to you and assess the performance and responsiveness
//                   of our employees and real estate agents;
//                 </li>
//                 <li>
//                   to provide you with information about new opportunities,
//                   promotions, alert notifications, special offers and other
//                   information that we may feel is relevant to you;
//                 </li>
//                 <li>
//                   to customize or enhance your experience on our platforms and
//                   services;
//                 </li>
//                 <li>
//                   to improve our platforms by determining the website's
//                   technical design specifications and identifying system
//                   performance or problem areas;
//                 </li>
//                 <li>
//                   to process your payments or any documents that you provide via
//                   the platforms;
//                 </li>
//                 <li>
//                   to measure or understand the effectiveness of advertising we
//                   serve to you and others, to deliver relevant advertising to
//                   you;
//                 </li>
//                 <li>to comply with legal obligations.</li>
//               </ul>
//             </section>

//             {/* Legal Basis */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 On what basis do we use your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We use your personal information on the following bases (where
//                 permitted in accordance with applicable data protection laws):
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700">
//                 <li>
//                   because the information is necessary for the performance of a
//                   contract with you or to take steps at your request to enter
//                   into a contract;
//                 </li>
//                 <li>
//                   because you have given your consent (if we expressly ask for
//                   consent to process your personal information, for a specific
//                   purpose);
//                 </li>
//                 <li>
//                   for our legitimate interests. Using your personal information
//                   helps us to operate, improve and minimise any disruption to
//                   the platforms and the services that we may offer to you;
//                 </li>
//                 <li>to comply with legal and regulatory obligations; or</li>
//                 <li>
//                   if you have made the personal information publicly available.
//                 </li>
//               </ul>
//             </section>

//             {/* Information Sharing */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Who do we share your information with
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 We will only disclose or transfer your personal information for
//                 the purposes set out in this notice, or as otherwise notified to
//                 you at the time your personal information is being collected:
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700">
//                 <li>
//                   to selected real estate brokers, real estate brokerage firms,
//                   agents, developers or other service providers that we use;
//                 </li>
//                 <li>
//                   to business partners, suppliers and sub-contractors for the
//                   performance of any contract we enter into with them or you;
//                 </li>
//                 <li>to any member of our group;</li>
//                 <li>
//                   to any competent authorities if we are legally required to
//                   comply with a request for data;
//                 </li>
//                 <li>
//                   to our third-party service providers. We partner with and are
//                   supported by service providers around the world;
//                 </li>
//                 <li>
//                   if we sell or buy any business or assets, in which case we may
//                   disclose your personal information to the prospective seller
//                   or buyer;
//                 </li>
//                 <li>if required in order to obtain professional advice;</li>
//                 <li>
//                   to perform a credit check and to contact other lenders, banks,
//                   or financial institutions;
//                 </li>
//                 <li>
//                   if we are under a duty to disclose or share your personal
//                   information in order to comply with any legal obligation;
//                 </li>
//                 <li>
//                   to protect our rights, property, or safety, as well as that of
//                   our affiliates, our customers, or others.
//                 </li>
//               </ul>
//             </section>

//             {/* International Transfers */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Countries to which we transfer your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 The information that we collect from you may be transferred,
//                 stored and hosted, outside of the country from which you may be
//                 accessing the platforms, and may be transferred to countries
//                 which do not have data protection laws or to countries where
//                 your privacy and other fundamental rights will not be protected
//                 as extensively.
//               </p>
//               <p className="text-gray-700 leading-relaxed">
//                 We will implement appropriate measures to ensure that your
//                 personal information remains protected and secure when it is
//                 transferred outside your home country and you can exercise your
//                 rights effectively.
//               </p>
//             </section>

//             {/* Security */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 The security of your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 Keeping your personal information secure and preventing
//                 unauthorized access is of utmost priority to us, and we take all
//                 steps reasonably necessary to protect your personal information
//                 against any unauthorised access, use, alteration, disclosure or
//                 destruction.
//               </p>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 Where we have given you, or where you have created a password
//                 which is part of our services or allows you to access parts of
//                 our platforms, you are responsible for keeping this password
//                 confidential. We ask you not to share your password with anyone.
//               </p>
//               <p className="text-gray-700 leading-relaxed">
//                 Unfortunately, the transmission of information via the internet
//                 is not completely secure. We will do our best to protect your
//                 personal information, however, we cannot guarantee the security
//                 of your information transmitted to our platforms.
//               </p>
//             </section>

//             {/* Data Retention */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Keeping your information
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 How long we hold your personal information for will vary, and we
//                 will typically keep your personal information only for as long
//                 as is necessary to respond to any queries or complaints, to
//                 improve the services that we offer to you or to comply with any
//                 legal obligations to which we may be subject.
//               </p>
//               <p className="text-gray-700 leading-relaxed">
//                 To determine the appropriate retention periods for personal
//                 information, we consider the amount, nature, and sensitivity of
//                 the personal information, the potential risk of harm from
//                 unauthorised use or disclosure of your personal information, the
//                 purposes for which we process your personal information and
//                 whether we can achieve such purposes through other means, and
//                 the applicable legal requirements.
//               </p>
//             </section>

//             {/* Your Rights */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Your choices and rights
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 With respect to your personal information which is held by us
//                 and under our direct control, under certain circumstances and
//                 under certain applicable data protection laws, you may have the
//                 right to:
//               </p>
//               <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
//                 <li>
//                   <span className="font-medium">Access your data</span> –
//                   request a copy of your personal information that we process
//                   about you;
//                 </li>
//                 <li>
//                   <span className="font-medium">Correct your data</span> –
//                   request us to amend or update your personal information where
//                   it is inaccurate or incomplete;
//                 </li>
//                 <li>
//                   <span className="font-medium">Erase your data</span> – request
//                   us to delete your personal information where it is no longer
//                   necessary;
//                 </li>
//                 <li>
//                   <span className="font-medium">Restrict your data</span> –
//                   request us temporarily or permanently to stop processing all
//                   or some of your personal data;
//                 </li>
//                 <li>
//                   <span className="font-medium">
//                     Object to the use of your data
//                   </span>{" "}
//                   – at any time, object to us processing your personal
//                   information;
//                 </li>
//                 <li>
//                   <span className="font-medium">Data portability</span> –
//                   request the receipt or transmission of your personal
//                   information to another organisation;
//                 </li>
//                 <li>
//                   <span className="font-medium">Withdraw your consent</span> –
//                   withdraw your consent at any time to the use of your personal
//                   information for a particular purpose.
//                 </li>
//               </ul>
//               <p className="text-gray-700 leading-relaxed">
//                 For any of the above, please email us at{" "}
//                 <a
//                   href="mailto:privacy@propertyfinder.ae"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   privacy@propertyfinder.ae
//                 </a>
//                 . Subject to any overriding legal obligations, requirements
//                 and/or exemptions, we will endeavour to respond to your request
//                 as soon as possible.
//               </p>
//             </section>

//             {/* Marketing Preferences */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 How to manage your marketing preferences
//               </h2>
//               <p className="text-gray-700 leading-relaxed">
//                 To opt out of email marketing, you can use the unsubscribe link
//                 found in the email communication you receive from us or by
//                 sending an email to{" "}
//                 <a
//                   href="mailto:privacy@propertyfinder.ae"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   privacy@propertyfinder.ae
//                 </a>
//                 . For other marketing preferences, you can contact us via any
//                 relevant link in the marketing communication, or by sending an
//                 email to{" "}
//                 <a
//                   href="mailto:privacy@propertyfinder.ae"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   privacy@propertyfinder.ae
//                 </a>
//                 .
//               </p>
//             </section>

//             {/* Third Party Links */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Hyperlinks
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 Our services may contain links to and may be used by you in
//                 conjunction with third-party apps, services, tools, and websites
//                 that are not affiliated with, controlled, or managed by us.
//                 Examples include but are not limited to Facebook, LinkedIn,
//                 Twitter and, third-party apps like voice software and readers.
//               </p>
//               <p className="text-gray-700 leading-relaxed">
//                 The privacy practices of these third parties will be governed by
//                 the parties' own privacy policies. We are not responsible for
//                 the security or privacy of any information collected by these
//                 third parties. Information that you provide to third-party
//                 companies is not covered by this Privacy Policy.
//               </p>
//             </section>

//             {/* Privacy of Minors */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Privacy of minors
//               </h2>
//               <p className="text-gray-700 leading-relaxed">
//                 We are committed to protecting the privacy needs of children and
//                 we encourage parents and guardians to take an active role in
//                 their children's online activities and interests. We do not
//                 knowingly collect information from children and we do not target
//                 our platforms to children. If you become aware that a child has
//                 provided us with personal information without the parent or
//                 guardian's consent, please contact us at{" "}
//                 <a
//                   href="mailto:privacy@propertyfinder.ae"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   privacy@propertyfinder.ae
//                 </a>{" "}
//                 and we will take steps to delete the information from our
//                 records.
//               </p>
//             </section>

//             {/* Policy Updates */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 Updates or changes to this Privacy Policy
//               </h2>
//               <p className="text-gray-700 leading-relaxed">
//                 We may update this Privacy Policy from time to time as we deem
//                 necessary. If there are material changes to this Privacy Policy,
//                 we will provide notice where, and in the manner required, by
//                 applicable laws, including but not limited to by email or via
//                 the platforms. Any changes to this Privacy Policy take effect
//                 immediately after being notified by us.
//               </p>
//             </section>

//             {/* Contact Information */}
//             <section>
//               <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
//                 How do you contact us
//               </h2>
//               <p className="text-gray-700 leading-relaxed mb-4">
//                 This Privacy Policy sets out in broad terms how we handle your
//                 personal information and safeguard your privacy. If you have any
//                 questions relating to our Privacy Policy, please send an email
//                 to{" "}
//                 <a
//                   href="mailto:privacy@propertyfinder.ae"
//                   className="text-blue-600 hover:text-blue-800"
//                 >
//                   privacy@propertyfinder.ae
//                 </a>{" "}
//                 or a postal mail to the following address:
//               </p>
//               <div className="bg-gray-50 p-6 rounded-lg">
//                 <p className="text-gray-700 font-medium">
//                   Data Protection Officer
//                   <br />
//                   Propertyfinder FZ-LLC
//                   <br />
//                   Office 1505 in Shatha Tower
//                   <br />
//                   Dubai Media City
//                   <br />
//                   Dubai, UAE
//                 </p>
//               </div>
//             </section>
//           </div>
//         </div>
//       </div>
//       <PropertyFinderFooter />
//     </div>
//   );
// }

import React, { useState } from "react";
import ReactCountryFlag from "react-country-flag";
import Header from "./Components/Header";
import Navbar from "./Components/Navbar";
import PropertyFinderFooter from "./Components/Footer";

export default function PrivacyPolicy() {
  const [selectedCountry, setSelectedCountry] = useState("UAE");
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);

  const countries = ["UAE", "KSA", "Qatar", "Bahrain", "Egypt"];

  const getCountrySpecificInfo = (country) => {
    const countryInfo = {
      UAE: {
        website: "www.propertyfinder.ae",
        email: "privacy@propertyfinder.ae",
        entity: "Propertyfinder FZ-LLC",
        jurisdiction: "UAE",
        currency: "AED",
        legalAge: "twenty-one (21)",
        regulations: "UAE Data Protection Law",
        mortgageEntity:
          "MF Mortgage Broker LLC (doing business as Mortgage Finder)",
        address: {
          line1: "Office 1505 in Shatha Tower",
          line2: "Dubai Media City",
          city: "Dubai, UAE",
        },
      },
      KSA: {
        website: "www.propertyfinder.sa",
        email: "privacy@propertyfinder.sa",
        entity: "Propertyfinder Saudi Arabia LLC",
        jurisdiction: "Kingdom of Saudi Arabia",
        currency: "SAR",
        legalAge: "eighteen (18)",
        regulations: "Personal Data Protection Law (PDPL)",
        mortgageEntity: "PropertyFinder Mortgage Services KSA",
        address: {
          line1: "King Fahd Road, Al Olaya District",
          line2: "Riyadh Business Center",
          city: "Riyadh, Saudi Arabia",
        },
      },
      Qatar: {
        website: "www.propertyfinder.qa",
        email: "privacy@propertyfinder.qa",
        entity: "PFQ Property Finder LLC",
        jurisdiction: "State of Qatar",
        currency: "QAR",
        legalAge: "eighteen (18)",
        regulations: "Qatar Data Protection Law",
        mortgageEntity: "PropertyFinder Financial Services Qatar",
        address: {
          line1: "West Bay Business District",
          line2: "Doha Financial Center",
          city: "Doha, Qatar",
        },
      },
      Bahrain: {
        website: "www.propertyfinder.bh",
        email: "privacy@propertyfinder.bh",
        entity: "PFB Bahrain W.L.L",
        jurisdiction: "Kingdom of Bahrain",
        currency: "BHD",
        legalAge: "eighteen (18)",
        regulations: "Personal Data Protection Law (PDPL)",
        mortgageEntity: "PropertyFinder Mortgage Bahrain",
        address: {
          line1: "Bahrain Financial Harbour",
          line2: "Manama Business District",
          city: "Manama, Bahrain",
        },
      },
      Egypt: {
        website: "www.propertyfinder.eg",
        email: "privacy@propertyfinder.eg",
        entity: "Property Finder Egypt LLC",
        jurisdiction: "Arab Republic of Egypt",
        currency: "EGP",
        legalAge: "eighteen (18)",
        regulations: "Egyptian Data Protection Law",
        mortgageEntity: "PropertyFinder Mortgage Egypt",
        address: {
          line1: "New Cairo Business District",
          line2: "Fifth Settlement",
          city: "Cairo, Egypt",
        },
      },
    };
    return countryInfo[country] || countryInfo.UAE;
  };

  const getCountryCode = (country) => {
    const countryCodes = {
      UAE: "AE",
      KSA: "SA",
      Qatar: "QA",
      Bahrain: "BH",
      Egypt: "EG",
    };
    return countryCodes[country] || "AE";
  };

  const countryInfo = getCountrySpecificInfo(selectedCountry);

  return (
    <div>
      <Header />

      <div className="min-h-screen bg-gray-50">
        <div className="max-w-8xl mx-auto py-12 px-4 sm:px-6 lg:px-14">
          {/* Header with Country Selector */}
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-xl md:text-4xl font-bold text-[#0b154f]">
              Privacy Policy
            </h1>

            {/* Country Selector */}
            <div className="relative">
              <button
                className="flex items-center space-x-2 bg-white border border-gray-300 rounded-md px-4 py-2 hover:bg-gray-50 transition-colors shadow-sm"
                onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              >
                <ReactCountryFlag
                  countryCode={getCountryCode(selectedCountry)}
                  svg
                  style={{
                    width: "1.5rem",
                    height: "1rem",
                  }}
                />
                <span className="font-medium text-gray-700">
                  {selectedCountry}
                </span>
                <svg
                  className={`w-4 h-4 text-gray-500 transition-transform ${
                    showCountryDropdown ? "rotate-180" : ""
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {/* Dropdown Menu */}
              {showCountryDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                  {countries.map((country) => (
                    <button
                      key={country}
                      onClick={() => {
                        setSelectedCountry(country);
                        setShowCountryDropdown(false);
                      }}
                      className={`w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 transition-colors ${
                        selectedCountry === country
                          ? "bg-blue-50 text-blue-700"
                          : "text-gray-700"
                      }`}
                    >
                      <ReactCountryFlag
                        countryCode={getCountryCode(country)}
                        svg
                        style={{
                          width: "1.5rem",
                          height: "1rem",
                        }}
                      />
                      <span className="font-medium">{country}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Country Info Banner */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-8 rounded-r-md">
            <p className="text-blue-800">
              <strong>Current Region:</strong> {countryInfo.jurisdiction} |
              <strong> Currency:</strong> {countryInfo.currency} |
              <strong> Entity:</strong> {countryInfo.entity}
            </p>
          </div>

          <div className="bg-white rounded-lg shadow-sm p-8 text-justify space-y-8">
            {/* Introduction */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Introduction
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Property Finder respects your privacy and is committed to
                protecting it. We provide this Privacy Policy to inform you of
                our privacy procedures and practices, as well as to describe
                what information we collect about you, how we obtain your
                information, and how we use, share and otherwise process your
                information in the course of operating our business and our
                platforms.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                In this Privacy Policy, "we", "our" and "us" refers to{" "}
                {countryInfo.entity}, {countryInfo.mortgageEntity}, and their
                worldwide affiliates (collectively, "Property Finder"); "the
                website" refers to the Property Finder website{" "}
                {countryInfo.website}; the website and our mobile applications
                together are the "platforms"; and "you" and "your" refers to a
                specific individual accessing and using the platforms or the
                services that we provide in {countryInfo.jurisdiction}.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We may update or revise this Privacy Policy at any time and this
                page will always reflect the current version applicable to users
                in {countryInfo.jurisdiction}.
              </p>
            </section>

            {/* Information We Collect */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                The information that we collect
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                For purposes of this Privacy Policy, Property Finder is a "data
                controller" in accordance with {countryInfo.regulations}, which
                means that we are responsible for the personal information that
                we collect about you and how we process it.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                "Personal information" is any information that can be used to
                identify you or that we can link to you and which we have in our
                possession or control, as defined under the laws of{" "}
                {countryInfo.jurisdiction}.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                The information we may collect from or about you includes:
              </p>

              <div className="space-y-6">
                <div>
                  <h3 className="text-xl font-medium text-[#0b154f] mb-3">
                    Personal data about you:
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    When you register on our platforms as a user or otherwise,
                    update your information, take part in promotions or
                    campaigns or contests, sign into our mobile application
                    using your personal information or a social media account,
                    send emails to us, send support requests, contact estate
                    agents via forms or phone numbers made available on our
                    platforms, provide feedback, or when you report a problem
                    with our platforms, you provide us with information that we
                    store and process. Such information may include your name,
                    address, phone number, email address, nationality, residency
                    status in {countryInfo.jurisdiction}, device IP address,
                    date of birth, national ID or passport information, spending
                    limits and budget in {countryInfo.currency}, survey
                    participation, video and audio recordings and your interests
                    (including preferred type of real estate), and any other
                    information that you independently choose to provide to us.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-medium text-[#0b154f] mb-3">
                    Purchase information:
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    We may collect information relating to any purchases or
                    potential purchases of our products, real estate listed on
                    our website in {countryInfo.jurisdiction}, or services that
                    you make (such as records of purchase processed in{" "}
                    {countryInfo.currency}).
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-medium text-[#0b154f] mb-3">
                    Website information:
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    We may receive information from you as a result of your
                    visits to, and use of, the website {countryInfo.website}.
                    This information may include information such as your IP
                    address, the date and time you access the website, length of
                    time you spend on the website, your browsing history within{" "}
                    {countryInfo.jurisdiction}, and the Internet address of the
                    website from which you redirected to our website.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-medium text-[#0b154f] mb-3">
                    Financial, payment and credit data:
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    We may collect payment data that you provide when you make
                    online purchases in {countryInfo.currency}. This may include
                    your payment instrument number, your name and billing
                    address in {countryInfo.jurisdiction}, and the security code
                    associated with your payment instrument. We may collect
                    information relating to payment and transaction history and
                    billing information. We may also collect personal credit
                    information, credit reports provided by credit reporting
                    agencies in {countryInfo.jurisdiction} used to report on
                    overdue credit payments and commercial credit information
                    for the purpose of providing mortgages to you via our
                    mortgage services.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-medium text-[#0b154f] mb-3">
                    Other information:
                  </h3>
                  <p className="text-gray-700 leading-relaxed">
                    We may collect other information so that we, including our
                    affiliates, customers, and associates, can provide services
                    to you in {countryInfo.jurisdiction}, such as credit scores,
                    payslips and salary letters for the purpose of obtaining a
                    mortgage. If you are a user of any of our products or
                    services, we may collect information you have made publicly
                    available in accordance with {countryInfo.jurisdiction} law.
                  </p>
                </div>
              </div>
            </section>

            {/* How We Obtain Information */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                How do we obtain and what are the sources of your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may collect your information during the course of our
                engagement with you and will only use your personal information
                in accordance with {countryInfo.regulations} and applicable data
                protection laws in {countryInfo.jurisdiction}.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may obtain this information from a variety of sources,
                including:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>
                  from you (for example, when you access and use the platforms,
                  when you make an inquiry about our platforms or services, send
                  WhatsApp communications to us or agents and brokers via our
                  platforms to enquire about a property in{" "}
                  {countryInfo.jurisdiction}, send emails or call our Customer
                  Care team, or otherwise provide us with your personal
                  information);
                </li>
                <li>
                  from real estate developers, agents and brokers and government
                  sources in {countryInfo.jurisdiction};
                </li>
                <li>
                  from our affiliates and business partners operating in{" "}
                  {countryInfo.jurisdiction}, such as mortgage and financial
                  services providers; and
                </li>
                <li>
                  from advertising networks, analytics providers and search
                  information providers operating within{" "}
                  {countryInfo.jurisdiction}.
                </li>
              </ul>
            </section>

            {/* How We Process Information */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                How do we process your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We will comply with {countryInfo.regulations} and applicable
                data protection laws that apply to our processing of your
                personal information in {countryInfo.jurisdiction}. We will:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>
                  process your personal information in a lawful, fair,
                  transparent and secure way in accordance with{" "}
                  {countryInfo.jurisdiction} law;
                </li>
                <li>
                  collect your personal information only for specific, explicit
                  and legitimate purposes as explained to you when collecting
                  your personal information;
                </li>
                <li>
                  not use your personal information in any way that is
                  incompatible with those purposes or violates{" "}
                  {countryInfo.jurisdiction} regulations;
                </li>
                <li>
                  process your personal information in a manner that is adequate
                  and relevant to the purposes for which we have collected it
                  and limited only to those purposes;
                </li>
                <li>
                  keep your personal information accurate and, where necessary,
                  up to date; and
                </li>
                <li>
                  keep your personal information in a form that identifies you
                  only as long as necessary for the purposes we have informed
                  you and/or as permitted by {countryInfo.jurisdiction} law.
                </li>
              </ul>
            </section>

            {/* How We Use Information */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                How do we use your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We may use or process your personal information for the
                following purposes in {countryInfo.jurisdiction}:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>to provide any services that you request from us;</li>
                <li>
                  to provide a better service to you, and in particular, to keep
                  internal records, as well as to improve our products, services
                  and the platforms;
                </li>
                <li>
                  to communicate with you (through various communication
                  platforms, such as WhatsApp, SMS, phone and email) if you have
                  ordered, purchased or participated in anything on the
                  platforms;
                </li>
                <li>
                  to assist third parties in providing services to you, such as
                  real estate developers, agents, and brokers operating in{" "}
                  {countryInfo.jurisdiction}, or banks with respect of issuing
                  mortgages;
                </li>
                <li>to contact you for market research purposes;</li>
                <li>
                  to monitor communications in order to improve the services we
                  provide to you and assess the performance and responsiveness
                  of our employees and real estate agents in{" "}
                  {countryInfo.jurisdiction};
                </li>
                <li>
                  to provide you with information about new opportunities,
                  promotions, alert notifications, special offers and other
                  information that we may feel is relevant to you in{" "}
                  {countryInfo.jurisdiction};
                </li>
                <li>
                  to customize or enhance your experience on our platforms and
                  services;
                </li>
                <li>
                  to improve our platforms by determining the website's
                  technical design specifications and identifying system
                  performance or problem areas;
                </li>
                <li>
                  to process your payments in {countryInfo.currency} or any
                  documents that you provide via the platforms;
                </li>
                <li>
                  to measure or understand the effectiveness of advertising we
                  serve to you and others, to deliver relevant advertising to
                  you;
                </li>
                <li>
                  to comply with legal obligations in {countryInfo.jurisdiction}
                  .
                </li>
              </ul>
            </section>

            {/* Legal Basis */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                On what basis do we use your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We use your personal information on the following bases (where
                permitted in accordance with {countryInfo.regulations} and
                applicable data protection laws in {countryInfo.jurisdiction}):
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>
                  because the information is necessary for the performance of a
                  contract with you or to take steps at your request to enter
                  into a contract;
                </li>
                <li>
                  because you have given your consent (if we expressly ask for
                  consent to process your personal information, for a specific
                  purpose);
                </li>
                <li>
                  for our legitimate interests. Using your personal information
                  helps us to operate, improve and minimise any disruption to
                  the platforms and the services that we may offer to you;
                </li>
                <li>
                  to comply with legal and regulatory obligations in{" "}
                  {countryInfo.jurisdiction}; or
                </li>
                <li>
                  if you have made the personal information publicly available.
                </li>
              </ul>
            </section>

            {/* Information Sharing */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Who do we share your information with
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                We will only disclose or transfer your personal information for
                the purposes set out in this notice, or as otherwise notified to
                you at the time your personal information is being collected,
                and in accordance with {countryInfo.jurisdiction} law:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700">
                <li>
                  to selected real estate brokers, real estate brokerage firms,
                  agents, developers or other service providers that we use in{" "}
                  {countryInfo.jurisdiction};
                </li>
                <li>
                  to business partners, suppliers and sub-contractors for the
                  performance of any contract we enter into with them or you;
                </li>
                <li>to any member of our group;</li>
                <li>
                  to any competent authorities in {countryInfo.jurisdiction} if
                  we are legally required to comply with a request for data;
                </li>
                <li>
                  to our third-party service providers. We partner with and are
                  supported by service providers around the world;
                </li>
                <li>
                  if we sell or buy any business or assets, in which case we may
                  disclose your personal information to the prospective seller
                  or buyer;
                </li>
                <li>if required in order to obtain professional advice;</li>
                <li>
                  to perform a credit check and to contact other lenders, banks,
                  or financial institutions in {countryInfo.jurisdiction};
                </li>
                <li>
                  if we are under a duty to disclose or share your personal
                  information in order to comply with any legal obligation in{" "}
                  {countryInfo.jurisdiction};
                </li>
                <li>
                  to protect our rights, property, or safety, as well as that of
                  our affiliates, our customers, or others.
                </li>
              </ul>
            </section>

            {/* International Transfers */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Countries to which we transfer your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                The information that we collect from you may be transferred,
                stored and hosted, outside of {countryInfo.jurisdiction}, and
                may be transferred to countries which do not have data
                protection laws equivalent to {countryInfo.jurisdiction} or to
                countries where your privacy and other fundamental rights will
                not be protected as extensively.
              </p>
              <p className="text-gray-700 leading-relaxed">
                We will implement appropriate measures in accordance with{" "}
                {countryInfo.regulations} to ensure that your personal
                information remains protected and secure when it is transferred
                outside {countryInfo.jurisdiction} and you can exercise your
                rights effectively.
              </p>
            </section>

            {/* Security */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                The security of your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Keeping your personal information secure and preventing
                unauthorized access is of utmost priority to us, and we take all
                steps reasonably necessary to protect your personal information
                against any unauthorised access, use, alteration, disclosure or
                destruction in accordance with {countryInfo.regulations}.
              </p>
              <p className="text-gray-700 leading-relaxed mb-4">
                Where we have given you, or where you have created a password
                which is part of our services or allows you to access parts of
                our platforms, you are responsible for keeping this password
                confidential. We ask you not to share your password with anyone.
              </p>
              <p className="text-gray-700 leading-relaxed">
                Unfortunately, the transmission of information via the internet
                is not completely secure. We will do our best to protect your
                personal information, however, we cannot guarantee the security
                of your information transmitted to our platforms.
              </p>
            </section>

            {/* Data Retention */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Keeping your information
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                How long we hold your personal information for will vary, and we
                will typically keep your personal information only for as long
                as is necessary to respond to any queries or complaints, to
                improve the services that we offer to you or to comply with any
                legal obligations to which we may be subject in{" "}
                {countryInfo.jurisdiction}.
              </p>
              <p className="text-gray-700 leading-relaxed">
                To determine the appropriate retention periods for personal
                information, we consider the amount, nature, and sensitivity of
                the personal information, the potential risk of harm from
                unauthorised use or disclosure of your personal information, the
                purposes for which we process your personal information and
                whether we can achieve such purposes through other means, and
                the applicable legal requirements in {countryInfo.jurisdiction}.
              </p>
            </section>

            {/* Your Rights */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Your choices and rights
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                With respect to your personal information which is held by us
                and under our direct control, under certain circumstances and
                under {countryInfo.regulations} and applicable data protection
                laws in {countryInfo.jurisdiction}, you may have the right to:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-700 mb-4">
                <li>
                  <span className="font-medium">Access your data</span> –
                  request a copy of your personal information that we process
                  about you;
                </li>
                <li>
                  <span className="font-medium">Correct your data</span> –
                  request us to amend or update your personal information where
                  it is inaccurate or incomplete;
                </li>
                <li>
                  <span className="font-medium">Erase your data</span> – request
                  us to delete your personal information where it is no longer
                  necessary;
                </li>
                <li>
                  <span className="font-medium">Restrict your data</span> –
                  request us temporarily or permanently to stop processing all
                  or some of your personal data;
                </li>
                <li>
                  <span className="font-medium">
                    Object to the use of your data
                  </span>{" "}
                  – at any time, object to us processing your personal
                  information;
                </li>
                <li>
                  <span className="font-medium">Data portability</span> –
                  request the receipt or transmission of your personal
                  information to another organisation;
                </li>
                <li>
                  <span className="font-medium">Withdraw your consent</span> –
                  withdraw your consent at any time to the use of your personal
                  information for a particular purpose.
                </li>
              </ul>
              <p className="text-gray-700 leading-relaxed">
                For any of the above, please email us at{" "}
                <a
                  href={`mailto:${countryInfo.email}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  {countryInfo.email}
                </a>
                . Subject to any overriding legal obligations, requirements
                and/or exemptions under {countryInfo.jurisdiction} law, we will
                endeavour to respond to your request as soon as possible.
              </p>
            </section>

            {/* Marketing Preferences */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                How to manage your marketing preferences
              </h2>
              <p className="text-gray-700 leading-relaxed">
                To opt out of email marketing, you can use the unsubscribe link
                found in the email communication you receive from us or by
                sending an email to{" "}
                <a
                  href={`mailto:${countryInfo.email}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  {countryInfo.email}
                </a>
                . For other marketing preferences, you can contact us via any
                relevant link in the marketing communication, or by sending an
                email to{" "}
                <a
                  href={`mailto:${countryInfo.email}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  {countryInfo.email}
                </a>
                .
              </p>
            </section>

            {/* Third Party Links */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Hyperlinks
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                Our services may contain links to and may be used by you in
                conjunction with third-party apps, services, tools, and websites
                that are not affiliated with, controlled, or managed by us.
                Examples include but are not limited to Facebook, LinkedIn,
                Twitter and, third-party apps like voice software and readers.
              </p>
              <p className="text-gray-700 leading-relaxed">
                The privacy practices of these third parties will be governed by
                the parties' own privacy policies and may not comply with{" "}
                {countryInfo.jurisdiction} data protection standards. We are not
                responsible for the security or privacy of any information
                collected by these third parties. Information that you provide
                to third-party companies is not covered by this Privacy Policy.
              </p>
            </section>

            {/* Privacy of Minors */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Privacy of minors
              </h2>
              <p className="text-gray-700 leading-relaxed">
                We are committed to protecting the privacy needs of children and
                we encourage parents and guardians to take an active role in
                their children's online activities and interests. We do not
                knowingly collect information from children under{" "}
                {countryInfo.legalAge} years of age in{" "}
                {countryInfo.jurisdiction} and we do not target our platforms to
                children. If you become aware that a child has provided us with
                personal information without the parent or guardian's consent,
                please contact us at{" "}
                <a
                  href={`mailto:${countryInfo.email}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  {countryInfo.email}
                </a>{" "}
                and we will take steps to delete the information from our
                records in accordance with {countryInfo.jurisdiction} law.
              </p>
            </section>

            {/* Policy Updates */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                Updates or changes to this Privacy Policy
              </h2>
              <p className="text-gray-700 leading-relaxed">
                We may update this Privacy Policy from time to time as we deem
                necessary or as required by changes in {countryInfo.regulations}
                . If there are material changes to this Privacy Policy, we will
                provide notice where, and in the manner required, by applicable
                laws in {countryInfo.jurisdiction}, including but not limited to
                by email or via the platforms. Any changes to this Privacy
                Policy take effect immediately after being notified by us.
              </p>
            </section>

            {/* Contact Information */}
            <section>
              <h2 className="text-2xl font-semibold text-[#0b154f] mb-4">
                How do you contact us
              </h2>
              <p className="text-gray-700 leading-relaxed mb-4">
                This Privacy Policy sets out in broad terms how we handle your
                personal information and safeguard your privacy in accordance
                with {countryInfo.jurisdiction} law. If you have any questions
                relating to our Privacy Policy, please send an email to{" "}
                <a
                  href={`mailto:${countryInfo.email}`}
                  className="text-blue-600 hover:text-blue-800"
                >
                  {countryInfo.email}
                </a>{" "}
                or a postal mail to the following address:
              </p>
              <div className="bg-gray-50 p-6 rounded-lg">
                <p className="text-gray-700 font-medium">
                  Data Protection Officer
                  <br />
                  {countryInfo.entity}
                  <br />
                  {countryInfo.address.line1}
                  <br />
                  {countryInfo.address.line2}
                  <br />
                  {countryInfo.address.city}
                </p>
              </div>
            </section>

            {/* Last Updated */}
            <div className="mt-12 pt-8 border-t border-gray-200">
              <p className="text-sm text-gray-500 text-center">
                Last updated: September 13, 2025 | Applicable for{" "}
                {countryInfo.jurisdiction} under {countryInfo.regulations}
              </p>
            </div>
          </div>
        </div>

        {/* Click outside handler */}
        {showCountryDropdown && (
          <div
            className="fixed inset-0 z-5"
            onClick={() => setShowCountryDropdown(false)}
          />
        )}
      </div>
      <PropertyFinderFooter />
    </div>
  );
}
