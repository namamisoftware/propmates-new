import React from "react";
import { Route, Routes } from "react-router-dom";
import Home from "./Home";
import BudgetCalculator from "./Calculator/BudgetCalculator";
import EMICalculator from "./Calculator/EMICalculator";
import LoanEligibility from "./Calculator/LoanEligibility";
import AreaConvertor from "./Calculator/AreaConvertor";
import Details from "./Details";
import Search from "./Search";
import RealEstateDevelopers from "./Developers";
import NewsPage from "./Newspage";
import NewAndOffPlanProjects from "./NewAndOffPlanProjects";
import UpcomingProject from "./UpcomingProject";
import PrivacyPolicy from "./PrivacyPolicy";
import TermsAndConditions from "./TermsAndConditions";
import Rent from "./Rent";
import ScrollToTop from "./Components/ScrollToTop";
import Commercial from "./Commercial";
import OurTeam from "./OurTeam";
import OurTeamDetails from "./OurTeamDetails";
import NewProjects from "./NewProjects";
import Mortgage from "./Calculator/Mortgage";
import MyListings from "./MyListings";
import Profile from "./Profile";
import ListProperty from "./ListProperty";
import { AuthProvider } from "./Components/AuthContext";
import CompanyPage from "./CompanyPage";
import Enquiry from "./Enquiry";
import ContactUs from "./ContactUs";
import Blog from "./Blog";
import BlogDetails from "./BlogDetails";
import SearchNewPage from "./SearchNewPage";
import MylistingsCommercial from "./MylistingsCommercial";
import MyListingsResidential from "./MyListingsResidential";
import MyListingsPG from "./MyListingsPG";
import ListpropertyCommercial from "./ListpropertyCommercial";
import ListpropertyPG from "./ListpropertyPG";
import ListpropertyResidential from "./ListPropertyResidential";
import ListAgricultureLand from "./ListAgricultureLand";
import MyListingsAgriculture from "./MyListingsAgriculture";
import AboveHeader from "./Components/AboveHeader";
import HolidayRentForm from "./HolidayRentForm";
import { LocationProvider } from "./Components/LocationContext";
import ListpropertyHolidayRent from "./ListpropertyHolidayRent";
import MylistingsHolidayRent from "./MylistingsHolidayRent";
import Listpropertybusinessforsale from "./Listpropertybusinessforsale";
import Mylistingsbusinessforsale from "./Mylistingsbusinessforsale";
import NewEnquiry from "./NewEnquiry";
import AllEnquiry from "./AllEnquiry";
import ViewEnquiry from "./ViewEnquiry";
import EditpropertyPG from "./EditpropertyPG";
import EditCommercial from "./EditCommercial";
import EditResidential from "./EditResidential";
import EditAgriculture from "./EditAgriculture";
import EditHolidayRent from "./EditHolidayRent";
import EditBusinessforsale from "./EditBusinessforsale";
import HolidayRent from "./HolidayRent";
import PG from "./PG";
import Agriculture from "./Agriculture";
import BusinessForSale from "./BusinessForSale";
import Help from "./Help";
import BuyOurServices from "./BuyOurServices";
import Packages from "./Packages";

const App = () => {
  return (
    <AuthProvider>
      <LocationProvider>
        <ScrollToTop />
        <AboveHeader />
        <Routes>
          {/* Home Page */}
          <Route path="/" element={<Home />} />

          {/* Individual Calculators */}
          <Route path="/budgetCalculator" element={<BudgetCalculator />} />
          <Route path="/emiCalculator" element={<EMICalculator />} />
          <Route path="/loanEligibility" element={<LoanEligibility />} />
          <Route path="/areaConverter" element={<AreaConvertor />} />
          <Route path="/mortgage" element={<Mortgage />} />

          <Route path="/details/:category/:id" element={<Details />} />
          <Route path="/search" element={<Search />} />
          <Route path="/searchnewpage" element={<SearchNewPage />} />
          <Route path="/rent" element={<Rent />} />
          <Route path="/newprojects" element={<NewProjects />} />
          <Route path="/holidayrent" element={<HolidayRent />} />
          <Route path="/commercial" element={<Commercial />} />
          <Route path="/pg" element={<PG />} />
          <Route path="/agriculture" element={<Agriculture />} />
          <Route path="/businessforsale" element={<BusinessForSale />} />
          <Route path="/developers" element={<RealEstateDevelopers />} />
          <Route path="/newspage" element={<NewsPage />} />
          <Route path="/ourteam" element={<OurTeam />} />
          <Route path="/ourteamdetails/:id" element={<OurTeamDetails />} />
          <Route
            path="/newandoffplanprojects"
            element={<NewAndOffPlanProjects />}
          />
          <Route path="/upcomingproject" element={<UpcomingProject />} />
          <Route path="/privacypolicy" element={<PrivacyPolicy />} />
          <Route path="/termsandconditions" element={<TermsAndConditions />} />

          <Route path="/mylistings" element={<MyListings />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/listproperty" element={<ListProperty />} />
          <Route path="/companypage" element={<CompanyPage />} />

          <Route path="/help" element={<Help />} />
          <Route path="/buyourservices" element={<BuyOurServices />} />
          <Route path="/packages" element={<Packages />} />
          <Route path="/contactus" element={<ContactUs />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blogdetails" element={<BlogDetails />} />
          <Route path="/holidayrentform" element={<HolidayRentForm />} />

          <Route path="/enquiry/addenquiry" element={<Enquiry />} />
          <Route path="/enquiry/newenquiry" element={<NewEnquiry />} />
          <Route path="/enquiry/allenquiry" element={<AllEnquiry />} />
          <Route path="/enquiry/viewenquiry" element={<ViewEnquiry />} />

          <Route
            path="/mylistings/commercial"
            element={<MylistingsCommercial />}
          />
          <Route
            path="/mylistings/residential"
            element={<MyListingsResidential />}
          />
          <Route path="/mylistings/pg" element={<MyListingsPG />} />
          <Route
            path="/mylistings/agriculture"
            element={<MyListingsAgriculture />}
          />
          <Route
            path="/mylistings/holidayrent"
            element={<MylistingsHolidayRent />}
          />
          <Route
            path="/mylistings/businessforsale"
            element={<Mylistingsbusinessforsale />}
          />

          <Route
            path="/listproperty/commercial"
            element={<ListpropertyCommercial />}
          />
          <Route
            path="/listproperty/residential"
            element={<ListpropertyResidential />}
          />
          <Route path="/listproperty/pg" element={<ListpropertyPG />} />
          <Route
            path="/listproperty/agriculture"
            element={<ListAgricultureLand />}
          />
          <Route
            path="/listproperty/holidayrent"
            element={<ListpropertyHolidayRent />}
          />
          <Route
            path="/listproperty/businessforsale"
            element={<Listpropertybusinessforsale />}
          />

          <Route path="/editcommercial" element={<EditCommercial />} />
          <Route path="/editresidential" element={<EditResidential />} />
          <Route path="/editpropertypg" element={<EditpropertyPG />} />
          <Route path="/editagriculture" element={<EditAgriculture />} />
          <Route path="/editholidayrent" element={<EditHolidayRent />} />
          <Route
            path="/editbusinessforsale"
            element={<EditBusinessforsale />}
          />

          <Route path="*" element={<Home />} />
        </Routes>
      </LocationProvider>
    </AuthProvider>
  );
};

export default App;
