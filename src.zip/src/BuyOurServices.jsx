import React, { useState } from "react";
import {
  ShoppingCart,
  Phone,
  User,
  Building2,
  Home,
  Mail,
  PackageCheck,
  Users,
  UserCheck,
} from "lucide-react";
import bgImage from "./assets/searchbg.png";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { useNavigate } from "react-router-dom";

const AdvertiseProperty = () => {
  const navigate = useNavigate();
  const [role, setRole] = useState("Individual");
  const [purpose, setPurpose] = useState("Sell");
  const [propertyType, setPropertyType] = useState("Residential");

  return (
    <>
      <Header />
      <div>
        {/* HERO SECTION */}
        <div className="relative w-full h-[450px]">
          <img
            src={bgImage}
            alt="background"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50"></div>

          {/* CONTENT CENTER */}
          <div className="relative z-10 max-w-6xl mx-auto px-5 pt-12 text-white">
            <p className="text-sm tracking-wide">
              11 Million Property Seekers Are Here!
            </p>
            <h2 className="text-2xl md:text-3xl font-bold mt-1">
              Advertise Your Property With Us
            </h2>

            {/* Option Buttons */}
            <div className="mt-6 space-y-4">
              {/* Role */}
              <div>
                <p className="mb-1 text-sm">I am a</p>
                <div className="flex gap-3 flex-wrap">
                  {["Individual", "Agent", "Builder"].map((item) => (
                    <button
                      key={item}
                      onClick={() => setRole(item)}
                      className={`px-4 py-1.5 rounded-md border ${
                        role === item
                          ? "bg-white text-black font-medium"
                          : "border-white text-white"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {/* Purpose */}
              <div>
                <p className="mb-1 text-sm">I am looking to</p>
                <div className="flex gap-3 flex-wrap">
                  {["Sell", "Rent"].map((item) => (
                    <button
                      key={item}
                      onClick={() => setPurpose(item)}
                      className={`px-4 py-1.5 rounded-md border ${
                        purpose === item
                          ? "bg-white text-black font-medium"
                          : "border-white text-white"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {/* Property Type */}
              <div>
                <p className="mb-1 text-sm">My Property is</p>
                <div className="flex gap-3 flex-wrap">
                  {["Residential", "Commercial"].map((item) => (
                    <button
                      key={item}
                      onClick={() => setPropertyType(item)}
                      className={`px-4 py-1.5 rounded-md border ${
                        propertyType === item
                          ? "bg-white text-black font-medium"
                          : "border-white text-white"
                      }`}
                    >
                      {item}
                    </button>
                  ))}
                </div>
              </div>

              {/* CTA Button */}
              <button
                onClick={() => navigate("/packages")}
                className="mt-4 bg-[#0b154f]  px-6 py-2 rounded text-white font-semibold"
              >
                Show Me Packages
              </button>
            </div>
          </div>

          {/* RIGHT SIDEBAR CARD */}
          {/* <div className="absolute right-10 top-10 bg-white shadow-lg rounded-lg w-[300px] px-4 py-6">
         
          <div className="flex justify-between items-center mb-4">
            <p className="text-sm font-semibold">MY ORDERS</p>
            <button className="bg-red-600 text-white px-4 py-1 text-sm rounded flex items-center gap-1">
              <ShoppingCart size={16} />
              GO TO CART
            </button>
          </div>

         
          <p className="text-sm mb-2 font-medium">
            Talk To Experts: +91 9870 260 930
          </p>

          <p className="font-semibold mt-3 mb-2 text-gray-800">
            Request a Callback
          </p>

          
          <div className="space-y-3">
            <input
              type="text"
              placeholder="Name"
              className="w-full border px-3 py-2 rounded text-sm"
            />

            <div className="flex gap-2">
              <select className="border px-2 py-2 rounded text-sm">
                <option>+91</option>
              </select>
              <input
                type="text"
                placeholder="Mobile"
                className="w-full border px-3 py-2 rounded text-sm"
              />
            </div>

            <input
              type="email"
              placeholder="Email"
              className="w-full border px-3 py-2 rounded text-sm"
            />

            <input
              type="text"
              placeholder="City"
              className="w-full border px-3 py-2 rounded text-sm"
            />

            <textarea
              placeholder="Enter your query..."
              className="w-full border px-3 py-2 rounded text-sm"
              rows="3"
            />

            <label className="flex items-start gap-2 text-xs">
              <input type="checkbox" className="mt-1" />
              <span>
                I agree to Magicbricks T&C, Privacy Policy & Cookie Policy.
              </span>
            </label>

            <button className="w-full bg-red-600 hover:bg-red-700 text-white py-2 rounded font-semibold text-sm">
              Get a Callback
            </button>
          </div>
        </div> */}
        </div>

        {/* BENEFITS SECTION */}
        <div className="max-w-6xl mx-auto px-6 py-12">
          <h3 className="text-lg font-semibold mb-6">Benefits You Get</h3>

          <div className="flex flex-col sm:flex-row gap-8">
            {/* Benefit 1 */}
            <div className="flex gap-4">
              <Users className="h-12 w-12 text-[#0b154f]" />
              <div>
                <h4 className="font-semibold">50,000+ Happy Clients</h4>
                <p className="text-sm text-gray-600">
                  95% of our customers are ‘happy with us’ and over 80%
                  ‘recommend us’.
                </p>
              </div>
            </div>

            {/* Benefit 2 */}
            <div className="flex gap-4">
              <PackageCheck className="h-12 w-12 text-[#0b154f]" />
              <div>
                <h4 className="font-semibold">75,000+ Services Delivered</h4>
                <p className="text-sm text-gray-600">
                  From advertising to legal assistance, we do it all for you.
                </p>
              </div>
            </div>

            {/* Benefit 3 */}
            <div className="flex gap-4">
              <UserCheck className="h-12 w-12 text-[#0b154f]" />
              <div>
                <h4 className="font-semibold">
                  Dedicated Relationship Manager
                </h4>
                <p className="text-sm text-gray-600">
                  Get expert guidance at every selling/ renting stage.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default AdvertiseProperty;
