import React from "react";
import Header from "./Components/Header";
import Navbar from "./Components/Navbar";
import Footer from "./Components/Footer";
import { ChevronLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";

const UpcomingProject = () => {
  const navigate = useNavigate();
  return (
    <div>
      <Header />

      <div className="px-8 md:px-14">
        {/* Navigation Header */}
        <button
          onClick={() => navigate(-1)}
          className="flex mt-4 items-center text-gray-600 hover:text-gray-900 transition-colors"
        >
          <ChevronLeft size={24} className="mr-1" />
          <span className="text-lg font-medium">Back</span>
        </button>

        {/* Main Content */}
        <div className="mt-8">
          {/* Hero Image */}
          <div className="relative mb-8 rounded overflow-hidden shadow-lg">
            <img
              src="https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
              alt="Singapore city skyline at sunset"
              className="w-full h-64 md:h-130 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent"></div>
          </div>

          {/* Project Details */}
          <div className="">
            <h1 className="text-3xl md:text-3xl font-semibold text-gray-900 mb-4">
              Upcoming Project
            </h1>

            <div className="text-gray-700 leading-relaxed">
              <p className="mb-4 text-justify">
                We are delighted to showcase our latest development by Alliances
                Properties, a collection of luxury landed As one of our exciting
                on-sites portfolio Alliances. Join a variety of breathtaking
                villas intended for individuals seeking the ultimate in
                luxurious living plus unique project is poised to become a
                genuine modern art form of luxury and sophistication. Join us on
                their brand experience journey as well. Peaceful beachfront
                access from resort anchored & offers an exceptional lifestyle in
                one of the most sought-after locations on earth. Lorem ipsum
                dolor sit amet consectetur adipisicing elit. Voluptatem enim
                distinctio numquam at laboriosam optio cupiditate voluptatibus,
                vitae reprehenderit placeat?
              </p>
            </div>
          </div>

          {/* Second Project Section */}
          <div className="mt-14">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              {/* Left Column - Modern Building Image */}
              <div className="relative">
                <img
                  src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Modern office building"
                  className="w-full h-64 md:h-80 object-cover rounded"
                />
              </div>

              {/* Right Column - Text Content */}
              <div className="space-y-4">
                <h1 className="text-3xl md:text-3xl font-semibold text-gray-900 mb-4">
                  Upcoming Project
                </h1>
                <div className="text-gray-700 text-justify leading-relaxed text-sm">
                  <p className="mb-4">
                    Palm Jebel Ali Front C is a prestigious real estate
                    development by National Properties. Located one of the
                    unique, Dubai, one of Dubai's most recognizable artificial
                    islands. With a variety of breathtaking villas created for
                    individuals seeking the ultimate in luxurious living this
                    unique project is poised to become a genuine modern art
                    luxury and sophistication. With its vast living areas,
                    modern facilities, and peaceful beachfront access, Palm
                    Jebel Ali Front C offers an exceptional lifestyle in one of
                    the most sought-after locations on earth.
                  </p>

                  <p className="mb-4">
                    A development by National Properties, is situated on Palm
                    Jebel Ali, one of Dubai's most recognizable artificial
                    islands with a variety of breathtaking villas created for
                    individuals seeking the ultimate in luxurious living this
                    unique project is poised to become a genuine emblem of
                    luxury and sophistication. With its vast living areas,
                    modern facilities, and peaceful beachfront access, Palm
                    Jebel Ali Front C offers an exceptional lifestyle in one of
                    the most sought-after locations on earth.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Third Project Section */}
          <div className="my-14 ">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
              {/* Left Column - Text Content */}
              <div className="space-y-4 order-2 lg:order-1">
                <h3 className="text-3xl font-semibold text-gray-900">
                  Upcoming Project
                </h3>
                <div className="text-gray-700 text-justify leading-relaxed text-sm">
                  <p className="mb-4">
                    Palm Jebel Ali Front C is a prestigious real estate
                    development by National Properties. Located one of the
                    unique, Dubai, Dubai is most recognizable artificial
                    islands. With a variety of breathtaking villas created for
                    individuals seeking the ultimate in luxurious living this
                    unique project is poised to become a genuine emblem of
                    luxury and sophistication. With its vast living areas,
                    modern facilities, and peaceful beachfront access.
                  </p>

                  <p>
                    A development by National Properties, is situated on Palm
                    Jebel Ali, one of Dubai's most recognizable artificial
                    islands with a variety of breathtaking villas created for
                    individuals seeking the ultimate in luxurious living this
                    unique project is poised to become a genuine emblem of
                    luxury and sophistication. With its vast living areas,
                    modern facilities, and peaceful beachfront access, Palm
                    Jebel Ali Front C offers an exceptional lifestyle in one of
                    the most sought-after locations on earth.
                  </p>
                </div>
              </div>

              {/* Right Column - City Skyline Image */}
              <div className="relative order-1 lg:order-2">
                <img
                  src="https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=2070&q=80"
                  alt="Dubai city skyline at sunset"
                  className="w-full h-64 md:h-80 object-cover rounded"
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default UpcomingProject;
