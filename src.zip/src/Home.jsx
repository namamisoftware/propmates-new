import React from "react";
import Header from "./Components/Header";
import Navbar from "./Components/Navbar";
import Herosection2 from "./Components/Herosection2";
import CalculatorCards from "./Components/CalculatorCards";
import UpcomingProjects from "./Components/UpcomingProjects";
import WhyUs from "./Components/WhyUs";
import RecentProjects from "./Components/RecentProjects";
import FirstTimeBuyer from "./Components/FirstTimeBuyer";
import RealEstateDevelopers from "./Components/RealEstateDevelopers";
import LatestNews from "./Components/LatestNews";
import Testimonials from "./Components/Testimonials";
import Footer from "./Components/Footer";
import Map from "./Components/Map";
import Experts from "./Components/Experts";
import PropertiesForSale from "./Components/PropertiesForSale";
import PropertiesForRent from "./Components/PropertiesForRent";
import PropertiesForPG from "./Components/PropertiesForPG";
import PropertiesForAgriculture from "./Components/PropertiesForAgriculture";
import AboveFooter from "./Components/AboveFooter";
import TestimonialVideo from "./Components/TestimonialVideo";
import AboveHeader from "./Components/AboveHeader";
import LocationSearch from "./Components/Location";

const App = () => {
  return (
    <div>
      {/* <LocationSearch /> */}
      <Header />
      <Herosection2 />
      {/* <Experts /> */}
      {/* <CalculatorCards /> */}
      <UpcomingProjects />
      <WhyUs />
      {/* <RecentProjects /> */}
      <PropertiesForSale />
      <PropertiesForRent />
      <PropertiesForPG />
      <PropertiesForAgriculture />
      <FirstTimeBuyer />
      <RealEstateDevelopers />
      <LatestNews />
      <Testimonials />
      <TestimonialVideo />
      <Map />
      <AboveFooter />
      <Footer />
    </div>
  );
};

export default App;
