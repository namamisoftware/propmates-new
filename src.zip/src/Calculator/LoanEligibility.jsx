// import React, { useState } from "react";
// import { ArrowLeft, ChevronLeft } from "lucide-react";
// import { PieChart, Pie, Cell, Tooltip } from "recharts";
// import { useNavigate } from "react-router-dom";
// import Header from "../Components/Header";
// import Footer from "../Components/Footer";
// import calc from "../assets/calc.png";

// export default function LoanEligibility() {
//   const navigate = useNavigate();
//   const [loanAmount, setLoanAmount] = useState(3000000);
//   const [tenure, setTenure] = useState(20);
//   const [rate, setRate] = useState(4.5); // UAE typical home loan rate

//   // EMI Formula: EMI = [P × r × (1 + r)^n] / [(1 + r)^n - 1]
//   // Where P = Principal loan amount, r = Monthly interest rate, n = Number of months
//   const monthlyRate = rate / 12 / 100;
//   const numberOfMonths = tenure * 12;

//   const emi =
//     (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numberOfMonths)) /
//     (Math.pow(1 + monthlyRate, numberOfMonths) - 1);

//   const totalPayable = Math.round(emi * numberOfMonths);
//   const interestAmount = totalPayable - loanAmount;

//   const data = [
//     { name: "Principal Amount", value: loanAmount },
//     { name: "Interest Amount", value: interestAmount },
//   ];

//   // Colors from design
//   const COLORS = ["#1d1b4c", "#6fd1c0"];

//   return (
//     <>
//       <Header />
//       <div className="">
//         <div className="flex flex-col lg:flex-row px-4 lg:px-8">
//           {/* Left Column - Scrollable Content */}
//           <div className="flex-1 overflow-y-auto w-full lg:w-[90%]">
//             <div className="p-2 lg:p-4 lg:pr-8">
//               <div className="w-full">
//                 {/* Header */}
//                 <div
//                   onClick={() => navigate(-1)}
//                   className="flex items-center mb-6 lg:mb-8 cursor-pointer"
//                 >
//                   <ChevronLeft className="w-6 h-6 lg:w-7 lg:h-7 mr-1" />
//                   <span className="text-lg lg:text-xl font-semibold">Back</span>
//                 </div>

//                 <div className="w-full bg-white rounded-xl shadow-md grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10">
//                   {/* Left Side - Chart */}
//                   <div className="px-4 lg:px-10 py-6 lg:py-8">
//                     <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6 mb-6 lg:mb-8">
//                       {/* Loan amount */}
//                       <div className="sm:col-span-1">
//                         <label className="block text-sm text-gray-600">
//                           Loan amount (AED)
//                         </label>
//                         <input
//                           type="number"
//                           value={loanAmount}
//                           onChange={(e) =>
//                             setLoanAmount(Number(e.target.value))
//                           }
//                           className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500"
//                         />
//                       </div>
//                       {/* Tenure */}
//                       <div className="sm:col-span-1">
//                         <label className="block text-sm text-gray-600">
//                           Tenure
//                         </label>
//                         <div className="flex items-center">
//                           <input
//                             type="number"
//                             value={tenure}
//                             onChange={(e) => setTenure(Number(e.target.value))}
//                             className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500"
//                           />
//                           <span className="ml-2 mt-1 text-gray-600 whitespace-nowrap">
//                             Years
//                           </span>
//                         </div>
//                       </div>
//                       {/* Rate of Interest */}
//                       <div className="sm:col-span-1">
//                         <label className="block text-sm text-gray-600">
//                           Rate of Interest
//                         </label>
//                         <div className="flex items-center">
//                           <input
//                             type="number"
//                             step="0.1"
//                             value={rate}
//                             onChange={(e) => setRate(Number(e.target.value))}
//                             className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500"
//                           />
//                           <span className="ml-2 mt-1 text-gray-600">%</span>
//                         </div>
//                       </div>
//                     </div>

//                     {/* Pie Chart */}
//                     <div className="flex justify-center">
//                       <PieChart
//                         width={
//                           window.innerWidth < 640
//                             ? 280
//                             : window.innerWidth < 1024
//                             ? 320
//                             : 350
//                         }
//                         height={
//                           window.innerWidth < 640
//                             ? 240
//                             : window.innerWidth < 1024
//                             ? 270
//                             : 300
//                         }
//                       >
//                         <Pie
//                           data={data}
//                           cx="50%"
//                           cy="50%"
//                           labelLine={false}
//                           outerRadius={
//                             window.innerWidth < 640
//                               ? 90
//                               : window.innerWidth < 1024
//                               ? 105
//                               : 120
//                           }
//                           dataKey="value"
//                           animationDuration={1000}
//                           label={({ percent }) =>
//                             `${(percent * 100).toFixed(2)}%`
//                           }
//                         >
//                           {data.map((entry, index) => (
//                             <Cell
//                               key={index}
//                               fill={COLORS[index % COLORS.length]}
//                             />
//                           ))}
//                         </Pie>
//                         <Tooltip
//                           formatter={(value) =>
//                             `AED ${value.toLocaleString("en-AE")}`
//                           }
//                         />
//                       </PieChart>
//                     </div>

//                     {/* Legend */}
//                     <div className="flex flex-col sm:flex-row justify-center mt-4 space-y-3 sm:space-y-0 sm:space-x-6 text-sm">
//                       <div className="flex items-center justify-center sm:justify-start space-x-2">
//                         <div
//                           className="w-4 h-4 rounded-full flex-shrink-0"
//                           style={{ background: COLORS[0] }}
//                         ></div>
//                         <span className="text-center sm:text-left">
//                           Principal Amount <br />
//                           AED {loanAmount.toLocaleString("en-AE")}
//                         </span>
//                       </div>
//                       <div className="flex items-center justify-center sm:justify-start space-x-2">
//                         <div
//                           className="w-4 h-4 rounded-full flex-shrink-0"
//                           style={{ background: COLORS[1] }}
//                         ></div>
//                         <span className="text-center sm:text-left">
//                           Interest Amount <br />
//                           AED {interestAmount.toLocaleString("en-AE")}
//                         </span>
//                       </div>
//                     </div>
//                   </div>

//                   {/* Right Side - EMI Result */}
//                   <div className="flex flex-col items-center justify-center px-4 lg:px-6 py-6 lg:py-0">
//                     <p className="text-gray-500 text-sm mb-2">Monthly EMI</p>
//                     <h2 className="text-2xl lg:text-3xl font-bold mb-4 text-center text-blue-600">
//                       AED{" "}
//                       {emi.toLocaleString("en-AE", {
//                         maximumFractionDigits: 0,
//                       })}
//                     </h2>
//                     <p className="text-gray-500 text-sm mb-2">
//                       Total Payable amount
//                     </p>
//                     <h2 className="text-lg lg:text-xl font-semibold mb-6 text-center">
//                       AED {totalPayable.toLocaleString("en-AE")}
//                     </h2>

//                     <button className="bg-blue-500 text-white py-3 rounded w-full max-w-60 hover:bg-blue-600 transition">
//                       Get instant loan
//                     </button>
//                     <p className="text-gray-500 text-sm mt-3 text-center">
//                       It's easy with Property Finder
//                     </p>
//                   </div>
//                 </div>

//                 {/* About Payment Section */}
//                 <div className="mt-16 lg:mt-38 mb-16 lg:mb-32">
//                   <h2 className="text-2xl lg:text-3xl font-semibold text-gray-900 mb-4 lg:mb-6">
//                     About Payment
//                   </h2>
//                   <p className="text-gray-500 text-base lg:text-lg leading-relaxed">
//                     Palm Jebel Ali Front is a prestigious real estate
//                     development by Nakheel Properties, is situated at the most
//                     Attractive prime popular Dubai Marina location in Dubai UAE.
//                     The development is particularly appealing, making this
//                     ultimate is luxurious living, this exquisite project is
//                     poised to becoming a genuine crossover of luxury and
//                     sophistication. With its calm living atmosphere, facilities,
//                     and beautiful waterfront access, Palm Jebel Ali Front offers
//                     an exceptional lifestyle in one of the most popular living
//                     waterfront locations.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Right Column - Fixed Sidebar */}
//           <div className="hidden lg:block w-full lg:w-[20%] mt-8 lg:mt-0">
//             <div className="sticky top-0 p-4 pb-16 lg:pb-32 overflow-y-auto flex justify-center lg:block">
//               <img
//                 src={calc}
//                 alt="Calculator"
//                 className="w-48 sm:w-56 lg:w-full max-w-xs lg:max-w-none"
//               />
//             </div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// }

import React, { useState, useMemo } from "react";
import { ChevronLeft, ChevronDown, Search } from "lucide-react";
import { PieChart, Pie, Cell, Tooltip } from "recharts";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import calc from "../assets/calc.png";
import { useNavigate } from "react-router-dom";

const useCountryData = () => {
  const [countriesFromPackage] = useState(() => {
    return generateCountriesFromPackage();
  });

  return countriesFromPackage;
};

function generateCountriesFromPackage() {
  const realCountries = [
    {
      code: "AF",
      name: "Afghanistan",
      currency: "AFN",
      region: "Asia",
      rate: 0.12,
    },
    {
      code: "AL",
      name: "Albania",
      currency: "ALL",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "DZ",
      name: "Algeria",
      currency: "DZD",
      region: "Africa",
      rate: 0.09,
    },
    {
      code: "AR",
      name: "Argentina",
      currency: "ARS",
      region: "Americas",
      rate: 0.4,
    },
    {
      code: "AM",
      name: "Armenia",
      currency: "AMD",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "AU",
      name: "Australia",
      currency: "AUD",
      region: "Oceania",
      rate: 0.06,
    },
    {
      code: "AT",
      name: "Austria",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "AZ",
      name: "Azerbaijan",
      currency: "AZN",
      region: "Asia",
      rate: 0.13,
    },
    {
      code: "BH",
      name: "Bahrain",
      currency: "BHD",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "BD",
      name: "Bangladesh",
      currency: "BDT",
      region: "Asia",
      rate: 0.09,
    },
    {
      code: "BY",
      name: "Belarus",
      currency: "BYN",
      region: "Europe",
      rate: 0.14,
    },
    {
      code: "BE",
      name: "Belgium",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "BR",
      name: "Brazil",
      currency: "BRL",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "BG",
      name: "Bulgaria",
      currency: "BGN",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "KH",
      name: "Cambodia",
      currency: "KHR",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "CA",
      name: "Canada",
      currency: "CAD",
      region: "Americas",
      rate: 0.065,
    },
    {
      code: "CL",
      name: "Chile",
      currency: "CLP",
      region: "Americas",
      rate: 0.055,
    },
    { code: "CN", name: "China", currency: "CNY", region: "Asia", rate: 0.055 },
    {
      code: "CO",
      name: "Colombia",
      currency: "COP",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "CR",
      name: "Costa Rica",
      currency: "CRC",
      region: "Americas",
      rate: 0.09,
    },
    {
      code: "HR",
      name: "Croatia",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    {
      code: "CY",
      name: "Cyprus",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CZ",
      name: "Czech Republic",
      currency: "CZK",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "DK",
      name: "Denmark",
      currency: "DKK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "EC",
      name: "Ecuador",
      currency: "USD",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "EG",
      name: "Egypt",
      currency: "EGP",
      region: "Africa",
      rate: 0.15,
    },
    {
      code: "EE",
      name: "Estonia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "ET",
      name: "Ethiopia",
      currency: "ETB",
      region: "Africa",
      rate: 0.14,
    },
    {
      code: "FI",
      name: "Finland",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "FR",
      name: "France",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "GE",
      name: "Georgia",
      currency: "GEL",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "DE",
      name: "Germany",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "GH", name: "Ghana", currency: "GHS", region: "Africa", rate: 0.2 },
    {
      code: "GR",
      name: "Greece",
      currency: "EUR",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "HK",
      name: "Hong Kong",
      currency: "HKD",
      region: "Asia",
      rate: 0.03,
    },
    {
      code: "HU",
      name: "Hungary",
      currency: "HUF",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "IS",
      name: "Iceland",
      currency: "ISK",
      region: "Europe",
      rate: 0.07,
    },
    { code: "IN", name: "India", currency: "INR", region: "Asia", rate: 0.085 },
    {
      code: "ID",
      name: "Indonesia",
      currency: "IDR",
      region: "Asia",
      rate: 0.075,
    },
    { code: "IR", name: "Iran", currency: "IRR", region: "Asia", rate: 0.18 },
    { code: "IQ", name: "Iraq", currency: "IQD", region: "Asia", rate: 0.08 },
    {
      code: "IE",
      name: "Ireland",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "IL", name: "Israel", currency: "ILS", region: "Asia", rate: 0.04 },
    {
      code: "IT",
      name: "Italy",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "JP", name: "Japan", currency: "JPY", region: "Asia", rate: 0.015 },
    {
      code: "JO",
      name: "Jordan",
      currency: "JOD",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "KZ",
      name: "Kazakhstan",
      currency: "KZT",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "KE",
      name: "Kenya",
      currency: "KES",
      region: "Africa",
      rate: 0.13,
    },
    {
      code: "KR",
      name: "South Korea",
      currency: "KRW",
      region: "Asia",
      rate: 0.045,
    },
    { code: "KW", name: "Kuwait", currency: "KWD", region: "Asia", rate: 0.04 },
    {
      code: "LV",
      name: "Latvia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LB",
      name: "Lebanon",
      currency: "LBP",
      region: "Asia",
      rate: 0.08,
    },
    {
      code: "LT",
      name: "Lithuania",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LU",
      name: "Luxembourg",
      currency: "EUR",
      region: "Europe",
      rate: 0.03,
    },
    {
      code: "MY",
      name: "Malaysia",
      currency: "MYR",
      region: "Asia",
      rate: 0.04,
    },
    {
      code: "MT",
      name: "Malta",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "MX",
      name: "Mexico",
      currency: "MXN",
      region: "Americas",
      rate: 0.095,
    },
    {
      code: "MA",
      name: "Morocco",
      currency: "MAD",
      region: "Africa",
      rate: 0.055,
    },
    {
      code: "NL",
      name: "Netherlands",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "NZ",
      name: "New Zealand",
      currency: "NZD",
      region: "Oceania",
      rate: 0.065,
    },
    {
      code: "NG",
      name: "Nigeria",
      currency: "NGN",
      region: "Africa",
      rate: 0.18,
    },
    {
      code: "NO",
      name: "Norway",
      currency: "NOK",
      region: "Europe",
      rate: 0.045,
    },
    { code: "OM", name: "Oman", currency: "OMR", region: "Asia", rate: 0.045 },
    {
      code: "PK",
      name: "Pakistan",
      currency: "PKR",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "PE",
      name: "Peru",
      currency: "PEN",
      region: "Americas",
      rate: 0.08,
    },
    {
      code: "PH",
      name: "Philippines",
      currency: "PHP",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "PL",
      name: "Poland",
      currency: "PLN",
      region: "Europe",
      rate: 0.07,
    },
    {
      code: "PT",
      name: "Portugal",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "QA", name: "Qatar", currency: "QAR", region: "Asia", rate: 0.045 },
    {
      code: "RO",
      name: "Romania",
      currency: "RON",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "RU",
      name: "Russia",
      currency: "RUB",
      region: "Europe",
      rate: 0.12,
    },
    {
      code: "SA",
      name: "Saudi Arabia",
      currency: "SAR",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "RS",
      name: "Serbia",
      currency: "RSD",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "SG",
      name: "Singapore",
      currency: "SGD",
      region: "Asia",
      rate: 0.035,
    },
    {
      code: "SK",
      name: "Slovakia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "SI",
      name: "Slovenia",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "ZA",
      name: "South Africa",
      currency: "ZAR",
      region: "Africa",
      rate: 0.11,
    },
    {
      code: "ES",
      name: "Spain",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LK",
      name: "Sri Lanka",
      currency: "LKR",
      region: "Asia",
      rate: 0.14,
    },
    {
      code: "SE",
      name: "Sweden",
      currency: "SEK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CH",
      name: "Switzerland",
      currency: "CHF",
      region: "Europe",
      rate: 0.025,
    },
    {
      code: "TW",
      name: "Taiwan",
      currency: "TWD",
      region: "Asia",
      rate: 0.025,
    },
    {
      code: "TH",
      name: "Thailand",
      currency: "THB",
      region: "Asia",
      rate: 0.045,
    },
    { code: "TR", name: "Turkey", currency: "TRY", region: "Asia", rate: 0.25 },
    {
      code: "UA",
      name: "Ukraine",
      currency: "UAH",
      region: "Europe",
      rate: 0.16,
    },
    {
      code: "AE",
      name: "United Arab Emirates",
      currency: "AED",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "GB",
      name: "United Kingdom",
      currency: "GBP",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "US",
      name: "United States",
      currency: "USD",
      region: "Americas",
      rate: 0.07,
    },
    {
      code: "UY",
      name: "Uruguay",
      currency: "UYU",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "VE",
      name: "Venezuela",
      currency: "VES",
      region: "Americas",
      rate: 0.35,
    },
    {
      code: "VN",
      name: "Vietnam",
      currency: "VND",
      region: "Asia",
      rate: 0.08,
    },
  ];

  return realCountries;
}

export default function LoanEligibility() {
  const navigate = useNavigate();
  const countriesData = useCountryData();
  const [selectedCountryCode, setSelectedCountryCode] = useState("AE");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [loanAmount, setLoanAmount] = useState(3000000);
  const [tenure, setTenure] = useState(20);

  // Get current country config
  const countryConfig = useMemo(() => {
    return (
      countriesData.find((c) => c.code === selectedCountryCode) ||
      countriesData[0]
    );
  }, [selectedCountryCode, countriesData]);

  const rate = countryConfig.rate * 100;

  // Filter countries based on search
  const filteredCountries = useMemo(() => {
    if (!searchQuery.trim()) return countriesData;
    const query = searchQuery.toLowerCase();
    return countriesData.filter(
      (country) =>
        country.name.toLowerCase().includes(query) ||
        country.currency.toLowerCase().includes(query) ||
        country.code.toLowerCase().includes(query) ||
        country.region.toLowerCase().includes(query)
    );
  }, [searchQuery, countriesData]);

  // Group countries by region
  const groupedCountries = useMemo(() => {
    const groups = {};
    filteredCountries.forEach((country) => {
      if (!groups[country.region]) {
        groups[country.region] = [];
      }
      groups[country.region].push(country);
    });
    return groups;
  }, [filteredCountries]);

  const handleCountryChange = (countryCode) => {
    setSelectedCountryCode(countryCode);
    setIsDropdownOpen(false);
    setSearchQuery("");
  };

  // EMI Formula: EMI = [P × r × (1 + r)^n] / [(1 + r)^n - 1]
  const monthlyRate = rate / 12 / 100;
  const numberOfMonths = tenure * 12;

  const emi =
    (loanAmount * monthlyRate * Math.pow(1 + monthlyRate, numberOfMonths)) /
    (Math.pow(1 + monthlyRate, numberOfMonths) - 1);

  const totalPayable = Math.round(emi * numberOfMonths);
  const interestAmount = totalPayable - loanAmount;

  const data = [
    { name: "Principal Amount", value: loanAmount },
    { name: "Interest Amount", value: interestAmount },
  ];

  const COLORS = ["#1d1b4c", "#6fd1c0"];

  return (
    <>
      <Header />
      <div className="">
        <div className="flex flex-col lg:flex-row px-4 lg:px-8">
          {/* Left Column - Scrollable Content */}
          <div className="flex-1 overflow-y-auto w-full lg:w-[90%]">
            <div className="p-2 lg:p-4 lg:pr-8">
              <div className="w-full">
                {/* Header with Back button and Country Dropdown */}
                <div className="flex items-center justify-between mb-6 lg:mb-8">
                  <div
                    onClick={() => navigate(-1)}
                    className="flex items-center cursor-pointer"
                  >
                    <ChevronLeft className="w-6 h-6 lg:w-7 lg:h-7 mr-1" />
                    <span className="text-lg lg:text-xl font-semibold">
                      Back
                    </span>
                  </div>

                  {/* Country Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                      className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <span className="font-medium text-sm lg:text-base">
                        {countryConfig.currency}
                      </span>
                      <ChevronDown className="w-4 h-4" />
                    </button>

                    {isDropdownOpen && (
                      <div className="absolute right-0 mt-2 w-72 bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-96 overflow-hidden flex flex-col">
                        <div className="p-3 border-b border-gray-200 sticky top-0 bg-white">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input
                              type="text"
                              placeholder="Search country..."
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                        </div>

                        <div className="overflow-y-auto">
                          {Object.entries(groupedCountries).map(
                            ([region, countries]) => (
                              <div key={region}>
                                <div className="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-600 sticky top-0">
                                  {region}
                                </div>
                                {countries.map((country) => (
                                  <button
                                    key={country.code}
                                    onClick={() =>
                                      handleCountryChange(country.code)
                                    }
                                    className={`w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors ${
                                      selectedCountryCode === country.code
                                        ? "bg-gray-100"
                                        : ""
                                    }`}
                                  >
                                    <div className="text-sm font-medium">
                                      {country.name}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {country.currency} •{" "}
                                      {(country.rate * 100).toFixed(1)}% rate
                                    </div>
                                  </button>
                                ))}
                              </div>
                            )
                          )}

                          {filteredCountries.length === 0 && (
                            <div className="p-4 text-center text-gray-500 text-sm">
                              No countries found
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="w-full bg-white rounded-xl shadow-md grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-10">
                  {/* Left Side - Chart */}
                  <div className="px-4 lg:px-10 py-6 lg:py-8">
                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 lg:gap-6 mb-6 lg:mb-8">
                      {/* Loan amount */}
                      <div className="sm:col-span-1">
                        <label className="block text-sm text-gray-600">
                          Loan amount ({countryConfig.currency})
                        </label>
                        <input
                          type="number"
                          value={loanAmount}
                          onChange={(e) =>
                            setLoanAmount(Number(e.target.value))
                          }
                          className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500"
                        />
                      </div>
                      {/* Tenure */}
                      <div className="sm:col-span-1">
                        <label className="block text-sm text-gray-600">
                          Tenure
                        </label>
                        <div className="flex items-center">
                          <input
                            type="number"
                            value={tenure}
                            onChange={(e) => setTenure(Number(e.target.value))}
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500"
                          />
                          <span className="ml-2 mt-1 text-gray-600 whitespace-nowrap">
                            Years
                          </span>
                        </div>
                      </div>
                      {/* Rate of Interest */}
                      <div className="sm:col-span-1">
                        <label className="block text-sm text-gray-600">
                          Rate of Interest
                        </label>
                        <div className="flex items-center">
                          <input
                            type="number"
                            step="0.1"
                            value={rate.toFixed(1)}
                            readOnly
                            className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 focus:outline-blue-500 bg-gray-50"
                          />
                          <span className="ml-2 mt-1 text-gray-600">%</span>
                        </div>
                      </div>
                    </div>

                    {/* Pie Chart */}
                    <div className="flex justify-center">
                      <PieChart
                        width={
                          window.innerWidth < 640
                            ? 280
                            : window.innerWidth < 1024
                            ? 320
                            : 350
                        }
                        height={
                          window.innerWidth < 640
                            ? 240
                            : window.innerWidth < 1024
                            ? 270
                            : 300
                        }
                      >
                        <Pie
                          data={data}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          outerRadius={
                            window.innerWidth < 640
                              ? 90
                              : window.innerWidth < 1024
                              ? 105
                              : 120
                          }
                          dataKey="value"
                          animationDuration={1000}
                          label={({ percent }) =>
                            `${(percent * 100).toFixed(2)}%`
                          }
                        >
                          {data.map((entry, index) => (
                            <Cell
                              key={index}
                              fill={COLORS[index % COLORS.length]}
                            />
                          ))}
                        </Pie>
                        <Tooltip
                          formatter={(value) =>
                            `${countryConfig.currency} ${value.toLocaleString(
                              "en-AE"
                            )}`
                          }
                        />
                      </PieChart>
                    </div>

                    {/* Legend */}
                    <div className="flex flex-col sm:flex-row justify-center mt-4 space-y-3 sm:space-y-0 sm:space-x-6 text-sm">
                      <div className="flex items-center justify-center sm:justify-start space-x-2">
                        <div
                          className="w-4 h-4 rounded-full flex-shrink-0"
                          style={{ background: COLORS[0] }}
                        ></div>
                        <span className="text-center sm:text-left">
                          Principal Amount <br />
                          {countryConfig.currency}{" "}
                          {loanAmount.toLocaleString("en-AE")}
                        </span>
                      </div>
                      <div className="flex items-center justify-center sm:justify-start space-x-2">
                        <div
                          className="w-4 h-4 rounded-full flex-shrink-0"
                          style={{ background: COLORS[1] }}
                        ></div>
                        <span className="text-center sm:text-left">
                          Interest Amount <br />
                          {countryConfig.currency}{" "}
                          {interestAmount.toLocaleString("en-AE")}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right Side - EMI Result */}
                  <div className="flex flex-col items-center justify-center px-4 lg:px-6 py-6 lg:py-0">
                    <p className="text-gray-500 text-sm mb-2">Monthly EMI</p>
                    <h2 className="text-2xl lg:text-3xl font-bold mb-4 text-center text-blue-600">
                      {countryConfig.currency}{" "}
                      {emi.toLocaleString("en-AE", {
                        maximumFractionDigits: 0,
                      })}
                    </h2>
                    <p className="text-gray-500 text-sm mb-2">
                      Total Payable amount
                    </p>
                    <h2 className="text-lg lg:text-xl font-semibold mb-6 text-center">
                      {countryConfig.currency}{" "}
                      {totalPayable.toLocaleString("en-AE")}
                    </h2>

                    <button className="bg-blue-500 text-white py-3 rounded w-full max-w-60 hover:bg-blue-600 transition">
                      Get instant loan
                    </button>
                    <p className="text-gray-500 text-sm mt-3 text-center">
                      It's easy with Property Finder
                    </p>
                  </div>
                </div>

                {/* About Payment Section */}
                <div className="mt-16 lg:mt-38 mb-16 lg:mb-32">
                  <h2 className="text-2xl lg:text-3xl font-semibold text-gray-900 mb-4 lg:mb-6">
                    About Payment
                  </h2>
                  <p className="text-gray-500 text-base lg:text-lg leading-relaxed">
                    Palm Jebel Ali Front is a prestigious real estate
                    development by Nakheel Properties, is situated at the most
                    Attractive prime popular Dubai Marina location in Dubai UAE.
                    The development is particularly appealing, making this
                    ultimate is luxurious living, this exquisite project is
                    poised to becoming a genuine crossover of luxury and
                    sophistication. With its calm living atmosphere, facilities,
                    and beautiful waterfront access, Palm Jebel Ali Front offers
                    an exceptional lifestyle in one of the most popular living
                    waterfront locations.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Fixed Sidebar */}
          <div className="hidden lg:block w-full lg:w-[20%] mt-8 lg:mt-0">
            <div className="sticky top-0 p-4 pb-16 lg:pb-32 overflow-y-auto flex justify-center lg:block">
              <img
                src={calc}
                alt="Calculator"
                className="w-48 sm:w-56 lg:w-full max-w-xs lg:max-w-none"
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
