import { useRef, useState } from "react";
import {
  Home,
  ChevronDown,
  ChevronLeft,
  Star,
  CheckCircle,
  Search,
  FileText,
  DollarSign,
  Key,
  ChevronRight,
} from "lucide-react";
import { Country } from "country-state-city";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import Navbar from "../Components/Navbar";
import { useNavigate } from "react-router-dom";

export default function MortgageCalculator() {
  const navigate = useNavigate();
  const [purchasePrice, setPurchasePrice] = useState(61150000);
  const [residencyStatus, setResidencyStatus] = useState("UAE national");
  const [downPayment, setDownPayment] = useState(15287500);
  const [downPaymentPercent, setDownPaymentPercent] = useState(25);
  const [loanAmount, setLoanAmount] = useState(45862500);
  const [loanPercent, setLoanPercent] = useState(75);
  const [loanPeriod, setLoanPeriod] = useState(25);
  const [interestRate, setInterestRate] = useState(4.24);
  const [selectedCountry, setSelectedCountry] = useState({
    isoCode: "AE",
    phonecode: "971",
  });
  const [isCountryDropdownOpen, setIsCountryDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const countries = Country.getAllCountries();

  const scrollContainerRef = useRef(null);

  const steps = [
    {
      number: 1,
      title: "Planning",
      description:
        "Use this calculator for your deposit: 15% for locals, 20% for expats, and 40% for non-residents or second home buyers. Keep in mind your budget for extra costs like agent fees (2%), transfer tax (4%), and other expenses such as trustee office, mortgage registration, and valuation.",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/budget-illustration.svg",
    },
    {
      number: 2,
      title: "Get pre-approval",
      description:
        "We advise all the necessary details to determine your borrowing limit. You receive our mortgage pre-approval so you can find your specific financial needs. We send the required documents for submission to the bank and handle any queries from a top vet. Result: saving you the hassle.",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/pre-approval-illustration.svg",
    },
    {
      number: 3,
      title: "Find property",
      description:
        "If you're still searching for your dream home, explore properties within your pre-approved range on Property Finder with insights on buildings, communities, and other pertinent information.",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/house-landscape-illustration.svg",
    },
    {
      number: 4,
      title: "Offer and valuation",
      description:
        "Upon finding the ideal property, make an offer. If accepted, the agent will draft an MOU (Memorandum of Understanding). Ensure Mortgage Finder's advisor reviews it. The agent supplies all necessary documents and property access details. After you pay the valuation fee, we handle the rest with the lender.",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/offer-illustration.svg",
    },
    {
      number: 5,
      title: "Final disbursement",
      description:
        "We'll assess your valuation report and final offer letter. Set up a bank account for mortgage payments; we'll advise on the amount. Sometimes, a manager's cheque and bank-required life insurance are necessary. Lastly, secure an NOC from the developer to ensure no seller debts and possibly a liability letter.",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/disbursement-illustration.svg",
    },
    {
      number: 6,
      title: "Get those keys",
      description:
        "We will liaise with all parties involved to arrange a suitable day for the transfer of the property. Congrats, home owner!",
      image:
        "https://static-assets.propertyfinder.com/images/mortgage/home-keys-illustration.svg",
    },
  ];

  const reviews = [
    {
      id: 1,
      text: "I would like to thank Mr Omar and Marry for their hard work, honestly, professionalism and continues support. It was a long journey, they were with me in every step which made the process so easy.",
      author: "Tarek Bassem",
      date: "26 Oct 2023",
    },
    {
      id: 2,
      text: "Outstanding service! The team went above and beyond to ensure everything was handled professionally. I couldn't be happier with the results and would highly recommend them to anyone.",
      author: "Sarah Johnson",
      date: "15 Nov 2023",
    },
    {
      id: 3,
      text: "Exceptional experience from start to finish. The attention to detail and customer care was remarkable. They made a complex process feel simple and stress-free.",
      author: "Michael Chen",
      date: "03 Dec 2023",
    },
    {
      id: 4,
      text: "I'm thoroughly impressed with the level of professionalism and expertise. The team was responsive, knowledgeable, and truly cared about my satisfaction. Five stars all the way!",
      author: "Emma Williams",
      date: "18 Jan 2024",
    },
    {
      id: 5,
      text: "Working with this team was a pleasure. They were patient, understanding, and always available to answer my questions. The results exceeded my expectations!",
      author: "David Martinez",
      date: "22 Feb 2024",
    },
  ];

  const scroll = (direction) => {
    if (scrollContainerRef.current) {
      const scrollAmount = 350;
      const newScrollLeft =
        direction === "left"
          ? scrollContainerRef.current.scrollLeft - scrollAmount
          : scrollContainerRef.current.scrollLeft + scrollAmount;

      scrollContainerRef.current.scrollTo({
        left: newScrollLeft,
        behavior: "smooth",
      });
    }
  };

  const handlePurchasePriceChange = (value) => {
    const price = Number(value);
    setPurchasePrice(price);
    const downPmt = (price * downPaymentPercent) / 100;
    setDownPayment(downPmt);
    setLoanAmount(price - downPmt);
  };

  const handleDownPaymentChange = (value) => {
    const amount = Number(value);
    setDownPayment(amount);
    const percent = (amount / purchasePrice) * 100;
    setDownPaymentPercent(Math.round(percent));
    setLoanAmount(purchasePrice - amount);
    setLoanPercent(100 - Math.round(percent));
  };

  const handleLoanAmountChange = (value) => {
    const amount = Number(value);
    setLoanAmount(amount);
    const percent = (amount / purchasePrice) * 100;
    setLoanPercent(Math.round(percent));
    setDownPayment(purchasePrice - amount);
    setDownPaymentPercent(100 - Math.round(percent));
  };

  const calculateMonthlyPayment = () => {
    const monthlyRate = interestRate / 100 / 12;
    const numberOfPayments = loanPeriod * 12;
    const monthlyPayment =
      (loanAmount *
        (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
      (Math.pow(1 + monthlyRate, numberOfPayments) - 1);
    return monthlyPayment.toLocaleString("en-US", { maximumFractionDigits: 0 });
  };

  const formatNumber = (num) => {
    return num.toLocaleString("en-US");
  };

  const filteredCountries = Array.isArray(countries)
    ? countries.filter((country) => {
        const q = searchQuery.trim().toLowerCase();
        if (!q) return true;
        return (
          country.name?.toLowerCase().includes(q) ||
          country.value?.toLowerCase().includes(q) ||
          country.isoCode?.toLowerCase().includes(q) ||
          country.phonecode?.toString().includes(q)
        );
      })
    : [];

  const minPurchasePrice = 300000;
  const maxPurchasePrice = 200000000;
  const minDownPayment = purchasePrice * 0.15;
  const maxDownPayment = purchasePrice * 0.8;
  const minLoanAmount = purchasePrice * 0.2;
  const maxLoanAmount = purchasePrice * 0.85;

  const [currentIndex, setCurrentIndex] = useState(0);

  const handlePrevious = () => {
    setCurrentIndex((prev) => (prev === 0 ? reviews.length - 1 : prev - 1));
  };

  const handleNext = () => {
    setCurrentIndex((prev) => (prev === reviews.length - 1 ? 0 : prev + 1));
  };

  const currentReview = reviews[currentIndex];

  return (
    <div className="">
      <Header />
      <Navbar />
      <div className="max-w-8xl mx-auto px-20">
        <div
          onClick={() => navigate(-1)}
          className="flex items-center mb-6 lg:mb-8 cursor-pointer"
        >
          <ChevronLeft className="w-6 h-6 lg:w-7 lg:h-7 mr-1" />
          <span className="text-lg lg:text-xl font-semibold">Back</span>
        </div>

        <h1 className="text-3xl md:text-4xl font-bold text-center mb-12">
          Get the right mortgage for you
        </h1>

        <div className="grid lg:grid-cols-2 gap-20">
          {/* Left Column - Calculator Inputs */}
          <div className="space-y-5">
            {/* Purchase Price */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Purchase price
              </label>

              <div className="relative">
                {/* Text Input */}
                <input
                  type="text"
                  value={formatNumber(purchasePrice)}
                  onChange={(e) =>
                    handlePurchasePriceChange(e.target.value.replace(/,/g, ""))
                  }
                  className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />

                {/* Slider */}
                <input
                  type="range"
                  min={minPurchasePrice}
                  max={maxPurchasePrice}
                  value={purchasePrice}
                  onChange={(e) => handlePurchasePriceChange(e.target.value)}
                  className="absolute bottom-0 left-0 right-0 w-full h-1 appearance-none bg-transparent cursor-pointer z-20 accent-indigo-600"
                />

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300"
                    style={{
                      width: `${
                        ((purchasePrice - minPurchasePrice) /
                          (maxPurchasePrice - minPurchasePrice)) *
                        100
                      }%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>300,000 AED</span>
                <span>200,000,000 AED</span>
              </div>
            </div>

            {/* Residency Status */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Residency status
              </label>
              <div className="grid grid-cols-3 gap-3">
                <button
                  onClick={() => setResidencyStatus("UAE national")}
                  className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    residencyStatus === "UAE national"
                      ? "bg-white text-gray-900 border-2 border-indigo-600 shadow-sm"
                      : "bg-white border-2 border-gray-200 text-gray-700 hover:border-gray-300"
                  }`}
                >
                  UAE national
                </button>
                <button
                  onClick={() => setResidencyStatus("UAE resident")}
                  className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    residencyStatus === "UAE resident"
                      ? "bg-white text-gray-900 border-2 border-indigo-600 shadow-sm"
                      : "bg-white border-2 border-gray-200 text-gray-700 hover:border-gray-300"
                  }`}
                >
                  UAE resident
                </button>
                <button
                  onClick={() => setResidencyStatus("Non-resident")}
                  className={`px-4 py-3 rounded-lg text-sm font-medium transition-all ${
                    residencyStatus === "Non-resident"
                      ? "bg-white text-gray-900 border-2 border-indigo-600 shadow-sm"
                      : "bg-white border-2 border-gray-200 text-gray-700 hover:border-gray-300"
                  }`}
                >
                  Non-resident
                </button>
              </div>
            </div>

            {/* Down Payment */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Down payment
              </label>

              <div className="relative">
                {/* Text Input */}
                <input
                  type="text"
                  value={formatNumber(downPayment)}
                  onChange={(e) =>
                    handleDownPaymentChange(e.target.value.replace(/,/g, ""))
                  }
                  className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pr-16"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-600 font-semibold">
                  {downPaymentPercent}%
                </span>

                {/* Slider */}
                <input
                  type="range"
                  min={minDownPayment}
                  max={maxDownPayment}
                  value={downPayment}
                  onChange={(e) => handleDownPaymentChange(e.target.value)}
                  className="absolute bottom-0 left-0 right-0 w-full h-1 appearance-none bg-transparent cursor-pointer z-20 accent-indigo-600"
                />

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300"
                    style={{
                      width: `${
                        ((downPayment - minDownPayment) /
                          (maxDownPayment - minDownPayment)) *
                        100
                      }%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{formatNumber(Math.round(minDownPayment))} AED</span>
                <span>{formatNumber(Math.round(maxDownPayment))} AED</span>
              </div>
            </div>

            {/* Loan Amount */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Loan amount
              </label>

              <div className="relative">
                {/* Text Input */}
                <input
                  type="text"
                  value={formatNumber(loanAmount)}
                  onChange={(e) =>
                    handleLoanAmountChange(e.target.value.replace(/,/g, ""))
                  }
                  className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pr-16"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-indigo-600 font-semibold">
                  {loanPercent}%
                </span>

                {/* Slider */}
                <input
                  type="range"
                  min={minLoanAmount}
                  max={maxLoanAmount}
                  value={loanAmount}
                  onChange={(e) => handleLoanAmountChange(e.target.value)}
                  className="absolute bottom-0 left-0 right-0 w-full h-1 appearance-none bg-transparent cursor-pointer z-20 accent-indigo-600"
                />

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300"
                    style={{
                      width: `${
                        ((loanAmount - minLoanAmount) /
                          (maxLoanAmount - minLoanAmount)) *
                        100
                      }%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>{formatNumber(Math.round(minLoanAmount))} AED</span>
                <span>{formatNumber(Math.round(maxLoanAmount))} AED</span>
              </div>
            </div>

            {/* Loan Period */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Loan period
              </label>

              <div className="relative">
                {/* Text Input */}
                <input
                  type="text"
                  value={loanPeriod}
                  onChange={(e) => setLoanPeriod(Number(e.target.value))}
                  className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />

                {/* Slider */}
                <input
                  type="range"
                  min={1}
                  max={25}
                  value={loanPeriod}
                  onChange={(e) => setLoanPeriod(Number(e.target.value))}
                  className="absolute bottom-0 left-0 right-0 w-full h-1 appearance-none bg-transparent cursor-pointer z-20 accent-indigo-600"
                />

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300"
                    style={{
                      width: `${((loanPeriod - 1) / (25 - 1)) * 100}%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>1 year</span>
                <span>25 years</span>
              </div>
            </div>

            {/* Interest Rate */}
            <div>
              <label className="block text-base font-semibold text-gray-900 mb-2">
                Interest rate
              </label>

              <div className="relative">
                {/* Text Input */}
                <input
                  type="text"
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="w-full px-4 py-3 text-lg border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pr-12"
                />
                <span className="absolute right-4 top-1/2 -translate-y-1/2 text-gray-500">
                  %
                </span>

                {/* Slider */}
                <input
                  type="range"
                  min={1}
                  max={10}
                  step={0.01}
                  value={interestRate}
                  onChange={(e) => setInterestRate(Number(e.target.value))}
                  className="absolute bottom-0 left-0 right-0 w-full h-1 appearance-none bg-transparent cursor-pointer z-20 accent-indigo-600"
                />

                {/* Progress Bar */}
                <div className="absolute bottom-0 left-0 right-0 h-1 bg-gray-200 rounded-b-lg overflow-hidden">
                  <div
                    className="h-full bg-indigo-600 transition-all duration-300"
                    style={{
                      width: `${((interestRate - 1) / (10 - 1)) * 100}%`,
                    }}
                  />
                </div>
              </div>

              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>1%</span>
                <span>10%</span>
              </div>
            </div>
          </div>

          {/* Right Column - Quote Form */}
          <div className="space-y-6">
            <div className="bg-white rounded-xl shadow-sm p-8 border border-gray-100">
              <h3 className="text-lg font-semibold text-gray-900 mb-6">
                Estimate your monthly mortgage payment
              </h3>

              <div className="flex flex-row items-center justify-center gap-6 mb-8">
                <div>
                  <div className="text-sm text-gray-600 mb-2">
                    monthly payment
                  </div>
                  <div className="text-3xl font-semibold text-gray-900">
                    {calculateMonthlyPayment()} AED
                  </div>
                </div>
                <div>
                  <div className="text-sm text-gray-600 mb-2">
                    with interest rate of
                  </div>
                  <div className="text-3xl font-semibold text-gray-900">
                    {interestRate}%
                  </div>
                </div>
              </div>

              <div className="flex justify-center">
                <button className="text-indigo-600 text-sm font-medium mb-8 hover:text-indigo-700 border border-indigo-600 px-6 py-2 rounded-lg hover:bg-indigo-50 transition-colors">
                  View upfront costs
                </button>
              </div>

              <div className="text-lg text-center font-semibold text-gray-600 mb-4">
                Please enter your details
              </div>

              <div className="space-y-4">
                <input
                  type="text"
                  placeholder="Name"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
                <input
                  type="email"
                  placeholder="Email"
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                />
                <div className="flex gap-3 items-stretch">
                  {/* Country Selector */}
                  <div className="relative w-26">
                    <button
                      onClick={() =>
                        setIsCountryDropdownOpen((prev) => {
                          const next = !prev;
                          // clear search when dropdown closes
                          if (!next) setSearchQuery("");
                          return next;
                        })
                      }
                      className="flex items-center gap-2 px-4 py-3 border border-gray-300 rounded-lg bg-white hover:bg-gray-50 transition-colors h-full w-full justify-between"
                    >
                      <img
                        src={`https://flagcdn.com/w20/${selectedCountry.isoCode.toLowerCase()}.png`}
                        alt=""
                        className="w-5 h-3 rounded-sm border"
                      />
                      <ChevronDown className="w-4 h-4 text-gray-400" />
                    </button>

                    {isCountryDropdownOpen && (
                      <div className="absolute top-full left-0 mt-2 w-80 max-h-96 overflow-y-auto bg-white border border-gray-300 rounded-lg shadow-lg z-50">
                        {/* Search Box */}
                        <div className="p-2 border-b border-gray-200 sticky top-0 bg-white z-10">
                          <input
                            type="text"
                            placeholder="Search country..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full px-3 py-2 border border-gray-300 rounded-md text-sm focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                          />
                        </div>

                        {/* Filtered Country List */}
                        {filteredCountries.map((country) => (
                          <button
                            key={country.isoCode}
                            onClick={() => {
                              setSelectedCountry({
                                isoCode: country.isoCode,
                                phonecode: country.phonecode,
                              });
                              setIsCountryDropdownOpen(false);
                              setSearchQuery("");
                            }}
                            className="w-full flex items-center gap-3 px-4 py-3 hover:bg-gray-50 transition-colors text-left"
                          >
                            <div className="flex items-center gap-2">
                              <img
                                src={`https://flagcdn.com/w20/${country.isoCode.toLowerCase()}.png`}
                                alt=""
                                className="w-5 h-3 rounded-sm border"
                              />
                              <span>{country.value}</span>
                            </div>
                            <span className="text-sm text-gray-700 flex-1">
                              {country.name}
                            </span>
                            <span className="text-sm text-gray-500">
                              +{country.phonecode}
                            </span>
                          </button>
                        ))}

                        {filteredCountries.length === 0 && (
                          <div className="p-4 text-sm text-gray-500">
                            No countries found
                          </div>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Phone Input */}
                  <div className="flex-1 relative">
                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 text-sm font-medium pointer-events-none">
                      +{selectedCountry.phonecode}
                    </span>
                    <input
                      type="tel"
                      placeholder="Phone number"
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-indigo-500 focus:border-transparent pl-20 h-full"
                    />
                  </div>
                </div>

                <button
                  onClick={(e) => e.preventDefault()}
                  className="w-full bg-[#0B154F] text-white py-3.5 rounded-lg font-medium transition-colors text-lg"
                >
                  Get a mortgage quote
                </button>
              </div>
            </div>

            <div className="bg-gradient-to-br from-yellow-50 via-orange-50 to-blue-50 rounded-xl p-6 flex items-center justify-between border border-gray-100">
              <div>
                <div className="text-sm text-gray-700 mb-1">
                  We found{" "}
                  <span className="font-bold text-gray-900">35 properties</span>
                </div>
                <div className="text-sm text-gray-600 mb-4">
                  within your budget.
                </div>
                <button className="text-indigo-600 text-sm font-medium border border-indigo-600 px-5 py-2 rounded-lg hover:bg-white transition-colors bg-white/80">
                  View properties
                </button>
              </div>
              <div className="relative w-32 h-32">
                <div className="absolute inset-0 flex items-center justify-center">
                  <Home className="w-20 h-20 text-red-400" strokeWidth={1.5} />
                </div>
                <div className="absolute top-0 right-0 w-8 h-8 bg-yellow-300 rounded-full opacity-80"></div>
                <div className="absolute bottom-2 left-0 w-6 h-6 bg-blue-300 rounded-full opacity-60"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-8xl mx-auto px-20 my-24">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-2xl md:text-3xl font-semibold text-gray-800 mb-10">
            Why thousands of home buyers trust us with their mortgage needs
          </h1>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Column - Single Large Card */}
          <div className="bg-[#f7f7f7] rounded-2xl p-8 flex flex-col justify-between md:col-span-1">
            {/* Logo */}
            <div className="flex items-center gap-2 mb-8">
              <div className="relative">
                <div className="w-10 h-10 bg-gradient-to-br from-red-500 to-orange-500 rounded-lg flex items-center justify-center">
                  <svg
                    className="w-6 h-6 text-white"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                  >
                    <path d="M10.707 2.293a1 1 0 00-1.414 0l-7 7a1 1 0 001.414 1.414L4 10.414V17a1 1 0 001 1h2a1 1 0 001-1v-2a1 1 0 011-1h2a1 1 0 011 1v2a1 1 0 001 1h2a1 1 0 001-1v-6.586l.293.293a1 1 0 001.414-1.414l-7-7z" />
                  </svg>
                </div>
              </div>
              <div className="leading-tight">
                <div className="text-lg font-bold text-gray-800">Mortgage</div>
                <div className="text-sm text-gray-600">Finder</div>
              </div>
            </div>

            {/* We work for you section */}
            <div className="mb-auto">
              <h2 className="text-3xl font-bold text-gray-900 mb-6 leading-tight">
                We work for you,
                <br />
                not the bank
              </h2>
              <button className="bg-[#0B154F] text-white px-6 py-3 rounded-lg font-medium  transition">
                Get a Mortgage Quote
              </button>
            </div>
          </div>

          {/* Right Column - 4 Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:col-span-2">
            {/* Card 1: 10 minutes */}
            <div className="bg-[#f7f7f7] rounded-2xl p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="text-2xl font-bold text-gray-900 mb-2">
                    10 minutes
                  </div>
                  <div className="text-base text-gray-600 leading-relaxed">
                    90% of inquiries submitted
                    <br />
                    between 9 AM - 6 PM receive
                    <br />a call within 10 minutes
                  </div>
                </div>
                <div className="relative w-24 h-24 ml-3 flex-shrink-0">
                  <img
                    src="https://static-assets.propertyfinder.com/images/mortgage/call-illustration.svg"
                    alt=""
                  />
                </div>
              </div>
            </div>

            {/* Card 2: 4.9 Rating */}
            <div className="bg-[#f7f7f7] rounded-2xl p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="text-2xl font-bold text-gray-900 mb-2">
                    4.9
                  </div>
                  <div className="text-base text-gray-600 mb-2">
                    Customer reviews from 1000+
                    <br />
                    people
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-base font-semibold text-gray-700">
                      Google
                    </span>
                    <div className="flex gap-0.5">
                      {[1, 2, 3, 4, 5].map((i) => (
                        <Star
                          key={i}
                          className="w-3 h-3 fill-yellow-400 text-yellow-400"
                        />
                      ))}
                    </div>
                  </div>
                </div>
                <div className="relative w-24 h-24 ml-3 flex-shrink-0">
                  <img
                    src="https://static-assets.propertyfinder.com/images/mortgage/5-star-review-illustration.svg"
                    alt=""
                  />
                </div>
              </div>
            </div>

            {/* Card 3: 5,000 AED Savings */}
            <div className="bg-[#f7f7f7] rounded-2xl p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="text-2xl font-bold text-gray-900 mb-2">
                    5,000 AED
                  </div>
                  <div className="text-base text-gray-600">
                    Average savings with 0 fees
                  </div>
                </div>
                <div className="relative w-24 h-24 ml-3 flex-shrink-0">
                  <img
                    src="https://static-assets.propertyfinder.com/images/mortgage/budget-illustration.svg"
                    alt=""
                  />
                </div>
              </div>
            </div>

            {/* Card 4: 100,000+ clients */}
            <div className="bg-[#f7f7f7] rounded-2xl p-6">
              <div className="flex items-start justify-between mb-3">
                <div className="flex-1">
                  <div className="text-2xl font-bold text-gray-900 mb-2">
                    100,000+
                  </div>
                  <div className="text-base text-gray-600 mb-3">
                    Happy clients we served
                  </div>
                </div>
                <div className="relative w-24 h-24 ml-3 flex-shrink-0">
                  <img
                    src="https://static-assets.propertyfinder.com/images/mortgage/home-keys-illustration.svg"
                    alt=""
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-8xl mx-auto px-20 my-24">
        <h2 className="text-3xl font-bold text-gray-800 mb-12">
          6 steps to get your place
        </h2>

        <div className="relative group">
          {/* Left Arrow */}
          <button
            onClick={() => scroll("left")}
            className="absolute left-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-all opacity-0 group-hover:opacity-100 -ml-4"
            aria-label="Scroll left"
          >
            <ChevronLeft className="w-6 h-6 text-gray-700" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={() => scroll("right")}
            className="absolute right-0 top-1/2 -translate-y-1/2 z-10 bg-white rounded-full p-2 shadow-lg hover:bg-gray-100 transition-all opacity-0 group-hover:opacity-100 -mr-4"
            aria-label="Scroll right"
          >
            <ChevronRight className="w-6 h-6 text-gray-700" />
          </button>

          <div
            ref={scrollContainerRef}
            className="overflow-x-auto pb-4 scrollbar-hide"
            style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
          >
            <div className="flex gap-6 min-w-max px-2">
              {steps.map((step) => (
                <div
                  key={step.number}
                  className="bg-[#f7f7f7] rounded-lg p-6 shadow-sm hover:shadow-md transition-shadow w-80 flex-shrink-0"
                >
                  <div className="flex items-start justify-between mb-4">
                    <h3 className="text-lg font-semibold text-gray-800">
                      {step.title}
                    </h3>
                    <span className="text-sm font-medium text-gray-400 ml-2">
                      {step.number}
                    </span>
                  </div>

                  <p className="text-sm text-gray-600 leading-relaxed mb-6 min-h-[160px]">
                    {step.description}
                  </p>

                  <div className="flex justify-end mt-auto pt-4">
                    <img src={step.image} alt="" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-8xl mx-auto px-20 my-24">
        <div className="w-full px-20 ">
          {/* Header */}
          <div className="flex items-start justify-between mb-6">
            <div>
              <div className="flex items-center gap-2 mb-1 text-base">
                <span className="text-gray-900 font-medium">
                  Rated 4.9 out of 5
                </span>
              </div>
              <p className=" text-gray-500">by 1100+ people</p>
            </div>
            <div className="flex items-center gap-1">
              <svg className="w-20 h-6" viewBox="0 0 80 24" fill="none">
                <text x="0" y="18" className="text-sm font-bold" fill="#4285F4">
                  G
                </text>
                <text
                  x="12"
                  y="18"
                  className="text-sm font-bold"
                  fill="#EA4335"
                >
                  o
                </text>
                <text
                  x="22"
                  y="18"
                  className="text-sm font-bold"
                  fill="#FBBC04"
                >
                  o
                </text>
                <text
                  x="32"
                  y="18"
                  className="text-sm font-bold"
                  fill="#4285F4"
                >
                  g
                </text>
                <text
                  x="42"
                  y="18"
                  className="text-sm font-bold"
                  fill="#34A853"
                >
                  l
                </text>
                <text
                  x="48"
                  y="18"
                  className="text-sm font-bold"
                  fill="#EA4335"
                >
                  e
                </text>
              </svg>
              <div className="flex ml-1">
                {[...Array(5)].map((_, i) => (
                  <svg
                    key={i}
                    className="w-4 h-4"
                    fill="#FBBC04"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" />
                  </svg>
                ))}
              </div>
            </div>
          </div>

          {/* Review Card */}
          <div className="relative bg-gray-50 rounded-lg p-6">
            {/* Navigation Buttons */}
            <button
              onClick={handlePrevious}
              className="absolute left-4 top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-sm flex items-center justify-center hover:bg-gray-50 transition-colors z-10"
            >
              <ChevronLeft className="w-5 h-5 text-gray-600" />
            </button>

            <button
              onClick={handleNext}
              className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 bg-white rounded-full shadow-sm flex items-center justify-center hover:bg-gray-50 transition-colors z-10"
            >
              <ChevronRight className="w-5 h-5 text-gray-600" />
            </button>

            {/* Review Content */}
            <div className="px-8 transition-opacity duration-300">
              <p className="text-gray-700 leading-relaxed mb-4">
                {currentReview.text}
              </p>

              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-medium text-gray-900">
                    {currentReview.author}
                  </span>
                  <span className="text-gray-500 ml-2">
                    {currentReview.date}
                  </span>
                </div>
              </div>
            </div>

            {/* Dots Indicator */}
            <div className="flex justify-center gap-2 mt-4">
              {reviews.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-2 h-2 rounded-full transition-colors ${
                    index === currentIndex ? "bg-gray-600" : "bg-gray-300"
                  }`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
