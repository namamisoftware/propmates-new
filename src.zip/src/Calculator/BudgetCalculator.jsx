// import React, { useState } from "react";
// import { ArrowLeft, ChevronLeft } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import Header from "../Components/Header";
// import Footer from "../Components/Footer";
// import calc from "../assets/calc.png";

// export default function BudgetCalculator() {
//   const navigate = useNavigate();
//   const [savings, setSavings] = useState(2000000);
//   const [emi, setEmi] = useState(20000);
//   const [tenure, setTenure] = useState(20);

//   // Calculate home budget
//   const calculateBudget = () => {
//     const interestRate = 0.045; // 4.5% annual interest rate (typical for UAE)
//     const monthlyRate = interestRate / 12;
//     const numberOfPayments = tenure * 12;

//     // Calculate loan amount using EMI formula: P = EMI × [(1 - (1 + r)^-n) / r]
//     const loanAmount =
//       emi * ((1 - Math.pow(1 + monthlyRate, -numberOfPayments)) / monthlyRate);

//     // Total budget = savings + loan amount
//     const totalBudget = savings + loanAmount;

//     return totalBudget;
//   };

//   const formatBudget = (amount) => {
//     if (amount >= 10000000) {
//       return `${(amount / 10000000).toFixed(2)} Cr`;
//     } else if (amount >= 100000) {
//       return `${(amount / 100000).toFixed(2)} Lacs`;
//     } else {
//       return `${amount.toLocaleString("en-AE")}`;
//     }
//   };

//   const budget = calculateBudget();
//   const budgetDisplay = formatBudget(budget);

//   return (
// <>
//   <Header />
//   <div className="">
//     <div className="flex flex-col lg:flex-row lg:px-8 px-4">
//       {/* Left Column - Scrollable Content */}
//       <div className="flex-1 overflow-y-auto lg:w-[90%] w-full">
//         <div className="lg:p-4 lg:pr-8 p-2">
//           <div className="lg:max-w-4xl max-w-full">
//             {/* Header */}
//             <div
//               onClick={() => navigate(-1)}
//               className="flex items-center lg:mb-8 mb-6"
//             >
//               <ChevronLeft className="lg:w-7 lg:h-7 w-6 h-6 mr-1" />
//               <span className="lg:text-xl text-lg font-semibold">Back</span>
//             </div>

//             <div className="flex flex-col justify-center lg:mt-20 mt-8 w-full">
//               <h2 className="lg:text-2xl text-xl text-center font-semibold text-[#0b154f] lg:mb-18 mb-8">
//                 Check your home buying budget
//               </h2>

//               <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-24 gap-8">
//                 {/* Savings */}
//                 <div>
//                   <div className="flex items-center justify-between">
//                     <label className="block text-sm lg:text-base">
//                       Saving for buying home
//                     </label>
//                     <span className="text-sm lg:text-base">
//                       {savings.toLocaleString("en-AE")} AED
//                     </span>
//                   </div>
//                   <input
//                     type="range"
//                     min="0"
//                     max="10000000"
//                     step="50000"
//                     value={savings}
//                     onChange={(e) => setSavings(Number(e.target.value))}
//                     className="w-full h-1 accent-blue-600 mt-2"
//                   />
//                   <span className="text-gray-600 text-sm">0 AED</span>
//                 </div>

//                 {/* Loan tenure */}
//                 <div className="">
//                   <div className="flex items-center justify-between">
//                     <label className="block text-sm lg:text-base">
//                       Preferred loan tenure
//                     </label>
//                     <span className="text-sm lg:text-base">20 Year</span>
//                   </div>
//                   <input
//                     type="range"
//                     min="1"
//                     max="30"
//                     step="1"
//                     value={tenure}
//                     onChange={(e) => setTenure(Number(e.target.value))}
//                     className="w-full h-1 accent-blue-600 mt-2"
//                   />
//                   <div className="flex items-center justify-between text-sm">
//                     <span className="text-gray-600">1 Year</span>
//                     <span className="text-gray-800">{tenure} Year</span>
//                   </div>
//                 </div>

//                 {/* EMI */}
//                 <div>
//                   <div className="flex items-center justify-between">
//                     <label className="block text-sm lg:text-base">
//                       EMI you Can Afford
//                     </label>
//                     <span className="text-sm lg:text-base">
//                       {emi.toLocaleString("en-AE")} AED
//                     </span>
//                   </div>
//                   <input
//                     type="range"
//                     min="1000"
//                     max="200000"
//                     step="1000"
//                     value={emi}
//                     onChange={(e) => setEmi(Number(e.target.value))}
//                     className="w-full h-1 accent-blue-600 mt-2"
//                   />

//                   <div className="flex items-center justify-between text-sm">
//                     <span className="text-gray-600">1,000 AED</span>
//                     <span className="text-gray-600">2,00,000 AED</span>
//                   </div>
//                 </div>

//                 {/* Budget Display */}
//                 <div className="flex flex-col lg:col-span-1 col-span-1">
//                   <h3 className="lg:text-2xl text-xl font-bold text-[#0b154f]">
//                     Your Home Budget
//                   </h3>
//                   <p className="lg:text-3xl text-2xl font-bold text-blue-600 mt-2">
//                     {budgetDisplay} AED
//                   </p>
//                   <p className="text-sm text-gray-600 mt-2">
//                     Based on {tenure} year loan tenure at 4.5% interest rate
//                   </p>
//                 </div>
//               </div>
//             </div>

//             {/* About Payment Section */}
//             <div className="lg:mt-38 lg:mb-32 mt-16 mb-16">
//               <h2 className="lg:text-3xl text-2xl font-semibold text-gray-900 mb-6">
//                 About Payment
//               </h2>
//               <p className="text-gray-500 lg:text-lg text-base leading-relaxed">
//                 Palm Jebel Ali Front is a prestigious real estate
//                 development by Nakheel Properties, is situated at the most
//                 Attractive prime popular Dubai Marina location in Dubai UAE.
//                 The development is particularly appealing, making this
//                 ultimate is luxurious living, this exquisite project is
//                 poised to becoming a genuine crossover of luxury and
//                 sophistication. With its calm living atmosphere, facilities,
//                 and beautiful waterfront access, Palm Jebel Ali Front offers
//                 an exceptional lifestyle in one of the most popular living
//                 waterfront locations.
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>

//       {/* Right Column - Fixed Sidebar */}
//       <div className="hidden lg:w-[20%] w-full lg:flex justify-center lg:mt-0 mt-8">
//         <div className="lg:sticky lg:top-0 lg:p-4 lg:pb-32 lg:overflow-y-auto p-4">
//           <img
//             src={calc}
//             alt="Calculator"
//             className="lg:w-auto w-48 h-auto max-w-full"
//           />
//         </div>
//       </div>
//     </div>
//   </div>
//   <Footer />
// </>
//   );
// }

import React, { useState, useMemo } from "react";
import { ChevronLeft, ChevronDown, Search } from "lucide-react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import calc from "../assets/calc.png";
import { useNavigate } from "react-router-dom";

const useCountryData = () => {
  const [countriesFromPackage] = useState(() => {
    return generateCountriesFromPackage();
  });

  return countriesFromPackage;
};

function generateCountriesFromPackage() {
  const realCountries = [
    {
      code: "AF",
      name: "Afghanistan",
      currency: "AFN",
      region: "Asia",
      rate: 0.12,
    },
    {
      code: "AL",
      name: "Albania",
      currency: "ALL",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "DZ",
      name: "Algeria",
      currency: "DZD",
      region: "Africa",
      rate: 0.09,
    },
    {
      code: "AR",
      name: "Argentina",
      currency: "ARS",
      region: "Americas",
      rate: 0.4,
    },
    {
      code: "AM",
      name: "Armenia",
      currency: "AMD",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "AU",
      name: "Australia",
      currency: "AUD",
      region: "Oceania",
      rate: 0.06,
    },
    {
      code: "AT",
      name: "Austria",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "AZ",
      name: "Azerbaijan",
      currency: "AZN",
      region: "Asia",
      rate: 0.13,
    },
    {
      code: "BH",
      name: "Bahrain",
      currency: "BHD",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "BD",
      name: "Bangladesh",
      currency: "BDT",
      region: "Asia",
      rate: 0.09,
    },
    {
      code: "BY",
      name: "Belarus",
      currency: "BYN",
      region: "Europe",
      rate: 0.14,
    },
    {
      code: "BE",
      name: "Belgium",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "BR",
      name: "Brazil",
      currency: "BRL",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "BG",
      name: "Bulgaria",
      currency: "BGN",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "KH",
      name: "Cambodia",
      currency: "KHR",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "CA",
      name: "Canada",
      currency: "CAD",
      region: "Americas",
      rate: 0.065,
    },
    {
      code: "CL",
      name: "Chile",
      currency: "CLP",
      region: "Americas",
      rate: 0.055,
    },
    { code: "CN", name: "China", currency: "CNY", region: "Asia", rate: 0.055 },
    {
      code: "CO",
      name: "Colombia",
      currency: "COP",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "CR",
      name: "Costa Rica",
      currency: "CRC",
      region: "Americas",
      rate: 0.09,
    },
    {
      code: "HR",
      name: "Croatia",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    {
      code: "CY",
      name: "Cyprus",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CZ",
      name: "Czech Republic",
      currency: "CZK",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "DK",
      name: "Denmark",
      currency: "DKK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "EC",
      name: "Ecuador",
      currency: "USD",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "EG",
      name: "Egypt",
      currency: "EGP",
      region: "Africa",
      rate: 0.15,
    },
    {
      code: "EE",
      name: "Estonia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "ET",
      name: "Ethiopia",
      currency: "ETB",
      region: "Africa",
      rate: 0.14,
    },
    {
      code: "FI",
      name: "Finland",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "FR",
      name: "France",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "GE",
      name: "Georgia",
      currency: "GEL",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "DE",
      name: "Germany",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "GH", name: "Ghana", currency: "GHS", region: "Africa", rate: 0.2 },
    {
      code: "GR",
      name: "Greece",
      currency: "EUR",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "HK",
      name: "Hong Kong",
      currency: "HKD",
      region: "Asia",
      rate: 0.03,
    },
    {
      code: "HU",
      name: "Hungary",
      currency: "HUF",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "IS",
      name: "Iceland",
      currency: "ISK",
      region: "Europe",
      rate: 0.07,
    },
    { code: "IN", name: "India", currency: "INR", region: "Asia", rate: 0.085 },
    {
      code: "ID",
      name: "Indonesia",
      currency: "IDR",
      region: "Asia",
      rate: 0.075,
    },
    { code: "IR", name: "Iran", currency: "IRR", region: "Asia", rate: 0.18 },
    { code: "IQ", name: "Iraq", currency: "IQD", region: "Asia", rate: 0.08 },
    {
      code: "IE",
      name: "Ireland",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "IL", name: "Israel", currency: "ILS", region: "Asia", rate: 0.04 },
    {
      code: "IT",
      name: "Italy",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "JP", name: "Japan", currency: "JPY", region: "Asia", rate: 0.015 },
    {
      code: "JO",
      name: "Jordan",
      currency: "JOD",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "KZ",
      name: "Kazakhstan",
      currency: "KZT",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "KE",
      name: "Kenya",
      currency: "KES",
      region: "Africa",
      rate: 0.13,
    },
    {
      code: "KR",
      name: "South Korea",
      currency: "KRW",
      region: "Asia",
      rate: 0.045,
    },
    { code: "KW", name: "Kuwait", currency: "KWD", region: "Asia", rate: 0.04 },
    {
      code: "LV",
      name: "Latvia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LB",
      name: "Lebanon",
      currency: "LBP",
      region: "Asia",
      rate: 0.08,
    },
    {
      code: "LT",
      name: "Lithuania",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LU",
      name: "Luxembourg",
      currency: "EUR",
      region: "Europe",
      rate: 0.03,
    },
    {
      code: "MY",
      name: "Malaysia",
      currency: "MYR",
      region: "Asia",
      rate: 0.04,
    },
    {
      code: "MT",
      name: "Malta",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "MX",
      name: "Mexico",
      currency: "MXN",
      region: "Americas",
      rate: 0.095,
    },
    {
      code: "MA",
      name: "Morocco",
      currency: "MAD",
      region: "Africa",
      rate: 0.055,
    },
    {
      code: "NL",
      name: "Netherlands",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "NZ",
      name: "New Zealand",
      currency: "NZD",
      region: "Oceania",
      rate: 0.065,
    },
    {
      code: "NG",
      name: "Nigeria",
      currency: "NGN",
      region: "Africa",
      rate: 0.18,
    },
    {
      code: "NO",
      name: "Norway",
      currency: "NOK",
      region: "Europe",
      rate: 0.045,
    },
    { code: "OM", name: "Oman", currency: "OMR", region: "Asia", rate: 0.045 },
    {
      code: "PK",
      name: "Pakistan",
      currency: "PKR",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "PE",
      name: "Peru",
      currency: "PEN",
      region: "Americas",
      rate: 0.08,
    },
    {
      code: "PH",
      name: "Philippines",
      currency: "PHP",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "PL",
      name: "Poland",
      currency: "PLN",
      region: "Europe",
      rate: 0.07,
    },
    {
      code: "PT",
      name: "Portugal",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "QA", name: "Qatar", currency: "QAR", region: "Asia", rate: 0.045 },
    {
      code: "RO",
      name: "Romania",
      currency: "RON",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "RU",
      name: "Russia",
      currency: "RUB",
      region: "Europe",
      rate: 0.12,
    },
    {
      code: "SA",
      name: "Saudi Arabia",
      currency: "SAR",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "RS",
      name: "Serbia",
      currency: "RSD",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "SG",
      name: "Singapore",
      currency: "SGD",
      region: "Asia",
      rate: 0.035,
    },
    {
      code: "SK",
      name: "Slovakia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "SI",
      name: "Slovenia",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "ZA",
      name: "South Africa",
      currency: "ZAR",
      region: "Africa",
      rate: 0.11,
    },
    {
      code: "ES",
      name: "Spain",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LK",
      name: "Sri Lanka",
      currency: "LKR",
      region: "Asia",
      rate: 0.14,
    },
    {
      code: "SE",
      name: "Sweden",
      currency: "SEK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CH",
      name: "Switzerland",
      currency: "CHF",
      region: "Europe",
      rate: 0.025,
    },
    {
      code: "TW",
      name: "Taiwan",
      currency: "TWD",
      region: "Asia",
      rate: 0.025,
    },
    {
      code: "TH",
      name: "Thailand",
      currency: "THB",
      region: "Asia",
      rate: 0.045,
    },
    { code: "TR", name: "Turkey", currency: "TRY", region: "Asia", rate: 0.25 },
    {
      code: "UA",
      name: "Ukraine",
      currency: "UAH",
      region: "Europe",
      rate: 0.16,
    },
    {
      code: "AE",
      name: "United Arab Emirates",
      currency: "AED",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "GB",
      name: "United Kingdom",
      currency: "GBP",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "US",
      name: "United States",
      currency: "USD",
      region: "Americas",
      rate: 0.07,
    },
    {
      code: "UY",
      name: "Uruguay",
      currency: "UYU",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "VE",
      name: "Venezuela",
      currency: "VES",
      region: "Americas",
      rate: 0.35,
    },
    {
      code: "VN",
      name: "Vietnam",
      currency: "VND",
      region: "Asia",
      rate: 0.08,
    },
  ];

  // Calculate max savings and EMI based on currency
  return realCountries.map((country) => {
    const currencyMultiplier = {
      USD: 1,
      EUR: 1,
      GBP: 1,
      AUD: 1,
      CAD: 1,
      CHF: 1,
      JPY: 100,
      KRW: 1000,
      INR: 100,
      CNY: 10,
      MXN: 20,
      BRL: 5,
      RUB: 100,
      TRY: 30,
      IDR: 20000,
      VND: 30000,
      THB: 35,
      PHP: 50,
      MYR: 5,
      SGD: 1.5,
      HKD: 8,
      AED: 4,
      SAR: 4,
      QAR: 4,
      KWD: 0.3,
      BHD: 0.4,
    };

    const multiplier = currencyMultiplier[country.currency] || 1;

    return {
      ...country,
      maxSavings: 500000 * multiplier,
      maxEmi: 10000 * multiplier,
    };
  });
}

// Interest rate mapping based on country/region
// This could also come from a financial API or package
const getInterestRate = (countryCode) => {
  const rateMap = {
    US: 0.07,
    GB: 0.055,
    DE: 0.04,
    IN: 0.085,
    CN: 0.055,
    JP: 0.015,
    AU: 0.06,
    CA: 0.065,
  };
  return rateMap[countryCode] || 0.06; // Default rate
};

// Get max values based on currency
const getMaxValues = (currency) => {
  const maxMap = {
    USD: { savings: 500000, emi: 10000 },
    EUR: { savings: 400000, emi: 8000 },
    GBP: { savings: 400000, emi: 8000 },
    INR: { savings: 50000000, emi: 500000 },
    JPY: { savings: 50000000, emi: 500000 },
    AED: { savings: 10000000, emi: 200000 },
  };
  return maxMap[currency] || { savings: 500000, emi: 10000 };
};

export default function BudgetCalculator() {
  const navigate = useNavigate();
  const countriesData = useCountryData();
  const [selectedCountryCode, setSelectedCountryCode] = useState("C00");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [savings, setSavings] = useState(2000000);
  const [emi, setEmi] = useState(20000);
  const [tenure, setTenure] = useState(20);

  // Get current country config
  const countryConfig = useMemo(() => {
    return (
      countriesData.find((c) => c.code === selectedCountryCode) ||
      countriesData[0]
    );
  }, [selectedCountryCode, countriesData]);

  // Filter countries based on search
  const filteredCountries = useMemo(() => {
    if (!searchQuery.trim()) return countriesData;
    const query = searchQuery.toLowerCase();
    return countriesData.filter(
      (country) =>
        country.name.toLowerCase().includes(query) ||
        country.currency.toLowerCase().includes(query) ||
        country.code.toLowerCase().includes(query) ||
        country.region.toLowerCase().includes(query)
    );
  }, [searchQuery, countriesData]);

  // Group countries by region
  const groupedCountries = useMemo(() => {
    const groups = {};
    filteredCountries.forEach((country) => {
      if (!groups[country.region]) {
        groups[country.region] = [];
      }
      groups[country.region].push(country);
    });
    return groups;
  }, [filteredCountries]);

  // Calculate home budget
  const calculateBudget = () => {
    const monthlyRate = countryConfig.rate / 12;
    const numberOfPayments = tenure * 12;

    const loanAmount =
      emi * ((1 - Math.pow(1 + monthlyRate, -numberOfPayments)) / monthlyRate);

    const totalBudget = savings + loanAmount;

    return totalBudget;
  };

  const formatBudget = (amount) => {
    if (amount >= 10000000) {
      return `${(amount / 10000000).toFixed(2)} Cr`;
    } else if (amount >= 100000) {
      return `${(amount / 100000).toFixed(2)} Lacs`;
    } else {
      return `${amount.toLocaleString("en-AE")}`;
    }
  };

  const handleCountryChange = (countryCode) => {
    const newCountry = countriesData.find((c) => c.code === countryCode);
    setSelectedCountryCode(countryCode);
    setIsDropdownOpen(false);
    setSearchQuery("");

    // Reset values to defaults for new country
    if (newCountry) {
      setSavings(Math.min(savings, newCountry.maxSavings));
      setEmi(Math.min(emi, newCountry.maxEmi));
    }
  };

  const budget = calculateBudget();
  const budgetDisplay = formatBudget(budget);

  return (
    <>
      <Header />
      <div className="">
        <div className="flex flex-col lg:flex-row px-4 sm:px-6 lg:px-8">
          {/* Left Column - Scrollable Content */}
          <div className="flex-1 overflow-y-auto lg:w-[90%] w-full">
            <div className="lg:p-4 lg:pr-8 p-2">
              <div className="lg:max-w-4xl max-w-full">
                {/* Header with Back button and Country Dropdown */}
                <div className="flex items-center justify-between lg:mb-8 mb-6">
                  <div
                    onClick={() => navigate(-1)}
                    className="flex items-center cursor-pointer"
                  >
                    <ChevronLeft className="lg:w-7 lg:h-7 w-6 h-6 mr-1" />
                    <span className="lg:text-xl text-lg font-semibold">
                      Back
                    </span>
                  </div>

                  {/* Country Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                      className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <span className="font-medium text-sm lg:text-base">
                        {countryConfig.currency}
                      </span>
                      <ChevronDown className="w-4 h-4" />
                    </button>

                    {isDropdownOpen && (
                      <div className="absolute right-0 mt-2 w-72 bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-96 overflow-hidden flex flex-col">
                        {/* Search Box */}
                        <div className="p-3 border-b border-gray-200 sticky top-0 bg-white">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input
                              type="text"
                              placeholder="Search country..."
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                        </div>

                        {/* Countries List - Grouped by Region */}
                        <div className="overflow-y-auto">
                          {Object.entries(groupedCountries).map(
                            ([region, countries]) => (
                              <div key={region}>
                                <div className="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-600 sticky top-0">
                                  {region}
                                </div>
                                {countries.map((country) => (
                                  <button
                                    key={country.code}
                                    onClick={() =>
                                      handleCountryChange(country.code)
                                    }
                                    className={`w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors ${
                                      selectedCountryCode === country.code
                                        ? "bg-gray-100"
                                        : ""
                                    }`}
                                  >
                                    <div className="text-sm font-medium">
                                      {country.name}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {country.currency} •{" "}
                                      {(country.rate * 100).toFixed(1)}% rate
                                    </div>
                                  </button>
                                ))}
                              </div>
                            )
                          )}

                          {filteredCountries.length === 0 && (
                            <div className="p-4 text-center text-gray-500 text-sm">
                              No countries found
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex flex-col justify-center lg:mt-20 mt-8 w-full">
                  <h2 className="lg:text-2xl text-xl text-center font-semibold text-[#0b154f] lg:mb-18 mb-8">
                    Check your home buying budget
                  </h2>

                  <div className="grid grid-cols-1 lg:grid-cols-2 lg:gap-24 gap-8">
                    {/* Savings */}
                    <div>
                      <div className="flex items-center justify-between">
                        <label className="block text-sm lg:text-base">
                          Saving for buying home
                        </label>
                        <span className="text-sm lg:text-base">
                          {savings.toLocaleString("en-AE")}{" "}
                          {countryConfig.currency}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="0"
                        max={countryConfig.maxSavings}
                        step={countryConfig.maxSavings / 200}
                        value={savings}
                        onChange={(e) => setSavings(Number(e.target.value))}
                        className="w-full h-1 accent-blue-600 mt-2"
                      />
                      <span className="text-gray-600 text-sm">
                        0 {countryConfig.currency}
                      </span>
                    </div>

                    {/* Loan tenure */}
                    <div className="">
                      <div className="flex items-center justify-between">
                        <label className="block text-sm lg:text-base">
                          Preferred loan tenure
                        </label>
                        <span className="text-sm lg:text-base">
                          {tenure} Year
                        </span>
                      </div>
                      <input
                        type="range"
                        min="1"
                        max="30"
                        step="1"
                        value={tenure}
                        onChange={(e) => setTenure(Number(e.target.value))}
                        className="w-full h-1 accent-blue-600 mt-2"
                      />
                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">1 Year</span>
                        <span className="text-gray-800">{tenure} Year</span>
                      </div>
                    </div>

                    {/* EMI */}
                    <div>
                      <div className="flex items-center justify-between">
                        <label className="block text-sm lg:text-base">
                          EMI you Can Afford
                        </label>
                        <span className="text-sm lg:text-base">
                          {emi.toLocaleString("en-AE")} {countryConfig.currency}
                        </span>
                      </div>
                      <input
                        type="range"
                        min="1000"
                        max={countryConfig.maxEmi}
                        step="1000"
                        value={emi}
                        onChange={(e) => setEmi(Number(e.target.value))}
                        className="w-full h-1 accent-blue-600 mt-2"
                      />

                      <div className="flex items-center justify-between text-sm">
                        <span className="text-gray-600">
                          1,000 {countryConfig.currency}
                        </span>
                        <span className="text-gray-600">
                          {countryConfig.maxEmi.toLocaleString("en-AE")}{" "}
                          {countryConfig.currency}
                        </span>
                      </div>
                    </div>

                    {/* Budget Display */}
                    <div className="flex flex-col lg:col-span-1 col-span-1">
                      <h3 className="lg:text-2xl text-xl font-bold text-[#0b154f]">
                        Your Home Budget
                      </h3>
                      <p className="lg:text-3xl text-2xl font-bold text-blue-600 mt-2">
                        {budgetDisplay} {countryConfig.currency}
                      </p>
                      <p className="text-sm text-gray-600 mt-2">
                        Based on {tenure} year loan tenure at{" "}
                        {(countryConfig.rate * 100).toFixed(1)}% interest rate
                      </p>
                    </div>
                  </div>
                </div>

                {/* About Payment Section */}
                <div className="lg:mt-38 lg:mb-32 mt-16 mb-16">
                  <h2 className="lg:text-3xl text-2xl font-semibold text-gray-900 mb-6">
                    About Payment
                  </h2>
                  <p className="text-gray-500 lg:text-lg text-base leading-relaxed">
                    Palm Jebel Ali Front is a prestigious real estate
                    development by Nakheel Properties, is situated at the most
                    Attractive prime popular Dubai Marina location in Dubai UAE.
                    The development is particularly appealing, making this
                    ultimate is luxurious living, this exquisite project is
                    poised to becoming a genuine crossover of luxury and
                    sophistication. With its calm living atmosphere, facilities,
                    and beautiful waterfront access, Palm Jebel Ali Front offers
                    an exceptional lifestyle in one of the most popular living
                    waterfront locations.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Fixed Sidebar */}
          <div className="hidden lg:block w-full lg:w-[20%] mt-8 lg:mt-0">
            <div className="sticky top-0 p-4 pb-16 lg:pb-32 overflow-y-auto flex justify-center lg:block">
              <img
                src={calc}
                alt="Calculator"
                className="w-48 sm:w-56 lg:w-full max-w-xs lg:max-w-none"
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
