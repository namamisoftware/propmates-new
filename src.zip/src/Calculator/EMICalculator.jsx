// import React, { useState } from "react";
// import { ArrowLeft, ChevronLeft } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import Header from "../Components/Header";
// import Footer from "../Components/Footer";
// import calc from "../assets/calc.png";
// import {
//   AreaChart,
//   Area,
//   XAxis,
//   YAxis,
//   Tooltip,
//   ResponsiveContainer,
// } from "recharts";

// export default function EMICalculator() {
//   const navigate = useNavigate();
//   const [borrowers, setBorrowers] = useState("one"); // "one" or "two"
//   const [age, setAge] = useState(35);
//   const [income, setIncome] = useState(100000);
//   const [emi, setEmi] = useState(10000);
//   const [roi, setRoi] = useState(4.5); // UAE typical rate
//   const [tenure, setTenure] = useState(20);

//   // Second borrower details
//   const [age2, setAge2] = useState(30);
//   const [income2, setIncome2] = useState(80000);
//   const [emi2, setEmi2] = useState(5000);

//   const [loanAmount, setLoanAmount] = useState(null);
//   const [monthlyEMI, setMonthlyEMI] = useState(null);
//   const [totalPayable, setTotalPayable] = useState(null);

//   const calculateLoan = () => {
//     let eligibleEMI;

//     if (borrowers === "two") {
//       // For two borrowers, combine incomes and EMIs
//       const totalIncome = income + income2;
//       const totalExistingEMI = emi + emi2;
//       eligibleEMI = totalIncome * 0.5 - totalExistingEMI;
//     } else {
//       // For single borrower
//       eligibleEMI = income * 0.5 - emi;
//     }

//     if (eligibleEMI <= 0) {
//       alert(
//         "Your existing EMI is too high. Please reduce existing obligations."
//       );
//       return;
//     }

//     // Calculate loan amount using EMI formula
//     // P = EMI × [(1 - (1 + r)^-n) / r]
//     const monthlyRate = roi / 12 / 100;
//     const numberOfMonths = tenure * 12;

//     const calculatedLoanAmount =
//       eligibleEMI *
//       ((1 - Math.pow(1 + monthlyRate, -numberOfMonths)) / monthlyRate);

//     const calculatedTotalPayable = eligibleEMI * numberOfMonths;

//     setLoanAmount(Math.round(calculatedLoanAmount));
//     setMonthlyEMI(Math.round(eligibleEMI));
//     setTotalPayable(Math.round(calculatedTotalPayable));
//   };

//   // Generate chart data showing loan principal and interest over time
//   const generateChartData = () => {
//     if (!loanAmount || !monthlyEMI) {
//       return Array.from({ length: tenure + 1 }, (_, i) => ({
//         year: i,
//         principal: 0,
//         interest: 0,
//       }));
//     }

//     const monthlyRate = roi / 12 / 100;
//     let remainingPrincipal = loanAmount;
//     const data = [];

//     for (let year = 0; year <= tenure; year++) {
//       const monthsElapsed = year * 12;

//       if (year === 0) {
//         data.push({
//           year: 0,
//           principal: loanAmount,
//           interest: 0,
//         });
//       } else {
//         // Calculate remaining principal after this year
//         for (let month = 0; month < 12 && remainingPrincipal > 0; month++) {
//           const interestForMonth = remainingPrincipal * monthlyRate;
//           const principalForMonth = monthlyEMI - interestForMonth;
//           remainingPrincipal -= principalForMonth;
//         }

//         const principalPaid = loanAmount - Math.max(0, remainingPrincipal);
//         const interestPaid = monthlyEMI * monthsElapsed - principalPaid;

//         data.push({
//           year: year,
//           principal: Math.max(0, remainingPrincipal),
//           interest: interestPaid,
//         });
//       }
//     }

//     return data;
//   };

//   const data = generateChartData();

//   return (
//     <>
//       <Header />

//       <div className="">
//         <div className="flex flex-col lg:flex-row px-4 sm:px-8">
//           {/* Left Column - Scrollable Content */}
//           <div className="flex-1 overflow-y-auto lg:w-[90%] w-full">
//             <div className="p-2 sm:p-4 lg:pr-8">
//               <div className="w-full">
//                 {/* Header */}
//                 <div
//                   onClick={() => navigate(-1)}
//                   className="flex items-center mb-6 sm:mb-8 cursor-pointer"
//                 >
//                   <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 mr-1" />
//                   <span className="text-lg sm:text-xl font-semibold">Back</span>
//                 </div>

//                 <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 sm:gap-8 w-full max-w-6xl">
//                   {/* Left Form */}
//                   <div className="bg-white h-fit p-4 sm:p-6 lg:p-8 rounded-xl shadow border border-gray-200">
//                     {/* Borrowers */}
//                     <div className="mb-4 sm:mb-6">
//                       <label className="block text-base sm:text-lg font-medium mb-3 sm:mb-4 text-gray-700">
//                         Number of Borrowers
//                       </label>
//                       <div className="flex gap-0">
//                         <button
//                           onClick={() => setBorrowers("one")}
//                           className={`px-4 sm:px-5 py-2 text-sm rounded-l-full font-medium shadow transition-colors ${
//                             borrowers === "one"
//                               ? "bg-[#00a884] text-white"
//                               : "bg-gray-100 text-gray-600 hover:bg-gray-200"
//                           }`}
//                         >
//                           One
//                         </button>
//                         <button
//                           onClick={() => setBorrowers("two")}
//                           className={`px-4 sm:px-5 py-2 text-sm rounded-r-full font-medium shadow transition-colors ${
//                             borrowers === "two"
//                               ? "bg-[#00a884] text-white"
//                               : "bg-gray-100 text-gray-600 hover:bg-gray-200"
//                           }`}
//                         >
//                           Two
//                         </button>
//                       </div>
//                     </div>

//                     {/* Inputs */}
//                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
//                       {/* First Borrower Section */}
//                       <div className="sm:col-span-2">
//                         <h3 className="text-sm font-semibold text-gray-700 mb-3">
//                           {borrowers === "two"
//                             ? "First Borrower"
//                             : "Borrower Details"}
//                         </h3>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">
//                           Your Age
//                         </label>
//                         <div className="flex items-center border border-gray-300  rounded-lg px-3 py-2 mt-1">
//                           <input
//                             type="number"
//                             value={age}
//                             onChange={(e) => setAge(Number(e.target.value))}
//                             className="w-full outline-none text-sm"
//                           />
//                           <span className="text-gray-400 text-sm">Years</span>
//                         </div>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">
//                           Occupation
//                         </label>
//                         <select className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 text-sm text-gray-700">
//                           <option>Salaried</option>
//                           <option>Self-employed</option>
//                         </select>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">
//                           Net income (Monthly)
//                         </label>
//                         <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                           <span className="text-gray-500 text-sm mr-1">
//                             AED
//                           </span>
//                           <input
//                             type="number"
//                             value={income}
//                             onChange={(e) => setIncome(Number(e.target.value))}
//                             className="w-full outline-none text-sm"
//                           />
//                         </div>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">
//                           Existing Monthly EMI
//                         </label>
//                         <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                           <span className="text-gray-500 text-sm mr-1">
//                             AED
//                           </span>
//                           <input
//                             type="number"
//                             value={emi}
//                             onChange={(e) => setEmi(Number(e.target.value))}
//                             className="w-full outline-none text-sm"
//                           />
//                         </div>
//                       </div>

//                       {/* Second Borrower Section - Only show when "Two" is selected */}
//                       {borrowers === "two" && (
//                         <>
//                           <div className="sm:col-span-2 mt-2">
//                             <h3 className="text-sm font-semibold text-gray-700 mb-3">
//                               Second Borrower
//                             </h3>
//                           </div>

//                           <div>
//                             <label className="text-xs text-gray-500">Age</label>
//                             <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                               <input
//                                 type="number"
//                                 value={age2}
//                                 onChange={(e) =>
//                                   setAge2(Number(e.target.value))
//                                 }
//                                 className="w-full outline-none text-sm"
//                               />
//                               <span className="text-gray-400 text-sm">
//                                 Years
//                               </span>
//                             </div>
//                           </div>

//                           <div>
//                             <label className="text-xs text-gray-500">
//                               Occupation
//                             </label>
//                             <select className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 text-sm text-gray-700">
//                               <option>Salaried</option>
//                               <option>Self-employed</option>
//                             </select>
//                           </div>

//                           <div>
//                             <label className="text-xs text-gray-500">
//                               Net income (Monthly)
//                             </label>
//                             <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                               <span className="text-gray-500 text-sm mr-1">
//                                 AED
//                               </span>
//                               <input
//                                 type="number"
//                                 value={income2}
//                                 onChange={(e) =>
//                                   setIncome2(Number(e.target.value))
//                                 }
//                                 className="w-full outline-none text-sm"
//                               />
//                             </div>
//                           </div>

//                           <div>
//                             <label className="text-xs text-gray-500">
//                               Existing Monthly EMI
//                             </label>
//                             <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                               <span className="text-gray-500 text-sm mr-1">
//                                 AED
//                               </span>
//                               <input
//                                 type="number"
//                                 value={emi2}
//                                 onChange={(e) =>
//                                   setEmi2(Number(e.target.value))
//                                 }
//                                 className="w-full outline-none text-sm"
//                               />
//                             </div>
//                           </div>
//                         </>
//                       )}

//                       {/* Common Fields */}
//                       <div className="sm:col-span-2 mt-2">
//                         <h3 className="text-sm font-semibold text-gray-700 mb-3">
//                           Loan Details
//                         </h3>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">
//                           Rate of Interest
//                         </label>
//                         <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                           <input
//                             type="number"
//                             step="0.1"
//                             value={roi}
//                             onChange={(e) => setRoi(Number(e.target.value))}
//                             className="w-full outline-none text-sm"
//                           />
//                           <span className="text-gray-400 text-sm ml-1">%</span>
//                         </div>
//                       </div>

//                       <div>
//                         <label className="text-xs text-gray-500">Tenure</label>
//                         <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
//                           <input
//                             type="number"
//                             value={tenure}
//                             onChange={(e) => setTenure(Number(e.target.value))}
//                             className="w-full outline-none text-sm"
//                           />
//                           <span className="text-gray-400 text-sm ml-1">
//                             Years
//                           </span>
//                         </div>
//                       </div>
//                     </div>

//                     {/* Calculate Button */}
//                     <div className="flex justify-center">
//                       <button
//                         onClick={calculateLoan}
//                         className="w-70 mt-6 sm:mt-8 py-3 border-2 border-blue-500 text-blue-500 text-sm font-medium rounded hover:bg-blue-50"
//                       >
//                         Calculate
//                       </button>
//                     </div>
//                   </div>

//                   {/* Right Results */}
//                   <div className="bg-white p-4 sm:p-6 lg:p-8 rounded-xl shadow border border-gray-200 flex flex-col">
//                     <h2 className="text-base font-medium mb-4 text-gray-700">
//                       Your Estimated Results
//                     </h2>
//                     <div className="h-48 sm:h-64 mb-6">
//                       <ResponsiveContainer width="100%" height="100%">
//                         <AreaChart
//                           data={data}
//                           margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
//                         >
//                           {/* X-Axis */}
//                           <XAxis
//                             dataKey="year"
//                             label={{
//                               value: "Time (in years)",
//                               position: "bottom",
//                               offset: 0,
//                             }}
//                             tick={{ fontSize: 12, fill: "#374151" }}
//                           />

//                           {/* Y-Axis */}
//                           <YAxis
//                             tickFormatter={(value) =>
//                               `${(value / 100000).toFixed(0)}L`
//                             }
//                             label={{
//                               value: "Amount (AED)",
//                               angle: -90,
//                               position: "insideLeft",
//                               offset: 10,
//                             }}
//                             tick={{ fontSize: 12, fill: "#374151" }}
//                           />

//                           {/* Tooltip with AED formatting */}
//                           <Tooltip
//                             formatter={(value) =>
//                               `AED ${value.toLocaleString("en-AE", {
//                                 maximumFractionDigits: 0,
//                               })}`
//                             }
//                           />

//                           {/* Principal (Dark Navy #0e0e43) */}
//                           <Area
//                             type="monotone"
//                             dataKey="principal"
//                             stackId="1"
//                             stroke="#0e0e43"
//                             fill="#0e0e43"
//                             fillOpacity={1}
//                             name="Principal Remaining"
//                           />

//                           {/* Interest (Teal Green #59cfb5) */}
//                           <Area
//                             type="monotone"
//                             dataKey="interest"
//                             stackId="1"
//                             stroke="#59cfb5"
//                             fill="#59cfb5"
//                             fillOpacity={1}
//                             name="Interest Paid"
//                           />
//                         </AreaChart>
//                       </ResponsiveContainer>
//                     </div>

//                     <div className="p-4 sm:p-5 bg-[#f6f6fb] rounded-lg">
//                       <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
//                         <p className="text-base sm:text-lg font-semibold text-[#0e0e43]">
//                           You could borrow upto <br />
//                           <span className="text-xl">
//                             AED{" "}
//                             {loanAmount
//                               ? loanAmount.toLocaleString("en-AE")
//                               : "0"}
//                           </span>
//                         </p>
//                         <p className="text-base sm:text-lg font-semibold text-[#59cfb5] mt-1">
//                           Payable Amount <br />
//                           <span className="text-xl">
//                             AED{" "}
//                             {totalPayable
//                               ? totalPayable.toLocaleString("en-AE")
//                               : "0"}
//                           </span>
//                         </p>
//                       </div>
//                     </div>
//                     <div className="bg-[#f6f6fb] text-center px-4 sm:px-6">
//                       <p className="text-base sm:text-lg text-gray-900 font-semibold border-t pt-2 pb-4 border-gray-300">
//                         Monthly EMI:{" "}
//                         <span className="font-semibold">
//                           AED{" "}
//                           {monthlyEMI
//                             ? monthlyEMI.toLocaleString("en-AE")
//                             : "0"}
//                         </span>
//                       </p>
//                     </div>
//                     <div className="flex items-center justify-center">
//                       <button className="w-70 mt-4 py-3 bg-blue-500 text-white text-sm font-medium rounded hover:bg-blue-600">
//                         Apply for Loan
//                       </button>
//                     </div>
//                     <p className="text-sm text-center text-gray-400 mt-2">
//                       It's easy with Property Finder
//                     </p>
//                   </div>
//                 </div>

//                 {/* About Payment Section */}
//                 <div className="mt-16 sm:mt-24 mb-16 sm:mb-32">
//                   <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900 mb-4 sm:mb-6">
//                     About Payment
//                   </h2>
//                   <p className="text-gray-500 text-base sm:text-lg leading-relaxed">
//                     Palm Jebel Ali Front is a prestigious real estate
//                     development by Nakheel Properties, is situated at the most
//                     Attractive prime popular Dubai Marina location in Dubai UAE.
//                     The development is particularly appealing, making this
//                     ultimate is luxurious living, this exquisite project is
//                     poised to becoming a genuine crossover of luxury and
//                     sophistication. With its calm living atmosphere, facilities,
//                     and beautiful waterfront access, Palm Jebel Ali Front offers
//                     an exceptional lifestyle in one of the most popular living
//                     waterfront locations.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Right Column - Fixed Sidebar */}
//           <div className="hidden lg:block w-full lg:w-[20%] order-last mb-4 lg:mb-0">
//             <div className="lg:sticky lg:top-0 p-2 sm:p-4 lg:pb-32 overflow-y-auto flex justify-center lg:block">
//               <img
//                 src={calc}
//                 alt="Calculator"
//                 className="w-48 sm:w-64 lg:w-auto"
//               />
//             </div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// }

import React, { useState, useMemo } from "react";
import { ChevronLeft, ChevronDown, Search } from "lucide-react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import calc from "../assets/calc.png";
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { useNavigate } from "react-router-dom";

const useCountryData = () => {
  const [countriesFromPackage] = useState(() => {
    return generateCountriesFromPackage();
  });

  return countriesFromPackage;
};

function generateCountriesFromPackage() {
  const realCountries = [
    {
      code: "AF",
      name: "Afghanistan",
      currency: "AFN",
      region: "Asia",
      rate: 0.12,
    },
    {
      code: "AL",
      name: "Albania",
      currency: "ALL",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "DZ",
      name: "Algeria",
      currency: "DZD",
      region: "Africa",
      rate: 0.09,
    },
    {
      code: "AR",
      name: "Argentina",
      currency: "ARS",
      region: "Americas",
      rate: 0.4,
    },
    {
      code: "AM",
      name: "Armenia",
      currency: "AMD",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "AU",
      name: "Australia",
      currency: "AUD",
      region: "Oceania",
      rate: 0.06,
    },
    {
      code: "AT",
      name: "Austria",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "AZ",
      name: "Azerbaijan",
      currency: "AZN",
      region: "Asia",
      rate: 0.13,
    },
    {
      code: "BH",
      name: "Bahrain",
      currency: "BHD",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "BD",
      name: "Bangladesh",
      currency: "BDT",
      region: "Asia",
      rate: 0.09,
    },
    {
      code: "BY",
      name: "Belarus",
      currency: "BYN",
      region: "Europe",
      rate: 0.14,
    },
    {
      code: "BE",
      name: "Belgium",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "BR",
      name: "Brazil",
      currency: "BRL",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "BG",
      name: "Bulgaria",
      currency: "BGN",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "KH",
      name: "Cambodia",
      currency: "KHR",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "CA",
      name: "Canada",
      currency: "CAD",
      region: "Americas",
      rate: 0.065,
    },
    {
      code: "CL",
      name: "Chile",
      currency: "CLP",
      region: "Americas",
      rate: 0.055,
    },
    { code: "CN", name: "China", currency: "CNY", region: "Asia", rate: 0.055 },
    {
      code: "CO",
      name: "Colombia",
      currency: "COP",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "CR",
      name: "Costa Rica",
      currency: "CRC",
      region: "Americas",
      rate: 0.09,
    },
    {
      code: "HR",
      name: "Croatia",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    {
      code: "CY",
      name: "Cyprus",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CZ",
      name: "Czech Republic",
      currency: "CZK",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "DK",
      name: "Denmark",
      currency: "DKK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "EC",
      name: "Ecuador",
      currency: "USD",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "EG",
      name: "Egypt",
      currency: "EGP",
      region: "Africa",
      rate: 0.15,
    },
    {
      code: "EE",
      name: "Estonia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "ET",
      name: "Ethiopia",
      currency: "ETB",
      region: "Africa",
      rate: 0.14,
    },
    {
      code: "FI",
      name: "Finland",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "FR",
      name: "France",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "GE",
      name: "Georgia",
      currency: "GEL",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "DE",
      name: "Germany",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "GH", name: "Ghana", currency: "GHS", region: "Africa", rate: 0.2 },
    {
      code: "GR",
      name: "Greece",
      currency: "EUR",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "HK",
      name: "Hong Kong",
      currency: "HKD",
      region: "Asia",
      rate: 0.03,
    },
    {
      code: "HU",
      name: "Hungary",
      currency: "HUF",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "IS",
      name: "Iceland",
      currency: "ISK",
      region: "Europe",
      rate: 0.07,
    },
    { code: "IN", name: "India", currency: "INR", region: "Asia", rate: 0.085 },
    {
      code: "ID",
      name: "Indonesia",
      currency: "IDR",
      region: "Asia",
      rate: 0.075,
    },
    { code: "IR", name: "Iran", currency: "IRR", region: "Asia", rate: 0.18 },
    { code: "IQ", name: "Iraq", currency: "IQD", region: "Asia", rate: 0.08 },
    {
      code: "IE",
      name: "Ireland",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "IL", name: "Israel", currency: "ILS", region: "Asia", rate: 0.04 },
    {
      code: "IT",
      name: "Italy",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "JP", name: "Japan", currency: "JPY", region: "Asia", rate: 0.015 },
    {
      code: "JO",
      name: "Jordan",
      currency: "JOD",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "KZ",
      name: "Kazakhstan",
      currency: "KZT",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "KE",
      name: "Kenya",
      currency: "KES",
      region: "Africa",
      rate: 0.13,
    },
    {
      code: "KR",
      name: "South Korea",
      currency: "KRW",
      region: "Asia",
      rate: 0.045,
    },
    { code: "KW", name: "Kuwait", currency: "KWD", region: "Asia", rate: 0.04 },
    {
      code: "LV",
      name: "Latvia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LB",
      name: "Lebanon",
      currency: "LBP",
      region: "Asia",
      rate: 0.08,
    },
    {
      code: "LT",
      name: "Lithuania",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LU",
      name: "Luxembourg",
      currency: "EUR",
      region: "Europe",
      rate: 0.03,
    },
    {
      code: "MY",
      name: "Malaysia",
      currency: "MYR",
      region: "Asia",
      rate: 0.04,
    },
    {
      code: "MT",
      name: "Malta",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "MX",
      name: "Mexico",
      currency: "MXN",
      region: "Americas",
      rate: 0.095,
    },
    {
      code: "MA",
      name: "Morocco",
      currency: "MAD",
      region: "Africa",
      rate: 0.055,
    },
    {
      code: "NL",
      name: "Netherlands",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "NZ",
      name: "New Zealand",
      currency: "NZD",
      region: "Oceania",
      rate: 0.065,
    },
    {
      code: "NG",
      name: "Nigeria",
      currency: "NGN",
      region: "Africa",
      rate: 0.18,
    },
    {
      code: "NO",
      name: "Norway",
      currency: "NOK",
      region: "Europe",
      rate: 0.045,
    },
    { code: "OM", name: "Oman", currency: "OMR", region: "Asia", rate: 0.045 },
    {
      code: "PK",
      name: "Pakistan",
      currency: "PKR",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "PE",
      name: "Peru",
      currency: "PEN",
      region: "Americas",
      rate: 0.08,
    },
    {
      code: "PH",
      name: "Philippines",
      currency: "PHP",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "PL",
      name: "Poland",
      currency: "PLN",
      region: "Europe",
      rate: 0.07,
    },
    {
      code: "PT",
      name: "Portugal",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "QA", name: "Qatar", currency: "QAR", region: "Asia", rate: 0.045 },
    {
      code: "RO",
      name: "Romania",
      currency: "RON",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "RU",
      name: "Russia",
      currency: "RUB",
      region: "Europe",
      rate: 0.12,
    },
    {
      code: "SA",
      name: "Saudi Arabia",
      currency: "SAR",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "RS",
      name: "Serbia",
      currency: "RSD",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "SG",
      name: "Singapore",
      currency: "SGD",
      region: "Asia",
      rate: 0.035,
    },
    {
      code: "SK",
      name: "Slovakia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "SI",
      name: "Slovenia",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "ZA",
      name: "South Africa",
      currency: "ZAR",
      region: "Africa",
      rate: 0.11,
    },
    {
      code: "ES",
      name: "Spain",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LK",
      name: "Sri Lanka",
      currency: "LKR",
      region: "Asia",
      rate: 0.14,
    },
    {
      code: "SE",
      name: "Sweden",
      currency: "SEK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CH",
      name: "Switzerland",
      currency: "CHF",
      region: "Europe",
      rate: 0.025,
    },
    {
      code: "TW",
      name: "Taiwan",
      currency: "TWD",
      region: "Asia",
      rate: 0.025,
    },
    {
      code: "TH",
      name: "Thailand",
      currency: "THB",
      region: "Asia",
      rate: 0.045,
    },
    { code: "TR", name: "Turkey", currency: "TRY", region: "Asia", rate: 0.25 },
    {
      code: "UA",
      name: "Ukraine",
      currency: "UAH",
      region: "Europe",
      rate: 0.16,
    },
    {
      code: "AE",
      name: "United Arab Emirates",
      currency: "AED",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "GB",
      name: "United Kingdom",
      currency: "GBP",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "US",
      name: "United States",
      currency: "USD",
      region: "Americas",
      rate: 0.07,
    },
    {
      code: "UY",
      name: "Uruguay",
      currency: "UYU",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "VE",
      name: "Venezuela",
      currency: "VES",
      region: "Americas",
      rate: 0.35,
    },
    {
      code: "VN",
      name: "Vietnam",
      currency: "VND",
      region: "Asia",
      rate: 0.08,
    },
  ];

  return realCountries.map((country) => {
    const currencyMultiplier = {
      USD: 1,
      EUR: 1,
      GBP: 1,
      AUD: 1,
      CAD: 1,
      CHF: 1,
      JPY: 100,
      KRW: 1000,
      INR: 100,
      CNY: 10,
      MXN: 20,
      BRL: 5,
      RUB: 100,
      TRY: 30,
      IDR: 20000,
      VND: 30000,
      THB: 35,
      PHP: 50,
      MYR: 5,
      SGD: 1.5,
      HKD: 8,
      AED: 4,
      SAR: 4,
      QAR: 4,
      KWD: 0.3,
      BHD: 0.4,
    };

    const multiplier = currencyMultiplier[country.currency] || 1;

    return {
      ...country,
    };
  });
}

export default function EMICalculator() {
  const navigate = useNavigate();
  const countriesData = useCountryData();
  const [selectedCountryCode, setSelectedCountryCode] = useState("AE");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [borrowers, setBorrowers] = useState("one");
  const [age, setAge] = useState(35);
  const [income, setIncome] = useState(100000);
  const [emi, setEmi] = useState(10000);
  const [tenure, setTenure] = useState(20);

  const [age2, setAge2] = useState(30);
  const [income2, setIncome2] = useState(80000);
  const [emi2, setEmi2] = useState(5000);

  const [loanAmount, setLoanAmount] = useState(null);
  const [monthlyEMI, setMonthlyEMI] = useState(null);
  const [totalPayable, setTotalPayable] = useState(null);

  // Get current country config
  const countryConfig = useMemo(() => {
    return (
      countriesData.find((c) => c.code === selectedCountryCode) ||
      countriesData[0]
    );
  }, [selectedCountryCode, countriesData]);

  const roi = countryConfig.rate * 100;

  // Filter countries based on search
  const filteredCountries = useMemo(() => {
    if (!searchQuery.trim()) return countriesData;
    const query = searchQuery.toLowerCase();
    return countriesData.filter(
      (country) =>
        country.name.toLowerCase().includes(query) ||
        country.currency.toLowerCase().includes(query) ||
        country.code.toLowerCase().includes(query) ||
        country.region.toLowerCase().includes(query)
    );
  }, [searchQuery, countriesData]);

  // Group countries by region
  const groupedCountries = useMemo(() => {
    const groups = {};
    filteredCountries.forEach((country) => {
      if (!groups[country.region]) {
        groups[country.region] = [];
      }
      groups[country.region].push(country);
    });
    return groups;
  }, [filteredCountries]);

  const handleCountryChange = (countryCode) => {
    setSelectedCountryCode(countryCode);
    setIsDropdownOpen(false);
    setSearchQuery("");
  };

  const calculateLoan = () => {
    let eligibleEMI;

    if (borrowers === "two") {
      const totalIncome = income + income2;
      const totalExistingEMI = emi + emi2;
      eligibleEMI = totalIncome * 0.5 - totalExistingEMI;
    } else {
      eligibleEMI = income * 0.5 - emi;
    }

    if (eligibleEMI <= 0) {
      alert(
        "Your existing EMI is too high. Please reduce existing obligations."
      );
      return;
    }

    const monthlyRate = countryConfig.rate / 12;
    const numberOfMonths = tenure * 12;

    const calculatedLoanAmount =
      eligibleEMI *
      ((1 - Math.pow(1 + monthlyRate, -numberOfMonths)) / monthlyRate);

    const calculatedTotalPayable = eligibleEMI * numberOfMonths;

    setLoanAmount(Math.round(calculatedLoanAmount));
    setMonthlyEMI(Math.round(eligibleEMI));
    setTotalPayable(Math.round(calculatedTotalPayable));
  };

  const generateChartData = () => {
    if (!loanAmount || !monthlyEMI) {
      return Array.from({ length: tenure + 1 }, (_, i) => ({
        year: i,
        principal: 0,
        interest: 0,
      }));
    }

    const monthlyRate = countryConfig.rate / 12;
    let remainingPrincipal = loanAmount;
    const data = [];

    for (let year = 0; year <= tenure; year++) {
      const monthsElapsed = year * 12;

      if (year === 0) {
        data.push({
          year: 0,
          principal: loanAmount,
          interest: 0,
        });
      } else {
        for (let month = 0; month < 12 && remainingPrincipal > 0; month++) {
          const interestForMonth = remainingPrincipal * monthlyRate;
          const principalForMonth = monthlyEMI - interestForMonth;
          remainingPrincipal -= principalForMonth;
        }

        const principalPaid = loanAmount - Math.max(0, remainingPrincipal);
        const interestPaid = monthlyEMI * monthsElapsed - principalPaid;

        data.push({
          year: year,
          principal: Math.max(0, remainingPrincipal),
          interest: interestPaid,
        });
      }
    }

    return data;
  };

  const data = generateChartData();

  return (
    <div className="">
      <Header />
      <div className="flex flex-col lg:flex-row px-4 sm:px-8">
        {/* Left Column - Scrollable Content */}
        <div className="flex-1 overflow-y-auto lg:w-[90%] w-full">
          <div className="p-2 sm:p-4 lg:pr-8">
            <div className="w-full">
              {/* Header with Back button and Country Dropdown */}
              <div className="flex items-center justify-between mb-6 sm:mb-8">
                <div
                  onClick={() => navigate(-1)}
                  className="flex items-center cursor-pointer"
                >
                  <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 mr-1" />
                  <span className="text-lg sm:text-xl font-semibold">Back</span>
                </div>

                {/* Country Dropdown */}
                <div className="relative">
                  <button
                    onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                    className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                  >
                    <span className="font-medium text-sm lg:text-base">
                      {countryConfig.currency}
                    </span>
                    <ChevronDown className="w-4 h-4" />
                  </button>

                  {isDropdownOpen && (
                    <div className="absolute right-0 mt-2 w-72 bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-96 overflow-hidden flex flex-col">
                      <div className="p-3 border-b border-gray-200 sticky top-0 bg-white">
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                          <input
                            type="text"
                            placeholder="Search country..."
                            value={searchQuery}
                            onChange={(e) => setSearchQuery(e.target.value)}
                            className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                          />
                        </div>
                      </div>

                      <div className="overflow-y-auto">
                        {Object.entries(groupedCountries).map(
                          ([region, countries]) => (
                            <div key={region}>
                              <div className="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-600 sticky top-0">
                                {region}
                              </div>
                              {countries.map((country) => (
                                <button
                                  key={country.code}
                                  onClick={() =>
                                    handleCountryChange(country.code)
                                  }
                                  className={`w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors ${
                                    selectedCountryCode === country.code
                                      ? "bg-gray-100"
                                      : ""
                                  }`}
                                >
                                  <div className="text-sm font-medium">
                                    {country.name}
                                  </div>
                                  <div className="text-xs text-gray-500">
                                    {country.currency} •{" "}
                                    {(country.rate * 100).toFixed(1)}% rate
                                  </div>
                                </button>
                              ))}
                            </div>
                          )
                        )}

                        {filteredCountries.length === 0 && (
                          <div className="p-4 text-center text-gray-500 text-sm">
                            No countries found
                          </div>
                        )}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 xl:grid-cols-2 gap-6 sm:gap-8 w-full max-w-6xl">
                {/* Left Form */}
                <div className="bg-white h-fit p-4 sm:p-6 lg:p-8 rounded-xl shadow border border-gray-200">
                  <div className="mb-4 sm:mb-6">
                    <label className="block text-base sm:text-lg font-medium mb-3 sm:mb-4 text-gray-700">
                      Number of Borrowers
                    </label>
                    <div className="flex gap-0">
                      <button
                        onClick={() => setBorrowers("one")}
                        className={`px-4 sm:px-5 py-2 text-sm rounded-l-full font-medium shadow transition-colors ${
                          borrowers === "one"
                            ? "bg-[#00a884] text-white"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        One
                      </button>
                      <button
                        onClick={() => setBorrowers("two")}
                        className={`px-4 sm:px-5 py-2 text-sm rounded-r-full font-medium shadow transition-colors ${
                          borrowers === "two"
                            ? "bg-[#00a884] text-white"
                            : "bg-gray-100 text-gray-600 hover:bg-gray-200"
                        }`}
                      >
                        Two
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 sm:gap-6">
                    <div className="sm:col-span-2">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        {borrowers === "two"
                          ? "First Borrower"
                          : "Borrower Details"}
                      </h3>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">Your Age</label>
                      <div className="flex items-center border border-gray-300  rounded-lg px-3 py-2 mt-1">
                        <input
                          type="number"
                          value={age}
                          onChange={(e) => setAge(Number(e.target.value))}
                          className="w-full outline-none text-sm"
                        />
                        <span className="text-gray-400 text-sm">Years</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">
                        Occupation
                      </label>
                      <select className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 text-sm text-gray-700">
                        <option>Salaried</option>
                        <option>Self-employed</option>
                      </select>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">
                        Net income (Monthly)
                      </label>
                      <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                        <span className="text-gray-500 text-sm mr-1">
                          {countryConfig.currency}
                        </span>
                        <input
                          type="number"
                          value={income}
                          onChange={(e) => setIncome(Number(e.target.value))}
                          className="w-full outline-none text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">
                        Existing Monthly EMI
                      </label>
                      <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                        <span className="text-gray-500 text-sm mr-1">
                          {countryConfig.currency}
                        </span>
                        <input
                          type="number"
                          value={emi}
                          onChange={(e) => setEmi(Number(e.target.value))}
                          className="w-full outline-none text-sm"
                        />
                      </div>
                    </div>

                    {borrowers === "two" && (
                      <>
                        <div className="sm:col-span-2 mt-2">
                          <h3 className="text-sm font-semibold text-gray-700 mb-3">
                            Second Borrower
                          </h3>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500">Age</label>
                          <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                            <input
                              type="number"
                              value={age2}
                              onChange={(e) => setAge2(Number(e.target.value))}
                              className="w-full outline-none text-sm"
                            />
                            <span className="text-gray-400 text-sm">Years</span>
                          </div>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500">
                            Occupation
                          </label>
                          <select className="w-full border border-gray-300 rounded-lg px-3 py-2 mt-1 text-sm text-gray-700">
                            <option>Salaried</option>
                            <option>Self-employed</option>
                          </select>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500">
                            Net income (Monthly)
                          </label>
                          <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                            <span className="text-gray-500 text-sm mr-1">
                              {countryConfig.currency}
                            </span>
                            <input
                              type="number"
                              value={income2}
                              onChange={(e) =>
                                setIncome2(Number(e.target.value))
                              }
                              className="w-full outline-none text-sm"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="text-xs text-gray-500">
                            Existing Monthly EMI
                          </label>
                          <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                            <span className="text-gray-500 text-sm mr-1">
                              {countryConfig.currency}
                            </span>
                            <input
                              type="number"
                              value={emi2}
                              onChange={(e) => setEmi2(Number(e.target.value))}
                              className="w-full outline-none text-sm"
                            />
                          </div>
                        </div>
                      </>
                    )}

                    <div className="sm:col-span-2 mt-2">
                      <h3 className="text-sm font-semibold text-gray-700 mb-3">
                        Loan Details
                      </h3>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">
                        Rate of Interest
                      </label>
                      <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                        <input
                          type="number"
                          step="0.1"
                          value={roi.toFixed(1)}
                          readOnly
                          className="w-full outline-none text-sm bg-gray-50"
                        />
                        <span className="text-gray-400 text-sm ml-1">%</span>
                      </div>
                    </div>

                    <div>
                      <label className="text-xs text-gray-500">Tenure</label>
                      <div className="flex items-center border border-gray-300 rounded-lg px-3 py-2 mt-1">
                        <input
                          type="number"
                          value={tenure}
                          onChange={(e) => setTenure(Number(e.target.value))}
                          className="w-full outline-none text-sm"
                        />
                        <span className="text-gray-400 text-sm ml-1">
                          Years
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex justify-center">
                    <button
                      onClick={calculateLoan}
                      className="w-70 mt-6 sm:mt-8 py-3 border-2 border-blue-500 text-blue-500 text-sm font-medium rounded hover:bg-blue-50"
                    >
                      Calculate
                    </button>
                  </div>
                </div>

                {/* Right Results */}
                <div className="bg-white p-4 sm:p-6 lg:p-8 rounded-xl shadow border border-gray-200 flex flex-col">
                  <h2 className="text-base font-medium mb-4 text-gray-700">
                    Your Estimated Results
                  </h2>
                  <div className="h-48 sm:h-64 mb-6">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart
                        data={data}
                        margin={{ top: 20, right: 20, left: 0, bottom: 20 }}
                      >
                        <XAxis
                          dataKey="year"
                          label={{
                            value: "Time (in years)",
                            position: "bottom",
                            offset: 0,
                          }}
                          tick={{ fontSize: 12, fill: "#374151" }}
                        />

                        <YAxis
                          tickFormatter={(value) =>
                            `${(value / 100000).toFixed(0)}L`
                          }
                          label={{
                            value: `Amount (${countryConfig.currency})`,
                            angle: -90,
                            position: "insideLeft",
                            offset: 10,
                          }}
                          tick={{ fontSize: 12, fill: "#374151" }}
                        />

                        <Tooltip
                          formatter={(value) =>
                            `${countryConfig.currency} ${value.toLocaleString(
                              "en-AE",
                              {
                                maximumFractionDigits: 0,
                              }
                            )}`
                          }
                        />

                        <Area
                          type="monotone"
                          dataKey="principal"
                          stackId="1"
                          stroke="#0e0e43"
                          fill="#0e0e43"
                          fillOpacity={1}
                          name="Principal Remaining"
                        />

                        <Area
                          type="monotone"
                          dataKey="interest"
                          stackId="1"
                          stroke="#59cfb5"
                          fill="#59cfb5"
                          fillOpacity={1}
                          name="Interest Paid"
                        />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>

                  <div className="p-4 sm:p-5 bg-[#f6f6fb] rounded-lg">
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-0">
                      <p className="text-base sm:text-lg font-semibold text-[#0e0e43]">
                        You could borrow upto <br />
                        <span className="text-xl">
                          {countryConfig.currency}{" "}
                          {loanAmount
                            ? loanAmount.toLocaleString("en-AE")
                            : "0"}
                        </span>
                      </p>
                      <p className="text-base sm:text-lg font-semibold text-[#59cfb5] mt-1">
                        Payable Amount <br />
                        <span className="text-xl">
                          {countryConfig.currency}{" "}
                          {totalPayable
                            ? totalPayable.toLocaleString("en-AE")
                            : "0"}
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="bg-[#f6f6fb] text-center px-4 sm:px-6">
                    <p className="text-base sm:text-lg text-gray-900 font-semibold border-t pt-2 pb-4 border-gray-300">
                      Monthly EMI:{" "}
                      <span className="font-semibold">
                        {countryConfig.currency}{" "}
                        {monthlyEMI ? monthlyEMI.toLocaleString("en-AE") : "0"}
                      </span>
                    </p>
                  </div>
                  <div className="flex items-center justify-center">
                    <button className="w-70 mt-4 py-3 bg-blue-500 text-white text-sm font-medium rounded hover:bg-blue-600">
                      Apply for Loan
                    </button>
                  </div>
                  <p className="text-sm text-center text-gray-400 mt-2">
                    It's easy with Property Finder
                  </p>
                </div>
              </div>

              {/* About Payment Section */}
              <div className="mt-16 sm:mt-24 mb-16 sm:mb-32">
                <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900 mb-4 sm:mb-6">
                  About Payment
                </h2>
                <p className="text-gray-500 text-base sm:text-lg leading-relaxed">
                  Palm Jebel Ali Front is a prestigious real estate development
                  by Nakheel Properties, is situated at the most Attractive
                  prime popular Dubai Marina location in Dubai UAE. The
                  development is particularly appealing, making this ultimate is
                  luxurious living, this exquisite project is poised to becoming
                  a genuine crossover of luxury and sophistication. With its
                  calm living atmosphere, facilities, and beautiful waterfront
                  access, Palm Jebel Ali Front offers an exceptional lifestyle
                  in one of the most popular living waterfront locations.
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Fixed Sidebar */}
        <div className="hidden lg:block w-full lg:w-[20%] order-last mb-4 lg:mb-0">
          <div className="lg:sticky lg:top-0 p-2 sm:p-4 lg:pb-32 overflow-y-auto flex justify-center lg:block">
            <img
              src={calc}
              alt="Calculator"
              className="w-48 sm:w-64 lg:w-auto"
            />
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
