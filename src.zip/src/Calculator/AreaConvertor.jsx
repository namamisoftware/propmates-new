// import React, { useState } from "react";
// import { ArrowUpDown, ChevronLeft } from "lucide-react";
// import { useNavigate } from "react-router-dom";
// import Header from "../Components/Header";
// import Footer from "../Components/Footer";
// import calc from "../assets/calc.png";

// export default function AreaConvertor() {
//   const navigate = useNavigate();
//   const [emirate, setEmirate] = useState("");
//   const [fromUnit, setFromUnit] = useState("");
//   const [toUnit, setToUnit] = useState("");
//   const [fromValue, setFromValue] = useState("");
//   const [toValue, setToValue] = useState("");

//   // UAE Emirates list
//   const emirates = [
//     "Abu Dhabi",
//     "Dubai",
//     "Sharjah",
//     "Ajman",
//     "Umm Al Quwain",
//     "Ras Al Khaimah",
//     "Fujairah",
//   ];

//   // Area units commonly used in UAE with conversion to Square Meters
//   const unitConversions = {
//     "Square Meter": 1,
//     "Square Feet": 0.092903,
//     "Square Yard": 0.836127,
//     Acre: 4046.86,
//     Hectare: 10000,
//     Kanal: 505.857, // Used in some regions
//     Marla: 25.2929, // Used in some regions
//   };

//   // Convert area from one unit to another
//   const convertArea = (value, from, to) => {
//     if (!value || !from || !to || isNaN(value)) return "";

//     // Convert to square meters first
//     const valueInSqMeters = parseFloat(value) * unitConversions[from];

//     // Convert from square meters to target unit
//     const result = valueInSqMeters / unitConversions[to];

//     return result.toFixed(6);
//   };

//   // Handle from value change
//   const handleFromValueChange = (e) => {
//     const value = e.target.value;
//     setFromValue(value);

//     if (fromUnit && toUnit) {
//       const converted = convertArea(value, fromUnit, toUnit);
//       setToValue(converted);
//     }
//   };

//   // Handle to value change
//   const handleToValueChange = (e) => {
//     const value = e.target.value;
//     setToValue(value);

//     if (fromUnit && toUnit) {
//       const converted = convertArea(value, toUnit, fromUnit);
//       setFromValue(converted);
//     }
//   };

//   // Handle unit changes
//   const handleFromUnitChange = (e) => {
//     const unit = e.target.value;
//     setFromUnit(unit);

//     if (fromValue && toUnit && unit) {
//       const converted = convertArea(fromValue, unit, toUnit);
//       setToValue(converted);
//     }
//   };

//   const handleToUnitChange = (e) => {
//     const unit = e.target.value;
//     setToUnit(unit);

//     if (fromValue && fromUnit && unit) {
//       const converted = convertArea(fromValue, fromUnit, unit);
//       setToValue(converted);
//     }
//   };

//   // Swap units and values
//   const handleSwap = () => {
//     setFromUnit(toUnit);
//     setToUnit(fromUnit);
//     setFromValue(toValue);
//     setToValue(fromValue);
//   };

//   return (
//     <>
//       <Header />
//       <div className="">
//         <div className="flex flex-col lg:flex-row px-4 sm:px-6 lg:px-8">
//           {/* Left Column - Scrollable Content */}
//           <div className="flex-1 overflow-y-auto w-full lg:w-[90%]">
//             <div className="p-2 sm:p-4 lg:pr-8">
//               <div className="max-w-6xl">
//                 {/* Header */}
//                 <div
//                   onClick={() => navigate(-1)}
//                   className="flex items-center mb-6 sm:mb-8 cursor-pointer"
//                 >
//                   <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 mr-1" />
//                   <span className="text-lg sm:text-xl font-semibold">Back</span>
//                 </div>

//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
//                   <div className="w-full max-w-lg bg-white shadow-lg rounded-xl px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10">
//                     <h2 className="text-xl sm:text-2xl font-bold mb-1 text-gray-800">
//                       Area Converter
//                     </h2>
//                     <p className="text-sm text-gray-500 mb-4 sm:mb-6">
//                       Enter the value and select desired unit
//                     </p>

//                     {/* Emirate Selector */}
//                     <div className="mb-4 sm:mb-6">
//                       <div className="flex justify-between items-center border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
//                         <span className="text-gray-600 text-sm sm:text-base">
//                           Emirate
//                         </span>
//                         <select
//                           value={emirate}
//                           onChange={(e) => setEmirate(e.target.value)}
//                           className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
//                         >
//                           <option value="">Select Emirate</option>
//                           {emirates.map((em) => (
//                             <option key={em} value={em}>
//                               {em}
//                             </option>
//                           ))}
//                         </select>
//                       </div>
//                       <p className="text-xs text-gray-400 mt-1">
//                         Different emirates may use different area measurement
//                         conventions
//                       </p>
//                     </div>

//                     {/* From + Swap + To */}
//                     <div className="relative flex flex-col gap-4 sm:gap-6">
//                       {/* From */}
//                       <div className="border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
//                         <div className="flex justify-between items-center mb-2">
//                           <span className="text-gray-600 text-sm sm:text-base">
//                             From
//                           </span>
//                           <select
//                             value={fromUnit}
//                             onChange={handleFromUnitChange}
//                             className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
//                           >
//                             <option value="">Select unit</option>
//                             {Object.keys(unitConversions).map((unit) => (
//                               <option key={unit} value={unit}>
//                                 {unit}
//                               </option>
//                             ))}
//                           </select>
//                         </div>
//                         <input
//                           type="number"
//                           value={fromValue}
//                           onChange={handleFromValueChange}
//                           placeholder="Enter value"
//                           className="w-full outline-none text-lg sm:text-xl font-semibold text-gray-800"
//                           step="any"
//                         />
//                       </div>

//                       {/* Swap button in middle */}
//                       <button
//                         type="button"
//                         onClick={handleSwap}
//                         className="absolute left-1/2 transform -translate-x-1/2 top-12 sm:top-14 bg-white border border-gray-200 shadow-md p-2 rounded-full hover:bg-gray-100 transition-colors z-10"
//                       >
//                         <ArrowUpDown className="w-4 h-4 text-gray-600" />
//                       </button>

//                       {/* To */}
//                       <div className="border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
//                         <div className="flex justify-between items-center mb-2">
//                           <span className="text-gray-600 text-sm sm:text-base">
//                             To
//                           </span>
//                           <select
//                             value={toUnit}
//                             onChange={handleToUnitChange}
//                             className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
//                           >
//                             <option value="">Select unit</option>
//                             {Object.keys(unitConversions).map((unit) => (
//                               <option key={unit} value={unit}>
//                                 {unit}
//                               </option>
//                             ))}
//                           </select>
//                         </div>
//                         <input
//                           type="number"
//                           value={toValue}
//                           onChange={handleToValueChange}
//                           placeholder="Converted value"
//                           className="w-full outline-none text-lg sm:text-xl font-semibold text-blue-600"
//                           step="any"
//                         />
//                       </div>
//                     </div>

//                     {/* Conversion Info */}
//                     {fromValue && fromUnit && toUnit && (
//                       <div className="mt-4 p-3 bg-blue-50 rounded-lg">
//                         <p className="text-sm text-blue-800">
//                           <span className="font-semibold">
//                             {fromValue} {fromUnit}
//                           </span>{" "}
//                           =
//                           <span className="font-semibold">
//                             {" "}
//                             {toValue} {toUnit}
//                           </span>
//                         </p>
//                       </div>
//                     )}

//                     {/* Info Text */}
//                     <p className="text-xs text-gray-400 italic mt-4">
//                       *This tool is for informational purposes only. Actual
//                       measurements may vary.
//                     </p>
//                   </div>

//                   {/* Conversion Table - Side by Side on Large Screens */}
//                   {fromValue && fromUnit && (
//                     <div className="bg-white shadow-lg rounded-xl p-4 sm:p-6 w-full max-w-lg lg:max-w-none">
//                       <h3 className="text-lg sm:text-xl font-semibold mb-4 text-gray-800">
//                         {fromValue} {fromUnit} is equal to:
//                       </h3>
//                       <div className="space-y-2">
//                         {Object.keys(unitConversions)
//                           .filter((unit) => unit !== fromUnit)
//                           .map((unit) => {
//                             const converted = convertArea(
//                               fromValue,
//                               fromUnit,
//                               unit
//                             );
//                             return (
//                               <div
//                                 key={unit}
//                                 className="flex justify-between items-center py-2 border-b border-gray-100"
//                               >
//                                 <span className="text-gray-600">{unit}</span>
//                                 <span className="font-semibold text-gray-800">
//                                   {converted}
//                                 </span>
//                               </div>
//                             );
//                           })}
//                       </div>
//                     </div>
//                   )}
//                 </div>

//                 {/* About Payment Section */}
//                 <div className="mt-16 sm:mt-24 lg:mt-32 mb-16 sm:mb-24 lg:mb-32">
//                   <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900 mb-4 sm:mb-6">
//                     About Payment
//                   </h2>
//                   <p className="text-gray-500 text-base sm:text-lg leading-relaxed">
//                     Palm Jebel Ali Front is a prestigious real estate
//                     development by Nakheel Properties, is situated at the most
//                     Attractive prime popular Dubai Marina location in Dubai UAE.
//                     The development is particularly appealing, making this
//                     ultimate is luxurious living, this exquisite project is
//                     poised to becoming a genuine crossover of luxury and
//                     sophistication. With its calm living atmosphere, facilities,
//                     and beautiful waterfront access, Palm Jebel Ali Front offers
//                     an exceptional lifestyle in one of the most popular living
//                     waterfront locations.
//                   </p>
//                 </div>
//               </div>
//             </div>
//           </div>

//           {/* Right Column - Fixed Sidebar */}
//           <div className="hidden lg:block w-full lg:w-[20%] mt-8 lg:mt-0">
//             <div className="sticky top-0 p-4 pb-16 lg:pb-32 overflow-y-auto flex justify-center lg:block">
//               <img
//                 src={calc}
//                 alt="Calculator"
//                 className="w-48 sm:w-56 lg:w-full max-w-xs lg:max-w-none"
//               />
//             </div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// }

import React, { useState, useMemo } from "react";
import { ArrowUpDown, ChevronLeft, ChevronDown, Search } from "lucide-react";
import Header from "../Components/Header";
import Footer from "../Components/Footer";
import calc from "../assets/calc.png";
import { useNavigate } from "react-router-dom";

const useCountryData = () => {
  const [countriesFromPackage] = useState(() => {
    return generateCountriesFromPackage();
  });

  return countriesFromPackage;
};

function generateCountriesFromPackage() {
  const realCountries = [
    {
      code: "AF",
      name: "Afghanistan",
      currency: "AFN",
      region: "Asia",
      rate: 0.12,
    },
    {
      code: "AL",
      name: "Albania",
      currency: "ALL",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "DZ",
      name: "Algeria",
      currency: "DZD",
      region: "Africa",
      rate: 0.09,
    },
    {
      code: "AR",
      name: "Argentina",
      currency: "ARS",
      region: "Americas",
      rate: 0.4,
    },
    {
      code: "AM",
      name: "Armenia",
      currency: "AMD",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "AU",
      name: "Australia",
      currency: "AUD",
      region: "Oceania",
      rate: 0.06,
    },
    {
      code: "AT",
      name: "Austria",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "AZ",
      name: "Azerbaijan",
      currency: "AZN",
      region: "Asia",
      rate: 0.13,
    },
    {
      code: "BH",
      name: "Bahrain",
      currency: "BHD",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "BD",
      name: "Bangladesh",
      currency: "BDT",
      region: "Asia",
      rate: 0.09,
    },
    {
      code: "BY",
      name: "Belarus",
      currency: "BYN",
      region: "Europe",
      rate: 0.14,
    },
    {
      code: "BE",
      name: "Belgium",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "BR",
      name: "Brazil",
      currency: "BRL",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "BG",
      name: "Bulgaria",
      currency: "BGN",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "KH",
      name: "Cambodia",
      currency: "KHR",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "CA",
      name: "Canada",
      currency: "CAD",
      region: "Americas",
      rate: 0.065,
    },
    {
      code: "CL",
      name: "Chile",
      currency: "CLP",
      region: "Americas",
      rate: 0.055,
    },
    { code: "CN", name: "China", currency: "CNY", region: "Asia", rate: 0.055 },
    {
      code: "CO",
      name: "Colombia",
      currency: "COP",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "CR",
      name: "Costa Rica",
      currency: "CRC",
      region: "Americas",
      rate: 0.09,
    },
    {
      code: "HR",
      name: "Croatia",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    {
      code: "CY",
      name: "Cyprus",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CZ",
      name: "Czech Republic",
      currency: "CZK",
      region: "Europe",
      rate: 0.06,
    },
    {
      code: "DK",
      name: "Denmark",
      currency: "DKK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "EC",
      name: "Ecuador",
      currency: "USD",
      region: "Americas",
      rate: 0.1,
    },
    {
      code: "EG",
      name: "Egypt",
      currency: "EGP",
      region: "Africa",
      rate: 0.15,
    },
    {
      code: "EE",
      name: "Estonia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "ET",
      name: "Ethiopia",
      currency: "ETB",
      region: "Africa",
      rate: 0.14,
    },
    {
      code: "FI",
      name: "Finland",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "FR",
      name: "France",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "GE",
      name: "Georgia",
      currency: "GEL",
      region: "Asia",
      rate: 0.11,
    },
    {
      code: "DE",
      name: "Germany",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "GH", name: "Ghana", currency: "GHS", region: "Africa", rate: 0.2 },
    {
      code: "GR",
      name: "Greece",
      currency: "EUR",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "HK",
      name: "Hong Kong",
      currency: "HKD",
      region: "Asia",
      rate: 0.03,
    },
    {
      code: "HU",
      name: "Hungary",
      currency: "HUF",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "IS",
      name: "Iceland",
      currency: "ISK",
      region: "Europe",
      rate: 0.07,
    },
    { code: "IN", name: "India", currency: "INR", region: "Asia", rate: 0.085 },
    {
      code: "ID",
      name: "Indonesia",
      currency: "IDR",
      region: "Asia",
      rate: 0.075,
    },
    { code: "IR", name: "Iran", currency: "IRR", region: "Asia", rate: 0.18 },
    { code: "IQ", name: "Iraq", currency: "IQD", region: "Asia", rate: 0.08 },
    {
      code: "IE",
      name: "Ireland",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    { code: "IL", name: "Israel", currency: "ILS", region: "Asia", rate: 0.04 },
    {
      code: "IT",
      name: "Italy",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "JP", name: "Japan", currency: "JPY", region: "Asia", rate: 0.015 },
    {
      code: "JO",
      name: "Jordan",
      currency: "JOD",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "KZ",
      name: "Kazakhstan",
      currency: "KZT",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "KE",
      name: "Kenya",
      currency: "KES",
      region: "Africa",
      rate: 0.13,
    },
    {
      code: "KR",
      name: "South Korea",
      currency: "KRW",
      region: "Asia",
      rate: 0.045,
    },
    { code: "KW", name: "Kuwait", currency: "KWD", region: "Asia", rate: 0.04 },
    {
      code: "LV",
      name: "Latvia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LB",
      name: "Lebanon",
      currency: "LBP",
      region: "Asia",
      rate: 0.08,
    },
    {
      code: "LT",
      name: "Lithuania",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LU",
      name: "Luxembourg",
      currency: "EUR",
      region: "Europe",
      rate: 0.03,
    },
    {
      code: "MY",
      name: "Malaysia",
      currency: "MYR",
      region: "Asia",
      rate: 0.04,
    },
    {
      code: "MT",
      name: "Malta",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "MX",
      name: "Mexico",
      currency: "MXN",
      region: "Americas",
      rate: 0.095,
    },
    {
      code: "MA",
      name: "Morocco",
      currency: "MAD",
      region: "Africa",
      rate: 0.055,
    },
    {
      code: "NL",
      name: "Netherlands",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "NZ",
      name: "New Zealand",
      currency: "NZD",
      region: "Oceania",
      rate: 0.065,
    },
    {
      code: "NG",
      name: "Nigeria",
      currency: "NGN",
      region: "Africa",
      rate: 0.18,
    },
    {
      code: "NO",
      name: "Norway",
      currency: "NOK",
      region: "Europe",
      rate: 0.045,
    },
    { code: "OM", name: "Oman", currency: "OMR", region: "Asia", rate: 0.045 },
    {
      code: "PK",
      name: "Pakistan",
      currency: "PKR",
      region: "Asia",
      rate: 0.15,
    },
    {
      code: "PE",
      name: "Peru",
      currency: "PEN",
      region: "Americas",
      rate: 0.08,
    },
    {
      code: "PH",
      name: "Philippines",
      currency: "PHP",
      region: "Asia",
      rate: 0.065,
    },
    {
      code: "PL",
      name: "Poland",
      currency: "PLN",
      region: "Europe",
      rate: 0.07,
    },
    {
      code: "PT",
      name: "Portugal",
      currency: "EUR",
      region: "Europe",
      rate: 0.045,
    },
    { code: "QA", name: "Qatar", currency: "QAR", region: "Asia", rate: 0.045 },
    {
      code: "RO",
      name: "Romania",
      currency: "RON",
      region: "Europe",
      rate: 0.065,
    },
    {
      code: "RU",
      name: "Russia",
      currency: "RUB",
      region: "Europe",
      rate: 0.12,
    },
    {
      code: "SA",
      name: "Saudi Arabia",
      currency: "SAR",
      region: "Asia",
      rate: 0.045,
    },
    {
      code: "RS",
      name: "Serbia",
      currency: "RSD",
      region: "Europe",
      rate: 0.08,
    },
    {
      code: "SG",
      name: "Singapore",
      currency: "SGD",
      region: "Asia",
      rate: 0.035,
    },
    {
      code: "SK",
      name: "Slovakia",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "SI",
      name: "Slovenia",
      currency: "EUR",
      region: "Europe",
      rate: 0.035,
    },
    {
      code: "ZA",
      name: "South Africa",
      currency: "ZAR",
      region: "Africa",
      rate: 0.11,
    },
    {
      code: "ES",
      name: "Spain",
      currency: "EUR",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "LK",
      name: "Sri Lanka",
      currency: "LKR",
      region: "Asia",
      rate: 0.14,
    },
    {
      code: "SE",
      name: "Sweden",
      currency: "SEK",
      region: "Europe",
      rate: 0.04,
    },
    {
      code: "CH",
      name: "Switzerland",
      currency: "CHF",
      region: "Europe",
      rate: 0.025,
    },
    {
      code: "TW",
      name: "Taiwan",
      currency: "TWD",
      region: "Asia",
      rate: 0.025,
    },
    {
      code: "TH",
      name: "Thailand",
      currency: "THB",
      region: "Asia",
      rate: 0.045,
    },
    { code: "TR", name: "Turkey", currency: "TRY", region: "Asia", rate: 0.25 },
    {
      code: "UA",
      name: "Ukraine",
      currency: "UAH",
      region: "Europe",
      rate: 0.16,
    },
    {
      code: "AE",
      name: "United Arab Emirates",
      currency: "AED",
      region: "Asia",
      rate: 0.045,
      states: [
        "Abu Dhabi",
        "Dubai",
        "Sharjah",
        "Ajman",
        "Umm Al Quwain",
        "Ras Al Khaimah",
        "Fujairah",
      ],
    },
    {
      code: "GB",
      name: "United Kingdom",
      currency: "GBP",
      region: "Europe",
      rate: 0.055,
    },
    {
      code: "US",
      name: "United States",
      currency: "USD",
      region: "Americas",
      rate: 0.07,
    },
    {
      code: "UY",
      name: "Uruguay",
      currency: "UYU",
      region: "Americas",
      rate: 0.12,
    },
    {
      code: "VE",
      name: "Venezuela",
      currency: "VES",
      region: "Americas",
      rate: 0.35,
    },
    {
      code: "VN",
      name: "Vietnam",
      currency: "VND",
      region: "Asia",
      rate: 0.08,
    },
  ];

  return realCountries;
}

export default function AreaConvertor() {
  const navigate = useNavigate();
  const countriesData = useCountryData();
  const [selectedCountryCode, setSelectedCountryCode] = useState("AE");
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const [state, setState] = useState("");
  const [fromUnit, setFromUnit] = useState("");
  const [toUnit, setToUnit] = useState("");
  const [fromValue, setFromValue] = useState("");
  const [toValue, setToValue] = useState("");

  // Get current country config
  const countryConfig = useMemo(() => {
    return (
      countriesData.find((c) => c.code === selectedCountryCode) ||
      countriesData[0]
    );
  }, [selectedCountryCode, countriesData]);

  // Filter countries based on search
  const filteredCountries = useMemo(() => {
    if (!searchQuery.trim()) return countriesData;
    const query = searchQuery.toLowerCase();
    return countriesData.filter(
      (country) =>
        country.name.toLowerCase().includes(query) ||
        country.currency.toLowerCase().includes(query) ||
        country.code.toLowerCase().includes(query) ||
        country.region.toLowerCase().includes(query)
    );
  }, [searchQuery, countriesData]);

  // Group countries by region
  const groupedCountries = useMemo(() => {
    const groups = {};
    filteredCountries.forEach((country) => {
      if (!groups[country.region]) {
        groups[country.region] = [];
      }
      groups[country.region].push(country);
    });
    return groups;
  }, [filteredCountries]);

  const handleCountryChange = (countryCode) => {
    setSelectedCountryCode(countryCode);
    setIsDropdownOpen(false);
    setSearchQuery("");
    setState(""); // Reset state when country changes
  };

  // Area units commonly used with conversion to Square Meters
  const unitConversions = {
    "Square Meter": 1,
    "Square Feet": 0.092903,
    "Square Yard": 0.836127,
    Acre: 4046.86,
    Hectare: 10000,
    Kanal: 505.857,
    Marla: 25.2929,
  };

  // Convert area from one unit to another
  const convertArea = (value, from, to) => {
    if (!value || !from || !to || isNaN(value)) return "";

    const valueInSqMeters = parseFloat(value) * unitConversions[from];
    const result = valueInSqMeters / unitConversions[to];

    return result.toFixed(6);
  };

  // Handle from value change
  const handleFromValueChange = (e) => {
    const value = e.target.value;
    setFromValue(value);

    if (fromUnit && toUnit) {
      const converted = convertArea(value, fromUnit, toUnit);
      setToValue(converted);
    }
  };

  // Handle to value change
  const handleToValueChange = (e) => {
    const value = e.target.value;
    setToValue(value);

    if (fromUnit && toUnit) {
      const converted = convertArea(value, toUnit, fromUnit);
      setFromValue(converted);
    }
  };

  // Handle unit changes
  const handleFromUnitChange = (e) => {
    const unit = e.target.value;
    setFromUnit(unit);

    if (fromValue && toUnit && unit) {
      const converted = convertArea(fromValue, unit, toUnit);
      setToValue(converted);
    }
  };

  const handleToUnitChange = (e) => {
    const unit = e.target.value;
    setToUnit(unit);

    if (fromValue && fromUnit && unit) {
      const converted = convertArea(fromValue, fromUnit, unit);
      setToValue(converted);
    }
  };

  // Swap units and values
  const handleSwap = () => {
    setFromUnit(toUnit);
    setToUnit(fromUnit);
    setFromValue(toValue);
    setToValue(fromValue);
  };

  return (
    <>
      <Header />
      <div className="">
        <div className="flex flex-col lg:flex-row px-4 sm:px-6 lg:px-8">
          {/* Left Column - Scrollable Content */}
          <div className="flex-1 overflow-y-auto w-full lg:w-[90%]">
            <div className="p-2 sm:p-4 lg:pr-8">
              <div className="max-w-6xl">
                {/* Header with Back button and Country Dropdown */}
                <div className="flex items-center justify-between mb-6 sm:mb-8">
                  <div
                    onClick={() => navigate(-1)}
                    className="flex items-center cursor-pointer"
                  >
                    <ChevronLeft className="w-6 h-6 sm:w-7 sm:h-7 mr-1" />
                    <span className="text-lg sm:text-xl font-semibold">
                      Back
                    </span>
                  </div>

                  {/* Country Dropdown */}
                  <div className="relative">
                    <button
                      onClick={() => setIsDropdownOpen(!isDropdownOpen)}
                      className="flex items-center gap-2 px-3 py-2 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 transition-colors"
                    >
                      <span className="font-medium text-sm lg:text-base">
                        {countryConfig.name}
                      </span>
                      <ChevronDown className="w-4 h-4" />
                    </button>

                    {isDropdownOpen && (
                      <div className="absolute right-0 mt-2 w-72 bg-white border border-gray-200 rounded-lg shadow-lg z-10 max-h-96 overflow-hidden flex flex-col">
                        <div className="p-3 border-b border-gray-200 sticky top-0 bg-white">
                          <div className="relative">
                            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                            <input
                              type="text"
                              placeholder="Search country..."
                              value={searchQuery}
                              onChange={(e) => setSearchQuery(e.target.value)}
                              className="w-full pl-9 pr-3 py-2 border border-gray-300 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                        </div>

                        <div className="overflow-y-auto">
                          {Object.entries(groupedCountries).map(
                            ([region, countries]) => (
                              <div key={region}>
                                <div className="px-4 py-2 bg-gray-50 text-xs font-semibold text-gray-600 sticky top-0">
                                  {region}
                                </div>
                                {countries.map((country) => (
                                  <button
                                    key={country.code}
                                    onClick={() =>
                                      handleCountryChange(country.code)
                                    }
                                    className={`w-full text-left px-4 py-2 hover:bg-gray-100 transition-colors ${
                                      selectedCountryCode === country.code
                                        ? "bg-gray-100"
                                        : ""
                                    }`}
                                  >
                                    <div className="text-sm font-medium">
                                      {country.name}
                                    </div>
                                    <div className="text-xs text-gray-500">
                                      {country.currency}
                                    </div>
                                  </button>
                                ))}
                              </div>
                            )
                          )}

                          {filteredCountries.length === 0 && (
                            <div className="p-4 text-center text-gray-500 text-sm">
                              No countries found
                            </div>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
                  <div className="w-full max-w-lg bg-white shadow-lg rounded-xl px-4 sm:px-6 lg:px-8 py-6 sm:py-8 lg:py-10">
                    <h2 className="text-xl sm:text-2xl font-bold mb-1 text-gray-800">
                      Area Converter
                    </h2>
                    <p className="text-sm text-gray-500 mb-4 sm:mb-6">
                      Enter the value and select desired unit
                    </p>

                    {/* State/Region Selector - Only show if country has states */}
                    {countryConfig.states && (
                      <div className="mb-4 sm:mb-6">
                        <div className="flex justify-between items-center border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
                          <span className="text-gray-600 text-sm sm:text-base">
                            {countryConfig.code === "AE"
                              ? "Emirate"
                              : "State/Region"}
                          </span>
                          <select
                            value={state}
                            onChange={(e) => setState(e.target.value)}
                            className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
                          >
                            <option value="">
                              Select{" "}
                              {countryConfig.code === "AE"
                                ? "Emirate"
                                : "State"}
                            </option>
                            {countryConfig.states.map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                        </div>
                        <p className="text-xs text-gray-400 mt-1">
                          Different regions may use different area measurement
                          conventions
                        </p>
                      </div>
                    )}

                    {/* From + Swap + To */}
                    <div className="relative flex flex-col gap-4 sm:gap-6">
                      {/* From */}
                      <div className="border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-gray-600 text-sm sm:text-base">
                            From
                          </span>
                          <select
                            value={fromUnit}
                            onChange={handleFromUnitChange}
                            className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
                          >
                            <option value="">Select unit</option>
                            {Object.keys(unitConversions).map((unit) => (
                              <option key={unit} value={unit}>
                                {unit}
                              </option>
                            ))}
                          </select>
                        </div>
                        <input
                          type="number"
                          value={fromValue}
                          onChange={handleFromValueChange}
                          placeholder="Enter value"
                          className="w-full outline-none text-lg sm:text-xl font-semibold text-gray-800"
                          step="any"
                        />
                      </div>

                      {/* Swap button in middle */}
                      <button
                        type="button"
                        onClick={handleSwap}
                        className="absolute left-1/2 transform -translate-x-1/2 top-12 sm:top-14 bg-white border border-gray-200 shadow-md p-2 rounded-full hover:bg-gray-100 transition-colors z-10"
                      >
                        <ArrowUpDown className="w-4 h-4 text-gray-600" />
                      </button>

                      {/* To */}
                      <div className="border border-gray-300 rounded-lg px-3 sm:px-4 py-2 sm:py-3">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-gray-600 text-sm sm:text-base">
                            To
                          </span>
                          <select
                            value={toUnit}
                            onChange={handleToUnitChange}
                            className="bg-transparent focus:outline-none text-gray-700 text-sm sm:text-base cursor-pointer"
                          >
                            <option value="">Select unit</option>
                            {Object.keys(unitConversions).map((unit) => (
                              <option key={unit} value={unit}>
                                {unit}
                              </option>
                            ))}
                          </select>
                        </div>
                        <input
                          type="number"
                          value={toValue}
                          onChange={handleToValueChange}
                          placeholder="Converted value"
                          className="w-full outline-none text-lg sm:text-xl font-semibold text-blue-600"
                          step="any"
                        />
                      </div>
                    </div>

                    {/* Conversion Info */}
                    {fromValue && fromUnit && toUnit && (
                      <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                        <p className="text-sm text-blue-800">
                          <span className="font-semibold">
                            {fromValue} {fromUnit}
                          </span>{" "}
                          =
                          <span className="font-semibold">
                            {" "}
                            {toValue} {toUnit}
                          </span>
                        </p>
                      </div>
                    )}

                    {/* Info Text */}
                    <p className="text-xs text-gray-400 italic mt-4">
                      *This tool is for informational purposes only. Actual
                      measurements may vary.
                    </p>
                  </div>

                  {/* Conversion Table - Side by Side on Large Screens */}
                  {fromValue && fromUnit && (
                    <div className="bg-white shadow-lg rounded-xl p-4 sm:p-6 w-full max-w-lg lg:max-w-none">
                      <h3 className="text-lg sm:text-xl font-semibold mb-4 text-gray-800">
                        {fromValue} {fromUnit} is equal to:
                      </h3>
                      <div className="space-y-2">
                        {Object.keys(unitConversions)
                          .filter((unit) => unit !== fromUnit)
                          .map((unit) => {
                            const converted = convertArea(
                              fromValue,
                              fromUnit,
                              unit
                            );
                            return (
                              <div
                                key={unit}
                                className="flex justify-between items-center py-2 border-b border-gray-100"
                              >
                                <span className="text-gray-600">{unit}</span>
                                <span className="font-semibold text-gray-800">
                                  {converted}
                                </span>
                              </div>
                            );
                          })}
                      </div>
                    </div>
                  )}
                </div>

                {/* About Payment Section */}
                <div className="mt-16 sm:mt-24 lg:mt-32 mb-16 sm:mb-24 lg:mb-32">
                  <h2 className="text-2xl sm:text-3xl font-semibold text-gray-900 mb-4 sm:mb-6">
                    About Payment
                  </h2>
                  <p className="text-gray-500 text-base sm:text-lg leading-relaxed">
                    Palm Jebel Ali Front is a prestigious real estate
                    development by Nakheel Properties, is situated at the most
                    Attractive prime popular Dubai Marina location in Dubai UAE.
                    The development is particularly appealing, making this
                    ultimate is luxurious living, this exquisite project is
                    poised to becoming a genuine crossover of luxury and
                    sophistication. With its calm living atmosphere, facilities,
                    and beautiful waterfront access, Palm Jebel Ali Front offers
                    an exceptional lifestyle in one of the most popular living
                    waterfront locations.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column - Fixed Sidebar */}
          <div className="hidden lg:block w-full lg:w-[20%] mt-8 lg:mt-0">
            <div className="sticky top-0 p-4 pb-16 lg:pb-32 overflow-y-auto flex justify-center lg:block">
              <img
                src={calc}
                alt="Calculator"
                className="w-48 sm:w-56 lg:w-full max-w-xs lg:max-w-none"
              />
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </>
  );
}
