import React, { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import searchbg from "./assets/developers.png";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "./Components/Navbar";

const Developers = () => {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState("Ras Al Khaimah");
  const [currentPage, setCurrentPage] = useState(1);
  const developersPerPage = 3;
  const locations = ["Ras Al Khaimah", "Dubai", "Abu Dhabi", "Sharjah"];

  // Developer/Company data
  const locationData = {
    "Abu Dhabi": [
      {
        id: 1,
        logo: "EMAAR",
        companyName: "Emaar Properties",
        description:
          "Emaar Properties is a global property developer and provider of premium lifestyles, with operations in the United Arab Emirates, Saudi Arabia, Syria, Jordan and other markets in the region.",
        foundedYear: "1997",
      },
      {
        id: 2,
        logo: "ALDAR",
        companyName: "Aldar Properties",
        description:
          "Aldar is the leading real estate developer, manager and investor in Abu Dhabi, with a diversified and sustainable asset portfolio.",
        foundedYear: "2004",
      },
      {
        id: 3,
        logo: "杜",
        companyName: "Dubai Properties",
        description:
          "Dubai Properties is one of the region's leading real estate master developers, with a diversified portfolio of residential, commercial, hospitality and retail assets.",
        foundedYear: "2002",
      },
      {
        id: 4,
        logo: "DAMAC",
        companyName: "DAMAC Properties",
        description:
          "DAMAC Properties is a luxury real estate development company established in 2002, delivering iconic residential, commercial and leisure properties across the Middle East.",
        foundedYear: "2002",
      },
    ],
    Dubai: [
      {
        id: 5,
        logo: "EMAAR",
        companyName: "Emaar Properties",
        description:
          "Emaar Properties is a global property developer and provider of premium lifestyles, with operations in the United Arab Emirates, Saudi Arabia, Syria, Jordan and other markets in the region.",
        foundedYear: "1997",
      },
      {
        id: 6,
        logo: "ALDAR",
        companyName: "Aldar Properties",
        description:
          "Aldar is the leading real estate developer, manager and investor in Abu Dhabi, with a diversified and sustainable asset portfolio.",
        foundedYear: "2004",
      },
      {
        id: 7,
        logo: "杜",
        companyName: "Dubai Properties",
        description:
          "Dubai Properties is one of the region's leading real estate master developers, with a diversified portfolio of residential, commercial, hospitality and retail assets.",
        foundedYear: "2002",
      },
      {
        id: 8,
        logo: "DAMAC",
        companyName: "DAMAC Properties",
        description:
          "DAMAC Properties is a luxury real estate development company established in 2002, delivering iconic residential, commercial and leisure properties across the Middle East.",
        foundedYear: "2002",
      },
    ],
    Sharjah: [
      {
        id: 9,
        logo: "EMAAR",
        companyName: "Emaar Properties",
        description:
          "Emaar Properties is a global property developer and provider of premium lifestyles, with operations in the United Arab Emirates, Saudi Arabia, Syria, Jordan and other markets in the region.",
        foundedYear: "1997",
      },
      {
        id: 10,
        logo: "ALDAR",
        companyName: "Aldar Properties",
        description:
          "Aldar is the leading real estate developer, manager and investor in Abu Dhabi, with a diversified and sustainable asset portfolio.",
        foundedYear: "2004",
      },
      {
        id: 11,
        logo: "杜",
        companyName: "Dubai Properties",
        description:
          "Dubai Properties is one of the region's leading real estate master developers, with a diversified portfolio of residential, commercial, hospitality and retail assets.",
        foundedYear: "2002",
      },
    ],
    "Ras Al Khaimah": [
      {
        id: 12,
        logo: "EMAAR",
        companyName: "Emaar Properties",
        description:
          "Emaar Properties is a global property developer and provider of premium lifestyles, with operations in the United Arab Emirates, Saudi Arabia, Syria, Jordan and other markets in the region.",
        foundedYear: "1997",
      },
      {
        id: 13,
        logo: "DAMAC",
        companyName: "DAMAC Properties",
        description:
          "DAMAC Properties is a luxury real estate development company established in 2002, delivering iconic residential, commercial and leisure properties across the Middle East.",
        foundedYear: "2002",
      },
    ],
  };

  const currentProperties = locationData[activeTab] || [];
  const totalPages = Math.ceil(currentProperties.length / developersPerPage);
  const startIndex = (currentPage - 1) * developersPerPage;
  const currentDevelopers = currentProperties.slice(
    startIndex,
    startIndex + developersPerPage
  );

  const handleTabChange = (location) => {
    setActiveTab(location);
    setCurrentPage(1); // Reset to first page when changing tabs
  };

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <div className="relative">
        {/* Background Image */}
        <div className="w-full h-[250px] sm:h-[350px] lg:h-[450px] relative overflow-hidden">
          <img
            src={searchbg}
            className="w-full h-full object-cover"
            alt="Real Estate Developers"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, white 5%, rgba(255,255,255,0) 100%)",
              pointerEvents: "none",
            }}
          />
        </div>

        {/* Hero Content */}
        <div className="absolute inset-0 flex flex-col justify-center items-center px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            {/* Main heading - Responsive text sizes */}
            <h1 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0B154F] mb-8 sm:mb-12 leading-tight">
              Top Real Estate Developers in UAE
            </h1>

            {/* Location tabs - Improved mobile experience */}
            <div className="w-full overflow-x-auto scrollbar-hide">
              <div className="flex items-center justify-center gap-2 sm:gap-4 md:gap-8 lg:gap-12 min-w-max px-2">
                {locations.map((location) => (
                  <button
                    key={location}
                    onClick={() => handleTabChange(location)}
                    className={`pb-2 px-2 sm:px-4 text-sm sm:text-base lg:text-lg font-medium transition-all duration-200 relative whitespace-nowrap ${
                      activeTab === location
                        ? "text-[#0B154F] border-b-2 border-[#0B154F]"
                        : "text-gray-600 hover:text-gray-800"
                    }`}
                  >
                    {location}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Content Section */}
      <div className="bg-white pt-8 sm:pt-12 lg:pt-16">
        {/* Back Button */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-6 lg:mb-8">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center text-gray-600 hover:text-gray-800 transition-colors group"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 mr-1 group-hover:-translate-x-1 transition-transform" />
            <span className="text-sm sm:text-base lg:text-lg font-medium">
              Back
            </span>
          </button>
        </div>

        {/* Developer Cards */}
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 sm:pb-20">
          <div className="space-y-4 sm:space-y-6">
            {currentDevelopers.map((developer) => (
              <div
                key={developer.id}
                onClick={() => navigate("/companypage")}
                className="bg-white rounded-lg sm:rounded-xl shadow-sm border border-gray-200 hover:shadow-md transition-all duration-200 overflow-hidden"
              >
                {/* Mobile Layout (< sm) */}
                <div className="block sm:hidden p-4 sm:p-6">
                  {/* Logo and Company Name */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="w-16 h-16 bg-gray-50 rounded-lg flex items-center justify-center flex-shrink-0 border border-gray-200">
                      <span className="text-lg font-bold text-gray-800 tracking-wide">
                        {developer.logo}
                      </span>
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-gray-500 mb-1">
                        Founded in {developer.foundedYear}
                      </p>
                      <h3 className="text-lg font-semibold text-gray-900 mb-2 leading-tight">
                        {developer.companyName}
                      </h3>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-gray-600 leading-relaxed mb-4">
                    {developer.description}
                  </p>

                  {/* Button */}
                  <button className="w-full px-4 py-3 rounded-lg border border-gray-300 text-gray-700 text-sm font-medium hover:bg-gray-50 transition-colors">
                    See all Projects
                  </button>
                </div>

                {/* Tablet & Desktop Layout (>= sm) */}
                <div className="hidden sm:flex items-center p-6 lg:p-8">
                  {/* Left side - Logo and Company info */}
                  <div className="flex items-center gap-4 lg:gap-6 flex-1 min-w-0">
                    {/* Logo */}
                    <div className="w-24 h-24 lg:w-32 lg:h-32 xl:w-40 xl:h-40 bg-gray-50 rounded-lg flex items-center justify-center flex-shrink-0 border border-gray-200 shadow-sm">
                      <span className="text-xl lg:text-2xl xl:text-3xl font-bold text-gray-800 tracking-wide">
                        {developer.logo}
                      </span>
                    </div>

                    {/* Company info and description */}
                    <div className="flex-1 min-w-0">
                      <p className="text-xs sm:text-sm text-gray-500 mb-1">
                        Founded in {developer.foundedYear}
                      </p>
                      <h3 className="text-lg sm:text-xl lg:text-2xl font-semibold text-gray-900 mb-2 sm:mb-3">
                        {developer.companyName}
                      </h3>
                      <p className="text-sm lg:text-base text-gray-600 leading-relaxed pr-4 lg:pr-8">
                        {developer.description}
                      </p>
                    </div>
                  </div>

                  {/* Right side - Button */}
                  <div className="flex-shrink-0 ml-4 lg:ml-6">
                    <button className="px-4 sm:px-6 lg:px-8 py-2.5 sm:py-3 rounded-lg sm:rounded-xl border border-gray-300 text-gray-700 text-sm lg:text-base font-medium hover:bg-gray-50 hover:border-gray-400 transition-all duration-200 whitespace-nowrap">
                      See All Projects
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          {totalPages > 1 && (
            <div className="flex items-center justify-center gap-2 mt-8 sm:mt-12">
              {/* Previous Button */}
              <button
                onClick={handlePrevPage}
                disabled={currentPage === 1}
                className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === 1
                    ? "text-gray-400 cursor-not-allowed"
                    : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
                }`}
              >
                <ChevronLeft className="w-4 h-4 mr-1" />
                Previous
              </button>

              {/* Page Numbers */}
              <div className="flex items-center gap-1">
                {[...Array(totalPages)].map((_, index) => {
                  const page = index + 1;
                  return (
                    <button
                      key={page}
                      onClick={() => handlePageChange(page)}
                      className={`w-10 h-10 rounded-lg text-sm font-medium transition-all ${
                        currentPage === page
                          ? "bg-[#0B154F] text-white"
                          : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
                      }`}
                    >
                      {page}
                    </button>
                  );
                })}
              </div>

              {/* Next Button */}
              <button
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                  currentPage === totalPages
                    ? "text-gray-400 cursor-not-allowed"
                    : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
                }`}
              >
                Next
                <ChevronRight className="w-4 h-4 ml-1" />
              </button>
            </div>
          )}
        </div>
      </div>

      <Footer />

      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
};

export default Developers;
