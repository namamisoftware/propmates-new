// import { useState } from "react";
// import { Mail, Phone, MapPin, Send } from "lucide-react";
// import PhoneInput from "react-phone-number-input";
// import "react-phone-number-input/style.css";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";

// const phoneInputStyles = `
//   .PhoneInput {
//     display: flex;
//     align-items: center;
//   }

//   .PhoneInputInput {
//     flex: 1;
//     border: none !important;
//     outline: none !important;
//     padding: 0;
//     font-size: 1rem;
//   }

//   .PhoneInputInput:focus {
//     border: none !important;
//     outline: none !important;
//     box-shadow: none !important;
//   }

//   .PhoneInputCountry {
//     margin-right: 0.5rem;
//     border: none !important;
//   }

//   .PhoneInputCountrySelect {
//     border: none !important;
//     outline: none !important;
//   }

//   .PhoneInputCountrySelect:focus {
//     border: none !important;
//     outline: none !important;
//     box-shadow: none !important;
//   }
// `;

// export default function ContactForm() {
//   const [formData, setFormData] = useState({
//     name: "",
//     email: "",
//     phone: "",
//     subject: "",
//     message: "",
//   });

//   const [errors, setErrors] = useState({});
//   const [submitted, setSubmitted] = useState(false);

//   const handleChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: value,
//     }));
//     if (errors[name]) {
//       setErrors((prev) => ({
//         ...prev,
//         [name]: "",
//       }));
//     }
//   };

//   const validate = () => {
//     const newErrors = {};

//     if (!formData.name.trim()) {
//       newErrors.name = "Name is required";
//     }

//     if (!formData.email.trim()) {
//       newErrors.email = "Email is required";
//     } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
//       newErrors.email = "Email is invalid";
//     }

//     if (!formData.message.trim()) {
//       newErrors.message = "Message is required";
//     }

//     return newErrors;
//   };

//   const handleSubmit = () => {
//     const newErrors = validate();

//     if (Object.keys(newErrors).length === 0) {
//       setSubmitted(true);
//       console.log("Form submitted:", formData);
//       setTimeout(() => {
//         setFormData({
//           name: "",
//           email: "",
//           phone: "",
//           subject: "",
//           message: "",
//         });
//         setSubmitted(false);
//       }, 3000);
//     } else {
//       setErrors(newErrors);
//     }
//   };

//   return (
//     <div className=" ">
//       <Header />
//       <div className="py-14 px-4">
//         <style>{phoneInputStyles}</style>
//         <div className="max-w-7xl mx-auto bg-amber-300 grid grid-cols-2">
//           <img
//             src="https://up.yimg.com/ib/th/id/OIP.U_VJuupQohwnzXcKMztqWgHaEo?pid=Api&rs=1&c=1&qlt=95&w=189&h=118"
//             alt=""
//           />
//           <div className="w-1/3 bg-red-400">
//             <div className="text-center mb-12">
//               <h1 className="text-4xl font-bold text-gray-900 mb-4">
//                 Get In Touch
//               </h1>
//               <p className="text-lg text-gray-600">
//                 We'd love to hear from you. Send us a message and we'll respond
//                 as soon as possible.
//               </p>
//             </div>

//             <div className=" bg-white rounded-lg shadow-xl p-8">
//               {submitted ? (
//                 <div className="text-center py-12">
//                   <div className="inline-flex items-center justify-center w-16 h-16 bg-[#0b154f] rounded-full mb-4">
//                     <Send className="w-8 h-8 text-white" />
//                   </div>
//                   <h2 className="text-2xl font-bold text-gray-900 mb-2">
//                     Message Sent!
//                   </h2>
//                   <p className="text-gray-600">
//                     Thank you for contacting us. We'll get back to you soon.
//                   </p>
//                 </div>
//               ) : (
//                 <div className="space-y-6">
//                   <div>
//                     <div className="grid md:grid-cols-2 gap-6">
//                       <div>
//                         <label
//                           htmlFor="name"
//                           className="block text-sm font-medium text-gray-700 mb-2"
//                         >
//                           Full Name *
//                         </label>
//                         <input
//                           type="text"
//                           id="name"
//                           name="name"
//                           value={formData.name}
//                           onChange={handleChange}
//                           className={`w-full px-4 py-3 border ${
//                             errors.name ? "border-red-500" : "border-gray-300"
//                           } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition`}
//                           placeholder="Enter Your Name"
//                         />
//                         {errors.name && (
//                           <p className="mt-1 text-sm text-red-500">
//                             {errors.name}
//                           </p>
//                         )}
//                       </div>

//                       <div>
//                         <label
//                           htmlFor="email"
//                           className="block text-sm font-medium text-gray-700 mb-2"
//                         >
//                           Email Address *
//                         </label>
//                         <input
//                           type="email"
//                           id="email"
//                           name="email"
//                           value={formData.email}
//                           onChange={handleChange}
//                           className={`w-full px-4 py-3 border ${
//                             errors.email ? "border-red-500" : "border-gray-300"
//                           } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition`}
//                           placeholder="Enter Your Email"
//                         />
//                         {errors.email && (
//                           <p className="mt-1 text-sm text-red-500">
//                             {errors.email}
//                           </p>
//                         )}
//                       </div>
//                     </div>

//                     <div className="grid md:grid-cols-2 gap-6">
//                       <div>
//                         <label
//                           htmlFor="phone"
//                           className="block text-sm font-medium text-gray-700 mb-2"
//                         >
//                           Phone Number
//                         </label>
//                         <div className="px-4 py-3 border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-[#0b154f] focus-within:border-transparent">
//                           <PhoneInput
//                             international
//                             defaultCountry="IN"
//                             value={formData.phone}
//                             onChange={(value) =>
//                               setFormData((prev) => ({ ...prev, phone: value }))
//                             }
//                           />
//                         </div>
//                       </div>

//                       <div>
//                         <label
//                           htmlFor="subject"
//                           className="block text-sm font-medium text-gray-700 mb-2"
//                         >
//                           Subject
//                         </label>
//                         <input
//                           type="text"
//                           id="subject"
//                           name="subject"
//                           value={formData.subject}
//                           onChange={handleChange}
//                           className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition"
//                           placeholder="How can we help?"
//                         />
//                       </div>
//                     </div>

//                     <div>
//                       <label
//                         htmlFor="message"
//                         className="block text-sm font-medium text-gray-700 mb-2"
//                       >
//                         Message *
//                       </label>
//                       <textarea
//                         id="message"
//                         name="message"
//                         value={formData.message}
//                         onChange={handleChange}
//                         rows="6"
//                         className={`w-full px-4 py-3 border ${
//                           errors.message ? "border-red-500" : "border-gray-300"
//                         } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition resize-none`}
//                         placeholder="Tell us more about your inquiry..."
//                       />
//                       {errors.message && (
//                         <p className="mt-1 text-sm text-red-500">
//                           {errors.message}
//                         </p>
//                       )}
//                     </div>

//                     <button
//                       onClick={handleSubmit}
//                       className="w-full bg-[#0b154f] text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
//                     >
//                       <Send className="w-5 h-5" />
//                       Send Message
//                     </button>
//                   </div>
//                 </div>
//               )}
//             </div>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </div>
//   );
// }

import { useState, useRef, useEffect } from "react";
import { Mail, Phone, MapPin, Send } from "lucide-react";
import PhoneInput from "react-phone-number-input";
import "react-phone-number-input/style.css";
import Header from "./Components/Header";
import Footer from "./Components/Footer";

const phoneInputStyles = `
  .PhoneInput {
    display: flex;
    align-items: center;
  }
  
  .PhoneInputInput {
    flex: 1;
    border: none !important;
    outline: none !important;
    padding: 0;
    font-size: 1rem;
  }
  
  .PhoneInputInput:focus {
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
  }
  
  .PhoneInputCountry {
    margin-right: 0.5rem;
    border: none !important;
  }
  
  .PhoneInputCountrySelect {
    border: none !important;
    outline: none !important;
  }
  
  .PhoneInputCountrySelect:focus {
    border: none !important;
    outline: none !important;
    box-shadow: none !important;
  }
`;

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const [errors, setErrors] = useState({});
  const [submitted, setSubmitted] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
    if (errors[name]) {
      setErrors((prev) => ({
        ...prev,
        [name]: "",
      }));
    }
  };

  const validate = () => {
    const newErrors = {};

    if (!formData.name.trim()) {
      newErrors.name = "Name is required";
    }

    if (!formData.email.trim()) {
      newErrors.email = "Email is required";
    } else if (!/\S+@\S+\.\S+/.test(formData.email)) {
      newErrors.email = "Email is invalid";
    }

    if (!formData.message.trim()) {
      newErrors.message = "Message is required";
    }

    return newErrors;
  };

  const handleSubmit = () => {
    const newErrors = validate();

    if (Object.keys(newErrors).length === 0) {
      setSubmitted(true);
      console.log("Form submitted:", formData);
      setTimeout(() => {
        setFormData({
          name: "",
          email: "",
          phone: "",
          subject: "",
          message: "",
        });
        setSubmitted(false);
      }, 3000);
    } else {
      setErrors(newErrors);
    }
  };

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    // Load Leaflet CSS
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href =
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
    document.head.appendChild(link);

    // Load Leaflet JS
    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
    script.async = true;

    script.onload = () => {
      if (mapRef.current && !mapInstanceRef.current) {
        // Initialize map centered on Dubai (horizontal view)
        const map = window.L.map(mapRef.current).setView(
          [25.2048, 55.2708],
          12
        );
        mapInstanceRef.current = map;

        // Add OpenStreetMap tiles
        window.L.tileLayer(
          "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          {
            attribution: "© OpenStreetMap contributors",
            maxZoom: 19,
          }
        ).addTo(map);

        // Location data with Dubai coordinates (horizontal spread)
        const locations = [
          {
            lat: 25.2048,
            lng: 55.15,
            name: "Dubai Marina",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.2048,
            lng: 55.2,
            name: "Jumeirah",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.2048,
            lng: 55.25,
            name: "Downtown Dubai",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.2048,
            lng: 55.3,
            name: "Business Bay",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.2048,
            lng: 55.35,
            name: "Dubai Creek",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.18,
            lng: 55.18,
            name: "JBR Beach",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.18,
            lng: 55.23,
            name: "DIFC",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.18,
            lng: 55.28,
            name: "Burj Khalifa Area",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.23,
            lng: 55.22,
            name: "Palm Jumeirah",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.23,
            lng: 55.32,
            name: "Deira",
            icon: "🏢",
            type: "Office Building",
          },
        ];

        // Create custom icon
        const createCustomIcon = (iconEmoji) => {
          return window.L.divIcon({
            className: "custom-div-icon",
            html: `<div style="
                background-color: #0f766e;
                border: 3px solid white;
                border-radius: 50%;
                width: 40px;
                height: 40px;
                display: flex;
                align-items: center;
                justify-content: center;
                font-size: 20px;
                box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
                cursor: pointer;
                transition: transform 0.2s;
              ">${iconEmoji}</div>`,
            iconSize: [40, 40],
            iconAnchor: [20, 20],
            popupAnchor: [0, -20],
          });
        };

        // Add markers to map
        locations.forEach((location) => {
          const marker = window.L.marker([location.lat, location.lng], {
            icon: createCustomIcon(location.icon),
          }).addTo(map);

          marker.bindPopup(`
              <div style="padding: 8px;">
                <div style="font-weight: 600; font-size: 16px; margin-bottom: 4px; color: #1f2937;">
                  ${location.name}
                </div>
                <div style="color: #6b7280; font-size: 13px;">
                  ${location.type}
                </div>
              </div>
            `);
        });

        // Add scale control
        window.L.control.scale().addTo(map);
      }
    };

    document.body.appendChild(script);

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  return (
    <div>
      <Header />
      <div className="py-14 px-4 mt-10">
        <style>{phoneInputStyles}</style>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-8 items-start">
            {/* Image Section */}
            <div className="hidden md:block rounded-lg overflow-hidden shadow-xl h-170">
              <img
                src="https://plus.unsplash.com/premium_photo-1670275658703-33fb95fe50d8?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8NXx8YXBhcnRtZW50JTIwYnVpbGRpbmd8ZW58MHx8MHx8fDA%3D"
                alt="Contact us"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Form Section */}
            <div>
              <div className="text-center mb-8">
                <h1 className="text-4xl font-bold text-gray-900 mb-4">
                  Get In Touch
                </h1>
                <p className="text-lg text-gray-600">
                  We'd love to hear from you. Send us a message and we'll
                  respond as soon as possible.
                </p>
              </div>

              <div className="bg-white rounded-lg shadow-xl p-8">
                {submitted ? (
                  <div className="text-center py-12">
                    <div className="inline-flex items-center justify-center w-16 h-16 bg-[#0b154f] rounded-full mb-4">
                      <Send className="w-8 h-8 text-white" />
                    </div>
                    <h2 className="text-2xl font-bold text-gray-900 mb-2">
                      Message Sent!
                    </h2>
                    <p className="text-gray-600">
                      Thank you for contacting us. We'll get back to you soon.
                    </p>
                  </div>
                ) : (
                  <div className="space-y-6">
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label
                          htmlFor="name"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Full Name *
                        </label>
                        <input
                          type="text"
                          id="name"
                          name="name"
                          value={formData.name}
                          onChange={handleChange}
                          className={`w-full px-4 py-3 border ${
                            errors.name ? "border-red-500" : "border-gray-300"
                          } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition`}
                          placeholder="Enter Your Name"
                        />
                        {errors.name && (
                          <p className="mt-1 text-sm text-red-500">
                            {errors.name}
                          </p>
                        )}
                      </div>

                      <div>
                        <label
                          htmlFor="email"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Email Address *
                        </label>
                        <input
                          type="email"
                          id="email"
                          name="email"
                          value={formData.email}
                          onChange={handleChange}
                          className={`w-full px-4 py-3 border ${
                            errors.email ? "border-red-500" : "border-gray-300"
                          } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition`}
                          placeholder="Enter Your Email"
                        />
                        {errors.email && (
                          <p className="mt-1 text-sm text-red-500">
                            {errors.email}
                          </p>
                        )}
                      </div>
                    </div>

                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <label
                          htmlFor="phone"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Phone Number
                        </label>
                        <div className="px-4 py-3 border border-gray-300 rounded-lg focus-within:ring-2 focus-within:ring-[#0b154f] focus-within:border-transparent">
                          <PhoneInput
                            international
                            defaultCountry="IN"
                            value={formData.phone}
                            onChange={(value) =>
                              setFormData((prev) => ({ ...prev, phone: value }))
                            }
                          />
                        </div>
                      </div>

                      <div>
                        <label
                          htmlFor="subject"
                          className="block text-sm font-medium text-gray-700 mb-2"
                        >
                          Subject
                        </label>
                        <input
                          type="text"
                          id="subject"
                          name="subject"
                          value={formData.subject}
                          onChange={handleChange}
                          className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition"
                          placeholder="How can we help?"
                        />
                      </div>
                    </div>

                    <div>
                      <label
                        htmlFor="message"
                        className="block text-sm font-medium text-gray-700 mb-2"
                      >
                        Message *
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        value={formData.message}
                        onChange={handleChange}
                        rows="6"
                        className={`w-full px-4 py-3 border ${
                          errors.message ? "border-red-500" : "border-gray-300"
                        } rounded-lg focus:ring-2 focus:ring-[#0b154f] focus:border-transparent outline-none transition resize-none`}
                        placeholder="Tell us more about your inquiry..."
                      />
                      {errors.message && (
                        <p className="mt-1 text-sm text-red-500">
                          {errors.message}
                        </p>
                      )}
                    </div>

                    <button
                      onClick={handleSubmit}
                      className="w-full bg-[#0b154f] hover:bg-[#151f6b] text-white font-semibold py-3 px-6 rounded-lg transition-colors duration-200 flex items-center justify-center gap-2"
                    >
                      <Send className="w-5 h-5" />
                      Send Message
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="h-100 max-w-7xl my-14 mx-auto px-4 sm:px-6 relative">
        <div ref={mapRef} className="w-full h-full rounded" />
      </div>
      <Footer />
    </div>
  );
}
