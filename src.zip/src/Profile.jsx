// import { useState } from "react";

// export default function ProfileForm() {
//   const [formData, setFormData] = useState({
//     name: "",
//     phoneNumber: "",
//     dateOfBirth: "",
//     email: "",
//     city: "",
//     pinCode: "",
//     languages: [],
//   });

//   const languages = [
//     "Hindi",
//     "English",
//     "Bengali",
//     "Telugu",
//     "Marathi",
//     "Tamil",
//     "Kannada",
//     "Gujarati",
//     "Odia",
//     "Malayalam",
//     "Punjabi",
//     "Arabic",
//     "Urdu",
//     "Spanish",
//     "French",
//     "Portuguese",
//     "Mandarin",
//   ];

//   const toggleLanguage = (lang) => {
//     setFormData((prev) => ({
//       ...prev,
//       languages: prev.languages.includes(lang)
//         ? prev.languages.filter((l) => l !== lang)
//         : [...prev.languages, lang],
//     }));
//   };

//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setFormData((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleSave = () => {
//     console.log("Profile saved:", formData);
//     alert("Profile saved successfully!");
//   };

//   return (
//     <div className="min-h-screen bg-gray-50 py-8 px-4">
//       <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-sm p-8">
//         {/* Header */}
//         <div className="flex items-center gap-4 mb-8">
//           <div className="w-16 h-16 bg-indigo-900 rounded-full"></div>
//           <div>
//             <h1 className="text-xl font-semibold text-gray-900">Name</h1>
//             <p className="text-sm text-gray-500">Location</p>
//           </div>
//         </div>

//         {/* Personal Details Section */}
//         <div className="mb-8">
//           <h2 className="text-lg font-semibold text-gray-900 mb-6 border-b-2 border-indigo-600 pb-2 inline-block">
//             Personal Details
//           </h2>

//           {/* Form Grid */}
//           <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
//             {/* Name */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 Name
//               </label>
//               <input
//                 type="text"
//                 name="name"
//                 placeholder="Enter your Name"
//                 value={formData.name}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>

//             {/* Phone Number */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 Phone Number
//               </label>
//               <input
//                 type="tel"
//                 name="phoneNumber"
//                 placeholder="Enter Phone Number"
//                 value={formData.phoneNumber}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>

//             {/* Date of Birth */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 Date of Birth
//               </label>
//               <input
//                 type="text"
//                 name="dateOfBirth"
//                 placeholder="DD/MM/YYYY"
//                 value={formData.dateOfBirth}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>

//             {/* Email Address */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 Email Address
//               </label>
//               <input
//                 type="email"
//                 name="email"
//                 placeholder="examle254@gmail.com"
//                 value={formData.email}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>

//             {/* City */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 City
//               </label>
//               <input
//                 type="text"
//                 name="city"
//                 placeholder="Enter Your City"
//                 value={formData.city}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>

//             {/* Pin Code */}
//             <div>
//               <label className="block text-sm font-medium text-gray-700 mb-2">
//                 Pin Code
//               </label>
//               <input
//                 type="text"
//                 name="pinCode"
//                 placeholder="Enter Pin"
//                 value={formData.pinCode}
//                 onChange={handleInputChange}
//                 className="w-full px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
//               />
//             </div>
//           </div>

//           {/* Language Preference */}
//           <div className="mt-8">
//             <label className="block text-sm font-medium text-gray-700 mb-4">
//               Language Preference
//             </label>
//             <div className="flex flex-wrap gap-3">
//               {languages.map((lang) => (
//                 <button
//                   key={lang}
//                   onClick={() => toggleLanguage(lang)}
//                   className={`px-6 py-2 rounded-full text-sm font-medium transition-colors ${
//                     formData.languages.includes(lang)
//                       ? "bg-indigo-900 text-white"
//                       : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
//                   }`}
//                 >
//                   {lang}
//                 </button>
//               ))}
//             </div>
//           </div>
//         </div>

//         {/* Save Button */}
//         <button
//           onClick={handleSave}
//           className="w-full bg-indigo-900 text-white py-3 rounded-md font-medium hover:bg-indigo-800 transition-colors"
//         >
//           Save Profile
//         </button>
//       </div>
//     </div>
//   );
// }

import React, { useState } from "react";
import {
  Home,
  User,
  LogOut,
  HelpCircle,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";
import AboveHeader from "./Components/AboveHeader";

const App = () => {
  // const [formData, setFormData] = useState({
  //   name: "",
  //   phoneNumber: "",
  //   dateOfBirth: "",
  //   email: "",
  //   city: "",
  //   pinCode: "",
  //   languages: [],
  // });
  // Add at the top of your component, after the imports
  console.log("Stored data:", localStorage.getItem("userData"));
  const [formData, setFormData] = useState(() => {
    const storedUser = localStorage.getItem("userData");
    const userData = storedUser ? JSON.parse(storedUser) : {};

    return {
      name: userData.full_name || "",
      phoneNumber: userData.phone || "",
      dateOfBirth: "",
      email: userData.email || "",
      city: userData.city || "", // This was already correct
      pinCode: userData.pincode || "", // Change: pincode (backend) → pinCode (frontend)
      languages: [],
    };
  });

  const languages = [
    "Hindi",
    "English",
    "Bengali",
    "Telugu",
    "Marathi",
    "Tamil",
    "Kannada",
    "Gujarati",
    "Odia",
    "Malayalam",
    "Punjabi",
    "Arabic",
    "Urdu",
    "Spanish",
    "French",
    "Portuguese",
    "Mandarin",
  ];

  const toggleLanguage = (lang) => {
    setFormData((prev) => ({
      ...prev,
      languages: prev.languages.includes(lang)
        ? prev.languages.filter((l) => l !== lang)
        : [...prev.languages, lang],
    }));
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSave = () => {
    console.log("Profile saved:", formData);
    alert("Profile saved successfully!");
  };

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  return (
    <>
      <Header />
      <div className="max-w-6xl mx-auto my-10 p-4">
        <div className="flex gap-4 items-start">
          {/* Sidebar */}
          <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded shadow-sm sticky top-8 max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-hide">
            <div className="p-4">
              <nav className="space-y-0.5">
                {/* My Listings */}
                <div>
                  <button
                    onClick={() => toggleMenu("mylistings")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>My Listings</span>
                    </div>
                    {openMenu === "mylistings" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "mylistings" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/mylistings/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/mylistings/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/mylistings/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/mylistings/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/mylistings/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/mylistings/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* List Property */}
                <div>
                  <button
                    onClick={() => toggleMenu("listproperty")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>List Property</span>
                    </div>
                    {openMenu === "listproperty" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "listproperty" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/listproperty/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/listproperty/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/listproperty/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/listproperty/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/listproperty/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/listproperty/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* Profile */}
                <Link
                  to="/profile"
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </Link>

                {/* Enquiry */}
                <div>
                  <button
                    onClick={() => toggleMenu("enquiry")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <HelpCircle className="w-4 h-4" />
                      <span>Enquiry/Ticket</span>
                    </div>
                    {openMenu === "enquiry" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "enquiry" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/enquiry/addenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Add Enquiry
                      </Link>
                      <Link
                        to="/enquiry/newenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        New Enquiry
                      </Link>
                      <Link
                        to="/enquiry/allenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        All Enquiry
                      </Link>
                    </div>
                  )}
                </div>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-white rounded shadow-sm">
            <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm p-4 sm:p-6 lg:p-8">
              {/* Header */}
              <div className="flex items-center gap-3 sm:gap-4 mb-6 sm:mb-8">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-indigo-900 rounded-full flex-shrink-0"></div>
                <div className="min-w-0">
                  <h1 className="text-lg sm:text-xl font-semibold text-gray-900 truncate">
                    {formData.name || "Name"}
                  </h1>
                  <p className="text-xs sm:text-sm text-gray-500 truncate">
                    {formData.city || "Location"}
                  </p>
                </div>
              </div>

              {/* Personal Details Section */}
              <div className="mb-6 sm:mb-8">
                <h2 className="text-base sm:text-lg font-semibold text-gray-900 mb-4 sm:mb-6 border-b-2 border-indigo-600 pb-2 inline-block">
                  Personal Details
                </h2>

                {/* Form Grid */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 mt-4 sm:mt-6">
                  {/* Name */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Name
                    </label>
                    <input
                      type="text"
                      name="name"
                      placeholder="Enter your Name"
                      value={formData.name}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Phone Number
                    </label>
                    <input
                      type="tel"
                      name="phoneNumber"
                      placeholder="Enter Phone Number"
                      value={formData.phoneNumber}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* Date of Birth */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Date of Birth
                    </label>
                    <input
                      type="text"
                      name="dateOfBirth"
                      placeholder="DD/MM/YYYY"
                      value={formData.dateOfBirth}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* Email Address */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Email Address
                    </label>
                    <input
                      type="email"
                      name="email"
                      placeholder="examle254@gmail.com"
                      value={formData.email}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* City */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      City
                    </label>
                    <input
                      type="text"
                      name="city"
                      placeholder="Enter Your City"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>

                  {/* Pin Code */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Pin Code
                    </label>
                    <input
                      type="text"
                      name="pinCode"
                      placeholder="Enter Pin"
                      value={formData.pinCode}
                      onChange={handleInputChange}
                      className="w-full px-3 sm:px-4 py-2 text-sm sm:text-base border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Language Preference */}
                {/* <div className="mt-6 sm:mt-8">
                <label className="block text-sm font-medium text-gray-700 mb-3 sm:mb-4">
                  Language Preference
                </label>
                <div className="flex flex-wrap gap-2 sm:gap-3">
                  {languages.map((lang) => (
                    <button
                      key={lang}
                      onClick={() => toggleLanguage(lang)}
                      className={`px-4 sm:px-6 py-2 rounded-full text-xs sm:text-sm font-medium transition-colors ${
                        formData.languages.includes(lang)
                          ? "bg-indigo-900 text-white"
                          : "bg-white text-gray-700 border border-gray-300 hover:bg-gray-50"
                      }`}
                    >
                      {lang}
                    </button>
                  ))}
                </div>
              </div> */}
              </div>

              {/* Save Button */}
              <button
                onClick={handleSave}
                className="w-full bg-indigo-900 text-white py-2.5 sm:py-3 rounded-md text-sm sm:text-base font-medium hover:bg-indigo-800 transition-colors"
              >
                Save Profile
              </button>
            </div>
          </div>

          <style jsx>{`
            .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .scrollbar-hide::-webkit-scrollbar {
              display: none;
            }
          `}</style>
        </div>
      </div>
      <Footer />
    </>
  );
};

export default App;
