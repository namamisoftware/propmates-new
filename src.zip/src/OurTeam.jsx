import React, { useEffect, useState } from "react";
import { ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import searchbg from "./assets/developers.png";
import { Link, useNavigate } from "react-router-dom";
import Navbar from "./Components/Navbar";
import ourteam from "./assets/ourteam.png";
import { ArrowLeft, Phone, MessageSquare } from "lucide-react";
import { Country, State, City } from "country-state-city";

const OurTeam = () => {
  const navigate = useNavigate();
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [selectedAgent, setSelectedAgent] = useState(null);
  const [connectFormData, setConnectFormData] = useState({
    fullName: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });
  const [searchData, setSearchData] = useState({
    location: "",
    agent: "",
    service: "",
    language: "",
    nationality: "",
  });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    experience_years: "",
    cv: null,
    image: null,

    // Self Location - ADD countryCode and stateCode
    country: "",
    countryCode: "", // ADD THIS
    state: "",
    stateCode: "", // ADD THIS
    city: "",
    address: "",
    pincode: "",

    // Preferred Location - ADD PcountryCode and PstateCode
    Pcountry: "",
    PcountryCode: "", // ADD THIS
    Pstate: "",
    PstateCode: "", // ADD THIS
    Pcity: "",
    Paddress: "",
    Ppincode: "",
    Role: "",
  });

  const countries = Country.getAllCountries();
  const countryOptions = countries.map((c) => ({
    value: c.isoCode,
    label: c.name,
  }));

  const getStateOptions = (countryCode) => {
    const states = State.getStatesOfCountry(countryCode);
    return states.map((s) => ({
      value: s.isoCode,
      label: s.name,
    }));
  };

  const getCityOptions = (countryCode, stateCode) => {
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities.map((c) => ({
      value: c.name,
      label: c.name,
    }));
  };

  const hasStates = (countryCode) => {
    if (!countryCode) return false;
    const states = State.getStatesOfCountry(countryCode);
    return states && states.length > 0;
  };

  const hasCities = (countryCode, stateCode) => {
    if (!countryCode || !stateCode) return false;
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities && cities.length > 0;
  };

  // 3. ADD THESE HANDLER FUNCTIONS inside your OurTeam component
  const handleCountryChange = (e) => {
    const iso = e.target.value;
    const country = countries.find((c) => c.isoCode === iso);

    setFormData((prev) => ({
      ...prev,
      countryCode: iso, // Store ISO for lookups
      country: country?.name || "", // Store name for API
      state: "",
      stateCode: "",
      city: "",
    }));
  };

  const handleStateChange = (e) => {
    const iso = e.target.value;
    const stateObj = State.getStatesOfCountry(formData.countryCode).find(
      (s) => s.isoCode === iso
    );

    setFormData((prev) => ({
      ...prev,
      stateCode: iso, // Store ISO for lookups
      state: stateObj?.name || "", // Store name for API
      city: "",
    }));
  };

  const handleCityChange = (e) => {
    const cityObj = City.getCitiesOfState(
      formData.countryCode,
      formData.stateCode
    ).find((c) => c.name === e.target.value);

    setFormData((prev) => ({
      ...prev,
      city: cityObj.name,
    }));
  };

  // 4. ADD THESE VARIABLES inside your OurTeam component (before the return statement)

  const stateOptions = formData.countryCode // Change from formData.country
    ? getStateOptions(formData.countryCode)
    : [];
  const cityOptions =
    formData.countryCode && formData.stateCode // Change both
      ? getCityOptions(formData.countryCode, formData.stateCode)
      : [];

  const handlePcountryChange = (e) => {
    const iso = e.target.value;
    const countryObj = Country.getAllCountries().find((c) => c.isoCode === iso);

    setFormData((prev) => ({
      ...prev,
      PcountryCode: iso, // Store ISO for lookups
      Pcountry: countryObj?.name || "", // Store name for API
      Pstate: "",
      PstateCode: "",
      Pcity: "",
    }));
  };

  const handlePstateChange = (e) => {
    const iso = e.target.value;
    const stateObj = State.getStatesOfCountry(formData.PcountryCode).find(
      (s) => s.isoCode === iso
    );

    setFormData((prev) => ({
      ...prev,
      PstateCode: iso, // Store ISO for lookups
      Pstate: stateObj?.name || "", // Store name for API
      Pcity: "",
    }));
  };
  const handlePcityChange = (e) => {
    const value = e.target.value;
    setFormData((prev) => ({
      ...prev,
      Pcity: value, // City name, works fine
    }));
  };

  // Add these variables:
  const PstateOptions = formData.PcountryCode // Change from formData.Pcountry
    ? getStateOptions(formData.PcountryCode)
    : [];
  const PcityOptions =
    formData.PcountryCode && formData.PstateCode // Change both
      ? getCityOptions(formData.PcountryCode, formData.PstateCode)
      : [];

  const handleFormChange = (field, value) => {
    setFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleCVUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Optional: Add file size validation (e.g., max 5MB)
      const maxSize = 5 * 1024 * 1024; // 5MB in bytes
      if (file.size > maxSize) {
        alert("CV file is too large. Maximum size is 5MB.");
        e.target.value = ""; // Clear the input
        return;
      }

      // Optional: Validate file type
      const allowedTypes = [
        "application/pdf",
        "application/msword",
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      ];
      if (!allowedTypes.includes(file.type)) {
        alert("Invalid file type. Please upload PDF or Word document.");
        e.target.value = ""; // Clear the input
        return;
      }

      setFormData((prev) => ({
        ...prev,
        cv: file, // Changed from 'image' to 'cv'
      }));
    }
  };

  const handleImageUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      // Validate file size (max 5MB)
      const maxSize = 5 * 1024 * 1024; // 5MB
      if (file.size > maxSize) {
        alert("Image file is too large. Maximum size is 5MB.");
        e.target.value = "";
        return;
      }

      // Validate file type (only images)
      const allowedTypes = [
        "image/jpeg",
        "image/jpg",
        "image/png",
        "image/gif",
        "image/webp",
      ];
      if (!allowedTypes.includes(file.type)) {
        alert(
          "Invalid file type. Please upload an image (JPEG, PNG, GIF, or WebP)."
        );
        e.target.value = "";
        return;
      }

      setFormData((prev) => ({
        ...prev,
        image: file,
      }));
    }
  };

  const convertFileToBase64 = (file) => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => resolve(reader.result.split(",")[1]); // Get base64 without prefix
      reader.onerror = (error) => reject(error);
      reader.readAsDataURL(file);
    });
  };

  // 3. REPLACE YOUR handleSubmit FUNCTION with this:
  //   const handleSubmit = async (e) => {
  //     e.preventDefault();

  //     try {
  //       // Show loading state
  //       const submitButton = e.target.querySelector('button[type="submit"]');
  //       const originalText = submitButton.textContent;
  //       submitButton.textContent = "Submitting...";
  //       submitButton.disabled = true;

  //       // Convert files to base64
  //       const cvBase64 = formData.cv
  //         ? await convertFileToBase64(formData.cv)
  //         : null;
  //       const imageBase64 = formData.image
  //         ? await convertFileToBase64(formData.image)
  //         : null;

  //       // Prepare JSON payload
  //       const payload = {
  //         name: formData.name,
  //         email: formData.email,
  //         phone: formData.phone,
  //         experience_years: parseInt(formData.experience_years),
  //         cv: cvBase64
  //           ? {
  //             filename: formData.cv.name,
  //             content: cvBase64,
  //             mimetype: formData.cv.type,
  //             size: formData.cv.size,
  //           }
  //           : null,
  //         image: imageBase64
  //           ? {
  //             filename: formData.image.name,
  //             content: imageBase64,
  //             mimetype: formData.image.type,
  //             size: formData.image.size,
  //           }
  //           : null,
  //         Role: formData.Role,

  //         country: formData.country,
  //         state: formData.state,
  //         city: formData.city,
  //         address: formData.address,
  //         pincode: formData.pincode,

  //         Pcountry: formData.Pcountry,
  //         Pstate: formData.Pstate,
  //         Pcity: formData.Pcity,
  //         Paddress: formData.Paddress,
  //         Ppincode: formData.Ppincode,

  //       };

  //       console.log("Sending payload:", payload); // Debug: check payload structure

  //       // Send to API as JSON
  //       const response = await fetch(`http://127.0.0.1:8000/api/agent/create/`, {
  //         method: "POST",
  //         headers: {
  //           "Content-Type": "application/json",
  //         },
  //         body: JSON.stringify(payload),
  //       });

  //      if (!response.ok) {
  //   const errorData = await response.json().catch(() => ({}));
  //   console.error("Backend Error:", errorData);

  //   // Check duplicate email
  //   if (errorData.email && errorData.email.length > 0) {
  //     alert("Email already exists. Please use a different email.");
  //     throw new Error("Email already exists");
  //   }

  //   throw new Error(
  //     errorData.message ||
  //     errorData.detail ||
  //     `HTTP error! status: ${response.status}`
  //   );
  // }

  //       const result = await response.json();
  //       console.log("Success:", result);

  //       // Show success message
  //       alert("Registration submitted successfully!");

  //       setFormData({
  //         name: "",
  //         email: "",
  //         phone: "",
  //         experience_years: "",
  //         cv: null,
  //         image: null,
  //         country: "",
  //         countryCode: "",      // ADD THIS
  //         state: "",
  //         stateCode: "",        // ADD THIS
  //         city: "",
  //         address: "",
  //         pincode: "",
  //         Pcountry: "",
  //         PcountryCode: "",     // ADD THIS
  //         Pstate: "",
  //         PstateCode: "",       // ADD THIS
  //         Pcity: "",
  //         Paddress: "",
  //         Ppincode: "",
  //         Role: "",
  //       });

  //       // Reset file inputs
  //       document.querySelectorAll('input[type="file"]').forEach((input) => {
  //         input.value = "";
  //       });

  //       // Restore button
  //       submitButton.textContent = originalText;
  //       submitButton.disabled = false;
  //     } catch (error) {
  //       console.error("Error submitting form:", error);
  //       alert(`Failed to submit registration: ${error.message}`);

  //       // Restore button
  //       const submitButton = e.target.querySelector('button[type="submit"]');
  //       submitButton.textContent = "Register";
  //       submitButton.disabled = false;
  //     }
  //   };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      // Show loading state
      const submitButton = e.target.querySelector('button[type="submit"]');
      const originalText = submitButton.textContent;
      submitButton.textContent = "Submitting...";
      submitButton.disabled = true;

      // Create FormData object
      const formDataToSend = new FormData();

      formDataToSend.append("name", formData.name);
      formDataToSend.append("email", formData.email);
      formDataToSend.append("phone", formData.phone);
      formDataToSend.append("experience_years", formData.experience_years);
      formDataToSend.append("Role", formData.Role);

      formDataToSend.append("country", formData.country);
      formDataToSend.append("state", formData.state);
      formDataToSend.append("city", formData.city);
      formDataToSend.append("address", formData.address);
      formDataToSend.append("pincode", formData.pincode);

      formDataToSend.append("Pcountry", formData.Pcountry);
      formDataToSend.append("Pstate", formData.Pstate);
      formDataToSend.append("Pcity", formData.Pcity);
      formDataToSend.append("Paddress", formData.Paddress);
      formDataToSend.append("Ppincode", formData.Ppincode);

      // Add files directly
      if (formData.cv) {
        formDataToSend.append("cv", formData.cv);
      }
      if (formData.image) {
        formDataToSend.append("image", formData.image);
      }

      console.log("Sending FormData...");

      // Send FormData (NO HEADERS)
      const response = await fetch("http://127.0.0.1:8000/api/agent/create/", {
        method: "POST",
        body: formDataToSend,
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error("Backend Error:", errorData);

        // Duplicate email
        if (errorData.email && errorData.email.length > 0) {
          alert("Email already exists. Please use a different email.");
          throw new Error("Email already exists");
        }

        throw new Error(
          errorData.message ||
            errorData.detail ||
            `HTTP error! status: ${response.status}`
        );
      }

      const result = await response.json();
      console.log("Success:", result);
      alert("Registration submitted successfully!");

      // Reset form
      setFormData({
        name: "",
        email: "",
        phone: "",
        experience_years: "",
        cv: null,
        image: null,
        country: "",
        countryCode: "",
        state: "",
        stateCode: "",
        city: "",
        address: "",
        pincode: "",
        Pcountry: "",
        PcountryCode: "",
        Pstate: "",
        PstateCode: "",
        Pcity: "",
        Paddress: "",
        Ppincode: "",
        Role: "",
      });

      document
        .querySelectorAll('input[type="file"]')
        .forEach((input) => (input.value = ""));

      submitButton.textContent = originalText;
      submitButton.disabled = false;
    } catch (error) {
      console.error("Error submitting form:", error);
      alert(`Failed to submit registration: ${error.message}`);

      const submitButton = e.target.querySelector('button[type="submit"]');
      submitButton.textContent = "Register";
      submitButton.disabled = false;
    }
  };

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 6; // You can adjust this number

  const handleInputChange = (field, value) => {
    setSearchData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleFind = () => {
    console.log("Search data:", searchData);
    // Add your search logic here
  };

  // const [teamMembers, setTeamMembers] = useState([
  //   {
  //     name: "David Wilson",
  //     role: "Executive Director",
  //     company: "ARABIAN",
  //     rating: 5.0,
  //     nationality: "Dubai",
  //     language: "English",
  //     image:
  //       "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Sarah Johnson",
  //     role: "Executive Director",
  //     company: "Thrive",
  //     rating: 5.0,
  //     nationality: "Dubai",
  //     language: "English",
  //     image:
  //       "https://images.unsplash.com/photo-1494790108755-2616b612b786?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Michael Chen",
  //     role: "Executive Director",
  //     company: "ARABIAN",
  //     rating: 5.0,
  //     nationality: "Dubai",
  //     language: "English",
  //     image:
  //       "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Robert Martinez",
  //     role: "Executive Director",
  //     company: "Thrive",
  //     rating: 5.0,
  //     nationality: "Dubai",
  //     language: "English",
  //     image:
  //       "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Emma Thompson",
  //     role: "Senior Agent",
  //     company: "ARABIAN",
  //     rating: 4.9,
  //     nationality: "Dubai",
  //     language: "English",
  //     image:
  //       "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "James Rodriguez",
  //     role: "Senior Agent",
  //     company: "Thrive",
  //     rating: 4.8,
  //     nationality: "Dubai",
  //     language: "Spanish",
  //     image:
  //       "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Lisa Wang",
  //     role: "Property Consultant",
  //     company: "ARABIAN",
  //     rating: 4.7,
  //     nationality: "Dubai",
  //     language: "Chinese",
  //     image:
  //       "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=500&fit=crop&crop=face",
  //   },
  //   {
  //     name: "Ahmed Hassan",
  //     role: "Investment Advisor",
  //     company: "Thrive",
  //     rating: 4.9,
  //     nationality: "Dubai",
  //     language: "Arabic",
  //     image:
  //       "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=400&h=500&fit=crop&crop=face",
  //   },
  // ]);

  const [teamMembers, setTeamMembers] = useState([]);

  useEffect(() => {
    fetchTeamMembers();
  }, []);

  const fetchTeamMembers = async () => {
    try {
      const response = await fetch(`http://127.0.0.1:8000/api/agent/`, {
        method: "GET",
        headers: {
          "Content-Type": "application/json",
        },
      });

      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }

      const data = await response.json();
      console.log("Fetched team members:", data);

      // Only update if we have valid data
      if (data && Array.isArray(data) && data.length > 0) {
        setTeamMembers(data);
      } else if (data && data.teamMembers && Array.isArray(data.teamMembers)) {
        // Handle if API returns { teamMembers: [...] }
        setTeamMembers(data.teamMembers);
      }
      // If no valid data, fallback data (initial state) remains
    } catch (error) {
      console.error("Error fetching team members:", error);
    }
  };

  // Calculate pagination values
  const totalPages = Math.ceil(teamMembers.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;
  const currentTeamMembers = teamMembers.slice(startIndex, endIndex);

  // Pagination handlers
  const goToPage = (pageNumber) => {
    setCurrentPage(pageNumber);
  };

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Generate page numbers for pagination
  const getPageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 5;
    let startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
    let endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

    if (endPage - startPage < maxVisiblePages - 1) {
      startPage = Math.max(1, endPage - maxVisiblePages + 1);
    }

    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    return pageNumbers;
  };

  const handleConnectClick = (member) => {
    setSelectedAgent(member);
    setShowConnectModal(true);
  };

  const handleConnectFormChange = (field, value) => {
    setConnectFormData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const handleConnectSubmit = (e) => {
    e.preventDefault();
    console.log("Connect form submitted:", {
      agent: selectedAgent,
      formData: connectFormData,
    });
    // Add your submission logic here

    // Close modal and reset form
    setShowConnectModal(false);
    setConnectFormData({
      fullName: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });
  };

  const handleCloseModal = () => {
    setShowConnectModal(false);
    setConnectFormData({
      fullName: "",
      email: "",
      phone: "",
      subject: "",
      message: "",
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="">
        {/* Header */}
        <div className="">
          <div className="max-w-6xl mx-auto px-4 py-4">
            <div className="flex items-center gap-3">
              <button
                onClick={() => navigate(-1)}
                className="flex items-center gap-1 text-gray-600 hover:text-gray-800 transition-colors"
              >
                <ChevronLeft size={20} className="sm:w-6 sm:h-6" />
                <span className="font-medium text-base sm:text-lg">Back</span>
              </button>
            </div>
          </div>
        </div>

        {/* Main Content */}
        <div className="max-w-8xl mx-auto px-4 sm:px-6 py-6 sm:py-0 ">
          <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-center text-[#0b154f] mb-2 sm:mb-4">
            Propmates Team
          </h1>

          <div className="max-w-4xl mx-auto text-center mb-2 sm:mb-6 px-4">
            <p className="text-gray-700 text-sm sm:text-base leading-relaxed">
              <span className="font-semibold text-[#0b154f]">
                Registration Eligibility:
              </span>{" "}
              Join our team of professionals! We welcome experienced real estate
              agents, brokers, and property consultants with a minimum of 2
              years industry experience. Must possess valid certifications and
              demonstrate strong client service skills.
            </p>
          </div>

          <div className="flex flex-col lg:flex-row items-start justify-center gap-10">
            <div className="flex-1 ">
              {/* Team Members Grid */}
              <div className="grid grid-cols-1 xl:grid-cols-2 gap-4 sm:gap-6 p-4">
                {currentTeamMembers.map((member, index) => (
                  <Link
                    to={`/ourteamdetails/${member.id}`}
                    key={index}
                    className="bg-white p-2 rounded shadow-lg overflow-hidden flex flex-col sm:flex-row h-auto sm:h-64"
                  >
                    {/* Left side - Image */}
                    <div className="relative w-full sm:w-35 lg:w-42 h-48 sm:h-full flex-shrink-0">
                      <img
                        src={`http://127.0.0.1:8000/${member.image}`}
                        alt={member.name}
                        className="w-full h-full object-cover rounded-lg sm:rounded-2xl"
                      />
                    </div>

                    {/* Right side - Content */}
                    <div className="flex-1 p-2 rounded relative bg-gray-50 flex flex-col justify-between">
                      {/* Company badge - top right */}
                      <div className="absolute top-2 sm:top-3 right-2 sm:right-3 bg-[#0b154f] text-white px-2 py-1 text-xs font-bold rounded-lg">
                        {member.status}
                      </div>

                      {/* Content */}
                      <div className="pr-12 sm:pr-16">
                        <div className="mb-2 sm:mb-3">
                          <h3 className="text-base sm:text-lg font-bold text-gray-900 mb-1">
                            {member.name}
                          </h3>
                        </div>

                        {/* SUPERAGENT badge with rating */}
                        <div className="flex items-center gap-2 sm:gap-3 mb-2 sm:mb-3">
                          <div className="bg-[#0b154f] text-white px-2 sm:px-3 py-1 sm:py-2 rounded-md text-xs font-bold">
                            {member.Role}
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-yellow-500 text-sm">★</span>
                            <span className="text-xs sm:text-sm font-semibold text-gray-900">
                              {member.rating}
                            </span>
                          </div>
                        </div>

                        {/* Location and Language info */}
                        <div className="space-y-1 mb-3 sm:mb-3">
                          <p className="text-gray-700 text-xs">
                            <span className="font-semibold">Nationality:</span>{" "}
                            {member.country}
                          </p>
                          <p className="text-gray-700 text-xs">
                            <span className="font-semibold">Language:</span>{" "}
                            {member.city} {member.address}
                          </p>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex gap-2 flex-wrap sm:flex-nowrap">
                        <button
                          onClick={(e) => {
                            e.preventDefault(); // Prevent Link navigation
                            e.stopPropagation(); // Stop event bubbling
                            handleConnectClick(member);
                          }}
                          className="flex-1 sm:flex-none flex items-center justify-center gap-1 sm:gap-2 border-2 border-[#0b154f] text-[#0b154f] hover:bg-slate-50 px-3 sm:px-4 py-1 rounded-lg text-sm sm:text-base font-semibold transition-colors min-w-0"
                        >
                          <Phone size={12} className="sm:w-3.5 sm:h-3.5" />
                          <span className="truncate">Connect</span>
                        </button>
                        <button className="flex-1 sm:flex-none flex items-center justify-center gap-1 sm:gap-2 border-2 border-[#0b154f] text-[#0b154f] hover:bg-slate-50 px-3 sm:px-4 py-1 rounded-lg text-sm sm:text-base font-semibold transition-colors min-w-0">
                          <MessageSquare
                            size={12}
                            className="sm:w-3.5 sm:h-3.5"
                          />
                          <span className="truncate">WhatsApp</span>
                        </button>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex justify-center items-center mt-8 sm:mt-12 space-x-1 sm:space-x-2 px-4">
                  {/* Previous Button */}
                  <button
                    onClick={goToPreviousPage}
                    disabled={currentPage === 1}
                    className={`flex items-center px-2 sm:px-4 py-2 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                      currentPage === 1
                        ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                        : "bg-white text-[#0b154f] border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    <ChevronLeft size={16} className="sm:w-5 sm:h-5" />
                    <span className="hidden sm:inline ml-1">Previous</span>
                  </button>

                  {/* Page Numbers - Hide some on mobile */}
                  <div className="flex items-center space-x-1">
                    {getPageNumbers()
                      .slice(0, window.innerWidth < 640 ? 3 : 5)
                      .map((pageNumber) => (
                        <button
                          key={pageNumber}
                          onClick={() => goToPage(pageNumber)}
                          className={`w-8 h-8 sm:w-10 sm:h-10 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                            currentPage === pageNumber
                              ? "bg-[#0b154f] text-white"
                              : "bg-white text-[#0b154f] border border-gray-300 hover:bg-gray-50"
                          }`}
                        >
                          {pageNumber}
                        </button>
                      ))}
                  </div>

                  {/* Next Button */}
                  <button
                    onClick={goToNextPage}
                    disabled={currentPage === totalPages}
                    className={`flex items-center px-2 sm:px-4 py-2 rounded-lg font-medium transition-colors text-sm sm:text-base ${
                      currentPage === totalPages
                        ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                        : "bg-white text-[#0b154f] border border-gray-300 hover:bg-gray-50"
                    }`}
                  >
                    <span className="hidden sm:inline mr-1">Next</span>
                    <ChevronRight size={16} className="sm:w-5 sm:h-5" />
                  </button>
                </div>
              )}

              {/* SuperAgent CTA Section */}
              <div className="my-10 sm:my-20 px-4 sm:px-6">
                <div className="max-w-6xl mx-auto">
                  <div className="px-4 sm:px-6 lg:px-10 py-8 sm:py-12 rounded bg-[#ff6709] flex flex-col lg:flex-row items-center justify-between gap-6 lg:gap-8">
                    {/* Left Content */}
                    <div className="flex-1 max-w-full lg:max-w-md text-center lg:text-left">
                      <h1 className="text-white text-2xl sm:text-3xl font-bold mb-3 sm:mb-4">
                        Find your SuperAgent
                      </h1>
                      <p className="text-white text-base sm:text-lg mb-4 sm:mb-6 leading-relaxed opacity-95">
                        The most responsive agents with up-to-date and improved
                        accuracy on the properties you are searching for.
                      </p>
                      <button className="bg-transparent border-2 border-white text-white px-4 sm:px-6 py-2 rounded hover:bg-white hover:text-orange-500 transition-all duration-300 font-medium text-sm sm:text-base">
                        Learn more
                      </button>
                    </div>

                    {/* Right Image */}
                    <div className="flex-1 flex justify-center lg:justify-end items-center">
                      <div className="w-48 h-36 sm:w-64 sm:h-48 max-w-full">
                        <img
                          src={ourteam}
                          alt="SuperAgent illustration showing two professional figures with briefcases"
                          className="w-full h-full object-contain"
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div className="w-full xl:w-fit bg-white mb-4 px-8 p-6 rounded-lg shadow-lg sticky top-24 max-h-[calc(100vh-120px)] overflow-y-auto">
              <h2 className="text-2xl font-bold text-[#0b154f] mb-6">
                Propmates Team Registration
              </h2>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.name}
                    onChange={(e) => handleFormChange("name", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your name"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={formData.email}
                    onChange={(e) => handleFormChange("email", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your email"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Phone *
                  </label>
                  <input
                    type="tel"
                    required
                    value={formData.phone}
                    onChange={(e) => handleFormChange("phone", e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your phone"
                  />
                </div>

                {/* Experience Years */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Experience Years *
                  </label>
                  <input
                    type="number"
                    required
                    value={formData.experience_years}
                    onChange={(e) =>
                      handleFormChange("experience_years", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Years of experience"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Upload CV/Resume
                  </label>
                  <input
                    type="file"
                    accept=".pdf,.doc,.docx"
                    onChange={handleCVUpload}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-[#0b154f] file:text-white hover:file:bg-[#0a1245]"
                  />
                  {formData.cv && (
                    <div className="mt-2 p-2 bg-gray-50 rounded border border-gray-200">
                      <div className="flex items-center gap-2">
                        <svg
                          className="w-5 h-5 text-[#0b154f]"
                          fill="none"
                          stroke="currentColor"
                          viewBox="0 0 24 24"
                        >
                          <path
                            strokeLinecap="round"
                            strokeLinejoin="round"
                            strokeWidth={2}
                            d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                          />
                        </svg>
                        <div className="flex-1">
                          <p className="text-xs font-medium text-gray-700">
                            {formData.cv.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {(formData.cv.size / 1024).toFixed(2)} KB
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Accepted formats: PDF, DOC, DOCX (Max size: 5MB)
                  </p>
                </div>

                {/* Profile Image Upload */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Profile Image
                  </label>
                  <input
                    type="file"
                    accept="image/jpeg,image/jpg,image/png,image/gif,image/webp"
                    onChange={handleImageUpload}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-[#0b154f] file:text-white hover:file:bg-[#0a1245]"
                  />
                  {formData.image && (
                    <div className="mt-2 p-2 bg-gray-50 rounded border border-gray-200">
                      <div className="flex items-center gap-2">
                        <img
                          src={URL.createObjectURL(formData.image)}
                          alt="Preview"
                          className="w-16 h-16 object-cover rounded-lg"
                        />
                        <div className="flex-1">
                          <p className="text-xs font-medium text-gray-700">
                            {formData.image.name}
                          </p>
                          <p className="text-xs text-gray-500">
                            {(formData.image.size / 1024).toFixed(2)} KB
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    Accepted formats: JPEG, JPG, PNG, GIF, WebP (Max size: 5MB)
                  </p>
                </div>

                {/* Self Location Section */}
                <div className="pt-4 border-t border-gray-200">
                  <h3 className="text-lg font-bold text-[#0b154f] mb-3">
                    Self Location
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Country *
                      </label>
                      <select
                        required
                        value={formData.countryCode}
                        onChange={(e) => handleCountryChange(e)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                      >
                        <option value="">Select Country</option>
                        {countryOptions.map((country) => (
                          <option key={country.value} value={country.value}>
                            {country.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        State *
                      </label>
                      {hasStates(formData.countryCode) ? (
                        <select
                          required
                          value={formData.stateCode}
                          onChange={handleStateChange}
                          disabled={!formData.countryCode}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select State</option>
                          {stateOptions.map((state) => (
                            <option key={state.value} value={state.value}>
                              {state.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          required
                          value={formData.state}
                          onChange={(e) =>
                            handleFormChange("state", e.target.value)
                          }
                          disabled={!formData.countryCode}
                          placeholder="Enter State/Province/Region"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        City *
                      </label>
                      {hasCities(formData.countryCode, formData.stateCode) ? (
                        <select
                          required
                          value={formData.city}
                          onChange={handleCityChange}
                          disabled={
                            !formData.countryCode || !formData.stateCode
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select City</option>
                          {cityOptions.map((city) => (
                            <option key={city.value} value={city.value}>
                              {city.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          required
                          value={formData.city}
                          onChange={(e) =>
                            handleFormChange("city", e.target.value)
                          }
                          disabled={
                            !formData.countryCode || !formData.stateCode
                          }
                          placeholder="Enter City"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Address *
                      </label>
                      <textarea
                        required
                        value={formData.address}
                        onChange={(e) =>
                          handleFormChange("address", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                        placeholder="Enter address"
                        rows="2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Pincode *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.pincode}
                        onChange={(e) =>
                          handleFormChange("pincode", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                        placeholder="Enter pincode"
                      />
                    </div>
                  </div>
                </div>

                {/* Preferred Location Section */}
                <div className="pt-4 border-t border-gray-200">
                  <h3 className="text-lg font-bold text-[#0b154f] mb-3">
                    Preferred Location
                  </h3>

                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred Country *
                      </label>
                      <select
                        required
                        value={formData.PcountryCode}
                        onChange={(e) => handlePcountryChange(e)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                      >
                        <option value="">Select Country</option>
                        {countryOptions.map((country) => (
                          <option key={country.value} value={country.value}>
                            {country.label}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred State *
                      </label>
                      {hasStates(formData.PcountryCode) ? (
                        <select
                          required
                          value={formData.PstateCode}
                          onChange={handlePstateChange}
                          disabled={!formData.PcountryCode}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select State</option>
                          {PstateOptions.map((state) => (
                            <option key={state.value} value={state.value}>
                              {state.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          required
                          value={formData.Pstate}
                          onChange={(e) =>
                            handleFormChange("Pstate", e.target.value)
                          }
                          disabled={!formData.PcountryCode}
                          placeholder="Enter State/Province/Region"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred City *
                      </label>
                      {hasCities(formData.PcountryCode, formData.PstateCode) ? (
                        <select
                          required
                          value={formData.Pcity}
                          onChange={handlePcityChange}
                          disabled={
                            !formData.PcountryCode || !formData.PstateCode
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select City</option>
                          {PcityOptions.map((city) => (
                            <option key={city.value} value={city.value}>
                              {city.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          required
                          value={formData.Pcity}
                          onChange={(e) =>
                            handleFormChange("Pcity", e.target.value)
                          }
                          disabled={
                            !formData.PcountryCode || !formData.PstateCode
                          }
                          placeholder="Enter City"
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f] disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred Address *
                      </label>
                      <textarea
                        required
                        value={formData.Paddress}
                        onChange={(e) =>
                          handleFormChange("Paddress", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                        placeholder="Enter preferred address"
                        rows="2"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred Pincode *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.Ppincode}
                        onChange={(e) =>
                          handleFormChange("Ppincode", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                        placeholder="Enter preferred pincode"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-1">
                        Preferred Role *
                      </label>
                      <select
                        required
                        value={formData.Role}
                        onChange={(e) =>
                          handleFormChange("Role", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                      >
                        <option value="">Select Role</option>
                        <option value="Executive Director">Manager</option>
                        <option value="Senior Agent">Member</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <button
                  type="submit"
                  className="w-full bg-[#0b154f] text-white py-3 rounded-lg font-semibold hover:bg-[#0a1245] transition-colors mt-6"
                >
                  Register
                </button>
              </form>
            </div>
          </div>
        </div>
      </div>

      {/* Connect Modal */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-[#000000b5] bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-lg max-w-md w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              {/* Modal Header */}
              <div className="flex justify-between items-center mb-4">
                <h3 className="text-xl font-bold text-[#0b154f]">
                  Connect with {selectedAgent?.name}
                </h3>
                <button
                  onClick={handleCloseModal}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <svg
                    className="w-6 h-6"
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M6 18L18 6M6 6l12 12"
                    />
                  </svg>
                </button>
              </div>

              {/* Modal Form */}
              <form onSubmit={handleConnectSubmit} className="space-y-4">
                {/* Full Name */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    required
                    value={connectFormData.fullName}
                    onChange={(e) =>
                      handleConnectFormChange("fullName", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your full name"
                  />
                </div>

                {/* Email */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Email *
                  </label>
                  <input
                    type="email"
                    required
                    value={connectFormData.email}
                    onChange={(e) =>
                      handleConnectFormChange("email", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your email"
                  />
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    required
                    value={connectFormData.phone}
                    onChange={(e) =>
                      handleConnectFormChange("phone", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your phone number"
                  />
                </div>

                {/* Subject */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Subject *
                  </label>
                  <input
                    type="text"
                    required
                    value={connectFormData.subject}
                    onChange={(e) =>
                      handleConnectFormChange("subject", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter subject"
                  />
                </div>

                {/* Message */}
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-1">
                    Message *
                  </label>
                  <textarea
                    required
                    value={connectFormData.message}
                    onChange={(e) =>
                      handleConnectFormChange("message", e.target.value)
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#0b154f]"
                    placeholder="Enter your message"
                    rows="4"
                  />
                </div>

                {/* Submit Button */}
                <div className="flex gap-3 pt-2">
                  <button
                    type="button"
                    onClick={handleCloseModal}
                    className="flex-1 px-4 py-2 border-2 border-gray-300 text-gray-700 rounded-lg font-semibold hover:bg-gray-50 transition-colors"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="flex-1 px-4 py-2 bg-[#0b154f] text-white rounded-lg font-semibold hover:bg-[#0a1245] transition-colors"
                  >
                    Send Message
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      <Footer />

      <style jsx>{`
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>
    </div>
  );
};

export default OurTeam;
