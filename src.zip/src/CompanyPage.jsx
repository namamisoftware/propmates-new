import React, { useState, useRef, useEffect } from "react";
import {
  Heart,
  Bed,
  Bath,
  Maximize,
  MapPin,
  Phone,
  Mail,
  MessageCircle,
  Calendar,
} from "lucide-react";
import Header from "./components/Header";
import Footer from "./components/Footer";

export default function CompanyPage() {
  const [likedProperties, setLikedProperties] = useState({});
  const [currentPage, setCurrentPage] = useState(1);
  const propertiesPerPage = 6;

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);

  useEffect(() => {
    // Load Leaflet CSS
    const link = document.createElement("link");
    link.rel = "stylesheet";
    link.href =
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.css";
    document.head.appendChild(link);

    // Load Leaflet JS
    const script = document.createElement("script");
    script.src =
      "https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.min.js";
    script.async = true;

    script.onload = () => {
      if (mapRef.current && !mapInstanceRef.current) {
        // Initialize map centered on Dubai (horizontal view)
        const map = window.L.map(mapRef.current).setView(
          [25.2048, 55.2708],
          12
        );
        mapInstanceRef.current = map;

        // Add OpenStreetMap tiles
        window.L.tileLayer(
          "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
          {
            attribution: "© OpenStreetMap contributors",
            maxZoom: 19,
          }
        ).addTo(map);

        // Location data with Dubai coordinates (horizontal spread)
        const locations = [
          {
            lat: 25.2048,
            lng: 55.15,
            name: "Dubai Marina",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.2048,
            lng: 55.2,
            name: "Jumeirah",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.2048,
            lng: 55.25,
            name: "Downtown Dubai",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.2048,
            lng: 55.3,
            name: "Business Bay",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.2048,
            lng: 55.35,
            name: "Dubai Creek",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.18,
            lng: 55.18,
            name: "JBR Beach",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.18,
            lng: 55.23,
            name: "DIFC",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.18,
            lng: 55.28,
            name: "Burj Khalifa Area",
            icon: "🏢",
            type: "Office Building",
          },
          {
            lat: 25.23,
            lng: 55.22,
            name: "Palm Jumeirah",
            icon: "🏪",
            type: "Retail Store",
          },
          {
            lat: 25.23,
            lng: 55.32,
            name: "Deira",
            icon: "🏢",
            type: "Office Building",
          },
        ];

        // Create custom icon
        const createCustomIcon = (iconEmoji) => {
          return window.L.divIcon({
            className: "custom-div-icon",
            html: `<div style="
              background-color: #0f766e;
              border: 3px solid white;
              border-radius: 50%;
              width: 40px;
              height: 40px;
              display: flex;
              align-items: center;
              justify-content: center;
              font-size: 20px;
              box-shadow: 0 4px 6px rgba(0, 0, 0, 0.3);
              cursor: pointer;
              transition: transform 0.2s;
            ">${iconEmoji}</div>`,
            iconSize: [40, 40],
            iconAnchor: [20, 20],
            popupAnchor: [0, -20],
          });
        };

        // Add markers to map
        locations.forEach((location) => {
          const marker = window.L.marker([location.lat, location.lng], {
            icon: createCustomIcon(location.icon),
          }).addTo(map);

          marker.bindPopup(`
            <div style="padding: 8px;">
              <div style="font-weight: 600; font-size: 16px; margin-bottom: 4px; color: #1f2937;">
                ${location.name}
              </div>
              <div style="color: #6b7280; font-size: 13px;">
                ${location.type}
              </div>
            </div>
          `);
        });

        // Add scale control
        window.L.control.scale().addTo(map);
      }
    };

    document.body.appendChild(script);

    // Cleanup
    return () => {
      if (mapInstanceRef.current) {
        mapInstanceRef.current.remove();
        mapInstanceRef.current = null;
      }
    };
  }, []);

  // Dummy property data
  const allProperties = [
    {
      id: 1,
      name: "Luxury Villa with Private Pool and Garden",
      expected_price: "4.5",
      bedrooms: 4,
      bathrooms: 3,
      carpet_area: "3500",
      locality: "Palm Jumeirah",
      sub_locality: "Frond M",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=100&h=100&fit=crop",
    },
    {
      id: 2,
      name: "Modern Apartment with Stunning City Views",
      expected_price: "2.8",
      bedrooms: 2,
      bathrooms: 2,
      carpet_area: "1800",
      locality: "Downtown Dubai",
      sub_locality: "Boulevard Heights",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1560184897-ae75f418493e?w=100&h=100&fit=crop",
    },
    {
      id: 3,
      name: "Spacious Penthouse with Panoramic Views",
      expected_price: "6.2",
      bedrooms: 5,
      bathrooms: 4,
      carpet_area: "4200",
      locality: "Dubai Marina",
      sub_locality: "Marina Promenade",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1564013799919-ab600027ffc6?w=100&h=100&fit=crop",
    },
    {
      id: 4,
      name: "Elegant Townhouse in Gated Community",
      expected_price: "3.2",
      bedrooms: 3,
      bathrooms: 3,
      carpet_area: "2400",
      locality: "Arabian Ranches",
      sub_locality: "Savannah",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=100&h=100&fit=crop",
    },
    {
      id: 5,
      name: "Contemporary Studio with Smart Home Features",
      expected_price: "1.5",
      bedrooms: 1,
      bathrooms: 1,
      carpet_area: "950",
      locality: "Business Bay",
      sub_locality: "Executive Towers",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=100&h=100&fit=crop",
    },
    {
      id: 6,
      name: "Beachfront Apartment with Private Beach Access",
      expected_price: "5.8",
      bedrooms: 3,
      bathrooms: 3,
      carpet_area: "2800",
      locality: "Jumeirah Beach Residence",
      sub_locality: "Shams Tower",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1502672260066-6bc35f0a1f80?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1600566753376-12c8ab7fb75b?w=100&h=100&fit=crop",
    },
    {
      id: 7,
      name: "Cozy Studio in the Heart of the City",
      expected_price: "1.2",
      bedrooms: 1,
      bathrooms: 1,
      carpet_area: "850",
      locality: "Deira",
      sub_locality: "Al Rigga",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=100&h=100&fit=crop",
    },
    {
      id: 8,
      name: "Golf Course Villa with Premium Amenities",
      expected_price: "7.5",
      bedrooms: 6,
      bathrooms: 5,
      carpet_area: "5500",
      locality: "Dubai Hills Estate",
      sub_locality: "Emerald Hills",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1558036117-15d82a90b9b1?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1600047509807-ba8f99d2cdde?w=100&h=100&fit=crop",
    },
    {
      id: 9,
      name: "Waterfront Duplex with Private Dock",
      expected_price: "4.8",
      bedrooms: 4,
      bathrooms: 3,
      carpet_area: "3200",
      locality: "Dubai Creek Harbour",
      sub_locality: "Creek Beach",
      city: "Dubai",
      images:
        "https://images.unsplash.com/photo-1600585154526-990dced4db0d?w=800&h=600&fit=crop",
      logo: "https://images.unsplash.com/photo-1600607687644-c7171b42498b?w=100&h=100&fit=crop",
    },
  ];

  const totalPages = Math.ceil(allProperties.length / propertiesPerPage);
  const indexOfLastProperty = currentPage * propertiesPerPage;
  const indexOfFirstProperty = indexOfLastProperty - propertiesPerPage;
  const currentProperties = allProperties.slice(
    indexOfFirstProperty,
    indexOfLastProperty
  );

  const handlePageChange = (pageNumber) => {
    setCurrentPage(pageNumber);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
      window.scrollTo({ top: 0, behavior: "smooth" });
    }
  };

  const toggleLike = (id) => {
    setLikedProperties((prev) => ({
      ...prev,
      [id]: !prev[id],
    }));
  };

  return (
    <>
      <Header />
      <div className="relative w-full overflow-hidden py-8 sm:py-12 md:py-14 lg:py-16 min-h-[500px] sm:min-h-[600px]">
        {/* Background Image */}
        <div
          className="absolute inset-0 bg-cover bg-center"
          style={{
            backgroundImage: `url('https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=1920&q=80')`,
          }}
        >
          {/* Overlay */}
          <div className="absolute inset-0 bg-gradient-to-r from-slate-900/80 via-slate-800/60 to-slate-900/40 sm:from-slate-900/70 sm:via-slate-800/50 sm:to-transparent"></div>
        </div>

        {/* Content */}
        <div className="relative z-10 flex items-center justify-center sm:justify-start px-4 sm:px-6 md:px-12 lg:px-20 h-full">
          {/* Glassmorphism Container */}
          <div className="w-full max-w-sm sm:max-w-md md:max-w-md backdrop-blur-md bg-white/10 border border-white/20 rounded-xl sm:rounded-2xl p-6 sm:p-8 shadow-2xl">
            {/* Logo */}
            <div className="bg-white rounded-lg p-4 sm:p-6 mb-6 sm:mb-8 inline-block shadow-lg">
              <h1 className="text-2xl sm:text-3xl font-bold text-slate-800 tracking-tight">
                EMAAR
              </h1>
            </div>

            {/* Description */}
            <div className="text-white space-y-3 sm:space-y-4 mb-8 sm:mb-10">
              <p className="text-sm sm:text-base leading-relaxed">
                Emaar, a real estate giant founded in 1997, is renowned for Burj
                Khalifa and Dubai Mall. Emaar offers different properties built
                to the highest standards. Their mission is to shape the future
                for everyone.
              </p>
            </div>

            {/* Contact Section */}
            <div className="space-y-3 sm:space-y-4">
              <h3 className="text-white text-base sm:text-lg font-semibold">
                Contact developer
              </h3>

              <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
                {/* Email Button */}
                <button className="flex items-center justify-center gap-2 bg-white hover:bg-gray-50 text-slate-800 px-5 sm:px-6 py-2.5 sm:py-3 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 w-full sm:w-auto">
                  <Mail className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="font-medium text-sm sm:text-base">
                    Email
                  </span>
                </button>

                {/* WhatsApp Button */}
                <button className="flex items-center justify-center gap-2 bg-white hover:bg-gray-50 text-slate-800 px-5 sm:px-6 py-2.5 sm:py-3 rounded-lg transition-all duration-300 shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 w-full sm:w-auto">
                  <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5" />
                  <span className="font-medium text-sm sm:text-base">
                    WhatsApp
                  </span>
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Decorative Elements */}
        <div className="absolute bottom-0 left-0 right-0 h-24 sm:h-32 bg-gradient-to-t from-slate-900/50 to-transparent pointer-events-none"></div>
      </div>

      <div className="my-10 p-6">
        <div className="max-w-7xl mx-auto">
          <h1 className="text-3xl font-bold text-gray-900 mb-8">
            Featured Properties
          </h1>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentProperties.map((property) => (
              <div
                key={property.id}
                className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-300 cursor-pointer"
              >
                {/* Image Section */}
                <div className="relative overflow-hidden">
                  <img
                    src={property.images}
                    alt={property.name}
                    className="w-full h-48 object-cover transition-transform duration-300 hover:scale-105 hover:rotate-3"
                  />

                  {/* Property Logo */}
                  <div className="absolute top-3 left-3">
                    <img
                      src={property.logo}
                      alt={`${property.name} logo`}
                      className="w-12 h-12 rounded object-cover"
                    />
                  </div>

                  {/* Like Button */}
                  <button
                    onClick={() => toggleLike(property.id)}
                    className="absolute top-3 right-3 w-8 h-8 bg-white rounded-full shadow-md flex items-center justify-center hover:bg-gray-50 transition-colors"
                  >
                    <Heart
                      className={`w-4 h-4 ${
                        likedProperties[property.id]
                          ? "text-red-500 fill-red-500"
                          : "text-gray-400"
                      }`}
                    />
                  </button>
                </div>

                {/* Content Section */}
                <div className="p-4">
                  {/* Title */}
                  <h3 className="text-sm text-gray-500 mb-2 line-clamp-2">
                    {property.name}
                  </h3>

                  {/* Price */}
                  <div className="mb-3">
                    <div className="flex items-baseline gap-1">
                      <span className="text-xl font-bold text-gray-900">
                        {property.expected_price}M AED
                      </span>
                      <span className="text-sm text-gray-500">Yearly</span>
                    </div>
                  </div>

                  {/* Property Details */}
                  <div className="flex items-center gap-4 mb-3 text-sm font-bold text-[#0f57d1]">
                    <div className="flex items-center gap-1">
                      <Bed className="w-4 h-4" />
                      <span>{property.bedrooms}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Bath className="w-4 h-4" />
                      <span>{property.bathrooms}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Maximize className="w-4 h-4" />
                      <span>{property.carpet_area} Sq.Ft</span>
                    </div>
                  </div>

                  {/* Location */}
                  <div className="flex items-start mb-4">
                    <MapPin className="w-4 h-4 text-[#0B154F] mt-0.5 mr-2 flex-shrink-0" />
                    <p className="text-xs text-gray-500 leading-relaxed line-clamp-1">
                      {property.locality} {property.sub_locality}{" "}
                      {property.city}
                    </p>
                  </div>

                  {/* Agent and Contact Section */}
                  <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                    {/* Agent Info */}
                    <div className="flex items-center gap-2">
                      <img
                        src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=40&h=40&fit=crop&crop=face"
                        alt="Agent"
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <span className="text-xs text-gray-700 font-medium">
                          Listed by <br />
                        </span>
                        <span className="text-sm text-gray-700 font-medium">
                          Layla Hassan
                        </span>
                      </div>
                    </div>

                    {/* Contact Buttons */}
                    <div className="flex items-center gap-2">
                      <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
                        <Phone className="w-4 h-4 text-green-600" />
                      </button>
                      <button className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center hover:bg-green-200 transition-colors">
                        <MessageCircle className="w-4 h-4 text-green-600" />
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Pagination */}
          <div className="flex items-center justify-center gap-2 mt-8">
            {/* Previous Button */}
            <button
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className={`w-10 h-10 flex items-center justify-center rounded-lg border ${
                currentPage === 1
                  ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                  : "bg-white text-gray-700 hover:bg-gray-50 border-gray-300"
              }`}
            >
              <span className="text-lg">‹</span>
            </button>

            {/* Page Numbers */}
            {[...Array(totalPages)].map((_, index) => {
              const pageNumber = index + 1;
              return (
                <button
                  key={pageNumber}
                  onClick={() => handlePageChange(pageNumber)}
                  className={`w-10 h-10 flex items-center justify-center rounded-lg font-medium transition-colors ${
                    currentPage === pageNumber
                      ? "bg-[#0b154f] text-white"
                      : "bg-white text-gray-700 hover:bg-gray-50 border border-gray-300"
                  }`}
                >
                  {pageNumber}
                </button>
              );
            })}

            {/* Next Button */}
            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className={`w-10 h-10 flex items-center justify-center rounded-lg border ${
                currentPage === totalPages
                  ? "bg-gray-100 text-gray-400 cursor-not-allowed"
                  : "bg-white text-gray-700 hover:bg-gray-50 border-gray-300"
              }`}
            >
              <span className="text-lg">›</span>
            </button>
          </div>
        </div>
      </div>

      <div className=" bg-gray-50">
        {/* Main Content */}
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          {/* Introduction Section */}
          <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <p className="text-gray-700 leading-relaxed mb-4">
              Emaar Properties (Emaar Developments or simply Emaar) is an
              Emirati multinational real estate development company located in
              the United Arab Emirates. It's one of the largest real estate
              developers in the UAE and develops residential properties,
              shopping malls, hospitality, leisure and retail projects.
            </p>
            <p className="text-gray-700 leading-relaxed mb-4">
              Emaar is the mastermind behind iconic projects such as Burj
              Khalifa, Dubai Mall,{" "}
              <a href="#" className="text-blue-600 hover:underline">
                Downtown Dubai
              </a>
              , and{" "}
              <a href="#" className="text-blue-600 hover:underline">
                Dubai Marina
              </a>
              .
            </p>
            <p className="text-gray-700 leading-relaxed">
              Emaar creates new lifestyles by prioritizing design excellence,
              construction quality, and prompt delivery.
            </p>
          </section>

          {/* Ongoing Projects Section */}
          <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Emaar's ongoing projects in Dubai
            </h2>
            <p className="text-gray-700 leading-relaxed">
              Each Emaar property has its own unique design aesthetic, providing
              an aspirational lifestyle within a thriving community, supported
              by Emaar's community management team. Discover luxurious Emaar
              Communities and properties in Dubai.
            </p>
          </section>

          {/* Know More Section */}
          <section className="bg-white rounded-lg shadow-sm p-6 mb-6">
            <h2 className="text-2xl font-bold text-gray-900 mb-6">
              Know more about Emaar Properties
            </h2>

            {/* Who is Emaar */}
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                Who is Emaar Properties?
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Emaar Properties is a real estate development company based in
                Dubai. The company is known for selling properties that are not
                yet constructed, also known as "off-plan" properties. Emaar was
                founded in 1997 and has since grown to become one of the largest
                real estate developers in the Middle East, with operations in
                several countries around the world.
              </p>
            </div>

            {/* Major Projects */}
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                What are some of Emaar Properties' major projects?
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Emaar Properties has developed some of the most iconic and
                ambitious projects in Dubai, including the Burj Khalifa (the
                tallest building in the world), The Dubai Mall (one of the
                largest shopping centers in the world), Downtown Dubai (one of
                Dubai's most iconic neighborhoods) and Dubai Marina (a luxurious
                waterfront development).
              </p>
            </div>

            {/* New Projects */}
            <div className="mb-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                What are some of Emaar's new projects in Dubai?
              </h3>
              <p className="text-gray-700 leading-relaxed">
                Emaar has developed several notable projects in Dubai in recent
                years. Some of these include{" "}
                <a href="#" className="text-blue-600 hover:underline">
                  Dubai Hills Estate
                </a>
                , a 2,700-acre master-planned community with residential,
                commercial, and retail components; Dubai Creek Harbour, a
                waterfront development that will include the world's tallest
                tower; and The Dubai Mall Zabeel, a new addition to the Dubai
                Mall complex that features high-end retail and entertainment
                offerings. Emaar is also developing other properties and
                projects in Dubai and other countries.
              </p>
            </div>

            {/* Off-Plan Projects */}
            <div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">
                What are some of Emaar's Off-Plan Projects?
              </h3>
              <p className="text-gray-700 leading-relaxed mb-4">
                Emaar's off-plan properties in Dubai are wide and varied. These
                include:
              </p>
            </div>
          </section>

          {/* Off-Plan Project Card */}
          <section className="bg-white rounded-lg shadow-sm p-6">
            <div className="space-y-6">
              <div className="border-l-4 border-blue-600 pl-4">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Club Drive
                </h3>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">
                    Delivery Date:{" "}
                    <span className="font-semibold text-gray-900">Q1 2028</span>
                  </span>
                </div>
              </div>

              <div className="border-l-4 border-blue-600 pl-4">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Cedar Creek Beach
                </h3>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">
                    Delivery Date:{" "}
                    <span className="font-semibold text-gray-900">Q3 2026</span>
                  </span>
                </div>
              </div>

              <div className="border-l-4 border-blue-600 pl-4">
                <h3 className="text-xl font-bold text-gray-900 mb-2">
                  Address Za'abeel
                </h3>
                <div className="flex items-center space-x-2 text-gray-600">
                  <Calendar className="w-4 h-4" />
                  <span className="text-sm">
                    Delivery Date:{" "}
                    <span className="font-semibold text-gray-900">Q3 2029</span>
                  </span>
                </div>
              </div>
            </div>
          </section>
        </main>
      </div>

      <div className="h-100 max-w-7xl my-14 mx-auto px-4 sm:px-6 relative">
        <div ref={mapRef} className="w-full h-full rounded" />
      </div>
      <Footer />
    </>
  );
}
