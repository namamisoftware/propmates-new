// import React, { useState } from "react";
// import {
//   Home,
//   User,
//   LogOut,
//   HelpCircle,
//   ChevronDown,
//   ChevronRight,
// } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import axios from 'axios'
// import { Link } from "react-router-dom";
// import AboveHeader from "./Components/AboveHeader";

// import { useNavigate } from "react-router-dom";


// const PropertyCard = ({ property }) => {
//   const navigate = useNavigate();

//   return (
//     <div className="bg-blue-50 rounded-lg shadow-sm overflow-hidden mb-3 p-3 sm:p-4">
//       {/* <button onClick={fetchData}>fetch</button> */}

//       <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
//         {/* Image */}
//         <img
//           src={property.image}
//           alt={property.title}
//           className="w-full sm:w-40 md:w-52 lg:w-66 h-40 sm:h-32 md:h-40 lg:h-46 rounded object-cover flex-shrink-0"
//         />

//         {/* Details */}
//         <div className="flex-1 flex flex-col justify-between min-w-0">
//           <div>
//             <div className="flex items-start justify-between gap-2">
//               <h3 className="font-semibold text-sm sm:text-base text-gray-900 flex-1">
//                 {property.title}
//               </h3>

//               {/* View & Edit Button */}
//               <button
//                 onClick={() => navigate(`/editpropertypg`)}
//                 className="px-3 py-1 bg-blue-600 text-white text-xs font-medium rounded hover:bg-blue-700 transition-colors flex-shrink-0"
//               >
//                 View & Edit
//               </button>
//             </div>

//             <p className="text-xs text-gray-600 mt-1 line-clamp-2">
//               {property.description}
//             </p>
//             <p className="text-xs text-gray-600 line-clamp-2">
//               {property.description2}
//             </p>
//           </div>

//           {/* Price */}
//           <div className="mt-3 sm:mt-4">
//             <div className="text-lg sm:text-base font-bold text-gray-900">
//               ₹{property.price.toLocaleString()}
//             </div>
//           </div>

//           {/* Area + Furnishing */}
//           <div className="flex flex-wrap items-center gap-4 sm:gap-6 mt-3">
//             <div>
//               <div className="text-xs font-semibold text-gray-900">
//                 {property.area} Sq.Ft.
//               </div>
//               <div className="text-xs text-gray-500">{property.rate}</div>
//             </div>
//             <div>
//               <div className="text-xs font-semibold text-gray-900">
//                 {property.furnished}
//               </div>
//               <div className="text-xs text-gray-500">
//                 {property.furnishedStatus}
//               </div>
//             </div>
//           </div>

//           {/* Posted On */}
//           <div className="text-xs text-gray-500 mt-3 sm:mt-4">
//             Posted on: {property.postedDate}
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// const Pagination = ({ currentPage, totalPages, onPageChange }) => {
//   return (
//     <div className="flex items-center justify-center gap-2 mt-6 pb-4">
//       {/* Previous Button */}
//       <button
//         onClick={() => onPageChange(currentPage - 1)}
//         disabled={currentPage === 1}
//         className={`px-3 py-1 rounded ${
//           currentPage === 1
//           ? "bg-gray-200 cursor-not-allowed"
//             : "bg-blue-600 text-white hover:bg-blue-700"
//           }`}
//       >
//         Previous
//       </button>

//       <button onClick={fetchData}>fetch</button>


//       {/* Page Numbers */}
//       <span className="text-sm text-gray-600">
//         Page {currentPage} of {totalPages}
//       </span>

//       {/* Next Button */}
//       <button
//         onClick={() => onPageChange(currentPage + 1)}
//         disabled={currentPage === totalPages}
//         className={`px-3 py-1 rounded ${
//           currentPage === totalPages
//             ? "bg-gray-200 cursor-not-allowed"
//             : "bg-blue-600 text-white hover:bg-blue-700"
//         }`}
//       >
//         Next
//       </button>
//     </div>
//   );
// };

// const App = () => {
//   const [currentPage, setCurrentPage] = useState(1);
//   const itemsPerPage = 3;
//   const properties = [

//   ]; 

//   const totalPages = Math.ceil(properties.length / itemsPerPage);
//   const startIndex = (currentPage - 1) * itemsPerPage;
//   const endIndex = startIndex + itemsPerPage;
//   // const currentProperties = properties.slice(startIndex, endIndex);
//   const [currentProperties, setCurrentProperties] = useState([])

//   const [openMenu, setOpenMenu] = useState(null);
//   const [users,setUsers] = useState([]);


//   const toggleMenu = (menu) => {
//     setOpenMenu(openMenu === menu ? null : menu);
//   };

//   return (
//     <>
//       <Header />
//       <div className="max-w-6xl mx-auto my-10 p-4">
//         <div className="flex gap-4 items-start">
//           {/* Sidebar */}
//           <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded shadow-sm sticky top-8 max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-hide">
//             <div className="p-4">
//               <nav className="space-y-0.5">
//                 {/* My Listings */}
//                 <div>
//                   <button
//                     onClick={() => toggleMenu("mylistings")}
//                     className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//                   >
//                     <div className="flex items-center gap-3">
//                       <Home className="w-4 h-4" />
//                       <span>My Listings</span>
//                     </div>
//                     {openMenu === "mylistings" ? (
//                       <ChevronDown className="w-4 h-4" />
//                     ) : (
//                       <ChevronRight className="w-4 h-4" />
//                     )}
//                   </button>

//                   {openMenu === "mylistings" && (
//                     <div className="ml-8 mt-1 space-y-1">
//                       <Link
//                         to="/mylistings/commercial"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Commercial
//                       </Link>
//                       <Link
//                         to="/mylistings/residential"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Residential
//                       </Link>
//                       <Link
//                         to="/mylistings/pg"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         PG
//                       </Link>
//                       <Link
//                         to="/mylistings/agriculture"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Agricultural/Farms
//                       </Link>
//                       <Link
//                         to="/mylistings/holidayrent"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Holiday Rent
//                       </Link>
//                       <Link
//                         to="/mylistings/businessforsale"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Business For Sale
//                       </Link>
//                     </div>
//                   )}
//                 </div>

//                 {/* List Property */}
//                 <div>
//                   <button
//                     onClick={() => toggleMenu("listproperty")}
//                     className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//                   >
//                     <div className="flex items-center gap-3">
//                       <Home className="w-4 h-4" />
//                       <span>List Property</span>
//                     </div>
//                     {openMenu === "listproperty" ? (
//                       <ChevronDown className="w-4 h-4" />
//                     ) : (
//                       <ChevronRight className="w-4 h-4" />
//                     )}
//                   </button>

//                   {openMenu === "listproperty" && (
//                     <div className="ml-8 mt-1 space-y-1">
//                       <Link
//                         to="/listproperty/commercial"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Commercial
//                       </Link>
//                       <Link
//                         to="/listproperty/residential"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Residential
//                       </Link>
//                       <Link
//                         to="/listproperty/pg"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         PG
//                       </Link>
//                       <Link
//                         to="/listproperty/agriculture"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Agricultural/Farms
//                       </Link>
//                       <Link
//                         to="/listproperty/holidayrent"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Holiday Rent
//                       </Link>
//                       <Link
//                         to="/listproperty/businessforsale"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Business For Sale
//                       </Link>
//                     </div>
//                   )}
//                 </div>

//                 {/* Profile */}
//                 <Link
//                   to="/profile"
//                   className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//                 >
//                   <User className="w-4 h-4" />
//                   <span>Profile</span>
//                 </Link>

//                 {/* Enquiry */}
//                 <div>
//                   <button
//                     onClick={() => toggleMenu("enquiry")}
//                     className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//                   >
//                     <div className="flex items-center gap-3">
//                       <HelpCircle className="w-4 h-4" />
//                       <span>Enquiry/Ticket</span>
//                     </div>
//                     {openMenu === "enquiry" ? (
//                       <ChevronDown className="w-4 h-4" />
//                     ) : (
//                       <ChevronRight className="w-4 h-4" />
//                     )}
//                   </button>

//                   {openMenu === "enquiry" && (
//                     <div className="ml-8 mt-1 space-y-1">
//                       <Link
//                         to="/enquiry/addenquiry"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         Add Enquiry
//                       </Link>
//                       <Link
//                         to="/enquiry/newenquiry"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         New Enquiry
//                       </Link>
//                       <Link
//                         to="/enquiry/allenquiry"
//                         className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
//                       >
//                         All Enquiry
//                       </Link>
//                     </div>
//                   )}
//                 </div>
//               </nav>
//             </div>
//           </div>

//           {/* Main Content */}
//           <div className="flex-1 bg-white rounded shadow-sm">
//             <div className="bg-white border-b border-gray-200 px-3 sm:px-5 py-2.5 hidden md:flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
//               <Link
//                 to="/mylistings/commercial"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 Commercial
//               </Link>
//               <Link
//                 to="/mylistings/residential"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 Residential
//               </Link>
//               <Link
//                 to="/mylistings/pg"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 PG
//               </Link>
//               <Link
//                 to="/mylistings/agriculture"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 Agriculture
//               </Link>
//               <Link
//                 to="/mylistings/holidayrent"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 Holiday Rent
//               </Link>
//               <Link
//                 to="/mylistings/businessforsale"
//                 className="text-base font-semibold text-gray-800 hover:text-[#0b154f] hover:underline"
//               >
//                 Business For Sale
//               </Link>
//             </div>
//             <div className="bg-white border-b border-gray-200 px-3 sm:px-5 py-2.5 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 sm:gap-0">
//                   {users.map((elem)=>{
//         <div>
//           <li key={elem.id}>{elem}</li>
//         </div>
//       })}


//               <h2 className="text-base font-semibold text-gray-800">
//                 PG Property Listings
//               </h2>
//             </div>

//             <div className="p-3 sm:p-5 bg-gray-50">
//               {currentProperties.map((property) => (
//                 <PropertyCard key={property.id} property={property} />
//               ))}

//               <Pagination
//                 currentPage={currentPage}
//                 totalPages={totalPages}
//                 onPageChange={setCurrentPage}
//               />
//             </div>
//           </div>

//           <style jsx>{`
//             .scrollbar-hide {
//               -ms-overflow-style: none;
//               scrollbar-width: none;
//             }
//             .scrollbar-hide::-webkit-scrollbar {
//               display: none;
//             }
//           `}</style>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default App;


import axios from 'axios'
import React from 'react'
import { useState } from 'react'

const App = () => {
  const [users, setUsers] = useState([])

  const fetchData = async () => {
    const res = await axios.get("https://fakestoreapi.com/products/1")
    console.log(res.data.id);

    setUsers([res.data])   
  }

  return (
    <div>
      {users.map((item, index) => (
        <div key={index}>
          <li>{item.id}</li> 
          <li>{item.description}</li> 
        </div>
      ))}

      <button onClick={fetchData}>Fetch</button>
    </div>
  )
}

export default App
