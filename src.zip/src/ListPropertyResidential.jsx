import React, { useState, useEffect, useRef } from "react";
import {
  Home,
  User,
  HelpCircle,
  X,
  ChevronDown,
  ChevronRight,
  MapPin,
  Navigation,
} from "lucide-react";
import { Country, State, City } from "country-state-city";
import Header from "./Components/Header";
import AboveHeader from "./Components/AboveHeader";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const PropertyListingForm = () => {
  const [propertyVideo, setPropertyVideo] = useState(null);
  const [videoPreview, setVideoPreview] = useState(null);
  const handleVideoUpload = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    // Check file size (100MB limit)
    const maxSize = 100 * 1024 * 1024; // 100MB in bytes
    if (file.size > maxSize) {
      alert("Video file is too large. Maximum size is 100MB.");
      return;
    }

    // Check file type
    const allowedTypes = ["video/mp4", "video/quicktime", "video/x-msvideo"];
    if (!allowedTypes.includes(file.type)) {
      alert("Invalid file type. Please upload MP4, MOV, or AVI format.");
      return;
    }

    // Create preview URL
    const previewUrl = URL.createObjectURL(file);

    setPropertyVideo(file);
    setVideoPreview(previewUrl);
  };

  const removeVideo = () => {
    // Revoke the URL to free memory
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }

    setPropertyVideo(null);
    setVideoPreview(null);
  };
  const [imageCategories] = useState([
    { id: "exterior", label: "Exterior View", required: true },
    { id: "living", label: "Living Room", required: false },
    { id: "bedroom", label: "Bedroom", required: false },
    { id: "bathroom", label: "Bathroom", required: false },
    { id: "kitchen", label: "Kitchen", required: false },
    { id: "floorplan", label: "Floor Plan", required: false },
    { id: "masterplan", label: "Master Plan", required: false },
    { id: "locationmap", label: "Location Map", required: false },
    { id: "other", label: "Other", required: false },
  ]);

  const [activeImageTab, setActiveImageTab] = useState("exterior");
  const [categorizedImages, setCategorizedImages] = useState({
    exterior: [],
    living: [],
    bedroom: [],
    bathroom: [],
    kitchen: [],
    floorplan: [],
    masterplan: [],
    locationmap: [],
    other: [],
  });
  const [categorizedPreviews, setCategorizedPreviews] = useState({
    exterior: [],
    living: [],
    bedroom: [],
    bathroom: [],
    kitchen: [],
    floorplan: [],
    masterplan: [],
    locationmap: [],
    other: [],
  });
  const handleCategorizedImageUpload = (e, category) => {
    const files = Array.from(e.target.files);

    // Limit to 10 images per category
    if (categorizedImages[category].length + files.length > 10) {
      alert(`You can upload a maximum of 10 images per category`);
      return;
    }

    // Create preview URLs
    const newPreviewUrls = files.map((file) => URL.createObjectURL(file));

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: [...prev[category], ...files],
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: [...prev[category], ...newPreviewUrls],
    }));
  };

  const removeCategorizedImage = (category, index) => {
    // Revoke the URL to free memory
    URL.revokeObjectURL(categorizedPreviews[category][index]);

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: prev[category].filter((_, i) => i !== index),
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: prev[category].filter((_, i) => i !== index),
    }));
  };

  const setDefaultCategorizedImage = (category, index) => {
    const newImages = [...categorizedImages[category]];
    const newPreviews = [...categorizedPreviews[category]];

    // Move selected image to first position
    const [selectedImage] = newImages.splice(index, 1);
    const [selectedPreview] = newPreviews.splice(index, 1);

    newImages.unshift(selectedImage);
    newPreviews.unshift(selectedPreview);

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: newImages,
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: newPreviews,
    }));
  };

  // Get total image count across all categories
  const getTotalImageCount = () => {
    return Object.values(categorizedImages).reduce(
      (total, imgs) => total + imgs.length,
      0
    );
  };

  // Get image count for a specific category
  const getCategoryImageCount = (category) => {
    return categorizedImages[category]?.length || 0;
  };

  const getCategoryTip = (categoryId) => {
    const tips = {
      exterior:
        "Include front view, entrance, and building facade. Good lighting is essential.",
      living: "Show the layout, furniture arrangement, and natural lighting.",
      bedroom:
        "Capture the bed, storage space, and windows. Show room size clearly.",
      bathroom: "Include toilet, shower/bathtub, and sink. Ensure cleanliness.",
      kitchen:
        "Show appliances, counter space, and storage. Highlight modern features.",
      floorplan:
        "Upload clear floor plan images showing room layouts and dimensions.",
      masterplan: "Include the complete property master plan or site layout.",
      locationmap:
        "Upload maps showing nearby landmarks, metro stations, and important locations.",
      other:
        "Upload any additional photos like balcony, garden, or special features.",
    };
    return tips[categoryId] || "Upload clear, well-lit photos.";
  };

  const countries = Country.getAllCountries();
  const countryOptions = countries.map((c) => ({
    value: c.isoCode,
    label: c.name,
  }));

  const getStateOptions = (countryCode) => {
    const states = State.getStatesOfCountry(countryCode);
    return states.map((s) => ({
      value: s.isoCode,
      label: s.name,
    }));
  };

  const getCityOptions = (countryCode, stateCode) => {
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities.map((c) => ({
      value: c.name,
      label: c.name,
    }));
  };

  const hasStates = (countryCode) => {
    if (!countryCode) return false;
    const states = State.getStatesOfCountry(countryCode);
    return states && states.length > 0;
  };

  const hasCities = (countryCode, stateCode) => {
    if (!countryCode || !stateCode) return false;
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities && cities.length > 0;
  };

  const [formData, setFormData] = useState({
    propertyTitle: "",
    description: "",
    listingType: "sale",
    country: "",
    state: "",
    city: "",
    address: "",
    latitude: 25.2048,
    longitude: 55.2708,
    propertySubtype: "",
    builtupArea: "",
    furnishing: "Furnished",
    bedrooms: "",
    bathrooms: "",
    parkingSpaces: "",
    balcony: false,
    view: "",
    price: "",
    priceType: "Fixed",
    paymentFrequency: "",
    depositAmount: "",
    maintenanceFees: "",
    serviceChargeIncluded: false,
    availableFrom: "",
    propertyStatus: "",
    ownershipType: "",
    developerName: "",
    reraPermitNumber: "",
    featuredListing: false,
    // APARTMENT FIELDS
    apartmentType: "",
    floorNumber: "",
    totalFloors: "",
    builtYear: "",
    centralAC: false,
    maintenanceIncluded: false,
    petsAllowed: false,
    maidsRoom: false,
    studyRoom: false,
    kitchenAppliancesIncluded: false,
    // VILLA FIELDS
    villaType: "",
    plotArea: "",
    noOfFloors: "",
    privateGarden: false,
    privatePool: false,
    driversRoom: false,
    storageRoom: false,
    coveredParking: false,
    // TOWNHOUSE FIELDS
    townhouseType: "",
    gatedCommunity: false,
    communityView: false,
    // STUDIO FIELDS
    kitchenType: "",
    bathroomType: "",
    parking: false,
    // PENTHOUSE FIELDS
    floorLevel: "",
    noOfFloorsInUnit: "",
    privateElevator: false,
    terraceDeck: false,
    // DUPLEX FIELDS
    levels: "",
    balconyTerrace: false,
    // COMPOUND FIELDS
    compoundName: "",
    totalVillasInCompound: "",
    sharedPool: false,
    sharedGym: false,
    security24x7: false,
    gardenArea: false,
    kidsPlayArea: false,
    // PLOT FIELDS
    landUsePermission: "",
    cornerPlot: false,
    roadAccess: false,
    electricityWaterAvailable: false,
    developmentStatus: "",
  });

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerRef = useRef(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  const [availableAmenities] = useState([
    "Swimming Pool",
    "Gym",
    "Security",
    "Kids Play Area",
    "Garden",
    "Lift/Elevator",
    "Club House",
    "Maids Room",
    "Covered Parking",
    "Basement Parking",
    "Central AC",
    "Central Heating",
    "Private Pool",
    "Private Garden",
    "Private Gym",
    "Balcony",
    "Built-in Wardrobes",
    "Walk-in Closet",
    "Built-in Kitchen Appliances",
    "Study Room",
    "Private Jacuzzi",
    "Steam Room",
    "Sauna",
    "Concierge Service",
    "Business Center",
    "Conference Room",
    "BBQ Area",
    "Children's Pool",
    "Shared Pool",
    "Shared Gym",
    "Shared Spa",
    "24/7 Security",
    "CCTV Security",
    "Intercom",
    "Maintenance Staff",
    "Pets Allowed",
    "Nearby Metro",
    "Beach Access",
    "Storage Room",
    "Laundry Room",
    "Parking",
  ]);

  const [chosenAmenities, setChosenAmenities] = useState([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Initialize map
  useEffect(() => {
    if (mapRef.current && !mapInstanceRef.current && window.L) {
      const map = window.L.map(mapRef.current).setView(
        [formData.latitude, formData.longitude],
        13
      );

      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map);

      const marker = window.L.marker([formData.latitude, formData.longitude], {
        draggable: true,
      }).addTo(map);

      marker.on("dragend", function (e) {
        const position = e.target.getLatLng();
        setFormData((prev) => ({
          ...prev,
          latitude: position.lat.toFixed(6),
          longitude: position.lng.toFixed(6),
        }));
        reverseGeocode(position.lat, position.lng);
      });

      map.on("click", function (e) {
        const { lat, lng } = e.latlng;
        marker.setLatLng([lat, lng]);
        setFormData((prev) => ({
          ...prev,
          latitude: lat.toFixed(6),
          longitude: lng.toFixed(6),
        }));
        reverseGeocode(lat, lng);
      });

      mapInstanceRef.current = map;
      markerRef.current = marker;
      setMapLoaded(true);
    }
  }, []);

  // Update map when coordinates change externally
  useEffect(() => {
    if (mapInstanceRef.current && markerRef.current && mapLoaded) {
      mapInstanceRef.current.setView(
        [formData.latitude, formData.longitude],
        13
      );
      markerRef.current.setLatLng([formData.latitude, formData.longitude]);
    }
  }, [formData.country, formData.city]);

  const reverseGeocode = async (lat, lng) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`
      );
      const data = await response.json();
      if (data.display_name) {
        setFormData((prev) => ({
          ...prev,
          address: data.display_name,
        }));
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);
    }
  };

  const searchAddress = async () => {
    if (!formData.address) return;

    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          formData.address
        )}`
      );
      const data = await response.json();
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        setFormData((prev) => ({
          ...prev,
          latitude: parseFloat(lat).toFixed(6),
          longitude: parseFloat(lon).toFixed(6),
        }));
        if (mapInstanceRef.current && markerRef.current) {
          mapInstanceRef.current.setView([lat, lon], 15);
          markerRef.current.setLatLng([lat, lon]);
        }
      } else {
        alert("Address not found. Please try a different search term.");
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      alert("Error searching for address. Please try again.");
    }
  };

  const useCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          setFormData((prev) => ({
            ...prev,
            latitude: lat.toFixed(6),
            longitude: lng.toFixed(6),
          }));
          if (mapInstanceRef.current && markerRef.current) {
            mapInstanceRef.current.setView([lat, lng], 15);
            markerRef.current.setLatLng([lat, lng]);
          }
          reverseGeocode(lat, lng);
        },
        (error) => {
          alert(
            "Unable to retrieve your location. Please enable location services."
          );
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
    }
  };

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleCountryChange = (e) => {
    const value = e.target.value;
    const country = countries.find((c) => c.isoCode === value);
    setFormData((prev) => ({
      ...prev,
      country: value,
      state: "",
      city: "",
      latitude: country ? country.latitude : prev.latitude,
      longitude: country ? country.longitude : prev.longitude,
    }));
  };

  const handleStateChange = (e) => {
    const value = e.target.value;
    const states = State.getStatesOfCountry(formData.country);
    const state = states.find((s) => s.isoCode === value);
    setFormData((prev) => ({
      ...prev,
      state: value,
      city: "",
      latitude: state ? state.latitude : prev.latitude,
      longitude: state ? state.longitude : prev.longitude,
    }));
  };

  const handleCityChange = (e) => {
    const value = e.target.value;
    const cities = City.getCitiesOfState(formData.country, formData.state);
    const city = cities.find((c) => c.name === value);
    setFormData((prev) => ({
      ...prev,
      city: value,
      latitude: city ? city.latitude : prev.latitude,
      longitude: city ? city.longitude : prev.longitude,
    }));
  };

  const moveAmenityToChosen = (amenity) => {
    setChosenAmenities((prev) => [...prev, amenity]);
  };

  const removeAmenityFromChosen = (amenity) => {
    setChosenAmenities((prev) => prev.filter((a) => a !== amenity));
  };

  const handleSubmit = () => {
    // Validate required category (Exterior View)
    if (categorizedImages.exterior.length === 0) {
      alert("Please upload at least one Exterior View image");
      setActiveImageTab("exterior"); // Switch to exterior tab
      return;
    }

    // Check total images
    const totalImages = getTotalImageCount();
    if (totalImages === 0) {
      alert("Please upload at least one image");
      return;
    }

    setIsSubmitting(true);

    const propertyData = {
      ...formData,
      amenities: chosenAmenities,
      images: categorizedImages,
      totalImages: totalImages,
      video: propertyVideo
        ? {
            name: propertyVideo.name,
            size: propertyVideo.size,
            type: propertyVideo.type,
          }
        : null,
      imagesByCategory: Object.entries(categorizedImages).map(
        ([category, images]) => ({
          category,
          count: images.length,
        })
      ),
    };

    console.log("Property data:", propertyData);
    alert(
      `Property submitted with ${totalImages} images${
        propertyVideo ? " and 1 video" : ""
      }!`
    );

    // Cleanup preview URLs
    Object.values(categorizedPreviews).forEach((previews) => {
      previews.forEach((url) => URL.revokeObjectURL(url));
    });

    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }

    // Reset form
    setFormData({
      propertyTitle: "",
      description: "",
      country: "",
      state: "",
      city: "",
      address: "",
      latitude: 25.2048,
      longitude: 55.2708,
      propertySubtype: "",
      builtupArea: "",
      furnishing: "Furnished",
      bedrooms: "",
      bathrooms: "",
      parkingSpaces: "",
      balcony: false,
      view: "",
      price: "",
      priceType: "Fixed",
      paymentFrequency: "",
      depositAmount: "",
      maintenanceFees: "",
      serviceChargeIncluded: false,
      availableFrom: "",
      propertyStatus: "",
      ownershipType: "",
      developerName: "",
      reraPermitNumber: "",
      featuredListing: false,
      apartmentType: "",
      floorNumber: "",
      totalFloors: "",
      builtYear: "",
      centralAC: false,
      maintenanceIncluded: false,
      petsAllowed: false,
      maidsRoom: false,
      studyRoom: false,
      kitchenAppliancesIncluded: false,
      villaType: "",
      plotArea: "",
      noOfFloors: "",
      privateGarden: false,
      privatePool: false,
      driversRoom: false,
      storageRoom: false,
      coveredParking: false,
      townhouseType: "",
      gatedCommunity: false,
      communityView: false,
      kitchenType: "",
      bathroomType: "",
      parking: false,
      floorLevel: "",
      noOfFloorsInUnit: "",
      privateElevator: false,
      terraceDeck: false,
      levels: "",
      balconyTerrace: false,
      compoundName: "",
      totalVillasInCompound: "",
      sharedPool: false,
      sharedGym: false,
      security24x7: false,
      gardenArea: false,
      kidsPlayArea: false,
      landUsePermission: "",
      cornerPlot: false,
      roadAccess: false,
      electricityWaterAvailable: false,
      developmentStatus: "",
    });
    setCategorizedImages({
      exterior: [],
      living: [],
      bedroom: [],
      bathroom: [],
      kitchen: [],
      floorplan: [],
      masterplan: [],
      locationmap: [],
      other: [],
    });
    setCategorizedPreviews({
      exterior: [],
      living: [],
      bedroom: [],
      bathroom: [],
      kitchen: [],
      floorplan: [],
      masterplan: [],
      locationmap: [],
      other: [],
    });
    setActiveImageTab("exterior");
    setChosenAmenities([]);
    setPropertyVideo(null);
    setVideoPreview(null);
    setIsSubmitting(false);
  };

  useEffect(() => {
    // Cleanup function to revoke all preview URLs when component unmounts
    return () => {
      // Cleanup image previews
      Object.values(categorizedPreviews).forEach((previews) => {
        previews.forEach((url) => URL.revokeObjectURL(url));
      });

      // Cleanup video preview
      if (videoPreview) {
        URL.revokeObjectURL(videoPreview);
      }
    };
  }, [categorizedPreviews, videoPreview]);

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const stateOptions = formData.country
    ? getStateOptions(formData.country)
    : [];
  const cityOptions =
    formData.country && formData.state
      ? getCityOptions(formData.country, formData.state)
      : [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Leaflet CSS */}
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css"
      />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>

      <Header />

      <div className="max-w-6xl mx-auto my-10 p-4">
        <div className="flex gap-4 items-start">
          {/* Sidebar */}
          <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded shadow-sm sticky top-8 max-h-[calc(100vh-120px)] overflow-y-auto scrollbar-hide">
            <div className="p-4">
              <nav className="space-y-0.5">
                {/* My Listings */}
                <div>
                  <button
                    onClick={() => toggleMenu("mylistings")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>My Listings</span>
                    </div>
                    {openMenu === "mylistings" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "mylistings" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/mylistings/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/mylistings/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/mylistings/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/mylistings/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/mylistings/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/mylistings/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* List Property */}
                <div>
                  <button
                    onClick={() => toggleMenu("listproperty")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <Home className="w-4 h-4" />
                      <span>List Property</span>
                    </div>
                    {openMenu === "listproperty" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "listproperty" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/listproperty/commercial"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Commercial
                      </Link>
                      <Link
                        to="/listproperty/residential"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Residential
                      </Link>
                      <Link
                        to="/listproperty/pg"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        PG
                      </Link>
                      <Link
                        to="/listproperty/agriculture"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Agricultural/Farms
                      </Link>
                      <Link
                        to="/listproperty/holidayrent"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Holiday Rent
                      </Link>
                      <Link
                        to="/listproperty/businessforsale"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Business For Sale
                      </Link>
                    </div>
                  )}
                </div>

                {/* Profile */}
                <Link
                  to="/profile"
                  className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <User className="w-4 h-4" />
                  <span>Profile</span>
                </Link>

                {/* Enquiry */}
                <div>
                  <button
                    onClick={() => toggleMenu("enquiry")}
                    className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                  >
                    <div className="flex items-center gap-3">
                      <HelpCircle className="w-4 h-4" />
                      <span>Enquiry/Ticket</span>
                    </div>
                    {openMenu === "enquiry" ? (
                      <ChevronDown className="w-4 h-4" />
                    ) : (
                      <ChevronRight className="w-4 h-4" />
                    )}
                  </button>

                  {openMenu === "enquiry" && (
                    <div className="ml-8 mt-1 space-y-1">
                      <Link
                        to="/enquiry/addenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        Add Enquiry
                      </Link>
                      <Link
                        to="/enquiry/newenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        New Enquiry
                      </Link>
                      <Link
                        to="/enquiry/allenquiry"
                        className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                      >
                        All Enquiry
                      </Link>
                    </div>
                  )}
                </div>
              </nav>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 bg-white rounded shadow-sm">
            <div className="max-w-4xl mx-auto p-6">
              <h1 className="text-2xl font-semibold mb-6">
                Residential Property Listing
              </h1>

              <div>
                {/* Step 1: Basic Information */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 1: Basic Information</h2>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Property Title <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="propertyTitle"
                      placeholder="e.g., 2BHK Apartment in Downtown Dubai"
                      value={formData.propertyTitle}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Description <span className="text-red-500">*</span>
                    </label>
                    <textarea
                      name="description"
                      placeholder="Full property overview"
                      value={formData.description}
                      onChange={handleInputChange}
                      rows="4"
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Listing Type <span className="text-red-500">*</span>
                    </label>
                    <div className="flex gap-6">
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="listingType"
                          value="sale"
                          checked={formData.listingType === "sale"}
                          onChange={handleInputChange}
                          className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <span className="text-sm font-medium">For Sale</span>
                      </label>
                      <label className="flex items-center gap-2 cursor-pointer">
                        <input
                          type="radio"
                          name="listingType"
                          value="rent"
                          checked={formData.listingType === "rent"}
                          onChange={handleInputChange}
                          className="w-4 h-4 text-blue-600 border-gray-300 focus:ring-blue-500"
                        />
                        <span className="text-sm font-medium">For Rent</span>
                      </label>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Property Subtype <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="propertySubtype"
                        value={formData.propertySubtype}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select Property Subtype</option>
                        <option value="apartment">Apartment</option>
                        <option value="villa">Villa</option>
                        <option value="townhouse">Townhouse</option>
                        <option value="studio">Studio</option>
                        <option value="penthouse">Penthouse</option>
                        <option value="duplex">Duplex</option>
                        <option value="compound">Compound</option>
                        <option value="plot">Plot</option>
                      </select>
                    </div>
                  </div>
                </div>

                {/* Conditional Property Subtype Fields */}
                {formData.propertySubtype && (
                  <div className="mb-6">
                    <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                      <h2 className="font-medium">
                        {formData.propertySubtype.charAt(0).toUpperCase() +
                          formData.propertySubtype.slice(1)}{" "}
                        Specific Details
                      </h2>
                    </div>

                    {/* APARTMENT FIELDS */}
                    {formData.propertySubtype === "apartment" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Apartment Type
                            </label>
                            <select
                              name="apartmentType"
                              value={formData.apartmentType}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select Type</option>
                              <option value="Standard">Standard</option>
                              <option value="Serviced">Serviced</option>
                              <option value="Hotel Apartment">
                                Hotel Apartment
                              </option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Floor Number
                            </label>
                            <input
                              type="number"
                              name="floorNumber"
                              value={formData.floorNumber}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Total Floors
                            </label>
                            <input
                              type="number"
                              name="totalFloors"
                              value={formData.totalFloors}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Built Year
                            </label>
                            <input
                              type="number"
                              name="builtYear"
                              value={formData.builtYear}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="1900"
                              max={new Date().getFullYear()}
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="centralAC"
                              checked={formData.centralAC}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Central AC
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maintenanceIncluded"
                              checked={formData.maintenanceIncluded}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maintenance Included
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="petsAllowed"
                              checked={formData.petsAllowed}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Pets Allowed
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maidsRoom"
                              checked={formData.maidsRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maids Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="studyRoom"
                              checked={formData.studyRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Study Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="kitchenAppliancesIncluded"
                              checked={formData.kitchenAppliancesIncluded}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Kitchen Appliances
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* VILLA FIELDS */}
                    {formData.propertySubtype === "villa" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Villa Type
                            </label>
                            <select
                              name="villaType"
                              value={formData.villaType}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select Type</option>
                              <option value="Independent">Independent</option>
                              <option value="Semi-detached">
                                Semi-detached
                              </option>
                              <option value="Compound">Compound</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Plot Area (sqft)
                            </label>
                            <input
                              type="number"
                              name="plotArea"
                              value={formData.plotArea}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">
                            No. of Floors
                          </label>
                          <input
                            type="number"
                            name="noOfFloors"
                            value={formData.noOfFloors}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            min="0"
                          />
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="privateGarden"
                              checked={formData.privateGarden}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Private Garden
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="privatePool"
                              checked={formData.privatePool}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Private Pool
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maidsRoom"
                              checked={formData.maidsRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maid's Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="driversRoom"
                              checked={formData.driversRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Driver's Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="storageRoom"
                              checked={formData.storageRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Storage Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="petsAllowed"
                              checked={formData.petsAllowed}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Pets Allowed
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="coveredParking"
                              checked={formData.coveredParking}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Covered Parking
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* TOWNHOUSE FIELDS */}
                    {formData.propertySubtype === "townhouse" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Townhouse Type
                            </label>
                            <select
                              name="townhouseType"
                              value={formData.townhouseType}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select Type</option>
                              <option value="Middle Unit">Middle Unit</option>
                              <option value="End Unit">End Unit</option>
                              <option value="Corner Unit">Corner Unit</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Plot Area (sqft)
                            </label>
                            <input
                              type="number"
                              name="plotArea"
                              value={formData.plotArea}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="privateGarden"
                              checked={formData.privateGarden}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Private Garden
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maidsRoom"
                              checked={formData.maidsRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maid's Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="storageRoom"
                              checked={formData.storageRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Storage Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="communityView"
                              checked={formData.communityView}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Community View
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="gatedCommunity"
                              checked={formData.gatedCommunity}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Gated Community
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* STUDIO FIELDS */}
                    {formData.propertySubtype === "studio" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Kitchen Type
                            </label>
                            <select
                              name="kitchenType"
                              value={formData.kitchenType}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select Type</option>
                              <option value="Open">Open</option>
                              <option value="Closed">Closed</option>
                            </select>
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Bathroom Type
                            </label>
                            <select
                              name="bathroomType"
                              value={formData.bathroomType}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select Type</option>
                              <option value="Full">Full</option>
                              <option value="Half">Half</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="parking"
                              checked={formData.parking}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">Parking</span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maintenanceIncluded"
                              checked={formData.maintenanceIncluded}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maintenance Included
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="petsAllowed"
                              checked={formData.petsAllowed}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Pets Allowed
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* PENTHOUSE FIELDS */}
                    {formData.propertySubtype === "penthouse" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Floor Level
                            </label>
                            <input
                              type="number"
                              name="floorLevel"
                              value={formData.floorLevel}
                              onChange={handleInputChange}
                              placeholder="Top floor number"
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              No. of Floors (within Unit)
                            </label>
                            <input
                              type="number"
                              name="noOfFloorsInUnit"
                              value={formData.noOfFloorsInUnit}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              View
                            </label>
                            <select
                              name="view"
                              value={formData.view}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select View</option>
                              <option value="Sea">Sea</option>
                              <option value="City">City</option>
                              <option value="Skyline">Skyline</option>
                              <option value="Marina">Marina</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="privatePool"
                              checked={formData.privatePool}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Private Pool
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="privateElevator"
                              checked={formData.privateElevator}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Private Elevator
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maidsRoom"
                              checked={formData.maidsRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maid's Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="storageRoom"
                              checked={formData.storageRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Storage Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="terraceDeck"
                              checked={formData.terraceDeck}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Terrace / Deck
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* DUPLEX FIELDS */}
                    {formData.propertySubtype === "duplex" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Levels
                            </label>
                            <input
                              type="number"
                              name="levels"
                              value={formData.levels}
                              onChange={handleInputChange}
                              placeholder="Usually 2"
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="2"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Parking Spaces
                            </label>
                            <input
                              type="number"
                              name="parkingSpaces"
                              value={formData.parkingSpaces}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              View
                            </label>
                            <select
                              name="view"
                              value={formData.view}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            >
                              <option value="">Select View</option>
                              <option value="City">City</option>
                              <option value="Garden">Garden</option>
                              <option value="Pool">Pool</option>
                            </select>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="balconyTerrace"
                              checked={formData.balconyTerrace}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Balcony / Terrace
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maidsRoom"
                              checked={formData.maidsRoom}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maid's Room
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="petsAllowed"
                              checked={formData.petsAllowed}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Pets Allowed
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* COMPOUND FIELDS */}
                    {formData.propertySubtype === "compound" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Compound Name
                            </label>
                            <input
                              type="text"
                              name="compoundName"
                              value={formData.compoundName}
                              onChange={handleInputChange}
                              placeholder="Name of the compound"
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Total Villas in Compound
                            </label>
                            <input
                              type="number"
                              name="totalVillasInCompound"
                              value={formData.totalVillasInCompound}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="sharedPool"
                              checked={formData.sharedPool}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Shared Pool
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="sharedGym"
                              checked={formData.sharedGym}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Shared Gym
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="security24x7"
                              checked={formData.security24x7}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              24/7 Security
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="gardenArea"
                              checked={formData.gardenArea}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Garden Area
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="kidsPlayArea"
                              checked={formData.kidsPlayArea}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Kids Play Area
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="maintenanceIncluded"
                              checked={formData.maintenanceIncluded}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Maintenance Included
                            </span>
                          </label>
                        </div>
                      </div>
                    )}

                    {/* PLOT FIELDS */}
                    {formData.propertySubtype === "plot" && (
                      <div className="space-y-4">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Plot Area (sqft){" "}
                              <span className="text-red-500">*</span>
                            </label>
                            <input
                              type="number"
                              name="plotArea"
                              value={formData.plotArea}
                              onChange={handleInputChange}
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                              min="0"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-2">
                              Land Use Permission
                            </label>
                            <input
                              type="text"
                              name="landUsePermission"
                              value={formData.landUsePermission}
                              onChange={handleInputChange}
                              placeholder="e.g., Residential / Mixed Use"
                              className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-2">
                            Development Status
                          </label>
                          <select
                            name="developmentStatus"
                            value={formData.developmentStatus}
                            onChange={handleInputChange}
                            className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                          >
                            <option value="">Select Status</option>
                            <option value="Ready">Ready</option>
                            <option value="Approved Plans">
                              Approved Plans
                            </option>
                            <option value="Under Construction">
                              Under Construction
                            </option>
                          </select>
                        </div>

                        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="gatedCommunity"
                              checked={formData.gatedCommunity}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Gated Community
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="cornerPlot"
                              checked={formData.cornerPlot}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Corner Plot
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="roadAccess"
                              checked={formData.roadAccess}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Road Access
                            </span>
                          </label>
                          <label className="flex items-center gap-2">
                            <input
                              type="checkbox"
                              name="electricityWaterAvailable"
                              checked={formData.electricityWaterAvailable}
                              onChange={handleInputChange}
                              className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                            />
                            <span className="text-sm font-medium">
                              Electricity / Water Available
                            </span>
                          </label>
                        </div>
                      </div>
                    )}
                  </div>
                )}

                {/* Step 2: Location */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 2: Location</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Country <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="country"
                        value={formData.country}
                        onChange={handleCountryChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select Country</option>
                        {countryOptions.map((country) => (
                          <option key={country.value} value={country.value}>
                            {country.label}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        State / Region <span className="text-red-500">*</span>
                      </label>
                      {hasStates(formData.country) ? (
                        <select
                          name="state"
                          value={formData.state}
                          onChange={handleStateChange}
                          disabled={!formData.country}
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select State</option>
                          {stateOptions.map((state) => (
                            <option key={state.value} value={state.value}>
                              {state.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          name="state"
                          value={formData.state}
                          onChange={handleInputChange}
                          disabled={!formData.country}
                          placeholder="Enter State/Province/Region"
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        City <span className="text-red-500">*</span>
                      </label>
                      {hasCities(formData.country, formData.state) ? (
                        <select
                          name="city"
                          value={formData.city}
                          onChange={handleCityChange}
                          disabled={!formData.country || !formData.state}
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                        >
                          <option value="">Select City</option>
                          {cityOptions.map((city) => (
                            <option key={city.value} value={city.value}>
                              {city.label}
                            </option>
                          ))}
                        </select>
                      ) : (
                        <input
                          type="text"
                          name="city"
                          value={formData.city}
                          onChange={handleInputChange}
                          disabled={!formData.country || !formData.state}
                          placeholder="Enter City"
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                        />
                      )}
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Address / Map Location
                    </label>
                    <div className="flex gap-2">
                      <input
                        type="text"
                        name="address"
                        placeholder="Enter full address"
                        value={formData.address}
                        onChange={handleInputChange}
                        className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                      <button
                        type="button"
                        onClick={searchAddress}
                        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center gap-2"
                      >
                        <MapPin size={16} />
                        <span className="hidden md:block">Search</span>
                      </button>
                      <button
                        type="button"
                        onClick={useCurrentLocation}
                        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
                        title="Use my current location"
                      >
                        <Navigation size={16} />
                      </button>
                    </div>
                  </div>

                  {/* Map Container */}
                  <div className="mb-4">
                    <div
                      ref={mapRef}
                      className="w-full h-96 rounded border border-gray-300"
                    ></div>
                    <div className="mt-2 text-sm text-gray-600 flex gap-4">
                      <span>
                        <strong>Latitude:</strong> {formData.latitude}
                      </span>
                      <span>
                        <strong>Longitude:</strong> {formData.longitude}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 mt-1">
                      Click on the map or drag the marker to select precise
                      location
                    </p>
                  </div>
                </div>

                {/* Step 3: Property Details */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 3: Property Details</h2>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Built-up Area (sqft){" "}
                      <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      name="builtupArea"
                      placeholder="e.g., 1200"
                      value={formData.builtupArea}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      min="0"
                    />
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Bedrooms <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="bedrooms"
                        value={formData.bedrooms}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select</option>
                        <option value="studio">Studio</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5+">5+</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Bathrooms <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="bathrooms"
                        value={formData.bathrooms}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select</option>
                        <option value="1">1</option>
                        <option value="2">2</option>
                        <option value="3">3</option>
                        <option value="4">4</option>
                        <option value="5+">5+</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Parking Spaces
                      </label>
                      <input
                        type="number"
                        name="parkingSpaces"
                        value={formData.parkingSpaces}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        min="0"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Furnishing <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="furnishing"
                        value={formData.furnishing}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Furnished">Furnished</option>
                        <option value="Semi-Furnished">Semi-Furnished</option>
                        <option value="Unfurnished">Unfurnished</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        View
                      </label>
                      <select
                        name="view"
                        value={formData.view}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select View</option>
                        <option value="city">City View</option>
                        <option value="sea">Sea View</option>
                        <option value="garden">Garden View</option>
                        <option value="hill">Hill View</option>
                        <option value="valley">Valley View</option>
                        <option value="community">Community View</option>
                      </select>
                    </div>
                  </div>

                  {!["townhouse", "duplex"].includes(
                    formData.propertySubtype
                  ) && (
                    <div className="mb-4">
                      <label className="flex items-center gap-2">
                        <input
                          type="checkbox"
                          name="balcony"
                          checked={formData.balcony}
                          onChange={handleInputChange}
                          className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                        />
                        <span className="text-sm font-medium">Has Balcony</span>
                      </label>
                    </div>
                  )}
                </div>

                {/* Step 4: Amenities */}
                <div className="mb-8">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 4: Amenities</h2>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Available Amenities
                      </label>
                      <div className="border border-gray-300 rounded p-2 h-48 overflow-y-auto bg-white">
                        {availableAmenities
                          .filter((a) => !chosenAmenities.includes(a))
                          .map((amenity) => (
                            <div
                              key={amenity}
                              onClick={() => moveAmenityToChosen(amenity)}
                              className="px-2 py-1 text-sm hover:bg-blue-50 cursor-pointer rounded"
                            >
                              {amenity}
                            </div>
                          ))}
                      </div>
                    </div>

                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Chosen Amenities
                      </label>
                      <div className="border border-gray-300 rounded p-2 h-48 overflow-y-auto bg-white">
                        {chosenAmenities.map((amenity) => (
                          <div
                            key={amenity}
                            onClick={() => removeAmenityFromChosen(amenity)}
                            className="px-2 py-1 text-sm hover:bg-red-50 cursor-pointer rounded flex justify-between items-center"
                          >
                            <span>{amenity}</span>
                            <X size={14} className="text-red-500" />
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Step 5: Pricing */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 5: Pricing</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Price <span className="text-red-500">*</span>
                      </label>
                      <input
                        type="number"
                        name="price"
                        placeholder="e.g., 850000"
                        value={formData.price}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        min="0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Price Type <span className="text-red-500">*</span>
                      </label>
                      <select
                        name="priceType"
                        value={formData.priceType}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="Fixed">Fixed</option>
                        <option value="Negotiable">Negotiable</option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Payment Frequency
                      </label>
                      <select
                        name="paymentFrequency"
                        value={formData.paymentFrequency}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select (if Rent)</option>
                        <option value="Monthly">Monthly</option>
                        <option value="Quarterly">Quarterly</option>
                        <option value="Yearly">Yearly</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Deposit Amount
                      </label>
                      <input
                        type="number"
                        name="depositAmount"
                        placeholder="e.g., 5000"
                        value={formData.depositAmount}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        min="0"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Maintenance Fees
                      </label>
                      <input
                        type="number"
                        name="maintenanceFees"
                        placeholder="e.g., 1200"
                        value={formData.maintenanceFees}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        min="0"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        name="serviceChargeIncluded"
                        checked={formData.serviceChargeIncluded}
                        onChange={handleInputChange}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium">
                        Service Charge Included
                      </span>
                    </label>
                  </div>
                </div>

                {/* Step :6 Additional Details */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 6: Additional Details</h2>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Available From
                      </label>
                      <input
                        type="date"
                        name="availableFrom"
                        value={formData.availableFrom}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Property Status
                      </label>
                      <select
                        name="propertyStatus"
                        value={formData.propertyStatus}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select Status</option>
                        <option value="Ready">Ready</option>
                        <option value="Off-plan">Off-plan</option>
                        <option value="Under Construction">
                          Under Construction
                        </option>
                      </select>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Ownership Type
                      </label>
                      <select
                        name="ownershipType"
                        value={formData.ownershipType}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="">Select Ownership</option>
                        <option value="Freehold">Freehold</option>
                        <option value="Leasehold">Leasehold</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Developer / Project Name
                      </label>
                      <input
                        type="text"
                        name="developerName"
                        placeholder="e.g., Emaar Properties"
                        value={formData.developerName}
                        onChange={handleInputChange}
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      RERA Permit Number <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="reraPermitNumber"
                      placeholder="e.g., 1234567890"
                      value={formData.reraPermitNumber}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>

                  <div className="mb-4">
                    <label className="flex items-center gap-2">
                      <input
                        type="checkbox"
                        name="featuredListing"
                        checked={formData.featuredListing}
                        onChange={handleInputChange}
                        className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                      />
                      <span className="text-sm font-medium">
                        Featured Listing
                      </span>
                    </label>
                  </div>
                </div>

                {/* Images */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">Step 7: Property Images</h2>
                  </div>

                  <div className="mb-4">
                    <p className="text-sm text-gray-600 mb-3">
                      Upload images for different areas of your property.
                      Exterior View is required.
                    </p>

                    {/* Tabs */}
                    <div className="border-b border-gray-300 mb-4">
                      <div className="flex overflow-x-auto">
                        {imageCategories.map((category) => (
                          <button
                            key={category.id}
                            type="button"
                            onClick={() => setActiveImageTab(category.id)}
                            className={`px-4 py-2 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                              activeImageTab === category.id
                                ? "border-blue-600 text-blue-600"
                                : "border-transparent text-gray-600 hover:text-gray-800"
                            }`}
                          >
                            {category.label}
                            {category.required && (
                              <span className="text-red-500 ml-1">*</span>
                            )}
                            {getCategoryImageCount(category.id) > 0 && (
                              <span className="ml-2 bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-xs">
                                {getCategoryImageCount(category.id)}
                              </span>
                            )}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Tab Content */}
                    <div className="min-h-[300px]">
                      {imageCategories.map((category) => (
                        <div
                          key={category.id}
                          className={
                            activeImageTab === category.id ? "block" : "hidden"
                          }
                        >
                          <div className="mb-3">
                            <label className="block text-sm font-medium mb-2">
                              {category.label} Images (Max 10)
                              {category.required && (
                                <span className="text-red-500 ml-1">*</span>
                              )}
                            </label>
                            <p className="text-xs text-gray-500">
                              {categorizedPreviews[category.id].length === 0
                                ? "No images uploaded yet. "
                                : "First image will be the default. "}
                              Click "Set as Default" to change the main image.
                            </p>
                          </div>

                          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                            {/* Uploaded Images */}
                            {categorizedPreviews[category.id].map(
                              (url, index) => (
                                <div key={index} className="relative group">
                                  <div className="aspect-square border-2 border-gray-300 rounded-lg overflow-hidden bg-gray-50">
                                    <img
                                      src={url}
                                      alt={`${category.label} ${index + 1}`}
                                      className="w-full h-full object-cover"
                                    />
                                  </div>

                                  {/* Default Badge */}
                                  {index === 0 && (
                                    <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded shadow-md">
                                      Default
                                    </div>
                                  )}

                                  {/* Image Number */}
                                  <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                                    {index + 1}/
                                    {categorizedPreviews[category.id].length}
                                  </div>

                                  {/* Overlay with actions */}
                                  <div className="absolute inset-0 bg-[#000000b6] bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                                    {index !== 0 && (
                                      <button
                                        type="button"
                                        onClick={() =>
                                          setDefaultCategorizedImage(
                                            category.id,
                                            index
                                          )
                                        }
                                        className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded hover:bg-blue-700 transition-colors"
                                      >
                                        Set Default
                                      </button>
                                    )}
                                    <button
                                      type="button"
                                      onClick={() =>
                                        removeCategorizedImage(
                                          category.id,
                                          index
                                        )
                                      }
                                      className="bg-red-600 text-white p-1.5 rounded hover:bg-red-700 transition-colors"
                                      title="Remove image"
                                    >
                                      <X size={16} />
                                    </button>
                                  </div>
                                </div>
                              )
                            )}

                            {/* Add More Photos Button */}
                            {categorizedImages[category.id].length < 10 && (
                              <label className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                                <div className="text-center p-4">
                                  <div className="w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                                    <svg
                                      className="w-8 h-8 text-gray-400"
                                      fill="none"
                                      stroke="currentColor"
                                      viewBox="0 0 24 24"
                                    >
                                      <path
                                        strokeLinecap="round"
                                        strokeLinejoin="round"
                                        strokeWidth={2}
                                        d="M12 4v16m8-8H4"
                                      />
                                    </svg>
                                  </div>
                                  <span className="text-sm text-gray-600 font-medium">
                                    Add more photos
                                  </span>
                                  <span className="text-xs text-gray-500 block mt-1">
                                    {10 - categorizedImages[category.id].length}{" "}
                                    remaining
                                  </span>
                                </div>
                                <input
                                  type="file"
                                  accept="image/*"
                                  multiple
                                  onChange={(e) =>
                                    handleCategorizedImageUpload(e, category.id)
                                  }
                                  className="hidden"
                                />
                              </label>
                            )}
                          </div>

                          {/* Category specific tips */}
                          <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                            <p className="text-xs text-blue-800">
                              <strong>Tip:</strong>{" "}
                              {getCategoryTip(category.id)}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Summary */}
                    <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between">
                        <span className="text-sm font-medium text-gray-700">
                          Total Images Uploaded:
                        </span>
                        <span className="text-sm font-semibold text-blue-600">
                          {getTotalImageCount()} images
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Video */}
                <div className="mb-6">
                  <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                    <h2 className="font-medium">
                      Step 8: Property Video (Optional)
                    </h2>
                  </div>

                  <div className="mb-4">
                    <label className="block text-sm font-medium mb-2">
                      Upload Property Video
                    </label>
                    <p className="text-xs text-gray-500 mb-3">
                      Upload a video tour of your property (Max size: 100MB,
                      Formats: MP4, MOV, AVI)
                    </p>

                    {!propertyVideo ? (
                      <label className="w-full border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                        <div className="text-center">
                          <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-gray-100 rounded-full">
                            <svg
                              className="w-8 h-8 text-gray-400"
                              fill="none"
                              stroke="currentColor"
                              viewBox="0 0 24 24"
                            >
                              <path
                                strokeLinecap="round"
                                strokeLinejoin="round"
                                strokeWidth={2}
                                d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                              />
                            </svg>
                          </div>
                          <span className="text-base text-gray-700 font-medium block mb-1">
                            Click to upload video
                          </span>
                          <span className="text-sm text-gray-500">
                            or drag and drop
                          </span>
                          <span className="text-xs text-gray-400 block mt-2">
                            MP4, MOV or AVI (MAX. 100MB)
                          </span>
                        </div>
                        <input
                          type="file"
                          accept="video/mp4,video/quicktime,video/x-msvideo"
                          onChange={handleVideoUpload}
                          className="hidden"
                        />
                      </label>
                    ) : (
                      <div className="border-2 border-gray-300 rounded-lg overflow-hidden">
                        {/* Video Preview */}
                        <div className="relative bg-black">
                          <video
                            src={videoPreview}
                            controls
                            className="w-full max-h-96 object-contain"
                          >
                            Your browser does not support the video tag.
                          </video>
                        </div>

                        {/* Video Info */}
                        <div className="p-4 bg-gray-50">
                          <div className="flex items-center justify-between">
                            <div className="flex-1">
                              <p className="text-sm font-medium text-gray-700 mb-1">
                                {propertyVideo.name}
                              </p>
                              <p className="text-xs text-gray-500">
                                Size:{" "}
                                {(propertyVideo.size / (1024 * 1024)).toFixed(
                                  2
                                )}{" "}
                                MB
                              </p>
                            </div>
                            <button
                              type="button"
                              onClick={removeVideo}
                              className="ml-4 bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors flex items-center gap-2"
                            >
                              <X size={16} />
                              Remove
                            </button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Video Tips */}
                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-xs text-blue-800">
                        <strong>Tips for a great video:</strong>
                      </p>
                      <ul className="text-xs text-blue-700 mt-2 ml-4 list-disc space-y-1">
                        <li>
                          Keep it short and engaging (1-3 minutes recommended)
                        </li>
                        <li>Show all rooms and important features</li>
                        <li>Use good lighting and stable camera movement</li>
                        <li>
                          Start with the exterior and move through each room
                        </li>
                        <li>Highlight unique selling points and amenities</li>
                      </ul>
                    </div>
                  </div>
                </div>

                {/* Submit Button */}
                <div className="flex justify-end">
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={isSubmitting}
                    className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                  >
                    {isSubmitting ? "Submitting..." : "Submit Property"}
                  </button>
                </div>
              </div>
            </div>
          </div>

          <style jsx>{`
            .scrollbar-hide {
              -ms-overflow-style: none;
              scrollbar-width: none;
            }
            .scrollbar-hide::-webkit-scrollbar {
              display: none;
            }
          `}</style>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default PropertyListingForm;
