import React, { useEffect, useState } from "react";
import {
  ChevronLeft,
  ChevronDown,
  Phone,
  MapPin,
  ArrowRight,
} from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import calc from "./assets/calc.png";
import img1 from "./assets/details/img1.png";
import img2 from "./assets/details/img2.png";
import img3 from "./assets/details/img3.png";
import Navbar from "./Components/Navbar";
import details from "./assets/details/details.png";
import map from "./assets/details/map.png";
import { useParams } from "react-router-dom";
import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import GalleryModal from "./Components/GalleryModal";

export default function Details() {
  const navigate = useNavigate();
  const { category, id } = useParams();
  console.log(id, category);
  const [activeTab, setActiveTab] = useState("Gallery");
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [propertyData, setPropertyData] = useState(null);
  const [coordinates, setCoordinates] = useState(null);
  const [amenityNames, setAmenityNames] = useState(null);
  const [companyData, setCompanyData] = useState(null);
  const [companyProperties, setCompanyProperties] = useState([]);
  const [propertyType, setPropertyType] = useState(null);
  const [isGalleryOpen, setIsGalleryOpen] = useState(false);

  useEffect(() => {
    fetch(`http://127.0.0.1:8000/api/property/detail/${category}/${id}/`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch property details");
        return res.json();
      })
      .then((data) => {
        console.log("Property Details Response:", data);

        // Set main property data
        setPropertyData(data);

        // Extract amenity names from amenities_details
        if (data.amenities_details && data.amenities_details.length > 0) {
          const names = data.amenities_details.map((amenity) => amenity.name);
          setAmenityNames(names);
        }

        // Set property type if available
        if (data.property_type) {
          setPropertyType(data.property_type);
        }

        // Set company data if available
        if (data.company_details) {
          setCompanyData(data.company_details);
        }

        // Set coordinates if available
        if (data.latitude && data.longitude) {
          setCoordinates([
            parseFloat(data.latitude),
            parseFloat(data.longitude),
          ]);
        }
      })
      .catch((err) => {
        console.error("Error fetching property details:", err);
      });
  }, [category, id]);

  const recommendedProperties = [
    {
      id: 1,
      name: "Luxury Waterfront Villa",
      city: "Dubai Marina",
      address: "Dubai Marina, Dubai",
      bedrooms: 4,
      bathrooms: 5,
      carpet_area: 3500,
      expected_price: "8.5M",
      status: "New Launch",
      image1:
        "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=600&auto=format&fit=crop&q=60",
    },
    {
      id: 2,
      name: "Modern Downtown Apartment",
      city: "Downtown Dubai",
      address: "Burj Khalifa District, Downtown Dubai",
      bedrooms: 2,
      bathrooms: 3,
      carpet_area: 1450,
      expected_price: "2.8M",
      status: "Ready to Move",
      image1:
        "https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=600&auto=format&fit=crop&q=60",
    },
    {
      id: 3,
      name: "Beachfront Penthouse",
      city: "Palm Jumeirah",
      address: "Palm Jumeirah, Dubai",
      bedrooms: 5,
      bathrooms: 6,
      carpet_area: 5200,
      expected_price: "15M",
      status: "Luxury",
      image1:
        "https://images.unsplash.com/photo-1600596542815-ffad4c1539a9?w=600&auto=format&fit=crop&q=60",
    },
    {
      id: 4,
      name: "Contemporary Family Home",
      city: "Arabian Ranches",
      address: "Arabian Ranches 2, Dubai",
      bedrooms: 3,
      bathrooms: 4,
      carpet_area: 2800,
      expected_price: "4.2M",
      status: "Off Plan",
      image1:
        "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=600&auto=format&fit=crop&q=60",
    },
    {
      id: 5,
      name: "Spacious Garden Villa",
      city: "Dubai Hills Estate",
      address: "Dubai Hills Estate, Dubai",
      bedrooms: 4,
      bathrooms: 5,
      carpet_area: 4100,
      expected_price: "6.8M",
      status: "Premium",
      image1:
        "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?w=600&auto=format&fit=crop&q=60",
    },
    {
      id: 6,
      name: "Elegant Studio Apartment",
      city: "Business Bay",
      address: "Business Bay, Dubai",
      bedrooms: 1,
      bathrooms: 1,
      carpet_area: 650,
      expected_price: "950K",
      status: "Investment",
      image1:
        "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=600&auto=format&fit=crop&q=60",
    },
  ];

  const navigationTabs = [
    "Gallery",
    "Developer",
    "Key information",
    // "Payment Plan",
    "About The project",
    "Masterplan",
  ];

  const keyInfo = [
    {
      label: "Bedrooms",
      value: "5 Beds",
    },
    {
      label: "Bathrooms",
      value: "3 Baths",
    },
    {
      label: "Location",
      value: "Dubai, Palm Jebel Ali, Palm Jebel Ali - Frond C",
    },
    {
      label: "Carpet Area",
      value: "1024 sqft",
    },
    {
      label: "Facing",
      value: "East",
    },
    {
      label: "Property types",
      value: "Apartment, Villa",
    },
    {
      label: "Furnishing",
      value: "Semi-Furnished",
    },
    {
      label: "Covered Parking",
      value: "4",
    },
    {
      label: "Open Parking",
      value: "5",
    },
    {
      label: "Ownership Type",
      value: "Freehold",
    },
    {
      label: "Width of road facing property",
      value: "40 feet",
    },
  ];

  const stages = [
    {
      percentage: "10%",
      title: "Down Payment",
    },
    {
      percentage: "40%",
      title: "During construction",
    },
    {
      percentage: "50%",
      title: "On handover",
    },
  ];

  const timelineItems = [
    {
      id: 1,
      title: "Project announcement",
      date: null,
      completed: true,
    },
    {
      id: 2,
      title: "Booking started",
      date: "January 14, 2023",
      completed: true,
    },
    {
      id: 3,
      title: "Construction Started",
      date: "January 15, 2025",
      completed: true,
      progress: "Construction progress: 23.5%",
      lastUpdate: "Latest update: May 28, 2025",
    },
    {
      id: 4,
      title: "Expected Completion",
      date: "January 18, 2028",
      completed: false,
    },
  ];

  const units = [
    {
      type: "APARTMENT",
      rows: [
        {
          beds: 5,
          priceFrom: "18M AED",
          area: "15 8205-8205 sqft",
        },
      ],
    },
    {
      type: "VILLA",
      rows: [
        {
          beds: 6,
          priceFrom: "19M AED",
          area: "18 7940-8465 sqft",
        },
        {
          beds: 6,
          priceFrom: "19M AED",
          area: "18 7877-8315 sqft",
        },
      ],
    },
  ];

  const amenitiesList = [
    "Indoor Swimming Pool",
    "CCTV Security",
    "Restaurants",
    "Landscaped Gardens",
    "Gymnasium",
    "Children's Play Area",
  ];

  const [openIndex, setOpenIndex] = useState(null);

  const faqData = [
    {
      question: "What documents are required to get pre-approved?",
      answer:
        "Typically, you'll need recent pay stubs, tax returns from the last 2 years, bank statements, employment verification, and identification. Your lender will provide a complete list based on your specific situation.",
    },
    {
      question: "Which bank should I choose?",
      answer:
        "Consider factors like interest rates, fees, customer service, loan terms, and pre-approval speed. It's recommended to get quotes from multiple lenders including banks, credit unions, and online lenders to compare options.",
    },
    {
      question: "Which mortgage options can Mortgage Finder help with?",
      answer:
        "Mortgage Finder can help with conventional loans, FHA loans, VA loans, USDA loans, jumbo loans, refinancing options, and first-time homebuyer programs. We'll match you with the best options for your situation.",
    },
    {
      question: "Should I get life and building insurance?",
      answer:
        "Yes, homeowners insurance is typically required by lenders and protects your investment. Life insurance isn't required but can help ensure your family can continue making mortgage payments if something happens to you.",
    },
    {
      question: "Why might I not qualify for a mortgage?",
      answer:
        "Common reasons include insufficient credit score, high debt-to-income ratio, inadequate income verification, insufficient down payment, or issues with employment history. A mortgage professional can help identify and address these issues.",
    },
    {
      question: "Can I get a mortgage if I live outside UAE?",
      answer:
        "Yes, many lenders offer mortgage products for non-residents or expats. Requirements may differ, including higher down payments, additional documentation, and proof of international income. Specialized lenders focus on these situations.",
    },
  ];

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const sections = [
    {
      title: "Find Projects by known developers",
      projects: [
        "Off Plan & New Projects by Emaar P...",
        "Off Plan & New Projects by AZizi Dev...",
        "Off Plan & New Projects by Aziur R...",
      ],
    },
    {
      title: "Find Projects on other cities",
      projects: [
        "New Aziur Properties Projects in ...",
        "New ARADA - Sale Projects in Sharjah",
        "New Alef Group Projects in Sharjah",
      ],
    },
    {
      title: "Find Projects on other communities",
      projects: [
        "New Azizi Developments Projects in D...",
        "New Emaar Properties Projects in D...",
        "New Emaar Properties Projects in D...",
      ],
    },
  ];

  const handleTabClick = (tab) => {
    setActiveTab(tab);

    // Convert tab name to ID format
    const sectionId = tab.toLowerCase().replace(/\s+/g, "-");

    // Smooth scroll to section
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({
        behavior: "smooth",
        block: "start",
        inline: "nearest",
      });
    }
  };

  const galleryImages = {
    exteriorView: propertyData?.media?.[0]?.exterior_image
      ? [propertyData.media[0].exterior_image]
      : [

      ],
    livingRoom: propertyData?.media?.[0]?.living_room_image
      ? [propertyData.media[0].living_room_image]
      : [

      ],
    bedroom: propertyData?.media?.[0]?.bedroom_image
      ? [propertyData.media[0].bedroom_image]
      : [

      ],
    bathroom: propertyData?.media?.[0]?.bathroom_image
      ? [propertyData.media[0].bathroom_image]
      : [

      ],
    kitchen: propertyData?.media?.[0]?.kitchen_image
      ? [propertyData.media[0].kitchen_image]
      : [

      ],
    floorPlan: propertyData?.media?.[0]?.floor_plan_image
      ? [propertyData.media[0].floor_plan_image]
      : [

      ],
    masterPlan: propertyData?.media?.[0]?.master_plan_image
      ? [propertyData.media[0].master_plan_image]
      : [

      ],
    locationMap: propertyData?.media?.[0]?.location_map_image
      ? [propertyData.media[0].location_map_image]
      : [

      ],
    other: propertyData?.media?.[0]?.image
      ? [propertyData.media[0].image]
      : [

      ],
  };

  const videoMedia = propertyData?.media?.find(m => m.video_file);


  return (
    <>
      <Header />

      {/* Navigation Bar */}
      <nav className="text-gray-600 px-4 sm:px-6 lg:px-10 pt-6 lg:pt-10 pb-4">
        {/* Desktop Navigation */}
        <div className="hidden lg:flex items-center justify-center space-x-8 xl:space-x-18">
          {navigationTabs.map((tab) => (
            <button
              key={tab}
              onClick={() => handleTabClick(tab)}
              className={`text-lg xl:text-xl font-medium transition-colors duration-200 whitespace-nowrap ${activeTab === tab
                ? "text-gray-900 border-b-2 border-[#0b154f]"
                : "hover:text-gray-900"
                }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Mobile/Tablet Horizontal Scrollable Navigation */}
        <div className="lg:hidden overflow-x-auto scrollbar-hide">
          <div className="flex space-x-6 min-w-max px-2">
            {navigationTabs.map((tab) => (
              <button
                key={tab}
                onClick={() => handleTabClick(tab)}
                className={`text-base sm:text-lg font-medium transition-colors duration-200 whitespace-nowrap pb-2 flex-shrink-0 ${activeTab === tab
                  ? "text-gray-900 border-b-2 border-[#0b154f]"
                  : "hover:text-gray-900"
                  }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <div id="gallery" className="px-4 sm:px-6 lg:px-10 py-4 lg:py-8">
        <div className="flex flex-col lg:flex-row gap-4 lg:gap-6">
          {/* Main Property Image */}
          <div className="flex-1 relative">
            <button
              onClick={() => navigate(-1)}
              className="absolute top-4 lg:top-6 left-4 lg:left-6 z-10 flex items-center gap-2 px-3 py-2"
            >
              <ChevronLeft size={20} className="lg:w-6 lg:h-6" />
              <span className="text-base lg:text-xl font-medium">Back</span>
            </button>

            <div
              className="w-full h-[250px] sm:h-[350px] lg:h-[500px] rounded-xl lg:rounded-2xl overflow-hidden bg-cover bg-center relative"
              style={{
                backgroundImage: (propertyData?.media?.[0]?.exterior_image || propertyData?.media?.[0]?.image)
                  ? `url(${propertyData.media[0].exterior_image || propertyData.media[0].image})`
                  : 'none',
              }}
            >
              {!(propertyData?.media?.[0]?.exterior_image || propertyData?.media?.[0]?.image) && (
                <div className="w-full h-full flex items-center justify-center bg-gray-200">
                  <span className="text-gray-500 text-lg">No Image</span>
                </div>
              )}
            </div>
            <button
              onClick={() => setIsGalleryOpen(true)}
              className="mt-4 ml-4 text-base md:text-lg bg-[#0b154f] text-white py-2 px-4 rounded hover:bg-[#0a1347] transition-colors"
            >
              View Gallery
            </button>
          </div>

          {/* Right Side Images */}
          <div className="w-full lg:w-80 flex flex-row lg:flex-col gap-4 lg:gap-6">
            {/* Aerial View 1 */}
            <div className="flex-1 lg:flex-none h-[120px] sm:h-[160px] lg:h-[240px] rounded-xl lg:rounded-2xl overflow-hidden bg-black flex items-center justify-center">
              {/* {propertyData?.media?.[0]?.video_file ? (
                <video
                  src={propertyData.media[0].video_file}
                  controls
                  className="w-full h-full object-cover"
                />
              ) : (
                <p className="text-gray-500 text-sm">No video available</p>
              )} */}

              {videoMedia ? (
                <video
                  src={videoMedia.video_file}
                  controls
                  className="w-full h-full object-cover"
                />
              ) : (
                <p className="text-gray-500 text-sm">No video available</p>
              )}
            </div>  

            {/* Aerial View 2 */}
            {(propertyData?.media?.[0]?.image || propertyData?.media?.[0]?.master_plan_image) && (
              <div
                className="flex-1 lg:flex-none h-[120px] sm:h-[160px] lg:h-[240px] rounded-xl lg:rounded-2xl overflow-hidden bg-cover bg-center"
                style={{
                  backgroundImage: `url(${propertyData.media[0].image || propertyData.media[0].master_plan_image})`,
                }}
              ></div>
            )}

          </div>
        </div>
      </div>

      <div className="flex flex-col xl:flex-row px-4 sm:px-6 lg:px-8">
        {/* Left Column - Scrollable Content */}
        <div className="flex-1 overflow-y-auto xl:w-[90%] w-full">
          <div className="max-w-5xl px-2 sm:px-4 mt-8 lg:mt-14">
            {/* Header Section */}
            <div id="developer" className="pb-10">
              <h1 className="text-2xl sm:text-3xl lg:text-4xl text-gray-900 mb-6 lg:mb-10">
                {propertyData?.title || "Property Title"}{propertyData?.subtype && (
                  <span className="capitalize">
                    /{propertyData.subtype.charAt(0).toUpperCase() + propertyData.subtype.slice(1)}
                  </span>
                )}
              </h1>

              {/* Launch Price */}
              {(propertyData?.expected_price || propertyData?.deposit_amount) && (
                <>
                  {propertyData?.expected_price && (
                    <div className="mb-2 flex flex-col sm:flex-row sm:items-center">
                      <span className="text-lg lg:text-xl text-gray-700 sm:mr-8 mb-1 sm:mb-0">
                        Price
                      </span>
                      <span className="text-lg lg:text-xl text-gray-900 font-semibold">
                        {`${propertyData.expected_price} ${propertyData.currency}`}
                        {propertyData?.payment_frequency &&
                          ` / ${propertyData.payment_frequency}`}
                      </span>
                    </div>
                  )}

                  {propertyData?.deposit_amount && (
                    <div className="mb-2 flex flex-col sm:flex-row sm:items-center">
                      <span className="text-lg lg:text-xl text-gray-700 sm:mr-8 mb-1 sm:mb-0">
                        Deposit Amount
                      </span>
                      <span className="text-lg lg:text-xl text-gray-900 font-semibold">
                        {`${propertyData.deposit_amount} ${propertyData.currency}`}
                      </span>
                    </div>
                  )}

                  <p className="text-sm lg:text-base text-gray-600 leading-relaxed">
                    *Prices, availability, and purchase conditions may change
                    frequently. Contact a representative for the latest availability
                    and pricing.
                  </p>
                </>
              )}
            </div>

            {/* Developer Section */}
            {(propertyData?.user_details || propertyData?.company_details) && (
              <div className="bg-[#ecefff] rounded-xl p-4 lg:p-6 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 sm:gap-6">
                <div className="flex items-center gap-4 lg:gap-6 w-full sm:w-auto">
                  <div className="w-16 h-16 bg-white rounded border border-gray-200 flex items-center justify-center flex-shrink-0 overflow-hidden">
                    {propertyData?.company_details?.image ? (
                      <img
                        src={propertyData.company_details.image}
                        alt={propertyData.company_details.name || "Company"}
                        className="w-full h-full object-cover"
                        onError={(e) => {
                          e.target.style.display = 'none';
                          e.target.parentElement.innerHTML = `<span class="text-xs font-bold text-gray-800">${propertyData.company_details.name || "Company"}</span>`;
                        }}
                      />
                    ) : (
                      <div className="text-center p-2">
                        <span className="text-xs font-bold text-gray-800">
                          {propertyData?.user_details?.full_name ||
                            propertyData?.company_details?.name ||
                            "Owner"}
                        </span>
                      </div>
                    )}
                  </div>

                  <div>
                    <p className="text-sm lg:text-base text-gray-600 mb-1">
                      Listed by
                    </p>
                    <p className="font-semibold text-base lg:text-lg text-gray-900">
                      {propertyData?.user_details?.full_name ||
                        propertyData?.company_details?.name ||
                        "Property Owner"}
                    </p>
                    {(propertyData?.user_details?.phone || propertyData?.company_details?.phone) && (
                      <p className="text-sm text-gray-600">
                        {propertyData?.user_details?.phone || propertyData?.company_details?.phone}
                      </p>
                    )}
                    {propertyData?.company_details?.email && !propertyData?.user_details && (
                      <p className="text-sm text-gray-600">
                        {propertyData.company_details.email}
                      </p>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* Key information */}
            {(propertyData?.room_type ||
              propertyData?.business_type ||
              propertyData?.established_year ||
              propertyData?.category ||
              propertyData?.facilities_included ||
              propertyData?.number_of_employees ||
              propertyData?.bathrooms ||
              propertyData?.bedrooms ||
              propertyData?.locality ||
              propertyData?.map_address ||
              propertyData?.electricity_available ||
              propertyData?.furnishing ||
              propertyData?.balcony ||
              propertyData?.fenced_property ||
              propertyData?.irrigation_system ||
              propertyData?.preferred_gender ||
              propertyData?.road_access ||
              propertyData?.soil_type ||
              propertyData?.water_source ||
              propertyData?.total_beds ||
              propertyData?.area_sqft ||
              propertyData?.carpet_area ||
              propertyData?.total_area ||
              propertyData?.minimum_stay ||
              propertyData?.maintenance_fees ||
              propertyData?.ownership_type ||
              propertyData?.parking_spaces ||
              propertyData?.address ||
              propertyData?.reason_for_sale ||
              propertyData?.attached_bathroom !== undefined ||
              propertyData?.kitchen_access !== undefined ||
              propertyData?.laundry_access !== undefined) && (
                <div id="key-information" className="mt-20">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-12">
                    Key Information
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {propertyData?.room_type && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Room Type
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.room_type}
                        </dd>
                      </div>
                    )}

                    {propertyData?.business_type && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Business Type
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.business_type}
                        </dd>
                      </div>
                    )}

                    {propertyData?.established_year && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Established Year
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.established_year}
                        </dd>
                      </div>
                    )}

                    {propertyData?.category && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Property Type
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.category}
                        </dd>
                      </div>
                    )}

                    {propertyData?.facilities_included && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Facilities Included
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.facilities_included}
                        </dd>
                      </div>
                    )}

                    {propertyData?.number_of_employees && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Number of Employees
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.number_of_employees}
                        </dd>
                      </div>
                    )}

                    {propertyData?.electricity_available && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Electricity Available
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.electricity_available ? 'Yes' : 'No'}
                        </dd>
                      </div>
                    )}

                    {propertyData?.fenced_property && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Fenced Property
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.fenced_property ? 'Yes' : 'No'}
                        </dd>
                      </div>
                    )}

                    {propertyData?.irrigation_system && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Irrigation System
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.irrigation_system ? 'Yes' : 'No'}
                        </dd>
                      </div>
                    )}

                    {propertyData?.road_access && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Road Access
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.road_access ? 'Yes' : 'No'}
                        </dd>
                      </div>
                    )}

                    {propertyData?.soil_type && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Soil Type
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.soil_type}
                        </dd>
                      </div>
                    )}

                    {propertyData?.water_source && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Water Source
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.water_source}
                        </dd>
                      </div>
                    )}

                    {propertyData?.locality && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Locality
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.locality} {propertyData.sub_locality}
                        </dd>
                      </div>
                    )}

                   {propertyData?.area_sqft > 0 && (
                       <div className="space-y-2">
                         <dt className="text-base font-medium text-gray-600">Area</dt>
                         <dd className="text-lg text-gray-900 font-medium capitalize">
                           {propertyData.area_sqft} sqft.
                         </dd>
                       </div>
                     )}
                        
                     {propertyData?.total_area > 0 && (
                       <div className="space-y-2">
                         <dt className="text-base font-medium text-gray-600">Area</dt>
                         <dd className="text-lg text-gray-900 font-medium capitalize">
                           {propertyData.total_area} sqft.
                         </dd>
                       </div>
                     )}
                     
                     {propertyData?.carpet_area > 0 && (
                       <div className="space-y-2">
                         <dt className="text-base font-medium text-gray-600">Carpet Area</dt>
                         <dd className="text-lg text-gray-900 font-medium capitalize">
                           {propertyData.carpet_area} sqft.
                         </dd>
                       </div>
                     )}



                    {propertyData?.bathrooms && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Bathrooms
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.bathrooms}
                        </dd>
                      </div>
                    )}

                    {propertyData?.bedrooms && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Bedrooms
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.bedrooms}
                        </dd>
                      </div>
                    )}

                    {propertyData?.map_address && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Address
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.map_address}
                        </dd>
                      </div>
                    )}

                    {propertyData?.furnishing && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Furnishing
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.furnishing}
                        </dd>
                      </div>
                    )}

                    {propertyData?.balcony && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Has Balcony
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData?.balcony ? "Yes" : "No"}
                        </dd>
                      </div>
                    )}

                    {propertyData?.maintenance_fees && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Maintenance Fees
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData?.maintenance_fees}
                        </dd>
                      </div>
                    )}

                    {propertyData?.ownership_type && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Ownership Type
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData?.ownership_type}
                        </dd>
                      </div>
                    )}

                    {propertyData?.parking_spaces && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Parking Space
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData?.parking_spaces}
                        </dd>
                      </div>
                    )}

                    {propertyData?.preferred_gender && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Preferred Gender
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium capitalize">
                          {propertyData.preferred_gender}
                        </dd>
                      </div>
                    )}

                    {propertyData?.total_beds && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Total Beds
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.total_beds}
                        </dd>
                      </div>
                    )}

                    {propertyData?.minimum_stay && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Minimum Stay
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.minimum_stay} months
                        </dd>
                      </div>
                    )}

                    {propertyData?.address && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Address
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.address}, {propertyData.city}
                        </dd>
                      </div>
                    )}

                    {propertyData?.attached_bathroom !== undefined && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Attached Bathroom
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.attached_bathroom ? "Yes" : "No"}
                        </dd>
                      </div>
                    )}

                    {propertyData?.kitchen_access !== undefined && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Kitchen Access
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.kitchen_access ? "Yes" : "No"}
                        </dd>
                      </div>
                    )}

                    {propertyData?.laundry_access !== undefined && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Laundry Access
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.laundry_access ? "Yes" : "No"}
                        </dd>
                      </div>
                    )}

                    {propertyData?.reason_for_sale !== undefined && (
                      <div className="space-y-2">
                        <dt className="text-base font-medium text-gray-600">
                          Reason for sale
                        </dt>
                        <dd className="text-lg text-gray-900 font-medium">
                          {propertyData.reason_for_sale}
                        </dd>
                      </div>
                    )}
                  </div>
                </div>
              )}

            {/* About Project */}
            {propertyData?.description && (
              <div id="about-the-project" className="my-20">
                <div className="space-y-6">
                  <h2 className="text-2xl font-bold text-gray-900">
                    About the project
                  </h2>

                  <div className="prose prose-gray max-w-none">
                    <p className="text-gray-700 leading-relaxed text-justify">
                      {propertyData.description}
                    </p>
                  </div>
                </div>
              </div>
            )}


            {/* Eden House Za'abeel masterplan */}
            {propertyData?.media?.[0]?.master_plan_image && (
              <div id="masterplan" className="mb-20">
                <h1 className="text-3xl font-semibold text-[#333333] mb-10">
                  {propertyData?.title || "Property"} Masterplan
                </h1>

                <div className="mb-6">
                  <img
                    src={propertyData.media[0].master_plan_image}
                    alt="Master Plan"
                    className="w-full h-full object-cover rounded-lg"
                    onError={(e) => {
                      e.target.style.display = 'none';
                    }}
                  />
                </div>
              </div>
            )}

            {/* Amenities */}
            {((amenityNames && amenityNames.length > 0) ||
              propertyData?.wifi ||
              propertyData?.water ||
              propertyData?.electricity ||
              propertyData?.cleaning) && (
                <div className="mb-20">
                  <h2 className="text-2xl font-semibold text-gray-800 mb-6">
                    Amenities & Utilities
                  </h2>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-16 gap-y-3">
                    {/* From amenities_details */}
                    {amenityNames?.map((amenity, index) => (
                      <div key={`amenity-${index}`} className="flex items-center">
                        <span className="w-2 h-2 bg-gray-600 rounded-full mr-3 flex-shrink-0"></span>
                        <span className="text-gray-700 text-base">{amenity}</span>
                      </div>
                    ))}

                    {/* Utilities from property data */}
                    {propertyData?.wifi && (
                      <div className="flex items-center">
                        <span className="w-2 h-2 bg-gray-600 rounded-full mr-3 flex-shrink-0"></span>
                        <span className="text-gray-700 text-base">WiFi</span>
                      </div>
                    )}

                    {propertyData?.water && (
                      <div className="flex items-center">
                        <span className="w-2 h-2 bg-gray-600 rounded-full mr-3 flex-shrink-0"></span>
                        <span className="text-gray-700 text-base">Water</span>
                      </div>
                    )}

                    {propertyData?.electricity && (
                      <div className="flex items-center">
                        <span className="w-2 h-2 bg-gray-600 rounded-full mr-3 flex-shrink-0"></span>
                        <span className="text-gray-700 text-base">Electricity</span>
                      </div>
                    )}

                    {propertyData?.cleaning && (
                      <div className="flex items-center">
                        <span className="w-2 h-2 bg-gray-600 rounded-full mr-3 flex-shrink-0"></span>
                        <span className="text-gray-700 text-base">
                          Cleaning Service
                        </span>
                      </div>
                    )}
                  </div>
                </div>
              )}

            {/* FAQ */}
            <div className="mb-20">
              <h2 className="text-2xl font-semibold text-gray-800 mb-12">
                Frequently asked questions
              </h2>

              <div className="space-y-3">
                {faqData.map((faq, index) => (
                  <div
                    key={index}
                    className="border border-gray-200 rounded-lg overflow-hidden"
                  >
                    <button
                      className="w-full px-6 py-4 text-left bg-white hover:bg-[#f7f7fc] hover:text-[#849dd5]  focus:outline-none focus:bg-gray-50 transition-colors duration-200 flex items-center justify-between"
                      onClick={() => toggleFAQ(index)}
                    >
                      <span className="text-gray-700 hover:text-[#849dd5] font-medium text-base leading-relaxed pr-4">
                        {faq.question}
                      </span>
                      <ChevronDown
                        className={`w-5 h-5 text-gray-400 transition-transform duration-200 flex-shrink-0 ${openIndex === index ? "transform rotate-180" : ""
                          }`}
                      />
                    </button>

                    {openIndex === index && (
                      <div className="px-6 pb-4 bg-white border-t border-gray-100">
                        <p className="text-gray-600 text-sm leading-relaxed mt-3">
                          {faq.answer}
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Right Column - Calculator */}
        <div className="hidden xl:block w-full lg:w-[20%] order-last mb-4 lg:mb-0">
          <div className="lg:sticky lg:top-0 p-2 sm:p-4 lg:pb-32 overflow-y-auto flex justify-center lg:block">
            <img
              src={calc}
              alt="Calculator"
              className="w-48 sm:w-64 lg:w-auto"
            />
          </div>
        </div>
      </div>

      <div className="mb-20 px-4 sm:px-6 lg:px-12">
        <h2 className="text-2xl font-semibold text-gray-800 mb-8">
          Recommended Properties
        </h2>

        {/* Horizontal Scrollable Container with Arrow Navigation */}
        <div className="relative group">
          {/* Left Arrow */}
          <button
            onClick={() => {
              const container = document.getElementById("properties-scroll");
              if (container) {
                const scrollAmount =
                  window.innerWidth < 640
                    ? container.offsetWidth
                    : window.innerWidth < 1024
                      ? container.offsetWidth / 2
                      : container.offsetWidth / 4;
                container.scrollBy({ left: -scrollAmount, behavior: "smooth" });
              }
            }}
            className="absolute left-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-full shadow-lg hover:bg-gray-100 flex items-center justify-center transition-all duration-200 opacity-0 group-hover:opacity-100"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700" />
          </button>

          {/* Right Arrow */}
          <button
            onClick={() => {
              const container = document.getElementById("properties-scroll");
              if (container) {
                const scrollAmount =
                  window.innerWidth < 640
                    ? container.offsetWidth
                    : window.innerWidth < 1024
                      ? container.offsetWidth / 2
                      : container.offsetWidth / 4;
                container.scrollBy({ left: scrollAmount, behavior: "smooth" });
              }
            }}
            className="absolute right-2 top-1/2 -translate-y-1/2 z-10 w-10 h-10 sm:w-12 sm:h-12 bg-white rounded-full shadow-lg hover:bg-gray-100 flex items-center justify-center transition-all duration-200 opacity-0 group-hover:opacity-100"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-gray-700 rotate-180" />
          </button>

          <div
            id="properties-scroll"
            className="overflow-x-auto scrollbar-hide pb-4 snap-x snap-mandatory"
            style={{
              scrollbarWidth: "none",
              msOverflowStyle: "none",
            }}
          >
            <div className="flex gap-4 sm:gap-6">
              {recommendedProperties.length > 0
                ? recommendedProperties.map((property, index) => (
                  <div
                    key={index}
                    className="w-full sm:w-[calc(50%-12px)] xl:w-[calc(25%-18px)] bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow duration-300 cursor-pointer flex-shrink-0 snap-start"
                    onClick={() => navigate(`/details/${property.id}`)}
                  >
                    {/* Property Image */}
                    <div className="relative h-48 rounded-t-xl overflow-hidden">
                      <img
                        src={property.image1}
                        alt={property.name}
                        className="w-full h-full object-cover"
                      />
                      {property.status && (
                        <div className="absolute top-3 left-3 bg-[#0b154f] text-white px-3 py-1 rounded-lg text-xs font-medium">
                          {property.status}
                        </div>
                      )}
                    </div>

                    {/* Property Details */}
                    <div className="p-5">
                      {/* Title */}
                      <h3 className="text-lg font-semibold text-gray-900 mb-2 line-clamp-1">
                        {property.name || "Property Name"}
                      </h3>

                      {/* Location */}
                      <div className="flex items-start gap-2 mb-3">
                        <MapPin className="w-4 h-4 text-gray-500 flex-shrink-0 mt-0.5" />
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {property.city || property.address || "Location"}
                        </p>
                      </div>

                      {/* Property Info */}
                      <div className="flex items-center gap-4 mb-4 text-sm text-gray-600">
                        <span>{property.bedrooms || 0} Beds</span>
                        <span>•</span>
                        <span>{property.bathrooms || 0} Baths</span>
                        <span>•</span>
                        <span>{property.carpet_area || 0} sqft</span>
                      </div>

                      {/* Price and CTA */}
                      <div className="flex items-center justify-between pt-4 border-t border-gray-100">
                        <div>
                          <p className="text-xs text-gray-500 mb-1">
                            Starting from
                          </p>
                          <p className="text-xl font-bold text-[#0b154f]">
                            {property.expected_price
                              ? `${property.expected_price} AED`
                              : property.rent_price
                                ? `${property.rent_price} AED`
                                : "Contact for Price"}
                          </p>
                        </div>
                        <button className="bg-[#0b154f] text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-[#0a1347] transition-colors">
                          View Details
                        </button>
                      </div>
                    </div>
                  </div>
                ))
                : // Placeholder cards while loading or if no data
                Array.from({ length: 4 }).map((_, index) => (
                  <div
                    key={index}
                    className="w-full sm:w-[calc(50%-12px)] lg:w-[calc(25%-18px)] bg-white rounded-xl shadow-md flex-shrink-0 animate-pulse snap-start"
                  >
                    <div className="h-48 bg-gray-200 rounded-t-xl"></div>
                    <div className="p-5 space-y-3">
                      <div className="h-6 bg-gray-200 rounded w-3/4"></div>
                      <div className="h-4 bg-gray-200 rounded w-full"></div>
                      <div className="h-4 bg-gray-200 rounded w-2/3"></div>
                      <div className="h-8 bg-gray-200 rounded w-1/2 mt-4"></div>
                    </div>
                  </div>
                ))}
            </div>
          </div>
        </div>
      </div>

      <style>{`
  #properties-scroll::-webkit-scrollbar {
    display: none;
  }
`}</style>

      <div className="mb-20 px-4 sm:px-6 lg:px-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {sections.map((section, index) => (
            <div key={index} className="bg-white">
              <h3 className="text-lg font-medium text-gray-900 mb-4 leading-relaxed">
                {section.title}
              </h3>
              <div className="space-y-3">
                {section.projects.map((project, projectIndex) => (
                  <div
                    key={projectIndex}
                    className="text-[#0b154f] hover:text-blue-800 cursor-pointer text-sm"
                  >
                    {project}
                  </div>
                ))}
              </div>
              <button className="flex items-center text-[#0b154f] px-4 py-2 rounded-xl hover:border hover:border-[#0b154f] text-sm mt-4 font-medium">
                Show more
                <ChevronDown className="ml-1 w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      <Footer />
      <style>{`
        #properties-scroll::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
      `}</style>

      {/* Gallery Modal */}
      <GalleryModal
        isOpen={isGalleryOpen}
        onClose={() => setIsGalleryOpen(false)}
        images={galleryImages}
      />
    </>
  );
}
