// import React, { useState } from "react";
// import { ChevronLeft } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import Map from "./Components/Map";
// import searchbg from "./assets/newandoffplanbg.png";
// import { Phone, Home } from "lucide-react";
// import img1 from "./assets/recentprojects/1.png";
// import img2 from "./assets/recentprojects/2.png";
// import img3 from "./assets/recentprojects/3.png";
// import img4 from "./assets/recentprojects/4.png";
// import img5 from "./assets/recentprojects/5.png";
// import img6 from "./assets/recentprojects/6.png";
// import logo1 from "./assets/recentprojects/logo1.png";
// import logo2 from "./assets/recentprojects/logo2.png";
// import logo3 from "./assets/recentprojects/logo3.png";
// import logo4 from "./assets/recentprojects/logo4.png";
// import logo5 from "./assets/recentprojects/logo5.png";
// import logo6 from "./assets/recentprojects/logo6.png";
// import { useNavigate } from "react-router-dom";

// const SearchPage = () => {
//   const navigate = useNavigate();
//   const [hoveredProject, setHoveredProject] = useState(null);

//   const currentProjects = [
//     {
//       id: 1,
//       title: "Chevalia Estate",
//       location: "Launch price 5M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img1,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo1,
//       whatsappLink: "#",
//     },
//     {
//       id: 2,
//       title: "Chevalia Estate",
//       location: "Launch price 8M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img2,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo2,
//       whatsappLink: "#",
//     },
//     {
//       id: 3,
//       title: "Chevalia Estate",
//       location: "Launch price 16M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img3,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo3,
//       whatsappLink: "#",
//     },
//     {
//       id: 4,
//       title: "Chevalia Estate",
//       location: "Launch price 9M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img4,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo4,
//       whatsappLink: "#",
//     },
//     {
//       id: 5,
//       title: "Chevalia Estate",
//       location: "Launch price 7M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img5,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo5,
//       whatsappLink: "#",
//     },
//     {
//       id: 6,
//       title: "Chevalia Estate",
//       location: "Launch price 12M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img6,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4", // Replace with actual video URL
//       logo: logo6,
//       whatsappLink: "#",
//     },
//   ];

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <Header />

//       {/* Hero Section */}
//       <div className="relative">
//         {/* Top Navigation Bar with Back Button and Logo */}
//         <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 sm:p-4 md:p-6">
//           {/* Back Button */}
//           <button
//             onClick={() => navigate(-1)}
//             className="flex items-center gap-1 sm:gap-2 text-white bg-[#0b154f] bg-opacity-20 hover:bg-opacity-30 rounded-lg pl-2 pr-3 sm:pl-3 sm:pr-4 py-2 transition-all duration-200 text-sm sm:text-base"
//           >
//             <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
//             <span className="font-medium">Back</span>
//           </button>

//           {/* Emaar Logo */}
//           <div className="bg-white rounded-lg px-3 py-2 sm:px-4 sm:py-3 md:px-6 md:py-8 shadow-lg">
//             <div className="text-base sm:text-lg md:text-xl lg:text-2xl font-bold text-gray-800">
//               EMAAR
//             </div>
//           </div>
//         </div>

//         {/* Background Image */}
//         <div className="w-full h-[280px] sm:h-[350px] md:h-[450px] lg:h-[550px] xl:h-[650px] relative overflow-hidden">
//           <img
//             src={searchbg}
//             className="w-full h-full object-cover object-center"
//             alt="Real Estate Developers"
//           />
//           <div
//             className="absolute inset-0"
//             style={{
//               background:
//                 "linear-gradient(to top, white 8%, rgba(255,255,255,0.8) 15%, rgba(255,255,255,0) 100%)",
//               pointerEvents: "none",
//             }}
//           />
//         </div>

//         {/* Content Overlay - Bottom Section */}
//         <div className="absolute bottom-4 sm:bottom-6 md:bottom-8 lg:bottom-10 xl:bottom-20 left-0 right-0 px-4 sm:px-6 md:px-8 lg:px-12 xl:px-8">
//           <div className="w-full mx-auto ">
//             <div className="max-w-4xl">
//               <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-1 sm:mb-2 leading-tight">
//                 New & Off-Plan Projects by
//               </h1>
//               <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-3 sm:mb-4 md:mb-5 leading-tight">
//                 Emaar Properties
//               </h2>
//               <p className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-700 font-medium max-w-xl md:max-w-2xl lg:max-w-3xl leading-relaxed">
//                 Emaar, a real estate giant founded in 1997, is renowned for Burj
//                 Khalifa and Dubai Mall. Emaar offers different properties built
//                 to the highest standards. Their mission is to shape the future
//                 for everyone.
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>

//       <div className="max-w-8xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10 mt-10 mb-24">
//         {/* Header Section */}
//         <div className="text-center mb-8 md:mb-14">
//           <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-6 md:mb-10">
//             190 New & Off-Plan Projects by Emaar Projects
//           </h2>
//         </div>

//         {/* Projects Grid  */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 lg:gap-7 mb-8 md:mb-12">
//           {currentProjects.map((project) => (
//             <div
//               key={project.id}
//               className="rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative"
//               style={{
//                 height:
//                   window.innerWidth >= 1024
//                     ? "480px"
//                     : window.innerWidth >= 768
//                     ? "400px"
//                     : "350px",
//               }}
//               onMouseEnter={() => setHoveredProject(project.id)}
//               onMouseLeave={() => setHoveredProject(null)}
//             >
//               {/* Background Image */}
//               {hoveredProject !== project.id && (
//                 <div
//                   className="absolute inset-0 transition-opacity duration-300"
//                   style={{
//                     backgroundImage: `linear-gradient(to top, rgba(0,0,0) 20%, rgba(0,0,0,0) 100%), url(${project.image})`,
//                     backgroundSize: "cover",
//                     backgroundPosition: "bottom",
//                   }}
//                 />
//               )}

//               {/* Background Video */}
//               {hoveredProject === project.id && (
//                 <video
//                   className="absolute inset-0 w-full h-full object-cover transition-opacity duration-300"
//                   autoPlay
//                   muted
//                   loop
//                   playsInline
//                 >
//                   <source src={project.video} type="video/mp4" />
//                   {/* Fallback to image if video fails to load */}
//                   <div
//                     className="absolute inset-0"
//                     style={{
//                       backgroundImage: `linear-gradient(to top, rgba(0,0,0) 20%, rgba(0,0,0,0) 100%), url(${project.image})`,
//                       backgroundSize: "cover",
//                       backgroundPosition: "bottom",
//                     }}
//                   />
//                 </video>
//               )}

//               {/* Dark overlay for video */}
//               {hoveredProject === project.id && (
//                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
//               )}

//               {/* Top section with logos */}
//               <div className="absolute top-2 right-2 sm:top-3 sm:right-3 md:top-4 md:right-4 z-10">
//                 <img
//                   src={project.logo}
//                   alt={`${project.title} logo`}
//                   className="w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 lg:w-22 lg:h-22"
//                 />
//               </div>

//               {/* Bottom content */}
//               <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-5 lg:p-6 text-white z-10">
//                 <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl mb-1 md:mb-2">
//                   {project.title}
//                 </h3>
//                 <p className="text-sm md:text-base mb-1">{project.beds}</p>
//                 <div className="flex items-center justify-between">
//                   <p className="text-sm md:text-base mb-4 md:mb-6">
//                     {project.location}
//                   </p>
//                   <p className="text-sm md:text-base mb-4 md:mb-6">
//                     {project.posted}
//                   </p>
//                 </div>

//                 {/* WhatsApp Button */}
//                 <button className="w-full bg-white text-gray-900 font-medium py-2 sm:py-2.5 md:py-3 px-3 sm:px-4 rounded-full transition-all duration-300 flex items-center justify-center hover:bg-gray-100 text-sm md:text-base">
//                   <Phone className="w-4 h-4 md:w-5 md:h-5 mr-2" />
//                   WhatsApp
//                 </button>
//               </div>
//             </div>
//           ))}
//         </div>
//       </div>

//       <Map />

//       <Footer />
//     </div>
//   );
// };

// export default SearchPage;

// import React, { useState } from "react";
// import { ChevronLeft, ChevronRight } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import Map from "./Components/Map";
// import searchbg from "./assets/newandoffplanbg.png";
// import { Phone, Home } from "lucide-react";
// import img1 from "./assets/recentprojects/1.png";
// import img2 from "./assets/recentprojects/2.png";
// import img3 from "./assets/recentprojects/3.png";
// import img4 from "./assets/recentprojects/4.png";
// import img5 from "./assets/recentprojects/5.png";
// import img6 from "./assets/recentprojects/6.png";
// import logo1 from "./assets/recentprojects/logo1.png";
// import logo2 from "./assets/recentprojects/logo2.png";
// import logo3 from "./assets/recentprojects/logo3.png";
// import logo4 from "./assets/recentprojects/logo4.png";
// import logo5 from "./assets/recentprojects/logo5.png";
// import logo6 from "./assets/recentprojects/logo6.png";
// import { useNavigate } from "react-router-dom";

// const SearchPage = () => {
//   const navigate = useNavigate();
//   const [hoveredProject, setHoveredProject] = useState(null);
//   const [currentPage, setCurrentPage] = useState(1);
//   const projectsPerPage = 6;

//   // All projects data - duplicated to create more projects for pagination demo
//   const allProjects = [
//     {
//       id: 1,
//       title: "Chevalia Estate",
//       location: "Launch price 5M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img1,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo1,
//       whatsappLink: "#",
//     },
//     {
//       id: 2,
//       title: "Chevalia Estate",
//       location: "Launch price 8M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img2,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo2,
//       whatsappLink: "#",
//     },
//     {
//       id: 3,
//       title: "Chevalia Estate",
//       location: "Launch price 16M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img3,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo3,
//       whatsappLink: "#",
//     },
//     {
//       id: 4,
//       title: "Chevalia Estate",
//       location: "Launch price 9M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img4,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo4,
//       whatsappLink: "#",
//     },
//     {
//       id: 5,
//       title: "Chevalia Estate",
//       location: "Launch price 7M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img5,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo5,
//       whatsappLink: "#",
//     },
//     {
//       id: 6,
//       title: "Chevalia Estate",
//       location: "Launch price 12M AED",
//       beds: "5 beds",
//       posted: "Posted on: 26 Aug 2025",
//       image: img6,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo6,
//       whatsappLink: "#",
//     },
//     // Additional projects for pagination demo
//     {
//       id: 7,
//       title: "Marina Heights",
//       location: "Launch price 6M AED",
//       beds: "4 beds",
//       posted: "Posted on: 25 Aug 2025",
//       image: img1,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo1,
//       whatsappLink: "#",
//     },
//     {
//       id: 8,
//       title: "Boulevard Towers",
//       location: "Launch price 11M AED",
//       beds: "6 beds",
//       posted: "Posted on: 24 Aug 2025",
//       image: img2,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo2,
//       whatsappLink: "#",
//     },
//     {
//       id: 9,
//       title: "Creek Residences",
//       location: "Launch price 14M AED",
//       beds: "5 beds",
//       posted: "Posted on: 23 Aug 2025",
//       image: img3,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo3,
//       whatsappLink: "#",
//     },
//     {
//       id: 10,
//       title: "Palm Villas",
//       location: "Launch price 18M AED",
//       beds: "7 beds",
//       posted: "Posted on: 22 Aug 2025",
//       image: img4,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo4,
//       whatsappLink: "#",
//     },
//     {
//       id: 11,
//       title: "Downtown Square",
//       location: "Launch price 10M AED",
//       beds: "4 beds",
//       posted: "Posted on: 21 Aug 2025",
//       image: img5,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo5,
//       whatsappLink: "#",
//     },
//     {
//       id: 12,
//       title: "Waterfront Living",
//       location: "Launch price 15M AED",
//       beds: "6 beds",
//       posted: "Posted on: 20 Aug 2025",
//       image: img6,
//       video:
//         "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
//       logo: logo6,
//       whatsappLink: "#",
//     },
//   ];

//   // Pagination calculations
//   const totalPages = Math.ceil(allProjects.length / projectsPerPage);
//   const startIndex = (currentPage - 1) * projectsPerPage;
//   const currentProjects = allProjects.slice(
//     startIndex,
//     startIndex + projectsPerPage
//   );

//   // Pagination handlers
//   const handlePageChange = (page) => {
//     setCurrentPage(page);
//     // Scroll to top of projects section
//     window.scrollTo({ top: 800, behavior: "smooth" });
//   };

//   const handlePrevPage = () => {
//     if (currentPage > 1) {
//       setCurrentPage(currentPage - 1);
//       window.scrollTo({ top: 800, behavior: "smooth" });
//     }
//   };

//   const handleNextPage = () => {
//     if (currentPage < totalPages) {
//       setCurrentPage(currentPage + 1);
//       window.scrollTo({ top: 800, behavior: "smooth" });
//     }
//   };

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <Header />

//       {/* Hero Section */}
//       <div className="relative">
//         {/* Top Navigation Bar with Back Button and Logo */}
//         <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 sm:p-4 md:p-6">
//           {/* Back Button */}
//           <button
//             onClick={() => navigate(-1)}
//             className="flex items-center gap-1 sm:gap-2 text-white bg-[#0b154f] bg-opacity-20 hover:bg-opacity-30 rounded-lg pl-2 pr-3 sm:pl-3 sm:pr-4 py-2 transition-all duration-200 text-sm sm:text-base"
//           >
//             <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
//             <span className="font-medium">Back</span>
//           </button>

//           {/* Emaar Logo */}
//           <div className="bg-white rounded-lg px-3 py-2 sm:px-4 sm:py-3 md:px-6 md:py-8 shadow-lg">
//             <div className="text-base sm:text-lg md:text-xl lg:text-2xl font-bold text-gray-800">
//               EMAAR
//             </div>
//           </div>
//         </div>

//         {/* Background Image */}
//         <div className="w-full h-[280px] sm:h-[350px] md:h-[450px] lg:h-[550px] xl:h-[650px] relative overflow-hidden">
//           <img
//             src={searchbg}
//             className="w-full h-full object-cover object-center"
//             alt="Real Estate Developers"
//           />
//           <div
//             className="absolute inset-0"
//             style={{
//               background:
//                 "linear-gradient(to top, white 8%, rgba(255,255,255,0.8) 15%, rgba(255,255,255,0) 100%)",
//               pointerEvents: "none",
//             }}
//           />
//         </div>

//         {/* Content Overlay - Bottom Section */}
//         <div className="absolute bottom-4 sm:bottom-6 md:bottom-8 lg:bottom-10 xl:bottom-20 left-0 right-0 px-4 sm:px-6 md:px-8 lg:px-12 xl:px-8">
//           <div className="w-full mx-auto ">
//             <div className="max-w-4xl">
//               <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-1 sm:mb-2 leading-tight">
//                 New & Off-Plan Projects by
//               </h1>
//               <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-3 sm:mb-4 md:mb-5 leading-tight">
//                 Emaar Properties
//               </h2>
//               <p className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-700 font-medium max-w-xl md:max-w-2xl lg:max-w-3xl leading-relaxed">
//                 Emaar, a real estate giant founded in 1997, is renowned for Burj
//                 Khalifa and Dubai Mall. Emaar offers different properties built
//                 to the highest standards. Their mission is to shape the future
//                 for everyone.
//               </p>
//             </div>
//           </div>
//         </div>
//       </div>

//       <div className="max-w-8xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10 mt-10 mb-24">
//         {/* Header Section */}
//         <div className="text-center mb-8 md:mb-14">
//           <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-6 md:mb-10">
//             {allProjects.length} New & Off-Plan Projects by Emaar Projects
//           </h2>
//         </div>

//         {/* Projects Grid  */}
//         <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 lg:gap-7 mb-8 md:mb-12">
//           {currentProjects.map((project) => (
//             <div
//               key={project.id}
//               className="rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative"
//               style={{
//                 height:
//                   window.innerWidth >= 1024
//                     ? "480px"
//                     : window.innerWidth >= 768
//                     ? "400px"
//                     : "350px",
//               }}
//               onMouseEnter={() => setHoveredProject(project.id)}
//               onMouseLeave={() => setHoveredProject(null)}
//             >
//               {/* Background Image */}
//               {hoveredProject !== project.id && (
//                 <div
//                   className="absolute inset-0 transition-opacity duration-300"
//                   style={{
//                     backgroundImage: `linear-gradient(to top, rgba(0,0,0) 20%, rgba(0,0,0,0) 100%), url(${project.image})`,
//                     backgroundSize: "cover",
//                     backgroundPosition: "bottom",
//                   }}
//                 />
//               )}

//               {/* Background Video */}
//               {hoveredProject === project.id && (
//                 <video
//                   className="absolute inset-0 w-full h-full object-cover transition-opacity duration-300"
//                   autoPlay
//                   muted
//                   loop
//                   playsInline
//                 >
//                   <source src={project.video} type="video/mp4" />
//                   {/* Fallback to image if video fails to load */}
//                   <div
//                     className="absolute inset-0"
//                     style={{
//                       backgroundImage: `linear-gradient(to top, rgba(0,0,0) 20%, rgba(0,0,0,0) 100%), url(${project.image})`,
//                       backgroundSize: "cover",
//                       backgroundPosition: "bottom",
//                     }}
//                   />
//                 </video>
//               )}

//               {/* Dark overlay for video */}
//               {hoveredProject === project.id && (
//                 <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
//               )}

//               {/* Top section with logos */}
//               <div className="absolute top-2 right-2 sm:top-3 sm:right-3 md:top-4 md:right-4 z-10">
//                 <img
//                   src={project.logo}
//                   alt={`${project.title} logo`}
//                   className="w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 lg:w-22 lg:h-22"
//                 />
//               </div>

//               {/* Bottom content */}
//               <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-5 lg:p-6 text-white z-10">
//                 <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl mb-1 md:mb-2">
//                   {project.title}
//                 </h3>
//                 <p className="text-sm md:text-base mb-1">{project.beds}</p>
//                 <div className="flex items-center justify-between">
//                   <p className="text-sm md:text-base mb-4 md:mb-6">
//                     {project.location}
//                   </p>
//                   <p className="text-sm md:text-base mb-4 md:mb-6">
//                     {project.posted}
//                   </p>
//                 </div>

//                 {/* WhatsApp Button */}
//                 <button className="w-full bg-white text-gray-900 font-medium py-2 sm:py-2.5 md:py-3 px-3 sm:px-4 rounded-full transition-all duration-300 flex items-center justify-center hover:bg-gray-100 text-sm md:text-base">
//                   <Phone className="w-4 h-4 md:w-5 md:h-5 mr-2" />
//                   WhatsApp
//                 </button>
//               </div>
//             </div>
//           ))}
//         </div>

//         {/* Pagination */}
//         {totalPages > 1 && (
//           <div className="flex items-center justify-center gap-2 mt-8 sm:mt-12 mb-8">
//             {/* Previous Button */}
//             <button
//               onClick={handlePrevPage}
//               disabled={currentPage === 1}
//               className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
//                 currentPage === 1
//                   ? "text-gray-400 cursor-not-allowed"
//                   : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
//               }`}
//             >
//               <ChevronLeft className="w-4 h-4 mr-1" />
//               Previous
//             </button>

//             {/* Page Numbers */}
//             <div className="flex items-center gap-1">
//               {[...Array(totalPages)].map((_, index) => {
//                 const page = index + 1;
//                 return (
//                   <button
//                     key={page}
//                     onClick={() => handlePageChange(page)}
//                     className={`w-10 h-10 rounded-lg text-sm font-medium transition-all ${
//                       currentPage === page
//                         ? "bg-[#0b154f] text-white"
//                         : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
//                     }`}
//                   >
//                     {page}
//                   </button>
//                 );
//               })}
//             </div>

//             {/* Next Button */}
//             <button
//               onClick={handleNextPage}
//               disabled={currentPage === totalPages}
//               className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
//                 currentPage === totalPages
//                   ? "text-gray-400 cursor-not-allowed"
//                   : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
//               }`}
//             >
//               Next
//               <ChevronRight className="w-4 h-4 ml-1" />
//             </button>
//           </div>
//         )}
//       </div>

//       <Map />

//       <Footer />
//     </div>
//   );
// };

// export default SearchPage;

import React, { useState } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import Map from "./Components/Map";
import searchbg from "./assets/newandoffplanbg.png";
import { Phone, Home } from "lucide-react";
import img1 from "./assets/recentprojects/1.png";
import img2 from "./assets/recentprojects/2.png";
import img3 from "./assets/recentprojects/3.png";
import img4 from "./assets/recentprojects/4.png";
import img5 from "./assets/recentprojects/5.png";
import img6 from "./assets/recentprojects/6.png";
import logo1 from "./assets/recentprojects/logo1.png";
import logo2 from "./assets/recentprojects/logo2.png";
import logo3 from "./assets/recentprojects/logo3.png";
import logo4 from "./assets/recentprojects/logo4.png";
import logo5 from "./assets/recentprojects/logo5.png";
import logo6 from "./assets/recentprojects/logo6.png";
import { useNavigate } from "react-router-dom";

const SearchPage = () => {
  const navigate = useNavigate();
  const [hoveredProject, setHoveredProject] = useState(null);
  const [currentPage, setCurrentPage] = useState(1);
  const projectsPerPage = 6;

  // All projects data - duplicated to create more projects for pagination demo
  const allProjects = [
    {
      id: 1,
      title: "Chevalia Estate",
      location: "Launch price 5M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img1,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo1,
      whatsappLink: "#",
    },
    {
      id: 2,
      title: "Chevalia Estate",
      location: "Launch price 8M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img2,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo2,
      whatsappLink: "#",
    },
    {
      id: 3,
      title: "Chevalia Estate",
      location: "Launch price 16M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img3,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo3,
      whatsappLink: "#",
    },
    {
      id: 4,
      title: "Chevalia Estate",
      location: "Launch price 9M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img4,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo4,
      whatsappLink: "#",
    },
    {
      id: 5,
      title: "Chevalia Estate",
      location: "Launch price 7M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img5,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo5,
      whatsappLink: "#",
    },
    {
      id: 6,
      title: "Chevalia Estate",
      location: "Launch price 12M AED",
      beds: "5 beds",
      posted: "Posted on: 26 Aug 2025",
      image: img6,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo6,
      whatsappLink: "#",
    },
    // Additional projects for pagination demo
    {
      id: 7,
      title: "Marina Heights",
      location: "Launch price 6M AED",
      beds: "4 beds",
      posted: "Posted on: 25 Aug 2025",
      image: img1,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo1,
      whatsappLink: "#",
    },
    {
      id: 8,
      title: "Boulevard Towers",
      location: "Launch price 11M AED",
      beds: "6 beds",
      posted: "Posted on: 24 Aug 2025",
      image: img2,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo2,
      whatsappLink: "#",
    },
    {
      id: 9,
      title: "Creek Residences",
      location: "Launch price 14M AED",
      beds: "5 beds",
      posted: "Posted on: 23 Aug 2025",
      image: img3,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo3,
      whatsappLink: "#",
    },
    {
      id: 10,
      title: "Palm Villas",
      location: "Launch price 18M AED",
      beds: "7 beds",
      posted: "Posted on: 22 Aug 2025",
      image: img4,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo4,
      whatsappLink: "#",
    },
    {
      id: 11,
      title: "Downtown Square",
      location: "Launch price 10M AED",
      beds: "4 beds",
      posted: "Posted on: 21 Aug 2025",
      image: img5,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo5,
      whatsappLink: "#",
    },
    {
      id: 12,
      title: "Waterfront Living",
      location: "Launch price 15M AED",
      beds: "6 beds",
      posted: "Posted on: 20 Aug 2025",
      image: img6,
      video:
        "https://new-projects-media.propertyfinder.com/project/e1a77fbb-7139-4a07-8572-281d7d80bd8f/gallery/video/Vx1C2xmF2ibaxOrHfc6mpZDlNbdym2N3RlEHYDMJww4=/original.mp4",
      logo: logo6,
      whatsappLink: "#",
    },
  ];

  // Pagination calculations
  const totalPages = Math.ceil(allProjects.length / projectsPerPage);
  const startIndex = (currentPage - 1) * projectsPerPage;
  const currentProjects = allProjects.slice(
    startIndex,
    startIndex + projectsPerPage
  );

  // Pagination handlers
  const handlePageChange = (page) => {
    setCurrentPage(page);
    // Scroll to top of projects section
    window.scrollTo({ top: 800, behavior: "smooth" });
  };

  const handlePrevPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
      window.scrollTo({ top: 800, behavior: "smooth" });
    }
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
      window.scrollTo({ top: 800, behavior: "smooth" });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />

      {/* Hero Section */}
      <div className="relative">
        {/* Top Navigation Bar with Back Button and Logo */}
        <div className="absolute top-0 left-0 right-0 z-20 flex items-center justify-between p-3 sm:p-4 md:p-6">
          {/* Back Button */}
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-1 sm:gap-2 text-white bg-[#0b154f] bg-opacity-20 hover:bg-opacity-30 rounded-lg pl-2 pr-3 sm:pl-3 sm:pr-4 py-2 transition-all duration-200 text-sm sm:text-base"
          >
            <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6" />
            <span className="font-medium">Back</span>
          </button>

          {/* Emaar Logo */}
          <div className="bg-white rounded-lg px-3 py-2 sm:px-4 sm:py-3 md:px-6 md:py-8 shadow-lg">
            <div className="text-base sm:text-lg md:text-xl lg:text-2xl font-bold text-gray-800">
              EMAAR
            </div>
          </div>
        </div>

        {/* Background Image */}
        <div className="w-full h-[280px] sm:h-[350px] md:h-[450px] lg:h-[550px] xl:h-[650px] relative overflow-hidden">
          <img
            src={searchbg}
            className="w-full h-full object-cover object-center"
            alt="Real Estate Developers"
          />
          <div
            className="absolute inset-0"
            style={{
              background:
                "linear-gradient(to top, white 8%, rgba(255,255,255,0.8) 15%, rgba(255,255,255,0) 100%)",
              pointerEvents: "none",
            }}
          />
        </div>

        {/* Content Overlay - Bottom Section */}
        <div className="absolute bottom-4 sm:bottom-6 md:bottom-8 lg:bottom-10 xl:bottom-20 left-0 right-0 px-4 sm:px-6 md:px-8 lg:px-12 xl:px-8">
          <div className="w-full mx-auto ">
            <div className="max-w-4xl">
              <h1 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-1 sm:mb-2 leading-tight">
                New & Off-Plan Projects by
              </h1>
              <h2 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl xl:text-5xl font-bold text-[#0b154f] mb-3 sm:mb-4 md:mb-5 leading-tight">
                Emaar Properties
              </h2>
              <p className="text-xs sm:text-sm md:text-base lg:text-lg text-gray-700 font-medium max-w-xl md:max-w-2xl lg:max-w-3xl leading-relaxed">
                Emaar, a real estate giant founded in 1997, is renowned for Burj
                Khalifa and Dubai Mall. Emaar offers different properties built
                to the highest standards. Their mission is to shape the future
                for everyone.
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-8xl mx-auto px-4 sm:px-6 md:px-8 lg:px-10 mt-10 mb-24">
        {/* Header Section */}
        <div className="text-center mb-8 md:mb-14">
          <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-[#0b154f] mb-6 md:mb-10">
            {allProjects.length} New & Off-Plan Projects by Emaar Projects
          </h2>
        </div>

        {/* Projects Grid  */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-5 md:gap-6 lg:gap-7 mb-8 md:mb-12">
          {currentProjects.map((project) => (
            <div
              key={project.id}
              className="rounded-2xl shadow-lg overflow-hidden hover:shadow-xl transition-all duration-300 transform hover:-translate-y-1 relative"
              style={{
                height:
                  window.innerWidth >= 1024
                    ? "480px"
                    : window.innerWidth >= 768
                    ? "400px"
                    : "350px",
              }}
              onMouseEnter={() => setHoveredProject(project.id)}
              onMouseLeave={() => setHoveredProject(null)}
            >
              {/* Background Image - Always present */}
              <div
                className={`absolute inset-0 transition-opacity duration-500 ease-in-out ${
                  hoveredProject === project.id ? "opacity-0" : "opacity-100"
                }`}
                style={{
                  backgroundImage: `linear-gradient(to top, rgba(0,0,0) 20%, rgba(0,0,0,0) 100%), url(${project.image})`,
                  backgroundSize: "cover",
                  backgroundPosition: "bottom",
                }}
              />

              {/* Background Video */}
              <div
                className={`absolute inset-0 transition-opacity duration-500 ease-in-out ${
                  hoveredProject === project.id ? "opacity-100" : "opacity-0"
                }`}
              >
                <video
                  className="absolute inset-0 w-full h-full object-cover"
                  autoPlay
                  muted
                  loop
                  playsInline
                  preload="metadata"
                  onLoadStart={() => {
                    // Video started loading
                  }}
                  onCanPlay={() => {
                    // Video can start playing
                  }}
                >
                  <source src={project.video} type="video/mp4" />
                </video>

                {/* Dark overlay for video */}
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
              </div>

              {/* Top section with logos */}
              <div className="absolute top-2 right-2 sm:top-3 sm:right-3 md:top-4 md:right-4 z-10">
                <img
                  src={project.logo}
                  alt={`${project.title} logo`}
                  className="w-16 h-16 sm:w-18 sm:h-18 md:w-20 md:h-20 lg:w-22 lg:h-22"
                />
              </div>

              {/* Bottom content */}
              <div className="absolute bottom-0 left-0 right-0 p-3 sm:p-4 md:p-5 lg:p-6 text-white z-10">
                <h3 className="text-xl sm:text-2xl md:text-3xl lg:text-4xl mb-1 md:mb-2">
                  {project.title}
                </h3>
                <p className="text-sm md:text-base mb-1">{project.beds}</p>
                <div className="flex items-center justify-between">
                  <p className="text-sm md:text-base mb-4 md:mb-6">
                    {project.location}
                  </p>
                  <p className="text-sm md:text-base mb-4 md:mb-6">
                    {project.posted}
                  </p>
                </div>

                {/* WhatsApp Button */}
                <button className="w-full bg-white text-gray-900 font-medium py-2 sm:py-2.5 md:py-3 px-3 sm:px-4 rounded-full transition-all duration-300 flex items-center justify-center hover:bg-gray-100 text-sm md:text-base">
                  <Phone className="w-4 h-4 md:w-5 md:h-5 mr-2" />
                  WhatsApp
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8 sm:mt-12 mb-8">
            {/* Previous Button */}
            <button
              onClick={handlePrevPage}
              disabled={currentPage === 1}
              className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentPage === 1
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
              }`}
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </button>

            {/* Page Numbers */}
            <div className="flex items-center gap-1">
              {[...Array(totalPages)].map((_, index) => {
                const page = index + 1;
                return (
                  <button
                    key={page}
                    onClick={() => handlePageChange(page)}
                    className={`w-10 h-10 rounded-lg text-sm font-medium transition-all ${
                      currentPage === page
                        ? "bg-[#0b154f] text-white"
                        : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
                    }`}
                  >
                    {page}
                  </button>
                );
              })}
            </div>

            {/* Next Button */}
            <button
              onClick={handleNextPage}
              disabled={currentPage === totalPages}
              className={`flex items-center px-3 py-2 rounded-lg text-sm font-medium transition-all ${
                currentPage === totalPages
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-gray-600 hover:text-gray-800 hover:bg-gray-100"
              }`}
            >
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </button>
          </div>
        )}
      </div>

      <Map />

      <Footer />
    </div>
  );
};

export default SearchPage;
