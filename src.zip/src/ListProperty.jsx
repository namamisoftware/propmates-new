// import React, { useState } from "react";
// import { Home, User, LogOut, HelpCircle } from "lucide-react";
// import Header from "./Components/Header";
// import Footer from "./Components/Footer";
// import { Link } from "react-router-dom";
// import { ChevronRight, ChevronLeft, X } from "lucide-react";

// const App = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     looking_to: "",
//     propertyType: "",
//     country: "",
//     city: "",
//     locality: "",
//     subLocality: "",
//     latitude: "",
//     longitude: "",
//     bedrooms: 0,
//     bathrooms: 0,
//     balconies: 0,
//     areaIn: "",
//     carpetArea: 0,
//     builtupArea: 0,
//     superBuiltupArea: 0,
//     furnishingStatus: "Furnished",
//     currency: "",
//     expectedPrice: "",
//     priceNegotiable: true,
//     description: "",
//     coveredParking: 0,
//     openParking: 0,
//     facing: "",
//   });

//   const [availableAmenities] = useState(["Maids Room", "Sunset View", "Cabin"]);
//   const [chosenAmenities, setChosenAmenities] = useState([]);
//   const [paymentPlans, setPaymentPlans] = useState([{ name: "", amount: "" }]);
//   const loggedInUser = JSON.parse(sessionStorage.getItem("user"));
// // console.log(loggedInUser);

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const moveAmenityToChosen = (amenity) => {
//     setChosenAmenities((prev) => [...prev, amenity]);
//   };

//   const removeAmenityFromChosen = (amenity) => {
//     setChosenAmenities((prev) => prev.filter((a) => a !== amenity));
//   };

//   const addPaymentPlan = () => {
//     setPaymentPlans((prev) => [...prev, { name: "", amount: "" }]);
//   };

//   const removePaymentPlan = (index) => {
//     setPaymentPlans((prev) => prev.filter((_, i) => i !== index));
//   };

//   const handlePaymentPlanChange = (index, field, value) => {
//     setPaymentPlans((prev) =>
//       prev.map((plan, i) => (i === index ? { ...plan, [field]: value } : plan))
//     );
//   };

//  const [isSubmitting, setIsSubmitting] = useState(false);

//  const handleSubmit = async (e) => {
//   e.preventDefault();
//   setIsSubmitting(true);

//   try {
//     // Get logged-in user from sessionStorage
//     const storedUser = JSON.parse(sessionStorage.getItem("user"));
//     console.log(sessionStorage.getItem("user"));

//     if (!storedUser || !storedUser.user_id) {
//       alert("You must be logged in to submit a property.");
//       setIsSubmitting(false);
//       return;
//     }

//     const userId = storedUser?.user_id; // or storedUser?.user_id depending on your backend
// console.log(userId);
//     const propertyData = {
//       ...formData,
//       amenities: chosenAmenities,
//       paymentPlans: paymentPlans,
//       user_id: userId, // include user_id here
//     };

//   const response = await fetch("https://propmatez.shop/api/property-create/", {
//   method: "POST",
//   headers: {
//     "Content-Type": "application/json",
//   },
//   body: JSON.stringify({
//     ...propertyData,
//   }),
//   credentials: "include", // important: sends session cookie
// });

//     if (!response.ok) {
//       const errorData = await response.json();
//       throw new Error(errorData.message || "Failed to submit property");
//     }

//     const result = await response.json();
//     console.log("Property submitted successfully:", result);
//     alert("Property submitted successfully!");

//     // Reset form after successful submission
//     setFormData({
//       name: "",
//       lookingTo: "",
//       propertyType: "",
//       country: "",
//       city: "",
//       locality: "",
//       subLocality: "",
//       latitude: "",
//       longitude: "",
//       bedrooms: 0,
//       bathrooms: 0,
//       balconies: 0,
//       areaIn: "",
//       carpetArea: 0,
//       builtupArea: 0,
//       superBuiltupArea: 0,
//       furnishingStatus: "Furnished",
//       currency: "",
//       expectedPrice: "",
//       priceNegotiable: true,
//       description: "",
//       coveredParking: 0,
//       openParking: 0,
//       facing: "",
//     });
//     setChosenAmenities([]);
//     setPaymentPlans([{ name: "", amount: "" }]);
//   } catch (error) {
//     console.error("Error submitting property:", error);
//     alert(`Error: ${error.message}`);
//   } finally {
//     setIsSubmitting(false);
//   }
// };

//   return (
//     <>
//       <Header />
//       <div className="flex gap-4 max-w-6xl mx-auto my-10">
//         {/* Sidebar */}
//         <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded">
//           <div className="p-4">
//             <nav className="space-y-0.5">
//               <Link
//                 to="/mylistings"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <Home className="w-4 h-4" />
//                 <span>My Listings</span>
//               </Link>
//               <Link
//                 to="/listproperty"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <Home className="w-4 h-4" />
//                 <span>List Property</span>
//               </Link>

//               <Link
//                 to="/profile"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <User className="w-4 h-4" />
//                 <span>Profile</span>
//               </Link>

//               <Link
//                 to="/enquiry"
//                 className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
//               >
//                 <HelpCircle className="w-4 h-4" />
//                 <span>Enquiry</span>
//               </Link>
//             </nav>
//           </div>
//         </div>

//         {/* Main Content */}
//         <div className="flex-1 overflow-auto bg-white rounded">
//           <div className="max-w-4xl mx-auto bg-white rounded-lg shadow-sm p-4 sm:p-6">
//             <h1 className="text-xl sm:text-2xl font-semibold mb-4 sm:mb-6">
//               Property Listing
//             </h1>

//             <form onSubmit={handleSubmit}>
//               {/* Step 1: Basic Information */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 1: Basic information
//                   </h2>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-1 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Name
//                     </label>
//                     <input
//                       type="text"
//                       name="name"
//                       placeholder="Enter property name"
//                       value={formData.name}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Looking to <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="looking_to"
//                       value={formData.looking_to}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select</option>
//                       <option value="1">Sell</option>
//                       <option value="2">Rent</option>
//                       <option value="3">Commercial Sell</option>
//                       <option value="4">Commercial Rent</option>
//                       <option value="5">New Project</option>
//                     </select>
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Property type <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="propertyType"
//                       value={formData.propertyType}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select First Looking To</option>
//                       <option value="apartment">Apartment</option>
//                       <option value="villa">Villa</option>
//                       <option value="house">House</option>
//                     </select>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 2: Location */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 2: Location
//                   </h2>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Country
//                     </label>
//                     <select
//                       name="country"
//                       value={formData.country}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select Country</option>
//                       <option value="2">India</option>
//                       <option value="3">USA</option>
//                     </select>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       City <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="city"
//                       value={formData.city}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select City</option>
//                       <option value="mumbai">Mumbai</option>
//                       <option value="delhi">Delhi</option>
//                     </select>
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Locality <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="text"
//                       name="locality"
//                       placeholder="Enter locality"
//                       value={formData.locality}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Sub locality
//                     </label>
//                     <input
//                       type="text"
//                       name="subLocality"
//                       placeholder="Enter sub locality"
//                       value={formData.subLocality}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Latitude
//                     </label>
//                     <input
//                       type="text"
//                       name="latitude"
//                       placeholder="Enter latitude"
//                       value={formData.latitude}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Longitude
//                     </label>
//                     <input
//                       type="text"
//                       name="longitude"
//                       placeholder="Enter longitude"
//                       value={formData.longitude}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>
//               </div>

//               {/* Step 3: Property Profile */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 3: Property Profile
//                   </h2>
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Bedrooms <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="bedrooms"
//                       value={formData.bedrooms}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Bathrooms <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="bathrooms"
//                       value={formData.bathrooms}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Balconies <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="balconies"
//                       value={formData.balconies}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Area in
//                     </label>
//                     <select
//                       name="areaIn"
//                       value={formData.areaIn}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select Option</option>
//                       <option value="sqft">Square Feet</option>
//                       <option value="sqm">Square Meters</option>
//                     </select>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Carpet area <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="carpetArea"
//                       value={formData.carpetArea}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Builtup area
//                     </label>
//                     <input
//                       type="number"
//                       name="builtupArea"
//                       value={formData.builtupArea}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Super builtup area
//                     </label>
//                     <input
//                       type="number"
//                       name="superBuiltupArea"
//                       value={formData.superBuiltupArea}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Furnishing status <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="furnishingStatus"
//                       value={formData.furnishingStatus}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="Furnished">Furnished</option>
//                       <option value="Semi-Furnished">Semi-Furnished</option>
//                       <option value="Unfurnished">Unfurnished</option>
//                     </select>
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Currency
//                     </label>
//                     <input
//                       type="text"
//                       name="currency"
//                       value={formData.currency}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Expected price
//                     </label>
//                     <input
//                       type="text"
//                       name="expectedPrice"
//                       placeholder="Enter expected price"
//                       value={formData.expectedPrice}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <label className="flex items-center gap-2 cursor-pointer">
//                     <input
//                       type="radio"
//                       name="priceType"
//                       value="inclusive"
//                       checked={!formData.priceNegotiable}
//                       onChange={() =>
//                         setFormData((prev) => ({
//                           ...prev,
//                           priceNegotiable: false,
//                         }))
//                       }
//                       className="w-4 h-4"
//                     />
//                     <span className="text-sm">All inclusive</span>
//                   </label>

//                   <label className="flex items-center gap-2 cursor-pointer">
//                     <input
//                       type="radio"
//                       name="priceType"
//                       value="negotiable"
//                       checked={formData.priceNegotiable}
//                       onChange={() =>
//                         setFormData((prev) => ({
//                           ...prev,
//                           priceNegotiable: true,
//                         }))
//                       }
//                       className="w-4 h-4"
//                     />
//                     <span className="text-sm">Price negotiable</span>
//                   </label>
//                 </div>

//                 <div className="mb-3 sm:mb-4">
//                   <label className="block text-sm font-medium mb-2">
//                     Description
//                   </label>
//                   <textarea
//                     name="description"
//                     placeholder="Enter property description"
//                     value={formData.description}
//                     onChange={handleInputChange}
//                     rows="5"
//                     className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                   />
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 sm:gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Covered Parking spaces{" "}
//                       <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="coveredParking"
//                       value={formData.coveredParking}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Open Parking spaces{" "}
//                       <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="openParking"
//                       value={formData.openParking}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Facing
//                     </label>
//                     <select
//                       name="facing"
//                       value={formData.facing}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select value</option>
//                       <option value="north">North</option>
//                       <option value="south">South</option>
//                       <option value="east">East</option>
//                       <option value="west">West</option>
//                     </select>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 4: Media */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 4: Media
//                   </h2>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4 mb-3 sm:mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Upload Images(Select Multiple Image)
//                     </label>
//                     <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
//                       <button
//                         type="button"
//                         className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-50 whitespace-nowrap"
//                       >
//                         Choose Files
//                       </button>
//                       <span className="text-xs sm:text-sm text-gray-500">
//                         No file chosen
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Second Image
//                     </label>
//                     <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
//                       <button
//                         type="button"
//                         className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-50 whitespace-nowrap"
//                       >
//                         Choose Files
//                       </button>
//                       <span className="text-xs sm:text-sm text-gray-500">
//                         No file chosen
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Masterplan Image
//                     </label>
//                     <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
//                       <button
//                         type="button"
//                         className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-50 whitespace-nowrap"
//                       >
//                         Choose Files
//                       </button>
//                       <span className="text-xs sm:text-sm text-gray-500">
//                         No file chosen
//                       </span>
//                     </div>
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Video
//                     </label>
//                     <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
//                       <button
//                         type="button"
//                         className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-50 whitespace-nowrap"
//                       >
//                         Choose File
//                       </button>
//                       <span className="text-xs sm:text-sm text-gray-500">
//                         No file chosen
//                       </span>
//                     </div>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Brochure
//                     </label>
//                     <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
//                       <button
//                         type="button"
//                         className="px-4 py-2 border border-gray-300 rounded text-sm hover:bg-gray-50 whitespace-nowrap"
//                       >
//                         Choose File
//                       </button>
//                       <span className="text-xs sm:text-sm text-gray-500">
//                         No file chosen
//                       </span>
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 5: Amenities */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 5: Amenities
//                   </h2>
//                 </div>

//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-3 sm:gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Available amenities
//                     </label>
//                     <p className="text-xs text-gray-500 mb-2">
//                       Choose amenities by selecting them and then select the
//                       "Choose" arrow button.
//                     </p>
//                     <input
//                       type="text"
//                       placeholder="Filter"
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                     <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto">
//                       {availableAmenities
//                         .filter((a) => !chosenAmenities.includes(a))
//                         .map((amenity) => (
//                           <div
//                             key={amenity}
//                             onClick={() => moveAmenityToChosen(amenity)}
//                             className="px-2 py-1 text-sm hover:bg-gray-100 cursor-pointer rounded"
//                           >
//                             {amenity}
//                           </div>
//                         ))}
//                     </div>
//                     <button
//                       type="button"
//                       className="text-blue-600 text-sm mt-2 hover:underline"
//                     >
//                       Choose all amenities
//                     </button>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Chosen amenities
//                     </label>
//                     <p className="text-xs text-gray-500 mb-2">
//                       Remove amenities by selecting them and then select the
//                       "Remove" arrow button.
//                     </p>
//                     <input
//                       type="text"
//                       placeholder="Filter"
//                       className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded mb-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                     <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto">
//                       {chosenAmenities.map((amenity) => (
//                         <div
//                           key={amenity}
//                           onClick={() => removeAmenityFromChosen(amenity)}
//                           className="px-2 py-1 text-sm hover:bg-gray-100 cursor-pointer rounded"
//                         >
//                           {amenity}
//                         </div>
//                       ))}
//                     </div>
//                     <button
//                       type="button"
//                       onClick={() => setChosenAmenities([])}
//                       className="text-red-600 text-sm mt-2 hover:underline"
//                     >
//                       Remove all amenities
//                     </button>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 6: Payment Plans */}
//               <div className="mb-4 sm:mb-6">
//                 <div className="bg-gray-100 px-3 sm:px-4 py-2 mb-3 sm:mb-4 rounded">
//                   <h2 className="font-medium text-sm sm:text-base">
//                     Step 6: Payment Plans
//                   </h2>
//                 </div>

//                 {paymentPlans.map((plan, index) => (
//                   <div
//                     key={index}
//                     className="grid grid-cols-1 md:grid-cols-2 gap-3 sm:gap-4 mb-3 sm:mb-4 items-end"
//                   >
//                     <div>
//                       <label className="block text-sm font-medium mb-2">
//                         Payment name
//                       </label>
//                       <input
//                         type="text"
//                         value={plan.name}
//                         onChange={(e) =>
//                           handlePaymentPlanChange(index, "name", e.target.value)
//                         }
//                         className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       />
//                     </div>

//                     <div className="flex gap-2">
//                       <div className="flex-1">
//                         <label className="block text-sm font-medium mb-2">
//                           Amount
//                         </label>
//                         <input
//                           type="text"
//                           value={plan.amount}
//                           onChange={(e) =>
//                             handlePaymentPlanChange(
//                               index,
//                               "amount",
//                               e.target.value
//                             )
//                           }
//                           className="w-full px-3 py-2 text-sm sm:text-base border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                         />
//                       </div>
//                       {paymentPlans.length > 1 && (
//                         <button
//                           type="button"
//                           onClick={() => removePaymentPlan(index)}
//                           className="bg-red-500 text-white p-2 rounded hover:bg-red-600 flex-shrink-0"
//                         >
//                           <X size={20} />
//                         </button>
//                       )}
//                     </div>
//                   </div>
//                 ))}

//                 <button
//                   type="button"
//                   onClick={addPaymentPlan}
//                   className="text-blue-600 border border-blue-600 px-4 py-2 rounded text-sm hover:bg-blue-50 w-full sm:w-auto"
//                 >
//                   + Add Payment Plan
//                 </button>
//               </div>

//               {/* Submit Button */}
//               <div className="flex justify-end">
//                 <button
//                   type="submit"
//                   className="bg-blue-600 text-white px-6 py-2 rounded text-sm sm:text-base hover:bg-blue-700 flex items-center gap-2 w-full sm:w-auto justify-center"
//                 >
//                   <span>Submit Property</span>
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       </div>
//       <Footer />
//     </>
//   );
// };

// export default App;

// import React, { useState } from "react";
// import { Home, User, HelpCircle, X } from "lucide-react";

// const PropertyListingForm = () => {
//   const [formData, setFormData] = useState({
//     name: "",
//     looking_to: "",
//     propertyType: "",
//     country: "",
//     city: "",
//     locality: "",
//     subLocality: "",
//     latitude: "",
//     longitude: "",
//     bedrooms: 0,
//     bathrooms: 0,
//     balconies: 0,
//     areaIn: "",
//     carpetArea: 0,
//     builtupArea: 0,
//     superBuiltupArea: 0,
//     furnishingStatus: "Furnished",
//     currency: "",
//     expectedPrice: "",
//     priceNegotiable: true,
//     description: "",
//     coveredParking: 0,
//     openParking: 0,
//     facing: "",
//   });

//   const [availableAmenities] = useState(["Maids Room", "Sunset View", "Cabin"]);
//   const [chosenAmenities, setChosenAmenities] = useState([]);
//   const [paymentPlans, setPaymentPlans] = useState([{ name: "", amount: "" }]);
//   const [isSubmitting, setIsSubmitting] = useState(false);

//   const handleInputChange = (e) => {
//     const { name, value, type, checked } = e.target;
//     setFormData((prev) => ({
//       ...prev,
//       [name]: type === "checkbox" ? checked : value,
//     }));
//   };

//   const moveAmenityToChosen = (amenity) => {
//     setChosenAmenities((prev) => [...prev, amenity]);
//   };

//   const removeAmenityFromChosen = (amenity) => {
//     setChosenAmenities((prev) => prev.filter((a) => a !== amenity));
//   };

//   const addPaymentPlan = () => {
//     setPaymentPlans((prev) => [...prev, { name: "", amount: "" }]);
//   };

//   const removePaymentPlan = (index) => {
//     setPaymentPlans((prev) => prev.filter((_, i) => i !== index));
//   };

//   const handlePaymentPlanChange = (index, field, value) => {
//     setPaymentPlans((prev) =>
//       prev.map((plan, i) => (i === index ? { ...plan, [field]: value } : plan))
//     );
//   };

// const handleSubmit = async (e) => {
//   e.preventDefault();
//   setIsSubmitting(true);

//   try {
//     // Get the logged-in user from sessionStorage
//     const storedUser = JSON.parse(sessionStorage.getItem("user"));

//     if (!storedUser || !storedUser.user_id) {
//       alert("You must be logged in to submit a property.");
//       setIsSubmitting(false);
//       return;
//     }

//     const propertyData = {
//       ...formData,
//       amenities: chosenAmenities,
//       paymentPlans: paymentPlans,
//       user_id: storedUser.user_id, // take user_id from sessionStorage
//     };

//     console.log("Submitting property data:", propertyData);

//     const response = await fetch("https://propmatez.shop/api/property-create/", {
//       method: "POST",
//       headers: {
//         "Content-Type": "application/json",
//       },
//       body: JSON.stringify(propertyData),
//       credentials: "include",
//     });

//     // Check if response is JSON
//     const contentType = response.headers.get("content-type");
//     if (!contentType || !contentType.includes("application/json")) {
//       const text = await response.text();
//       console.error("Server returned non-JSON response:", text);
//       throw new Error("Server error: Expected JSON response but got HTML. Check server logs.");
//     }

//     if (!response.ok) {
//       const errorData = await response.json();
//       throw new Error(errorData.message || errorData.detail || "Failed to submit property");
//     }

//     const result = await response.json();
//     console.log("Property submitted successfully:", result);
//     alert("Property submitted successfully!");

//     // Reset form
//     setFormData({
//       name: "",
//       looking_to: "",
//       propertyType: "",
//       country: "",
//       city: "",
//       locality: "",
//       subLocality: "",
//       latitude: "",
//       longitude: "",
//       bedrooms: 0,
//       bathrooms: 0,
//       balconies: 0,
//       areaIn: "",
//       carpetArea: 0,
//       builtupArea: 0,
//       superBuiltupArea: 0,
//       furnishingStatus: "Furnished",
//       currency: "",
//       expectedPrice: "",
//       priceNegotiable: true,
//       description: "",
//       coveredParking: 0,
//       openParking: 0,
//       facing: "",
//     });
//     setChosenAmenities([]);
//     setPaymentPlans([{ name: "", amount: "" }]);
//   } catch (error) {
//     console.error("Error submitting property:", error);
//     alert(`Error: ${error.message}`);
//   } finally {
//     setIsSubmitting(false);
//   }
// };

//   return (
//     <div className="min-h-screen bg-gray-50">
//       <div className="flex gap-4 max-w-6xl mx-auto my-10 p-4">
//         {/* Sidebar */}
//         <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded">
//           <div className="p-4">
//             <nav className="space-y-0.5">
//               <button className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left">
//                 <Home className="w-4 h-4" />
//                 <span>My Listings</span>
//               </button>
//               <button className="w-full flex items-center gap-3 px-3 py-2 text-sm bg-indigo-900 rounded text-left">
//                 <Home className="w-4 h-4" />
//                 <span>List Property</span>
//               </button>
//               <button className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left">
//                 <User className="w-4 h-4" />
//                 <span>Profile</span>
//               </button>
//               <button className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left">
//                 <HelpCircle className="w-4 h-4" />
//                 <span>Enquiry</span>
//               </button>
//             </nav>
//           </div>
//         </div>

//         {/* Main Content */}
//         <div className="flex-1 overflow-auto bg-white rounded shadow-sm">
//           <div className="max-w-4xl mx-auto p-6">
//             <h1 className="text-2xl font-semibold mb-6">Property Listing</h1>

//             <form onSubmit={handleSubmit}>
//               {/* Step 1: Basic Information */}
//               <div className="mb-6">
//                 <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
//                   <h2 className="font-medium">Step 1: Basic information</h2>
//                 </div>

//                 <div className="mb-4">
//                   <label className="block text-sm font-medium mb-2">Name</label>
//                   <input
//                     type="text"
//                     name="name"
//                     placeholder="Enter property name"
//                     value={formData.name}
//                     onChange={handleInputChange}
//                     className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                   />
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Looking to <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="looking_to"
//                       value={formData.looking_to}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                     >
//                       <option value="">Select</option>
//                       <option value="1">Sell</option>
//                       <option value="2">Rent</option>
//                       <option value="3">Commercial Sell</option>
//                       <option value="4">Commercial Rent</option>
//                       <option value="5">New Project</option>
//                     </select>
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Property type <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="propertyType"
//                       value={formData.propertyType}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                     >
//                       <option value="">Select First Looking To</option>
//                       <option value="apartment">Apartment</option>
//                       <option value="villa">Villa</option>
//                       <option value="house">House</option>
//                     </select>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 2: Location */}
//               <div className="mb-6">
//                 <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
//                   <h2 className="font-medium">Step 2: Location</h2>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">Country</label>
//                     <select
//                       name="country"
//                       value={formData.country}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     >
//                       <option value="">Select Country</option>
//                       <option value="2">India</option>
//                       <option value="3">USA</option>
//                     </select>
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       City <span className="text-red-500">*</span>
//                     </label>
//                     <select
//                       name="city"
//                       value={formData.city}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                     >
//                       <option value="">Select City</option>
//                       <option value="mumbai">Mumbai</option>
//                       <option value="delhi">Delhi</option>
//                     </select>
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Locality <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="text"
//                       name="locality"
//                       placeholder="Enter locality"
//                       value={formData.locality}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">Sub locality</label>
//                     <input
//                       type="text"
//                       name="subLocality"
//                       placeholder="Enter sub locality"
//                       value={formData.subLocality}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>
//               </div>

//               {/* Step 3: Property Profile */}
//               <div className="mb-6">
//                 <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
//                   <h2 className="font-medium">Step 3: Property Profile</h2>
//                 </div>

//                 <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Bedrooms <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="bedrooms"
//                       value={formData.bedrooms}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                       min="0"
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Bathrooms <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="bathrooms"
//                       value={formData.bathrooms}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                       min="0"
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">
//                       Balconies <span className="text-red-500">*</span>
//                     </label>
//                     <input
//                       type="number"
//                       name="balconies"
//                       value={formData.balconies}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       required
//                       min="0"
//                     />
//                   </div>
//                 </div>

//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">Currency</label>
//                     <input
//                       type="text"
//                       name="currency"
//                       placeholder="e.g., USD, INR"
//                       value={formData.currency}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                   <div>
//                     <label className="block text-sm font-medium mb-2">Expected price</label>
//                     <input
//                       type="text"
//                       name="expectedPrice"
//                       placeholder="Enter expected price"
//                       value={formData.expectedPrice}
//                       onChange={handleInputChange}
//                       className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                     />
//                   </div>
//                 </div>

//                 <div className="mb-4">
//                   <label className="block text-sm font-medium mb-2">Description</label>
//                   <textarea
//                     name="description"
//                     placeholder="Enter property description"
//                     value={formData.description}
//                     onChange={handleInputChange}
//                     rows="4"
//                     className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                   />
//                 </div>
//               </div>

//               {/* Step 4: Amenities */}
//               <div className="mb-6">
//                 <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
//                   <h2 className="font-medium">Step 4: Amenities</h2>
//                 </div>

//                 <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
//                   <div>
//                     <label className="block text-sm font-medium mb-2">Available amenities</label>
//                     <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
//                       {availableAmenities
//                         .filter((a) => !chosenAmenities.includes(a))
//                         .map((amenity) => (
//                           <div
//                             key={amenity}
//                             onClick={() => moveAmenityToChosen(amenity)}
//                             className="px-2 py-1 text-sm hover:bg-blue-50 cursor-pointer rounded"
//                           >
//                             {amenity}
//                           </div>
//                         ))}
//                     </div>
//                   </div>

//                   <div>
//                     <label className="block text-sm font-medium mb-2">Chosen amenities</label>
//                     <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
//                       {chosenAmenities.map((amenity) => (
//                         <div
//                           key={amenity}
//                           onClick={() => removeAmenityFromChosen(amenity)}
//                           className="px-2 py-1 text-sm hover:bg-red-50 cursor-pointer rounded flex justify-between items-center"
//                         >
//                           <span>{amenity}</span>
//                           <X size={14} className="text-red-500" />
//                         </div>
//                       ))}
//                     </div>
//                   </div>
//                 </div>
//               </div>

//               {/* Step 5: Payment Plans */}
//               <div className="mb-6">
//                 <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
//                   <h2 className="font-medium">Step 5: Payment Plans</h2>
//                 </div>

//                 {paymentPlans.map((plan, index) => (
//                   <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 items-end">
//                     <div>
//                       <label className="block text-sm font-medium mb-2">Payment name</label>
//                       <input
//                         type="text"
//                         value={plan.name}
//                         onChange={(e) => handlePaymentPlanChange(index, "name", e.target.value)}
//                         className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                       />
//                     </div>
//                     <div className="flex gap-2">
//                       <div className="flex-1">
//                         <label className="block text-sm font-medium mb-2">Amount</label>
//                         <input
//                           type="text"
//                           value={plan.amount}
//                           onChange={(e) => handlePaymentPlanChange(index, "amount", e.target.value)}
//                           className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
//                         />
//                       </div>
//                       {paymentPlans.length > 1 && (
//                         <button
//                           type="button"
//                           onClick={() => removePaymentPlan(index)}
//                           className="bg-red-500 text-white p-2 rounded hover:bg-red-600 flex-shrink-0 self-end"
//                         >
//                           <X size={20} />
//                         </button>
//                       )}
//                     </div>
//                   </div>
//                 ))}

//                 <button
//                   type="button"
//                   onClick={addPaymentPlan}
//                   className="text-blue-600 border border-blue-600 px-4 py-2 rounded hover:bg-blue-50"
//                 >
//                   + Add Payment Plan
//                 </button>
//               </div>

//               {/* Submit Button */}
//               <div className="flex justify-end">
//                 <button
//                   type="submit"
//                   disabled={isSubmitting}
//                   className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
//                 >
//                   {isSubmitting ? "Submitting..." : "Submit Property"}
//                 </button>
//               </div>
//             </form>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default PropertyListingForm;

import React, { useState, useEffect } from "react";
import {
  Home,
  User,
  HelpCircle,
  X,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const PropertyListingForm = () => {
  const [formData, setFormData] = useState({
    name: "",
    looking_to: "",
    propertyType: "",
    country: "",
    city: "",
    locality: "",
    subLocality: "",
    latitude: "",
    longitude: "",
    bedrooms: 0,
    bathrooms: 0,
    balconies: 0,
    areaIn: "",
    carpetArea: 0,
    builtupArea: 0,
    superBuiltupArea: 0,
    furnishingStatus: "Furnished",
    currency: "",
    expectedPrice: "",
    priceNegotiable: true,
    description: "",
    coveredParking: 0,
    openParking: 0,
    facing: "",
    user_id: "",
  });

  const [availableAmenities] = useState(["Maids Room", "Sunset View", "Cabin"]);
  const [chosenAmenities, setChosenAmenities] = useState([]);
  const [paymentPlans, setPaymentPlans] = useState([{ name: "", amount: "" }]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Load user_id from sessionStorage on component mount
  useEffect(() => {
    const storedUser = JSON.parse(sessionStorage.getItem("user") || "{}");
    if (storedUser && storedUser.user_id) {
      setFormData((prev) => ({ ...prev, user_id: storedUser.user_id }));
    }
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const moveAmenityToChosen = (amenity) => {
    setChosenAmenities((prev) => [...prev, amenity]);
  };

  const removeAmenityFromChosen = (amenity) => {
    setChosenAmenities((prev) => prev.filter((a) => a !== amenity));
  };

  const addPaymentPlan = () => {
    setPaymentPlans((prev) => [...prev, { name: "", amount: "" }]);
  };

  const removePaymentPlan = (index) => {
    setPaymentPlans((prev) => prev.filter((_, i) => i !== index));
  };

  const handlePaymentPlanChange = (index, field, value) => {
    setPaymentPlans((prev) =>
      prev.map((plan, i) => (i === index ? { ...plan, [field]: value } : plan))
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);

    try {
      // Get user_id from sessionStorage
      const storedUser = JSON.parse(sessionStorage.getItem("user") || "{}");
      const userId = storedUser.user_id || formData.user_id;

      // Check if user_id is present
      if (!userId) {
        alert("You must be logged in to submit a property.");
        setIsSubmitting(false);
        return;
      }

      const propertyData = {
        ...formData,

        amenities: chosenAmenities,
        paymentPlans: paymentPlans,
      };

      console.log("Submitting property data:", propertyData);

      const response = await fetch(
        "https://propmatez.shop/api/property-create/",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(propertyData),
          credentials: "include",
        }
      );

      // Check if response is JSON
      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Server returned non-JSON response:", text);
        throw new Error(
          "Server error: Expected JSON response but got HTML. Check server logs."
        );
      }

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          errorData.message || errorData.detail || "Failed to submit property"
        );
      }

      const result = await response.json();
      console.log("Property submitted successfully:", result);
      alert("Property submitted successfully!");

      // Reset form
      // const storedUser = JSON.parse(sessionStorage.getItem("user") || "{}");
      setFormData({
        name: "",
        looking_to: "",
        propertyType: "",
        country: "",
        city: "",
        locality: "",
        subLocality: "",
        latitude: "",
        longitude: "",
        bedrooms: 0,
        bathrooms: 0,
        balconies: 0,
        areaIn: "",
        carpetArea: 0,
        builtupArea: 0,
        superBuiltupArea: 0,
        furnishingStatus: "Furnished",
        currency: "",
        expectedPrice: "",
        priceNegotiable: true,
        description: "",
        coveredParking: 0,
        openParking: 0,
        facing: "",
        user_id: storedUser.user_id || "",
      });
      setChosenAmenities([]);
      setPaymentPlans([{ name: "", amount: "" }]);
    } catch (error) {
      console.error("Error submitting property:", error);
      alert(`Error: ${error.message}`);
    } finally {
      setIsSubmitting(false);
    }
  };

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <div className="flex gap-4 max-w-6xl mx-auto my-10 p-4">
        {/* Sidebar */}
        <div className="hidden lg:block h-fit w-52 bg-indigo-950 text-white flex-shrink-0 rounded">
          <div className="p-4">
            {/* <nav className="space-y-0.5">
              <Link
                to="/mylistings"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <Home className="w-4 h-4" />
                <span>My Listings</span>
              </Link>
              <Link
                to="/listproperty"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm bg-indigo-900 rounded text-left"
              >
                <Home className="w-4 h-4" />
                <span>List Property</span>
              </Link>
              <Link
                to="/profile"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </Link>
              <Link
                to="/enquiry"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Enquiry</span>
              </Link>
            </nav> */}
            <nav className="space-y-0.5">
              {/* My Listings */}
              <div>
                <button
                  onClick={() => toggleMenu("mylistings")}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
                >
                  <div className="flex items-center gap-3">
                    <Home className="w-4 h-4" />
                    <span>My Listings</span>
                  </div>
                  {openMenu === "mylistings" ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>

                {/* Submenu for My Listings */}
                {openMenu === "mylistings" && (
                  <div className="ml-8 mt-1 space-y-1">
                    <Link
                      to="/mylistings/commercial"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Commercial
                    </Link>
                    <Link
                      to="/mylistings/residential"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Residential
                    </Link>
                    <Link
                      to="/mylistings/pg"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      PG
                    </Link>
                  </div>
                )}
              </div>

              {/* List Property */}
              <div>
                <button
                  onClick={() => toggleMenu("listproperty")}
                  className="w-full flex items-center justify-between gap-3 px-3 py-2 text-sm bg-indigo-900 rounded text-left"
                >
                  <div className="flex items-center gap-3">
                    <Home className="w-4 h-4" />
                    <span>List Property</span>
                  </div>
                  {openMenu === "listproperty" ? (
                    <ChevronDown className="w-4 h-4" />
                  ) : (
                    <ChevronRight className="w-4 h-4" />
                  )}
                </button>

                {/* Submenu for List Property */}
                {openMenu === "listproperty" && (
                  <div className="ml-8 mt-1 space-y-1">
                    <Link
                      to="/listproperty/commercial"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Commercial
                    </Link>
                    <Link
                      to="/listproperty/residential"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      Residential
                    </Link>
                    <Link
                      to="/listproperty/pg"
                      className="block text-sm px-3 py-1 hover:bg-indigo-900 rounded"
                    >
                      PG
                    </Link>
                  </div>
                )}
              </div>

              {/* Profile */}
              <Link
                to="/profile"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <User className="w-4 h-4" />
                <span>Profile</span>
              </Link>

              {/* Enquiry */}
              <Link
                to="/enquiry"
                className="w-full flex items-center gap-3 px-3 py-2 text-sm hover:bg-indigo-900 rounded text-left"
              >
                <HelpCircle className="w-4 h-4" />
                <span>Enquiry</span>
              </Link>
            </nav>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto bg-white rounded shadow-sm">
          <div className="max-w-4xl mx-auto p-6">
            <h1 className="text-2xl font-semibold mb-6">Property Listing</h1>

            <form onSubmit={handleSubmit}>
              {/* Hidden user_id field */}
              <input type="hidden" name="user_id" value={formData.user_id} />

              {/* Step 1: Basic Information */}
              <div className="mb-6">
                <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                  <h2 className="font-medium">Step 1: Basic information</h2>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">Name</label>
                  <input
                    type="text"
                    name="name"
                    placeholder="Enter property name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Looking to <span className="text-red-500">*</span>
                    </label>
                    <select
                      name="looking_to"
                      value={formData.looking_to}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select</option>
                      <option value="1">Sell</option>
                      <option value="2">Rent</option>
                      <option value="3">Commercial Sell</option>
                      <option value="4">Commercial Rent</option>
                      <option value="5">New Project</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Property type <span className="text-red-500">*</span>
                    </label>
                    <select
                      name="propertyType"
                      value={formData.propertyType}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select First Looking To</option>
                      <option value="apartment">Apartment</option>
                      <option value="villa">Villa</option>
                      <option value="house">House</option>
                    </select>
                  </div>
                </div>
              </div>

              {/* Step 2: Location */}
              <div className="mb-6">
                <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                  <h2 className="font-medium">Step 2: Location</h2>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Country
                    </label>
                    <select
                      name="country"
                      value={formData.country}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    >
                      <option value="">Select Country</option>
                      <option value="2">India</option>
                      <option value="3">USA</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      City <span className="text-red-500">*</span>
                    </label>
                    <select
                      name="city"
                      value={formData.city}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    >
                      <option value="">Select City</option>
                      <option value="mumbai">Mumbai</option>
                      <option value="delhi">Delhi</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Locality <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="text"
                      name="locality"
                      placeholder="Enter locality"
                      value={formData.locality}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Sub locality
                    </label>
                    <input
                      type="text"
                      name="subLocality"
                      placeholder="Enter sub locality"
                      value={formData.subLocality}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>
              </div>

              {/* Step 3: Property Profile */}
              <div className="mb-6">
                <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                  <h2 className="font-medium">Step 3: Property Profile</h2>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Bedrooms <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      name="bedrooms"
                      value={formData.bedrooms}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Bathrooms <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      name="bathrooms"
                      value={formData.bathrooms}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                      min="0"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Balconies <span className="text-red-500">*</span>
                    </label>
                    <input
                      type="number"
                      name="balconies"
                      value={formData.balconies}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      required
                      min="0"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Currency
                    </label>
                    <input
                      type="text"
                      name="currency"
                      placeholder="e.g., USD, INR"
                      value={formData.currency}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Expected price
                    </label>
                    <input
                      type="text"
                      name="expectedPrice"
                      placeholder="Enter expected price"
                      value={formData.expectedPrice}
                      onChange={handleInputChange}
                      className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </div>
                </div>

                <div className="mb-4">
                  <label className="block text-sm font-medium mb-2">
                    Description
                  </label>
                  <textarea
                    name="description"
                    placeholder="Enter property description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="4"
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                </div>
              </div>

              {/* Step 4: Amenities */}
              <div className="mb-6">
                <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                  <h2 className="font-medium">Step 4: Amenities</h2>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Available amenities
                    </label>
                    <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
                      {availableAmenities
                        .filter((a) => !chosenAmenities.includes(a))
                        .map((amenity) => (
                          <div
                            key={amenity}
                            onClick={() => moveAmenityToChosen(amenity)}
                            className="px-2 py-1 text-sm hover:bg-blue-50 cursor-pointer rounded"
                          >
                            {amenity}
                          </div>
                        ))}
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Chosen amenities
                    </label>
                    <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
                      {chosenAmenities.map((amenity) => (
                        <div
                          key={amenity}
                          onClick={() => removeAmenityFromChosen(amenity)}
                          className="px-2 py-1 text-sm hover:bg-red-50 cursor-pointer rounded flex justify-between items-center"
                        >
                          <span>{amenity}</span>
                          <X size={14} className="text-red-500" />
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Step 5: Payment Plans */}
              <div className="mb-6">
                <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
                  <h2 className="font-medium">Step 5: Payment Plans</h2>
                </div>

                {paymentPlans.map((plan, index) => (
                  <div
                    key={index}
                    className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4 items-end"
                  >
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Payment name
                      </label>
                      <input
                        type="text"
                        value={plan.name}
                        onChange={(e) =>
                          handlePaymentPlanChange(index, "name", e.target.value)
                        }
                        className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                      />
                    </div>
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <label className="block text-sm font-medium mb-2">
                          Amount
                        </label>
                        <input
                          type="text"
                          value={plan.amount}
                          onChange={(e) =>
                            handlePaymentPlanChange(
                              index,
                              "amount",
                              e.target.value
                            )
                          }
                          className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                        />
                      </div>
                      {paymentPlans.length > 1 && (
                        <button
                          type="button"
                          onClick={() => removePaymentPlan(index)}
                          className="bg-red-500 text-white p-2 rounded hover:bg-red-600 flex-shrink-0 self-end"
                        >
                          <X size={20} />
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                <button
                  type="button"
                  onClick={addPaymentPlan}
                  className="text-blue-600 border border-blue-600 px-4 py-2 rounded hover:bg-blue-50"
                >
                  + Add Payment Plan
                </button>
              </div>

              {/* Submit Button */}
              <div className="flex justify-end">
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
                >
                  {isSubmitting ? "Submitting..." : "Submit Property"}
                </button>
              </div>
            </form>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
};

export default PropertyListingForm;
