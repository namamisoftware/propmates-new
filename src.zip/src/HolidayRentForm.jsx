import React, { useState, useEffect, useRef } from "react";
import {
  Home,
  User,
  HelpCircle,
  X,
  ChevronDown,
  ChevronRight,
  MapPin,
  Navigation,
} from "lucide-react";
import { Country, State, City } from "country-state-city";
import Header from "./Components/Header";
import AboveHeader from "./Components/AboveHeader";
import Footer from "./Components/Footer";
import { Link } from "react-router-dom";

const PropertyListingForm = () => {
  const [propertyVideo, setPropertyVideo] = useState(null);
  const [videoPreview, setVideoPreview] = useState(null);
  const handleVideoUpload = (e) => {
    const file = e.target.files[0];

    if (!file) return;

    // Check file size (100MB limit)
    const maxSize = 100 * 1024 * 1024; // 100MB in bytes
    if (file.size > maxSize) {
      alert("Video file is too large. Maximum size is 100MB.");
      return;
    }

    // Check file type
    const allowedTypes = ["video/mp4", "video/quicktime", "video/x-msvideo"];
    if (!allowedTypes.includes(file.type)) {
      alert("Invalid file type. Please upload MP4, MOV, or AVI format.");
      return;
    }

    // Create preview URL
    const previewUrl = URL.createObjectURL(file);

    setPropertyVideo(file);
    setVideoPreview(previewUrl);
  };

  const removeVideo = () => {
    // Revoke the URL to free memory
    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }

    setPropertyVideo(null);
    setVideoPreview(null);
  };

  const [imageCategories] = useState([
    { id: "exterior", label: "Exterior View", required: true },
    { id: "living", label: "Living Room", required: false },
    { id: "bedroom", label: "Bedroom", required: false },
    { id: "bathroom", label: "Bathroom", required: false },
    { id: "kitchen", label: "Kitchen", required: false },
    { id: "floorplan", label: "Floor Plan", required: false },
    { id: "masterplan", label: "Master Plan", required: false },
    { id: "locationmap", label: "Location Map", required: false },
    { id: "other", label: "Other", required: false },
  ]);

  const [activeImageTab, setActiveImageTab] = useState("exterior");
  const [categorizedImages, setCategorizedImages] = useState({
    exterior: [],
    living: [],
    bedroom: [],
    bathroom: [],
    kitchen: [],
    floorplan: [],
    masterplan: [],
    locationmap: [],
    other: [],
  });
  const [categorizedPreviews, setCategorizedPreviews] = useState({
    exterior: [],
    living: [],
    bedroom: [],
    bathroom: [],
    kitchen: [],
    floorplan: [],
    masterplan: [],
    locationmap: [],
    other: [],
  });
  const handleCategorizedImageUpload = (e, category) => {
    const files = Array.from(e.target.files);

    // Limit to 10 images per category
    if (categorizedImages[category].length + files.length > 10) {
      alert(`You can upload a maximum of 10 images per category`);
      return;
    }

    // Create preview URLs
    const newPreviewUrls = files.map((file) => URL.createObjectURL(file));

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: [...prev[category], ...files],
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: [...prev[category], ...newPreviewUrls],
    }));
  };

  const removeCategorizedImage = (category, index) => {
    // Revoke the URL to free memory
    URL.revokeObjectURL(categorizedPreviews[category][index]);

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: prev[category].filter((_, i) => i !== index),
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: prev[category].filter((_, i) => i !== index),
    }));
  };

  const setDefaultCategorizedImage = (category, index) => {
    const newImages = [...categorizedImages[category]];
    const newPreviews = [...categorizedPreviews[category]];

    // Move selected image to first position
    const [selectedImage] = newImages.splice(index, 1);
    const [selectedPreview] = newPreviews.splice(index, 1);

    newImages.unshift(selectedImage);
    newPreviews.unshift(selectedPreview);

    setCategorizedImages((prev) => ({
      ...prev,
      [category]: newImages,
    }));

    setCategorizedPreviews((prev) => ({
      ...prev,
      [category]: newPreviews,
    }));
  };

  // Get total image count across all categories
  const getTotalImageCount = () => {
    return Object.values(categorizedImages).reduce(
      (total, imgs) => total + imgs.length,
      0
    );
  };

  // Get image count for a specific category
  const getCategoryImageCount = (category) => {
    return categorizedImages[category]?.length || 0;
  };

  const getCategoryTip = (categoryId) => {
    const tips = {
      exterior:
        "Include front view, entrance, and building facade. Good lighting is essential.",
      living: "Show the layout, furniture arrangement, and natural lighting.",
      bedroom:
        "Capture the bed, storage space, and windows. Show room size clearly.",
      bathroom: "Include toilet, shower/bathtub, and sink. Ensure cleanliness.",
      kitchen:
        "Show appliances, counter space, and storage. Highlight modern features.",
      floorplan:
        "Upload clear floor plan images showing room layouts and dimensions.",
      masterplan: "Include the complete property master plan or site layout.",
      locationmap:
        "Upload maps showing nearby landmarks, metro stations, and important locations.",
      other:
        "Upload any additional photos like balcony, garden, or special features.",
    };
    return tips[categoryId] || "Upload clear, well-lit photos.";
  };

  const countries = Country.getAllCountries();
  const countryOptions = countries.map((c) => ({
    value: c.isoCode,
    label: c.name,
  }));

  const getStateOptions = (countryCode) => {
    const states = State.getStatesOfCountry(countryCode);
    return states.map((s) => ({
      value: s.isoCode,
      label: s.name,
    }));
  };

  const getCityOptions = (countryCode, stateCode) => {
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities.map((c) => ({
      value: c.name,
      label: c.name,
    }));
  };

  const hasStates = (countryCode) => {
    if (!countryCode) return false;
    const states = State.getStatesOfCountry(countryCode);
    return states && states.length > 0;
  };

  const hasCities = (countryCode, stateCode) => {
    if (!countryCode || !stateCode) return false;
    const cities = City.getCitiesOfState(countryCode, stateCode);
    return cities && cities.length > 0;
  };

  const [formData, setFormData] = useState({
    propertyTitle: "",
    propertyType: "",
    listingType: "",
    currency: "",
    price: "",
    priceType: "",
    availabilityFrom: "",
    availabilityTo: "",
    description: "",
    country: "",
    state: "",
    city: "",
    address: "",
    latitude: 25.2048,
    longitude: 55.2708,
    bedrooms: "",
    bathrooms: "",
    balconies: "",
    builtUpArea: "",
    carpetArea: "",
    plotArea: "",
    furnishing: "",
    parkingSpaces: "",
    floorNumber: "",
    totalFloors: "",
    facingDirection: "",
    propertyAge: "",
    beachDistance: "",
    beachDistanceUnit: "meters",
    marketDistance: "",
    marketDistanceUnit: "km",
    restaurantDistance: "",
    restaurantDistanceUnit: "meters",
    airportDistance: "",
    airportDistanceUnit: "minutes",
    hospitalDistance: "",
    hospitalDistanceUnit: "km",
    metroDistance: "",
    metroDistanceUnit: "meters",
    listedBy: "",
    ownerName: "",
    contactNumber: "",
    emailAddress: "",
    profilePhoto: null,
    profilePhotoPreview: null,
    metaTitle: "",
    metaDescription: "",
    tags: "",
    featureListing: false,
  });

  const [availableAmenities] = useState([
    "Swimming Pool",
    "Gym",
    "Security",
    "Kids Play Area",
    "Garden",
    "Lift/Elevator",
    "Club House",
    "Maids Room",
    "Covered Parking",
    "Basement Parking",
    "Central AC",
    "Central Heating",
    "Private Pool",
    "Private Garden",
    "Private Gym",
    "Balcony",
    "Built-in Wardrobes",
    "Walk-in Closet",
    "Built-in Kitchen Appliances",
    "Study Room",
    "Private Jacuzzi",
    "Steam Room",
    "Sauna",
    "Concierge Service",
    "Business Center",
    "Conference Room",
    "BBQ Area",
    "Children's Pool",
    "Shared Pool",
    "Shared Gym",
    "Shared Spa",
    "24/7 Security",
    "CCTV Security",
    "Intercom",
    "Maintenance Staff",
    "Pets Allowed",
    "Nearby Metro",
    "Beach Access",
    "Storage Room",
    "Laundry Room",
    "Parking",
  ]);
  const [chosenAmenities, setChosenAmenities] = useState([]);
  const [paymentPlans, setPaymentPlans] = useState([{ name: "", amount: "" }]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const mapRef = useRef(null);
  const mapInstanceRef = useRef(null);
  const markerRef = useRef(null);
  const [mapLoaded, setMapLoaded] = useState(false);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const moveAmenityToChosen = (amenity) => {
    setChosenAmenities((prev) => [...prev, amenity]);
  };

  const removeAmenityFromChosen = (amenity) => {
    setChosenAmenities((prev) => prev.filter((a) => a !== amenity));
  };

  // Initialize map
  useEffect(() => {
    if (mapRef.current && !mapInstanceRef.current && window.L) {
      const map = window.L.map(mapRef.current).setView(
        [formData.latitude, formData.longitude],
        13
      );

      window.L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution:
          '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors',
      }).addTo(map);

      const marker = window.L.marker([formData.latitude, formData.longitude], {
        draggable: true,
      }).addTo(map);

      marker.on("dragend", function (e) {
        const position = e.target.getLatLng();
        setFormData((prev) => ({
          ...prev,
          latitude: position.lat.toFixed(6),
          longitude: position.lng.toFixed(6),
        }));
        reverseGeocode(position.lat, position.lng);
      });

      map.on("click", function (e) {
        const { lat, lng } = e.latlng;
        marker.setLatLng([lat, lng]);
        setFormData((prev) => ({
          ...prev,
          latitude: lat.toFixed(6),
          longitude: lng.toFixed(6),
        }));
        reverseGeocode(lat, lng);
      });

      mapInstanceRef.current = map;
      markerRef.current = marker;
      setMapLoaded(true);
    }
  }, []);

  // Update map when coordinates change externally
  useEffect(() => {
    if (mapInstanceRef.current && markerRef.current && mapLoaded) {
      mapInstanceRef.current.setView(
        [formData.latitude, formData.longitude],
        13
      );
      markerRef.current.setLatLng([formData.latitude, formData.longitude]);
    }
  }, [formData.country, formData.city]);

  const reverseGeocode = async (lat, lng) => {
    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`
      );
      const data = await response.json();
      if (data.display_name) {
        setFormData((prev) => ({
          ...prev,
          address: data.display_name,
        }));
      }
    } catch (error) {
      console.error("Reverse geocoding error:", error);
    }
  };

  const searchAddress = async () => {
    if (!formData.address) return;

    try {
      const response = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(
          formData.address
        )}`
      );
      const data = await response.json();
      if (data && data.length > 0) {
        const { lat, lon } = data[0];
        setFormData((prev) => ({
          ...prev,
          latitude: parseFloat(lat).toFixed(6),
          longitude: parseFloat(lon).toFixed(6),
        }));
        if (mapInstanceRef.current && markerRef.current) {
          mapInstanceRef.current.setView([lat, lon], 15);
          markerRef.current.setLatLng([lat, lon]);
        }
      } else {
        alert("Address not found. Please try a different search term.");
      }
    } catch (error) {
      console.error("Geocoding error:", error);
      alert("Error searching for address. Please try again.");
    }
  };

  const useCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const lat = position.coords.latitude;
          const lng = position.coords.longitude;
          setFormData((prev) => ({
            ...prev,
            latitude: lat.toFixed(6),
            longitude: lng.toFixed(6),
          }));
          if (mapInstanceRef.current && markerRef.current) {
            mapInstanceRef.current.setView([lat, lng], 15);
            markerRef.current.setLatLng([lat, lng]);
          }
          reverseGeocode(lat, lng);
        },
        (error) => {
          alert(
            "Unable to retrieve your location. Please enable location services."
          );
        }
      );
    } else {
      alert("Geolocation is not supported by your browser.");
    }
  };

  const handleCountryChange = (e) => {
    const value = e.target.value;
    const country = countries.find((c) => c.isoCode === value);
    setFormData((prev) => ({
      ...prev,
      country: value,
      state: "",
      city: "",
      latitude: country ? country.latitude : prev.latitude,
      longitude: country ? country.longitude : prev.longitude,
    }));
  };

  const handleStateChange = (e) => {
    const value = e.target.value;
    const states = State.getStatesOfCountry(formData.country);
    const state = states.find((s) => s.isoCode === value);
    setFormData((prev) => ({
      ...prev,
      state: value,
      city: "",
      latitude: state ? state.latitude : prev.latitude,
      longitude: state ? state.longitude : prev.longitude,
    }));
  };

  const handleCityChange = (e) => {
    const value = e.target.value;
    const cities = City.getCitiesOfState(formData.country, formData.state);
    const city = cities.find((c) => c.name === value);
    setFormData((prev) => ({
      ...prev,
      city: value,
      latitude: city ? city.latitude : prev.latitude,
      longitude: city ? city.longitude : prev.longitude,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate required category (Exterior View)
    if (categorizedImages.exterior.length === 0) {
      alert("Please upload at least one Exterior View image");
      setActiveImageTab("exterior"); // Switch to exterior tab
      return;
    }

    // Check total images
    const totalImages = getTotalImageCount();
    if (totalImages === 0) {
      alert("Please upload at least one image");
      return;
    }

    setIsSubmitting(true);

    const propertyData = {
      ...formData,
      amenities: chosenAmenities,
      paymentPlans: paymentPlans,
      images: categorizedImages,
      totalImages: totalImages,
      video: propertyVideo
        ? {
            name: propertyVideo.name,
            size: propertyVideo.size,
            type: propertyVideo.type,
          }
        : null,
      imagesByCategory: Object.entries(categorizedImages).map(
        ([category, images]) => ({
          category,
          count: images.length,
        })
      ),
    };

    console.log("Property data:", propertyData);
    alert(
      `Property submitted with ${totalImages} images${
        propertyVideo ? " and 1 video" : ""
      }!`
    );

    // Cleanup preview URLs
    Object.values(categorizedPreviews).forEach((previews) => {
      previews.forEach((url) => URL.revokeObjectURL(url));
    });

    if (videoPreview) {
      URL.revokeObjectURL(videoPreview);
    }

    setFormData({
      propertyTitle: "",
      propertyType: "",
      listingType: "",
      currency: "",
      price: "",
      priceType: "",
      availabilityFrom: "",
      availabilityTo: "",
      description: "",
      country: "",
      state: "",
      city: "",
      address: "",
      latitude: 25.2048,
      longitude: 55.2708,
      bedrooms: "",
      bathrooms: "",
      balconies: "",
      builtUpArea: "",
      carpetArea: "",
      plotArea: "",
      furnishing: "",
      parkingSpaces: "",
      floorNumber: "",
      totalFloors: "",
      facingDirection: "",
      propertyAge: "",
      beachDistance: "",
      beachDistanceUnit: "meters",
      marketDistance: "",
      marketDistanceUnit: "km",
      restaurantDistance: "",
      restaurantDistanceUnit: "meters",
      airportDistance: "",
      airportDistanceUnit: "minutes",
      hospitalDistance: "",
      hospitalDistanceUnit: "km",
      metroDistance: "",
      metroDistanceUnit: "meters",
      listedBy: "",
      ownerName: "",
      contactNumber: "",
      emailAddress: "",
      profilePhoto: null,
      profilePhotoPreview: null,
      metaTitle: "",
      metaDescription: "",
      tags: "",
      featureListing: false,
    });
    setChosenAmenities([]);
    setPaymentPlans([{ name: "", amount: "" }]);
    setCategorizedImages({
      exterior: [],
      living: [],
      bedroom: [],
      bathroom: [],
      kitchen: [],
      floorplan: [],
      masterplan: [],
      locationmap: [],
      other: [],
    });
    setCategorizedPreviews({
      exterior: [],
      living: [],
      bedroom: [],
      bathroom: [],
      kitchen: [],
      floorplan: [],
      masterplan: [],
      locationmap: [],
      other: [],
    });
    setActiveImageTab("exterior");
    setPropertyVideo(null);
    setVideoPreview(null);
    setIsSubmitting(false);
  };
  useEffect(() => {
    // Cleanup function to revoke all preview URLs when component unmounts
    return () => {
      // Cleanup image previews
      Object.values(categorizedPreviews).forEach((previews) => {
        previews.forEach((url) => URL.revokeObjectURL(url));
      });

      // Cleanup video preview
      if (videoPreview) {
        URL.revokeObjectURL(videoPreview);
      }

      // Cleanup profile photo preview
      if (formData.profilePhotoPreview) {
        URL.revokeObjectURL(formData.profilePhotoPreview);
      }
    };
  }, [categorizedPreviews, videoPreview, formData.profilePhotoPreview]);

  const [openMenu, setOpenMenu] = useState(null);

  const toggleMenu = (menu) => {
    setOpenMenu(openMenu === menu ? null : menu);
  };

  const stateOptions = formData.country
    ? getStateOptions(formData.country)
    : [];
  const cityOptions =
    formData.country && formData.state
      ? getCityOptions(formData.country, formData.state)
      : [];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Leaflet CSS */}
      <link
        rel="stylesheet"
        href="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.css"
      />
      <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.9.4/leaflet.js"></script>

      <Header />

      <div className="max-w-4xl mx-auto p-6">
        <div className="text-center mb-8">
          <h1 className="text-2xl md:text-4xl font-bold text-gray-800 mb-2">
            Holiday Rent Property
          </h1>
        </div>
        <form onSubmit={handleSubmit}>
          {/* Property Profile */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 1: Property Details</h2>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Property Title <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                name="propertyTitle"
                placeholder="e.g., Luxury Beachfront Villa in Goa"
                value={formData.propertyTitle}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Property Type <span className="text-red-500">*</span>
                </label>
                <select
                  name="propertyType"
                  value={formData.propertyType}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Property Type</option>
                  <option value="villa">Villa</option>
                  <option value="apartment">Apartment</option>
                  <option value="farmhouse">Farmhouse</option>
                  <option value="studio">Studio</option>
                  <option value="plot">Plot</option>
                  <option value="cottage">Cottage</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Listing Type <span className="text-red-500">*</span>
                </label>
                <select
                  name="listingType"
                  value={formData.listingType}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Listing Type</option>
                  <option value="sale">For Sale</option>
                  <option value="rent">For Rent</option>
                  <option value="lease">For Lease</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Currency <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="currency"
                  placeholder="e.g., USD, INR, AED"
                  value={formData.currency}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Price <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="price"
                  placeholder="Enter price"
                  value={formData.price}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Price Type <span className="text-red-500">*</span>
                </label>
                <select
                  name="priceType"
                  value={formData.priceType}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Price Type</option>
                  <option value="fixed">Fixed</option>
                  <option value="negotiable">Negotiable</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Availability From <span className="text-red-500">*</span>
                </label>
                <input
                  type="date"
                  name="availabilityFrom"
                  value={formData.availabilityFrom}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Availability To{" "}
                  <span className="text-gray-500">(Optional)</span>
                </label>
                <input
                  type="date"
                  name="availabilityTo"
                  value={formData.availabilityTo}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <p className="text-xs text-gray-500 mt-1">
                  Leave blank for long-term availability
                </p>
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Description <span className="text-red-500">*</span>
              </label>
              <textarea
                name="description"
                placeholder="Describe your property in detail - highlight unique features, nearby attractions, amenities, etc."
                value={formData.description}
                onChange={handleInputChange}
                rows="5"
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                required
              />
            </div>
          </div>

          {/*Location */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 2: Location</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Country <span className="text-red-500">*</span>
                </label>
                <select
                  name="country"
                  value={formData.country}
                  onChange={handleCountryChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select Country</option>
                  {countryOptions.map((country) => (
                    <option key={country.value} value={country.value}>
                      {country.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  State / Region <span className="text-red-500">*</span>
                </label>
                {hasStates(formData.country) ? (
                  <select
                    name="state"
                    value={formData.state}
                    onChange={handleStateChange}
                    disabled={!formData.country}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                  >
                    <option value="">Select State</option>
                    {stateOptions.map((state) => (
                      <option key={state.value} value={state.value}>
                        {state.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    name="state"
                    value={formData.state}
                    onChange={handleInputChange}
                    disabled={!formData.country}
                    placeholder="Enter State/Province/Region"
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                  />
                )}
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">
                  City <span className="text-red-500">*</span>
                </label>
                {hasCities(formData.country, formData.state) ? (
                  <select
                    name="city"
                    value={formData.city}
                    onChange={handleCityChange}
                    disabled={!formData.country || !formData.state}
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                  >
                    <option value="">Select City</option>
                    {cityOptions.map((city) => (
                      <option key={city.value} value={city.value}>
                        {city.label}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    name="city"
                    value={formData.city}
                    onChange={handleInputChange}
                    disabled={!formData.country || !formData.state}
                    placeholder="Enter City"
                    className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:bg-gray-50 disabled:text-gray-600"
                  />
                )}
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Address / Map Location
              </label>
              <div className="flex gap-2">
                <input
                  type="text"
                  name="address"
                  placeholder="Enter full address"
                  value={formData.address}
                  onChange={handleInputChange}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <button
                  type="button"
                  onClick={searchAddress}
                  className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 flex items-center gap-2"
                >
                  <MapPin size={16} />
                  <span className="hidden md:block">Search</span>
                </button>
                <button
                  type="button"
                  onClick={useCurrentLocation}
                  className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 flex items-center gap-2"
                  title="Use my current location"
                >
                  <Navigation size={16} />
                </button>
              </div>
            </div>

            <div className="mb-4">
              <div
                ref={mapRef}
                className="w-full h-96 rounded border border-gray-300"
              ></div>
              <div className="mt-2 text-sm text-gray-600 flex gap-4">
                <span>
                  <strong>Latitude:</strong> {formData.latitude}
                </span>
                <span>
                  <strong>Longitude:</strong> {formData.longitude}
                </span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                Click on the map or drag the marker to select precise location
              </p>
            </div>
          </div>

          {/* Property Specifications */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 3: Property Specifications</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Bedrooms <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="bedrooms"
                  placeholder="e.g., 4"
                  value={formData.bedrooms}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Bathrooms <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="bathrooms"
                  placeholder="e.g., 5"
                  value={formData.bathrooms}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Balconies
                </label>
                <input
                  type="number"
                  name="balconies"
                  placeholder="e.g., 2"
                  value={formData.balconies}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Built-up Area (sq. ft.)
                </label>
                <input
                  type="number"
                  name="builtUpArea"
                  placeholder="e.g., 3200"
                  value={formData.builtUpArea}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Carpet Area (sq. ft.)
                </label>
                <input
                  type="number"
                  name="carpetArea"
                  placeholder="e.g., 2850"
                  value={formData.carpetArea}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Plot Area (sq. ft.)
                </label>
                <input
                  type="number"
                  name="plotArea"
                  placeholder="e.g., 4000"
                  value={formData.plotArea}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Furnishing <span className="text-red-500">*</span>
                </label>
                <select
                  name="furnishing"
                  value={formData.furnishing}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Furnishing</option>
                  <option value="fully">Fully Furnished</option>
                  <option value="semi">Semi Furnished</option>
                  <option value="unfurnished">Unfurnished</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Parking Spaces <span className="text-red-500">*</span>
                </label>
                <input
                  type="number"
                  name="parkingSpaces"
                  placeholder="e.g., 2"
                  value={formData.parkingSpaces}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Floor Number <span className="text-gray-500">(Optional)</span>
                </label>
                <input
                  type="number"
                  name="floorNumber"
                  placeholder="e.g., 2"
                  value={formData.floorNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Total Floors <span className="text-gray-500">(Optional)</span>
                </label>
                <input
                  type="number"
                  name="totalFloors"
                  placeholder="e.g., 3"
                  value={formData.totalFloors}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  min="0"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Facing Direction <span className="text-red-500">*</span>
                </label>
                <select
                  name="facingDirection"
                  value={formData.facingDirection}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Direction</option>
                  <option value="north">North</option>
                  <option value="south">South</option>
                  <option value="east">East</option>
                  <option value="west">West</option>
                  <option value="north-east">North-East</option>
                  <option value="north-west">North-West</option>
                  <option value="south-east">South-East</option>
                  <option value="south-west">South-West</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Property Age <span className="text-red-500">*</span>
                </label>
                <select
                  name="propertyAge"
                  value={formData.propertyAge}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Property Age</option>
                  <option value="new">New / Under Construction</option>
                  <option value="<5">Less than 5 Years</option>
                  <option value="5-10">5-10 Years</option>
                  <option value=">10">More than 10 Years</option>
                </select>
              </div>
            </div>
          </div>

          {/* Amenities */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 4: Amenities</h2>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Available amenities
                </label>
                <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
                  {availableAmenities
                    .filter((a) => !chosenAmenities.includes(a))
                    .map((amenity) => (
                      <div
                        key={amenity}
                        onClick={() => moveAmenityToChosen(amenity)}
                        className="px-2 py-1 text-sm hover:bg-blue-50 cursor-pointer rounded"
                      >
                        {amenity}
                      </div>
                    ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Chosen amenities
                </label>
                <div className="border border-gray-300 rounded p-2 h-32 overflow-y-auto bg-white">
                  {chosenAmenities.map((amenity) => (
                    <div
                      key={amenity}
                      onClick={() => removeAmenityFromChosen(amenity)}
                      className="px-2 py-1 text-sm hover:bg-red-50 cursor-pointer rounded flex justify-between items-center"
                    >
                      <span>{amenity}</span>
                      <X size={14} className="text-red-500" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Nearby Attractions */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">
                Step 5: Nearby Attractions (Optional)
              </h2>
            </div>

            <p className="text-sm text-gray-600 mb-4">
              Add distances to nearby attractions and amenities to help guests
              understand the location better.
            </p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Beach Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="beachDistance"
                    placeholder="e.g., 200"
                    value={formData.beachDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="beachDistanceUnit"
                    value={formData.beachDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Market Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="marketDistance"
                    placeholder="e.g., 1"
                    value={formData.marketDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="marketDistanceUnit"
                    value={formData.marketDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Restaurant Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="restaurantDistance"
                    placeholder="e.g., 500"
                    value={formData.restaurantDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="restaurantDistanceUnit"
                    value={formData.restaurantDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Airport Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="airportDistance"
                    placeholder="e.g., 20"
                    value={formData.airportDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="airportDistanceUnit"
                    value={formData.airportDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Hospital Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="hospitalDistance"
                    placeholder="e.g., 2"
                    value={formData.hospitalDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="hospitalDistanceUnit"
                    value={formData.hospitalDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Metro/Train Station Distance
                </label>
                <div className="flex gap-2">
                  <input
                    type="number"
                    name="metroDistance"
                    placeholder="e.g., 800"
                    value={formData.metroDistance}
                    onChange={handleInputChange}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                    min="0"
                  />
                  <select
                    name="metroDistanceUnit"
                    value={formData.metroDistanceUnit}
                    onChange={handleInputChange}
                    className="w-32 px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="meters">Meters</option>
                    <option value="km">KM</option>
                    <option value="minutes">Minutes</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-4 p-3 bg-blue-50 rounded-lg">
              <p className="text-xs text-blue-800">
                <strong>Tip:</strong> Providing distance information helps
                guests plan their stay better. You can specify distances in
                meters, kilometers, or travel time in minutes.
              </p>
            </div>
          </div>

          {/* Images */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 4: Property Images</h2>
            </div>

            <div className="mb-4">
              <p className="text-sm text-gray-600 mb-3">
                Upload images for different areas of your property. Exterior
                View is required.
              </p>

              <div className="border-b border-gray-300 mb-4">
                <div className="flex overflow-x-auto">
                  {imageCategories.map((category) => (
                    <button
                      key={category.id}
                      type="button"
                      onClick={() => setActiveImageTab(category.id)}
                      className={`px-4 py-2 text-sm font-medium whitespace-nowrap border-b-2 transition-colors ${
                        activeImageTab === category.id
                          ? "border-blue-600 text-blue-600"
                          : "border-transparent text-gray-600 hover:text-gray-800"
                      }`}
                    >
                      {category.label}
                      {category.required && (
                        <span className="text-red-500 ml-1">*</span>
                      )}
                      {getCategoryImageCount(category.id) > 0 && (
                        <span className="ml-2 bg-blue-100 text-blue-600 px-2 py-0.5 rounded-full text-xs">
                          {getCategoryImageCount(category.id)}
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </div>

              <div className="min-h-[300px]">
                {imageCategories.map((category) => (
                  <div
                    key={category.id}
                    className={
                      activeImageTab === category.id ? "block" : "hidden"
                    }
                  >
                    <div className="mb-3">
                      <label className="block text-sm font-medium mb-2">
                        {category.label} Images (Max 10)
                        {category.required && (
                          <span className="text-red-500 ml-1">*</span>
                        )}
                      </label>
                      <p className="text-xs text-gray-500">
                        {categorizedPreviews[category.id].length === 0
                          ? "No images uploaded yet. "
                          : "First image will be the default. "}
                        Click "Set as Default" to change the main image.
                      </p>
                    </div>

                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                      {categorizedPreviews[category.id].map((url, index) => (
                        <div key={index} className="relative group">
                          <div className="aspect-square border-2 border-gray-300 rounded-lg overflow-hidden bg-gray-50">
                            <img
                              src={url}
                              alt={`${category.label} ${index + 1}`}
                              className="w-full h-full object-cover"
                            />
                          </div>

                          {index === 0 && (
                            <div className="absolute top-2 left-2 bg-blue-600 text-white text-xs px-2 py-1 rounded shadow-md">
                              Default
                            </div>
                          )}

                          <div className="absolute bottom-2 left-2 bg-black bg-opacity-60 text-white text-xs px-2 py-1 rounded">
                            {index + 1}/
                            {categorizedPreviews[category.id].length}
                          </div>

                          <div className="absolute inset-0 bg-[#000000b6] bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 flex items-center justify-center gap-2 opacity-0 group-hover:opacity-100">
                            {index !== 0 && (
                              <button
                                type="button"
                                onClick={() =>
                                  setDefaultCategorizedImage(category.id, index)
                                }
                                className="bg-blue-600 text-white text-xs px-3 py-1.5 rounded hover:bg-blue-700 transition-colors"
                              >
                                Set Default
                              </button>
                            )}
                            <button
                              type="button"
                              onClick={() =>
                                removeCategorizedImage(category.id, index)
                              }
                              className="bg-red-600 text-white p-1.5 rounded hover:bg-red-700 transition-colors"
                              title="Remove image"
                            >
                              <X size={16} />
                            </button>
                          </div>
                        </div>
                      ))}

                      {categorizedImages[category.id].length < 10 && (
                        <label className="aspect-square border-2 border-dashed border-gray-300 rounded-lg flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                          <div className="text-center p-4">
                            <div className="w-12 h-12 mx-auto mb-2 flex items-center justify-center">
                              <svg
                                className="w-8 h-8 text-gray-400"
                                fill="none"
                                stroke="currentColor"
                                viewBox="0 0 24 24"
                              >
                                <path
                                  strokeLinecap="round"
                                  strokeLinejoin="round"
                                  strokeWidth={2}
                                  d="M12 4v16m8-8H4"
                                />
                              </svg>
                            </div>
                            <span className="text-sm text-gray-600 font-medium">
                              Add more photos
                            </span>
                            <span className="text-xs text-gray-500 block mt-1">
                              {10 - categorizedImages[category.id].length}{" "}
                              remaining
                            </span>
                          </div>
                          <input
                            type="file"
                            accept="image/*"
                            multiple
                            onChange={(e) =>
                              handleCategorizedImageUpload(e, category.id)
                            }
                            className="hidden"
                          />
                        </label>
                      )}
                    </div>

                    <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                      <p className="text-xs text-blue-800">
                        <strong>Tip:</strong> {getCategoryTip(category.id)}
                      </p>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-4 p-4 bg-gray-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium text-gray-700">
                    Total Images Uploaded:
                  </span>
                  <span className="text-sm font-semibold text-blue-600">
                    {getTotalImageCount()} images
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Video */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 5: Property Video (Optional)</h2>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Upload Property Video
              </label>
              <p className="text-xs text-gray-500 mb-3">
                Upload a video tour of your property (Max size: 100MB, Formats:
                MP4, MOV, AVI)
              </p>

              {!propertyVideo ? (
                <label className="w-full border-2 border-dashed border-gray-300 rounded-lg p-8 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-4 flex items-center justify-center bg-gray-100 rounded-full">
                      <svg
                        className="w-8 h-8 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z"
                        />
                      </svg>
                    </div>
                    <span className="text-base text-gray-700 font-medium block mb-1">
                      Click to upload video
                    </span>
                    <span className="text-sm text-gray-500">
                      or drag and drop
                    </span>
                    <span className="text-xs text-gray-400 block mt-2">
                      MP4, MOV or AVI (MAX. 100MB)
                    </span>
                  </div>
                  <input
                    type="file"
                    accept="video/mp4,video/quicktime,video/x-msvideo"
                    onChange={handleVideoUpload}
                    className="hidden"
                  />
                </label>
              ) : (
                <div className="border-2 border-gray-300 rounded-lg overflow-hidden">
                  <div className="relative bg-black">
                    <video
                      src={videoPreview}
                      controls
                      className="w-full max-h-96 object-contain"
                    >
                      Your browser does not support the video tag.
                    </video>
                  </div>

                  <div className="p-4 bg-gray-50">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-700 mb-1">
                          {propertyVideo.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          Size:{" "}
                          {(propertyVideo.size / (1024 * 1024)).toFixed(2)} MB
                        </p>
                      </div>
                      <button
                        type="button"
                        onClick={removeVideo}
                        className="ml-4 bg-red-600 text-white px-4 py-2 rounded hover:bg-red-700 transition-colors flex items-center gap-2"
                      >
                        <X size={16} />
                        Remove
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="mt-4 p-3 bg-blue-50 rounded-lg">
                <p className="text-xs text-blue-800">
                  <strong>Tips for a great video:</strong>
                </p>
                <ul className="text-xs text-blue-700 mt-2 ml-4 list-disc space-y-1">
                  <li>Keep it short and engaging (1-3 minutes recommended)</li>
                  <li>Show all rooms and important features</li>
                  <li>Use good lighting and stable camera movement</li>
                  <li>Start with the exterior and move through each room</li>
                  <li>Highlight unique selling points and amenities</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Owner / Agent Information */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">Step 8: Owner / Agent Information</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Listed By <span className="text-red-500">*</span>
                </label>
                <select
                  name="listedBy"
                  value={formData.listedBy}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                >
                  <option value="">Select Type</option>
                  <option value="owner">Owner</option>
                  <option value="agent">Agent</option>
                  <option value="builder">Builder</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  name="ownerName"
                  placeholder="Owner Name"
                  value={formData.ownerName}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label className="block text-sm font-medium mb-2">
                  Contact Number <span className="text-red-500">*</span>
                </label>
                <input
                  type="tel"
                  name="contactNumber"
                  placeholder="e.g., +91 9876543210"
                  value={formData.contactNumber}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium mb-2">
                  Email Address <span className="text-red-500">*</span>
                </label>
                <input
                  type="email"
                  name="emailAddress"
                  placeholder="e.g., owner@gmail.com"
                  value={formData.emailAddress}
                  onChange={handleInputChange}
                  className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                  required
                />
              </div>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Profile Photo <span className="text-gray-500">(Optional)</span>
              </label>
              <p className="text-xs text-gray-500 mb-3">
                Upload your profile photo or company logo (Max size: 5MB,
                Format: JPG, PNG)
              </p>

              {!formData.profilePhoto ? (
                <label className="w-full border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-500 hover:bg-blue-50 transition-colors">
                  <div className="text-center">
                    <div className="w-16 h-16 mx-auto mb-3 flex items-center justify-center bg-gray-100 rounded-full">
                      <svg
                        className="w-8 h-8 text-gray-400"
                        fill="none"
                        stroke="currentColor"
                        viewBox="0 0 24 24"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          strokeWidth={2}
                          d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                        />
                      </svg>
                    </div>
                    <span className="text-sm text-gray-700 font-medium block mb-1">
                      Click to upload profile photo
                    </span>
                    <span className="text-xs text-gray-500">
                      JPG or PNG (MAX. 5MB)
                    </span>
                  </div>
                  <input
                    type="file"
                    accept="image/jpeg,image/png"
                    onChange={(e) => {
                      const file = e.target.files[0];
                      if (!file) return;

                      const maxSize = 5 * 1024 * 1024;
                      if (file.size > maxSize) {
                        alert("Image file is too large. Maximum size is 5MB.");
                        return;
                      }

                      const previewUrl = URL.createObjectURL(file);
                      setFormData((prev) => ({
                        ...prev,
                        profilePhoto: file,
                        profilePhotoPreview: previewUrl,
                      }));
                    }}
                    className="hidden"
                  />
                </label>
              ) : (
                <div className="border-2 border-gray-300 rounded-lg overflow-hidden inline-block">
                  <div className="relative">
                    <img
                      src={formData.profilePhotoPreview}
                      alt="Profile"
                      className="w-32 h-32 object-cover"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        if (formData.profilePhotoPreview) {
                          URL.revokeObjectURL(formData.profilePhotoPreview);
                        }
                        setFormData((prev) => ({
                          ...prev,
                          profilePhoto: null,
                          profilePhotoPreview: null,
                        }));
                      }}
                      className="absolute top-2 right-2 bg-red-600 text-white p-1 rounded hover:bg-red-700 transition-colors"
                      title="Remove photo"
                    >
                      <X size={16} />
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* SEO & Promotion */}
          <div className="mb-6">
            <div className="bg-gray-100 px-4 py-2 mb-4 rounded">
              <h2 className="font-medium">
                Step 9: SEO & Promotion (Optional)
              </h2>
            </div>

            <p className="text-sm text-gray-600 mb-4">
              Optimize your listing for search engines and increase visibility.
            </p>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Meta Title
              </label>
              <input
                type="text"
                name="metaTitle"
                placeholder="e.g., Luxury Villa in Goa for Sale"
                value={formData.metaTitle}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                maxLength="60"
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.metaTitle.length}/60 characters (recommended length
                for SEO)
              </p>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Meta Description
              </label>
              <textarea
                name="metaDescription"
                placeholder="e.g., Beautiful 4BHK beachfront villa for sale in North Goa. Features modern amenities, private pool, and stunning ocean views."
                value={formData.metaDescription}
                onChange={handleInputChange}
                rows="3"
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
                maxLength="160"
              />
              <p className="text-xs text-gray-500 mt-1">
                {formData.metaDescription.length}/160 characters (recommended
                length for SEO)
              </p>
            </div>

            <div className="mb-4">
              <label className="block text-sm font-medium mb-2">
                Tags / Keywords
              </label>
              <input
                type="text"
                name="tags"
                placeholder="e.g., villa, goa, beachfront, rent, sale"
                value={formData.tags}
                onChange={handleInputChange}
                className="w-full px-3 py-2 border border-gray-300 rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <p className="text-xs text-gray-500 mt-1">
                Separate keywords with commas. Use relevant terms that buyers
                might search for.
              </p>
            </div>

            <div className="mb-4">
              <label className="flex items-center gap-3 cursor-pointer">
                <div className="relative">
                  <input
                    type="checkbox"
                    name="featureListing"
                    checked={formData.featureListing}
                    onChange={handleInputChange}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-300 rounded-full peer peer-checked:bg-blue-600 transition-colors"></div>
                  <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full transition-transform peer-checked:translate-x-5"></div>
                </div>
                <div>
                  <span className="text-sm font-medium">
                    Feature this Listing
                  </span>
                  <p className="text-xs text-gray-500">
                    Highlight your property at the top of search results for
                    better visibility
                  </p>
                </div>
              </label>
            </div>

            <div className="mt-4 p-3 bg-yellow-50 rounded-lg border border-yellow-200">
              <p className="text-xs text-yellow-800">
                <strong>Note:</strong> Featured listings may incur additional
                charges. Your listing will be reviewed before being featured.
              </p>
            </div>
          </div>

          {/* Submit Button */}
          <div className="flex justify-end">
            <button
              type="submit"
              disabled={isSubmitting}
              className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed"
            >
              {isSubmitting ? "Submitting..." : "Submit Property"}
            </button>
          </div>
        </form>
      </div>

      <Footer />
    </div>
  );
};

export default PropertyListingForm;
