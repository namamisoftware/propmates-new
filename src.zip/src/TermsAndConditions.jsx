import React, { useState } from "react";
import ReactCountryFlag from "react-country-flag";
import Header from "./Components/Header";
import Navbar from "./Components/Navbar";
import PropertyFinderFooter from "./Components/Footer";

const TermsAndConditions = () => {
  const [selectedTab, setSelectedTab] = useState("Terms of Use");
  const [selectedCountry, setSelectedCountry] = useState("UAE");
  const [showCountryDropdown, setShowCountryDropdown] = useState(false);

  const tabs = [
    "Terms of Use",
    "Customer Agreement",
    "API Access Terms",
    "PF Expert Terms",
    "Mobile App Terms",
  ];

  const countries = ["UAE", "KSA", "Qatar", "Bahrain", "Egypt"];

  const getCountrySpecificInfo = (country) => {
    const countryInfo = {
      UAE: {
        website: "www.propertyfinder.ae",
        email: "info@propertyfinder.ae",
        entity: "Propertyfinder FZ LLC",
        jurisdiction: "UAE",
        currency: "AED",
        legalAge: "twenty-one (21)",
        regulations: "UAE Real Estate Regulatory Authority (RERA)",
      },
      KSA: {
        website: "www.propertyfinder.sa",
        email: "info@propertyfinder.sa",
        entity: "Propertyfinder Saudi Arabia LLC",
        jurisdiction: "Kingdom of Saudi Arabia",
        currency: "SAR",
        legalAge: "eighteen (18)",
        regulations: "Saudi Real Estate General Authority",
      },
      Qatar: {
        website: "www.propertyfinder.qa",
        email: "info@propertyfinder.qa",
        entity: "Propertyfinder Qatar LLC",
        jurisdiction: "State of Qatar",
        currency: "QAR",
        legalAge: "eighteen (18)",
        regulations: "Qatar Ministry of Municipality and Environment",
      },
      Bahrain: {
        website: "www.propertyfinder.bh",
        email: "info@propertyfinder.bh",
        entity: "Propertyfinder Bahrain WLL",
        jurisdiction: "Kingdom of Bahrain",
        currency: "BHD",
        legalAge: "eighteen (18)",
        regulations: "Bahrain Real Estate Regulatory Authority",
      },
      Egypt: {
        website: "www.propertyfinder.eg",
        email: "info@propertyfinder.eg",
        entity: "Propertyfinder Egypt LLC",
        jurisdiction: "Arab Republic of Egypt",
        currency: "EGP",
        legalAge: "eighteen (18)",
        regulations: "Egyptian Real Estate Investment Authority",
      },
    };
    return countryInfo[country] || countryInfo.UAE;
  };

  const getTabContent = () => {
    const countryInfo = getCountrySpecificInfo(selectedCountry);

    switch (selectedTab) {
      case "Terms of Use":
        return (
          <>
            <h2 className="text-2xl font-bold text-gray-800 mb-8">
              Terms & Conditions For Users - {selectedCountry}
            </h2>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">1.</span>
                <span>Who we are and how to contact us</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  <a href="#" className="text-blue-600 hover:underline">
                    {countryInfo.website}
                  </a>{" "}
                  is a website (the{" "}
                  <span className="font-semibold">"Website"</span>) owned and
                  operated by {countryInfo.entity} and its worldwide affiliates{" "}
                  (<span className="font-semibold">"we"</span>,{" "}
                  <span className="font-semibold">"us"</span> and{" "}
                  <span className="font-semibold">"our"</span>).
                </p>
                <p>
                  To contact us, please email{" "}
                  <a
                    href={`mailto:${countryInfo.email}`}
                    className="text-blue-600 hover:underline"
                  >
                    {countryInfo.email}
                  </a>
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">2.</span>
                <span>You accept these Terms by using the Website</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  These Website terms of use (
                  <span className="font-semibold">"Terms"</span>) constitute a
                  legal agreement between us and you. By using the Website, you
                  confirm that you accept these Terms and that you agree to
                  comply with them. If you do not accept and agree to comply
                  with these Terms, then you must not use the Website.
                </p>
                <p>
                  You may not use the Website and may not accept these Terms if
                  (a) you are not of {countryInfo.legalAge} years of age, or (b)
                  you are a person who is either barred or otherwise legally
                  prohibited from receiving or using the Website under the laws
                  of {countryInfo.jurisdiction} or from which you access or use
                  the Website.
                </p>
                <p className="text-sm text-gray-600 bg-gray-50 p-4 rounded">
                  <strong>Jurisdiction Notice:</strong> These terms are governed
                  by the laws of {countryInfo.jurisdiction} and are subject to
                  regulations by {countryInfo.regulations}.
                </p>
              </div>
            </div>
          </>
        );

      case "Customer Agreement":
        return (
          <>
            <h2 className="text-2xl font-bold text-gray-800 mb-8">
              Customer Agreement - {selectedCountry}
            </h2>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">1.</span>
                <span>Service Agreement</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  This Customer Agreement governs your relationship with
                  PropertyFinder {selectedCountry} as a registered user seeking
                  property services. By creating an account, you agree to
                  provide accurate information and maintain the confidentiality
                  of your login credentials.
                </p>
                <p>
                  We commit to providing you with access to verified property
                  listings in {countryInfo.jurisdiction}, professional real
                  estate agents, and comprehensive market data with prices
                  displayed in {countryInfo.currency} to facilitate your
                  property search experience.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">2.</span>
                <span>Customer Responsibilities</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  As a customer in {countryInfo.jurisdiction}, you agree to use
                  our services responsibly and in accordance with local laws and
                  regulations. You must not misuse our platform for fraudulent
                  activities or provide false information during inquiries.
                </p>
                <p>
                  You are responsible for all activities that occur under your
                  account and must notify us immediately of any unauthorized use
                  of your account.
                </p>
              </div>
            </div>
          </>
        );

      case "API Access Terms":
        return (
          <>
            <h2 className="text-2xl font-bold text-gray-800 mb-8">
              API Access Terms - {selectedCountry}
            </h2>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">1.</span>
                <span>API License and Usage</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  PropertyFinder {selectedCountry} grants you a limited,
                  non-exclusive, non-transferable license to access and use our
                  API services subject to these terms. API access is provided
                  for legitimate business purposes within{" "}
                  {countryInfo.jurisdiction} only.
                </p>
                <p>
                  You must obtain proper authentication credentials and comply
                  with rate limiting and usage quotas as specified in your API
                  agreement. All data requests must comply with{" "}
                  {countryInfo.jurisdiction} data protection laws.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">2.</span>
                <span>Data Usage and Restrictions</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  API data must be used in accordance with our data usage
                  policies and {countryInfo.jurisdiction} regulations. You may
                  not redistribute, resell, or sublicense API data without
                  explicit written permission from {countryInfo.entity}.
                </p>
                <p>
                  All API requests must include proper attribution to
                  PropertyFinder and comply with applicable data protection
                  regulations in {countryInfo.jurisdiction}. Currency values are
                  provided in {countryInfo.currency}.
                </p>
              </div>
            </div>
          </>
        );

      case "PF Expert Terms":
        return (
          <>
            <h2 className="text-2xl font-bold text-gray-800 mb-8">
              PropertyFinder Expert Terms - {selectedCountry}
            </h2>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">1.</span>
                <span>Expert Membership Requirements</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  PropertyFinder Experts in {countryInfo.jurisdiction} must be
                  licensed real estate professionals with valid credentials from{" "}
                  {countryInfo.regulations}. All experts undergo a comprehensive
                  verification process before approval.
                </p>
                <p>
                  Experts must maintain professional standards as required by{" "}
                  {countryInfo.jurisdiction} law, respond promptly to inquiries,
                  and provide accurate property information to maintain their
                  expert status on our platform.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">2.</span>
                <span>Commission and Payment Terms</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  Commission structures and payment terms are outlined in your
                  individual Expert Agreement and are processed in{" "}
                  {countryInfo.currency}. Payments are processed according to
                  the schedule specified in your contract and local banking
                  regulations.
                </p>
                <p>
                  Experts are responsible for their own tax obligations in{" "}
                  {countryInfo.jurisdiction} and must comply with local
                  regulations regarding real estate transactions and commission
                  payments as governed by {countryInfo.regulations}.
                </p>
              </div>
            </div>
          </>
        );

      case "Mobile App Terms":
        return (
          <>
            <h2 className="text-2xl font-bold text-gray-800 mb-8">
              Mobile Application Terms - {selectedCountry}
            </h2>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">1.</span>
                <span>App License and Installation</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  The PropertyFinder {selectedCountry} mobile application is
                  licensed, not sold, to you. You may install and use the app on
                  devices you own or control within {countryInfo.jurisdiction},
                  subject to these terms and applicable app store terms.
                </p>
                <p>
                  The app requires certain permissions to function properly,
                  including location services for nearby property searches in{" "}
                  {selectedCountry} and camera access for photo uploads. All
                  data is processed in compliance with{" "}
                  {countryInfo.jurisdiction} privacy laws.
                </p>
              </div>
            </div>

            <div className="mb-8">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-start">
                <span className="mr-3 text-[#0b154f]">2.</span>
                <span>Mobile-Specific Features</span>
              </h3>
              <div className="ml-6 space-y-4 text-gray-700 leading-relaxed">
                <p>
                  Our mobile app includes features such as push notifications,
                  offline browsing, and location-based search within{" "}
                  {countryInfo.jurisdiction}. You can manage notification
                  preferences through your device settings. All property prices
                  are displayed in {countryInfo.currency}.
                </p>
                <p>
                  Data usage charges may apply when using the mobile app in{" "}
                  {selectedCountry}. We recommend using Wi-Fi when possible to
                  avoid excessive data charges from your mobile carrier. Some
                  features may be limited based on local regulations.
                </p>
              </div>
            </div>
          </>
        );

      default:
        return null;
    }
  };

  const getCountryCode = (country) => {
    const countryCodes = {
      UAE: "AE",
      KSA: "SA",
      Qatar: "QA",
      Bahrain: "BH",
      Egypt: "EG",
    };
    return countryCodes[country] || "AE";
  };

  return (
    <>
      <Header />

      <div className="min-h-screen bg-gray-50">
        {/* Main Content Container */}
        <div className="max-w-8xl mx-auto px-6 md:px-14 py-12">
          {/* Page Header */}
          <div className="flex justify-between items-center mb-8">
            <h1 className="text-xl md:text-4xl font-bold text-[#0b154f]">
              Terms and Conditions
            </h1>

            {/* Country Selector */}
            <div className="relative">
              <button
                className="flex items-center space-x-2 bg-white border border-gray-300 rounded-md px-4 py-2 hover:bg-gray-50 transition-colors shadow-sm"
                onClick={() => setShowCountryDropdown(!showCountryDropdown)}
              >
                <ReactCountryFlag
                  countryCode={getCountryCode(selectedCountry)}
                  svg
                  style={{
                    width: "1.5rem",
                    height: "1rem",
                  }}
                />
                <span className="font-medium text-gray-700">
                  {selectedCountry}
                </span>
                <svg
                  className={`w-4 h-4 text-gray-500 transition-transform ${
                    showCountryDropdown ? "rotate-180" : ""
                  }`}
                  fill="none"
                  stroke="currentColor"
                  viewBox="0 0 24 24"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth={2}
                    d="M19 9l-7 7-7-7"
                  />
                </svg>
              </button>

              {/* Dropdown Menu */}
              {showCountryDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-gray-200 rounded-md shadow-lg z-10">
                  {countries.map((country) => (
                    <button
                      key={country}
                      onClick={() => {
                        setSelectedCountry(country);
                        setShowCountryDropdown(false);
                      }}
                      className={`w-full flex items-center space-x-3 px-4 py-2 text-left hover:bg-gray-50 transition-colors ${
                        selectedCountry === country
                          ? "bg-blue-50 text-blue-700"
                          : "text-gray-700"
                      }`}
                    >
                      <ReactCountryFlag
                        countryCode={getCountryCode(country)}
                        svg
                        style={{
                          width: "1.5rem",
                          height: "1rem",
                        }}
                      />
                      <span className="font-medium">{country}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* Country Info Banner */}
          <div className="bg-blue-50 border-l-4 border-blue-400 p-4 mb-8 rounded-r-md">
            <p className="text-blue-800">
              <strong>Current Region:</strong>{" "}
              {getCountrySpecificInfo(selectedCountry).jurisdiction} |
              <strong> Currency:</strong>{" "}
              {getCountrySpecificInfo(selectedCountry).currency} |
              <strong> Entity:</strong>{" "}
              {getCountrySpecificInfo(selectedCountry).entity}
            </p>
          </div>

          {/* Navigation Tabs */}
          <div className="border-b border-gray-200 mb-8">
            <nav className="flex space-x-8 overflow-x-auto">
              {tabs.map((tab) => (
                <button
                  key={tab}
                  onClick={() => setSelectedTab(tab)}
                  className={`py-4 px-1 border-b-2 font-medium text-sm whitespace-nowrap transition-colors ${
                    selectedTab === tab
                      ? "border-[#0b154f] text-[#0b154f]"
                      : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  }`}
                >
                  {tab}
                </button>
              ))}
            </nav>
          </div>

          {/* Terms Content */}
          <div className="bg-white rounded-lg shadow-sm p-8">
            {getTabContent()}

            <div className="mt-12 pt-8 border-t border-gray-200">
              <p className="text-sm text-gray-500 text-center">
                Last updated: September 13, 2025 | Applicable for{" "}
                {getCountrySpecificInfo(selectedCountry).jurisdiction}
              </p>
            </div>
          </div>
        </div>

        {/* Click outside handler */}
        {showCountryDropdown && (
          <div
            className="fixed inset-0 z-5"
            onClick={() => setShowCountryDropdown(false)}
          />
        )}
      </div>
      <PropertyFinderFooter />
    </>
  );
};

export default TermsAndConditions;
