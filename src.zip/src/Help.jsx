import React, { useState } from "react";
import Header from "./Components/Header";
import Footer from "./Components/Footer";
import searchbg from "./assets/searchbg.png";
import { CiSearch } from "react-icons/ci";
import {
  User,
  FileQuestion,
  Package,
  Shield,
  Bug,
  Home,
  ChevronDown,
} from "lucide-react";

const Help = () => {
  const [openIndex, setOpenIndex] = useState(null);

  const topics = [
    {
      icon: <User className="w-6 h-6 text-gray-700" />,
      title: "User Profile",
      links: [
        "New Registration & Login",
        "Account Deactivation/Re-activation",
        "My Profile",
        "Password Settings",
        "Update Email Address",
      ],
    },
    {
      icon: <Home className="w-6 h-6 text-gray-700" />,
      title: "Property Management",
      links: [
        "Free Property Listing",
        "Posting Property",
        "Edit/Update Property Details",
        "Locality Update",
        "Upload/Edit Photos",
      ],
    },
    {
      icon: <Shield className="w-6 h-6 text-gray-700" />,
      title: "Response Management",
      links: [
        "View Responses on Property Posted",
        "Download Responses on Property Posted",
        "Protection from online frauds",
      ],
    },
    {
      icon: <Package className="w-6 h-6 text-gray-700" />,
      title: "Orders & Services",
      links: [
        "Planning to Buy Ad Packages",
        "Package Queries",
        "Package Activation",
        "My Package Details",
        "Package Services",
      ],
    },
    {
      icon: <FileQuestion className="w-6 h-6 text-gray-700" />,
      title: "MB Features",
      links: ["What is Propworth?", "All About Property Auctions"],
    },
    {
      icon: <Bug className="w-6 h-6 text-gray-700" />,
      title: "Bug Bounty",
      links: ["Submit Bug Report"],
    },
  ];

  const faqs = [
    {
      question: "How do I Deactivate my account?",
      answer:
        "To deactivate your account, go to settings → My Profile → Deactivate Account.",
    },
    {
      question: "How can I know the status or validity of my package?",
      answer:
        "You can check your package details under My Orders → Package Details.",
    },
    {
      question: "When will my Property become visible on the site?",
      answer: "It usually takes a few hours after verification by our team.",
    },
    {
      question: "What all can I do with the Propmates package I have?",
      answer:
        "You can post properties, boost ads, get premium visibility and more.",
    },
    {
      question: "How to Renew or Refresh my Property?",
      answer:
        "Open your property listing and click the Refresh button to renew visibility.",
    },
    {
      question: "Why is my package still not activated?",
      answer:
        "It may be due to payment verification delay or incorrect information.",
    },
  ];

  return (
    <div>
      <Header />

      {/* Hero Section with Search Form */}
      <div className="relative">
        {/* Background Image */}
        <div className="w-full h-[200px] text-white relative overflow-hidden">
          <img src={searchbg} className="w-full h-full object-cover" alt="" />

          {/* Dark overlay for readability */}
          <div className="absolute inset-0 bg-black/30"></div>

          {/* Text + Search Box */}
          <div className="absolute inset-0 flex flex-col items-center justify-center px-4">
            <h2 className="text-xl sm:text-2xl font-semibold text-white mb-4 text-center">
              Have Questions?{" "}
              <span className="font-normal">We've All the Answers</span>
            </h2>

            {/* Search Input Box */}
            <div className="flex bg-white rounded-md shadow-md w-full max-w-xl overflow-hidden">
              <input
                type="text"
                placeholder="Type your question here..."
                className="flex-1 px-4 py-2 text-black outline-none"
              />
              <button className="bg-[#0b154f] px-4 flex items-center justify-center">
                <CiSearch className="text-white h-6 w-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="w-full px-6 lg:px-16 py-10 flex flex-col lg:flex-row gap-10">
        {/* LEFT SECTION */}
        <div className="w-full lg:w-2/3 grid grid-cols-1 sm:grid-cols-2 gap-8">
          {topics.map((t, index) => (
            <div key={index} className="space-y-2">
              <div className="flex items-center gap-2">
                {t.icon}
                <h3 className="font-semibold text-gray-800">{t.title}</h3>
              </div>

              <ul className="ml-8 list-disc text-sm text-gray-700 space-y-1">
                {t.links.map((l, i) => (
                  <li key={i}>
                    <a href="#" className="hover:text-[#0b154f]">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* RIGHT SECTION: FAQ */}
        <div className="w-full lg:w-1/3">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            Frequently Asked Questions
          </h3>

          <div className="space-y-3">
            {faqs.map((q, i) => {
              const isOpen = openIndex === i;

              return (
                <div key={i} className="bg-gray-100 rounded-md shadow-sm">
                  <button
                    onClick={() => setOpenIndex(isOpen ? null : i)}
                    className="w-full px-4 py-3 flex items-center justify-between hover:bg-gray-200 transition"
                  >
                    <span className="text-sm text-gray-800 text-left">
                      {q.question}
                    </span>

                    <ChevronDown
                      className={`w-5 h-5 text-gray-600 transition-transform duration-300 ${
                        isOpen ? "rotate-180" : ""
                      }`}
                    />
                  </button>

                  {/* Animated Answer */}
                  <div
                    className={`overflow-hidden transition-all duration-300 ${
                      isOpen ? "max-h-40 px-4 pb-3" : "max-h-0"
                    }`}
                  >
                    <p className="text-sm text-gray-600">{q.answer}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default Help;
